"""ark-team-agent: Python multi-agent team manager for Kiro CLI."""
__version__ = "1.4.9"
