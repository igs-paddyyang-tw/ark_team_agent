"""Daemon HTTP API — FastAPI-based endpoints for team MCP communication and dashboard."""
from __future__ import annotations

import asyncio
import collections
import json
import logging
import os
from pathlib import Path
from typing import Any

# 🔴 [1.4.7] `Request` 一定要在這裡 import。
# `POST /api/v1/dispatch`（e611315 加入）宣告 `request: Request`，但當時沒 import 它 ——
# 而本檔有 `from __future__ import annotations`，所以註解是**字串**、不會在定義時求值：
#   → 沒有 NameError、沒有 ImportError
#   → FastAPI 解析不出型別，把它當成**名為 request 的 query 參數**
#   → 每一次呼叫都回 422 `{"loc":["query","request"],"msg":"Field required"}`
#   → 連 `app.openapi()` 也炸（`ForwardRef('Request')` 無法建 TypeAdapter）
# 也就是**整條 dispatch API 從加進來就沒有一次成功過**，而唯一的症狀是 422。
from fastapi import Body, FastAPI, HTTPException, Request, Response, WebSocket, WebSocketDisconnect
from pydantic import BaseModel
import uvicorn

from . import __version__
from .session_key import SessionKey

log = logging.getLogger(__name__)


# ── Web Reply Queue ───────────────────────────────────────────────
# session_id → deque of reply texts
# 當 source 以 "web:" 開頭時，reply 存入此佇列而非送 Telegram
_web_reply_queues: dict[str, collections.deque] = {}
_WEB_REPLY_MAX = 20  # 每個 session 最多保留 20 則回覆


def _web_queue(session_id: str) -> collections.deque:
    """取得或建立 session 的 web reply 佇列。"""
    if session_id not in _web_reply_queues:
        _web_reply_queues[session_id] = collections.deque(maxlen=_WEB_REPLY_MAX)
    return _web_reply_queues[session_id]


def _cleanup_web_queue(session_id: str) -> None:
    """清除 session 的 web reply 佇列。"""
    _web_reply_queues.pop(session_id, None)


# ── Request / Response models ─────────────────────────────────────


class SendRequest(BaseModel):
    instance: str
    message: str
    source: str = ""
    ttl_minutes: int = 0  # [1.5.0] 訊息存活時間（分鐘），0 = 不過期


class ReplyRequest(BaseModel):
    instance: str
    text: str
    kind: str = "primary"  # "primary" | "followup"
    style: str = "chat"  # "chat" | "report"
    template: str = ""  # [1.2.0 N4] 具名 TG 模板（news-daily/ops-report…）；空=default


class LogRequest(BaseModel):
    instance: str
    source: str = ""
    text: str


class SpendRequest(BaseModel):
    instance: str
    amount_usd: float
    note: str = ""  # optional free-form note for audit


# ── Reply HTML formatting ─────────────────────────────────────────

import html as _html_mod
import re as _re_mod


def _html_escape(text: str) -> str:
    """Escape text for Telegram HTML."""
    return _html_mod.escape(text)


# [1.3.2] Telegram HTML 白名單 —— style="report" 專用。
# TG 只認這些標籤，其餘 <...> 一律被當成未知標籤而**整則 400 拒收**。
# 來源：Bot API "HTML style" 章節。span 只在 class="tg-spoiler" 時合法，但這裡
# 一併放行 —— 我們的職責是「不要讓非標籤文字被誤判」，不是替 TG 做完整驗證。
_TG_ALLOWED_TAGS: frozenset[str] = frozenset({
    "b", "strong", "i", "em", "u", "ins", "s", "strike", "del",
    "span", "tg-spoiler", "a", "code", "pre", "blockquote", "tg-emoji",
})

# 只匹配「長得像標籤」的片段；tag 名允許連字號（tg-spoiler / tg-emoji）
_TAG_CANDIDATE = _re_mod.compile(r"<(/?)([A-Za-z][A-Za-z0-9-]*)((?:\s[^<>]*)?)/?>")
# 合法 HTML entity（&amp; &lt; &#39; &#x27;）—— 用來判斷哪些 & 是裸的
_HTML_ENTITY = _re_mod.compile(r"&(?:[A-Za-z][A-Za-z0-9]{1,31}|#[0-9]{1,7}|#[xX][0-9A-Fa-f]{1,6});")


def _sanitize_tg_html(text: str) -> str:
    """把非標籤的 `<`、`>`、裸 `&` 跳脫，只保留 TG 支援的標籤原樣。

    **為什麼需要這個**：`style="report"` 原本是 raw passthrough（agent 自控 HTML），
    於是 agent 回覆裡任何 `<260>`、`<=5%`、`a<b` 都會被 TG 當成未知標籤 →
    整則 400 Bad Request。而下游 fallback 是 `_strip_html()`，它用
    `re.sub(r"<[^>]+>", "")` **把那段直接刪掉** —— 訊息會送達，但
    `<260>` 這個數值**從報告裡無聲消失**。比報錯更難發現。

    escape-first 不能用（那會連 agent 刻意寫的 `<b>` 一起殺掉，
    這正是 2026-08-10 為何改用 `style="report"` 繞過 escape 的原因）。
    所以改成白名單：**標籤留、其他跳脫**，兩個需求同時成立。

    **順帶保證結構平衡**（TG 對不平衡標籤也是 400）：跳脫掉某個開標籤時，
    它的 closer 也一併跳脫（否則變成落單的 `</a>`）；無主 closer 跳脫；
    收尾補關未關閉的標籤。所以輸出永遠是合法嵌套。

    永不拋例外 —— 失敗退回全體跳脫（保底可送，只是失去格式）。

    Author: ark-agent（1.3.2）
    """
    try:
        out: list[str] = []
        pos = 0
        stack: list[str] = []              # 已保留、尚未關閉的標籤
        dropped: dict[str, int] = {}       # 被跳脫掉的開標籤（其 closer 也要跳脫）
        for m in _TAG_CANDIDATE.finditer(text):
            out.append(_escape_text_segment(text[pos:m.start()]))
            pos = m.end()
            raw, closing, name = m.group(0), bool(m.group(1)), m.group(2).lower()

            if closing:
                # 對應的開標籤被跳脫過 → 這個 closer 也要跳脫，否則落單
                if dropped.get(name):
                    dropped[name] -= 1
                    out.append(_escape_text_segment(raw))
                elif name in stack:
                    # 關掉它，並把它之後才開、卻沒關的標籤補關（保持嵌套合法）
                    while stack and stack[-1] != name:
                        out.append(f"</{stack.pop()}>")
                    stack.pop()
                    out.append(raw)
                else:
                    out.append(_escape_text_segment(raw))   # 無主 closer
                continue

            if _is_allowed_tag(name, m.group(3)):
                stack.append(name)
                out.append(raw)
            else:
                dropped[name] = dropped.get(name, 0) + 1
                out.append(_escape_text_segment(raw))

        out.append(_escape_text_segment(text[pos:]))
        while stack:                        # 補關尚未關閉的標籤
            out.append(f"</{stack.pop()}>")
        return "".join(out)
    except Exception:  # noqa: BLE001 — NFR-3：永不因格式化失敗而丟訊息
        return _html_escape(text)


# 各標籤允許的屬性樣式。**沒列在這裡的屬性一律當成非標籤文字**——
# 因為 `if x <b then y> 0` 這種句子會讓 tag 名比對通過（`b` 是合法標籤），
# 只驗名字就會把「then y」當屬性吃掉。驗屬性才擋得住。
_TAG_ATTRS: dict[str, "_re_mod.Pattern[str]"] = {
    "a":        _re_mod.compile(r"""^\s+href\s*=\s*("[^"]*"|'[^']*')\s*$"""),
    "code":     _re_mod.compile(r"""^\s+class\s*=\s*("[^"]*"|'[^']*')\s*$"""),
    "span":     _re_mod.compile(r"""^\s+class\s*=\s*("[^"]*"|'[^']*')\s*$"""),
    "blockquote": _re_mod.compile(r"""^\s+expandable\s*$"""),
    "tg-emoji": _re_mod.compile(r"""^\s+emoji-id\s*=\s*("[^"]*"|'[^']*')\s*$"""),
}


def _is_allowed_tag(name: str, attrs: str) -> bool:
    """標籤名在白名單內，且屬性符合該標籤允許的樣式（無屬性一律可）。"""
    name = name.lower()
    if name not in _TG_ALLOWED_TAGS:
        return False
    if not attrs.strip():
        return True
    pat = _TAG_ATTRS.get(name)
    return bool(pat and pat.match(attrs))


def _escape_text_segment(seg: str) -> str:
    """跳脫非標籤片段：`<` `>` 全跳脫，`&` 只跳脫**裸的**（保留既有 entity）。"""
    if not seg:
        return seg
    # 先保護合法 entity，避免把 &amp; 變成 &amp;amp;
    holes: list[str] = []

    def _stash(m: "_re_mod.Match") -> str:
        holes.append(m.group(0))
        return f"\x00E{len(holes) - 1}\x00"

    seg = _HTML_ENTITY.sub(_stash, seg)
    seg = seg.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    for i, h in enumerate(holes):
        seg = seg.replace(f"\x00E{i}\x00", h)
    return seg


def _md_to_html(text: str) -> str:
    """[v1.1.5 FR-2] 將任意 LLM 輸出正規化為「合法且平衡」的 Telegram HTML。

    策略：先抽出 code、再全體 html-escape（中和任何 raw `< > &`，避免 TG 整則拒收），
    最後只插入成對的 <b>/<code>/<pre>/<a> 標籤 → 輸出天然平衡。
    永不拋例外：任何失敗退回純跳脫文字（保底可送）。

    Author: ark-agent
    """
    import re
    try:
        blocks: list[str] = []
        inlines: list[str] = []

        def _stash_block(m: "re.Match") -> str:
            blocks.append(m.group(1))
            return f"\x00B{len(blocks) - 1}\x00"

        def _stash_inline(m: "re.Match") -> str:
            inlines.append(m.group(1))
            return f"\x00C{len(inlines) - 1}\x00"

        # 1) 保護 fenced code ```...``` 與 inline `code`
        t = re.sub(r"```[A-Za-z0-9_+-]*\n?(.*?)```", _stash_block, text, flags=re.DOTALL)
        t = re.sub(r"`([^`\n]+)`", _stash_inline, t)
        # 2) 全體跳脫
        t = _html_escape(t)
        # 3) 在已跳脫文字上插入平衡標籤
        t = re.sub(r"^\s{0,3}#{1,6}\s+(.+)$", r"<b>\1</b>", t, flags=re.MULTILINE)  # 標題→粗體
        t = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", t)                                # **粗體**
        t = re.sub(r"__(.+?)__", r"<b>\1</b>", t)                                    # __粗體__
        t = re.sub(r"^\s*[-*]\s+", "• ", t, flags=re.MULTILINE)                      # 清單→bullet
        # [1.1.10] 刪除線 / 斜體 / 引用（沿用 escape-first：於已跳脫文字插入成對 tag）
        t = re.sub(r"~~(.+?)~~", r"<s>\1</s>", t)                                    # ~~刪除~~
        # *斜體*：排除 ** 殘留、避免 "3 * 4" 數學（前後不接空白）
        t = re.sub(r"(?<!\*)\*(?!\s)([^*\n]+?)(?<!\s)\*(?!\*)", r"<i>\1</i>", t)
        # _斜體_：前後非單字字元，避開 snake_case（my_var）與已處理的 __粗__
        t = re.sub(r"(?<!\w)_(?!\s)([^_\n]+?)(?<!\s)_(?!\w)", r"<i>\1</i>", t)
        # > 引用（text 已跳脫，故比對 &gt;）；逐行成對 <blockquote>
        t = re.sub(r"^\s*&gt;\s?(.+)$", r"<blockquote>\1</blockquote>", t, flags=re.MULTILINE)
        t = re.sub(r"\[([^\]\n]+)\]\((https?://[^)\s]+)\)", r'<a href="\2">\1</a>', t)  # 連結
        # 4) 還原 code（內容跳脫）
        for i, c in enumerate(inlines):
            t = t.replace(f"\x00C{i}\x00", f"<code>{_html_escape(c)}</code>")
        for i, b in enumerate(blocks):
            t = t.replace(f"\x00B{i}\x00", f"<pre>{_html_escape(b)}</pre>")
        return t
    except Exception:  # noqa: BLE001 — NFR-3：永不因格式化失敗而丟訊息
        return _html_escape(text)


# [1.2.0 N4] 具名 TG 回覆模板：name → (emoji, 標籤)。body 一律走 _md_to_html（escape-first）。
# default / 未知名 → 沿用現行 chat 格式（保底）。
_TG_TEMPLATES: dict[str, tuple[str, str]] = {
    "news-daily":    ("📰", "科技日報"),
    "status-report": ("📊", "狀態回報"),
    "ops-report":    ("🛠️", "維運日報"),
    "task-dispatch": ("📋", "任務派工"),
    "error-alert":   ("⚠️", "錯誤通報"),
}


def _format_reply_html(instance: str, text: str, tg, style: str = "chat", template: str = "") -> str:
    """Format agent reply as Telegram HTML with header line.

    [v1.1.5 FR-2] 全程保底：任何格式化失敗都退回純跳脫文字，確保訊息仍可送。
    [1.2.0 N4] template：具名模板（news-daily/ops-report…）；default/未知 → 現行 chat 格式。
    """
    if style == "report":
        # Report mode: agent 自控 HTML、無 header —— 但 [1.3.2] 起會過白名單，
        # 把非標籤的 < > & 跳脫。原本是 raw passthrough，導致回覆裡的 `<260>`
        # 讓 TG 整則 400，而 fallback 的 _strip_html() 會把那段**直接刪掉**。
        return _sanitize_tg_html(text)
    try:
        # Chat mode: short codename header (emoji + role name only)
        if tg and hasattr(tg, "_CODENAMES"):
            codename = tg._CODENAMES.get(instance, f"🤖 {instance.replace('-agent', '')}")
        else:
            codename = instance.replace("-agent", "")

        # [1.2.0 N4] 具名模板優先（body 走 _md_to_html 保持 escape-first）
        _tpl = _TG_TEMPLATES.get(template)
        if _tpl:
            _emoji, _label = _tpl
            return (f"{_emoji} <b>{_html_escape(codename)}｜{_label}</b>\n"
                    f"━━━━━━━━━━━━━━━\n{_md_to_html(text)}")

        # 自動結構化：第一行 ≤ 30 字 → 視為標題加粗
        lines = text.strip().split("\n", 1)
        first_line = lines[0].strip()
        rest = lines[1] if len(lines) > 1 else ""

        if len(first_line) <= 30 and first_line:
            body = f"<b>{_html_escape(first_line)}</b>"
            if rest:
                body += f"\n{_md_to_html(rest)}"
        else:
            body = _md_to_html(text)

        return f"<b>{_html_escape(codename)}</b>\n━━━━━━━━━━━━━━━\n{body}"
    except Exception:  # noqa: BLE001 — NFR-3
        return _html_escape(text)


# ── DaemonAPI ─────────────────────────────────────────────────────


class DaemonAPI:
    """FastAPI-based Daemon API on 127.0.0.1 for team-mcp and dashboard."""

    def __init__(
        self,
        daemon,
        telegram_adapter=None,
        topic_map: dict[str, int] | None = None,
        private_chat_map: dict[str, int] | None = None,
        team_manager=None,
    ) -> None:
        self.daemon = daemon
        self.tg = telegram_adapter
        self.team_manager = team_manager
        self._topic_map = topic_map or {}  # instance_name → topic_id
        self._private_chat_map = private_chat_map or {}  # instance_name → chat_id
        self._server_task: asyncio.Task | None = None
        self._uvicorn_server: uvicorn.Server | None = None
        # P2P round tracking: {(agent_a, agent_b): count}
        self._p2p_rounds: dict[tuple[str, str], int] = {}
        # Web Chat source map: instance_name → session_id
        # 當 /api/send 的 source 以 "web:" 開頭時，記錄此 instance 的回覆要送到哪個 web session
        self._web_source_map: dict[str, str] = {}
        # [1.4.8] dispatch 等待註冊表：instance → FIFO of Future[str]
        #
        # `POST /api/v1/dispatch` 是 headless 外部整合入口（`ark_bot_agent.TeamClient`
        # 等），呼叫端要的是「送進去 + 拿到那次的回覆」。而回覆是 agent 透過
        # `reply()` → `POST /api/reply` 非同步送回來的，跟請求不在同一條路徑上。
        #
        # 這裡**刻意沿用 Web Chat 已驗證過的形狀**（`_web_source_map` + reply 佇列）：
        # 送出前先登記等待者，`/api/reply` 命中登記就把 text 交給 Future 並提早返回。
        # 不自己在 daemon 另開一套狀態機 —— 同一件事兩套實作必然漂移。
        #
        # FIFO 而非單一 Future：同一個 instance 可能同時有多個 dispatch 在等，
        # 用單值會讓後到的把前一個踢掉（前一個變成永不完成的 await）。
        self._dispatch_waiters: dict[str, collections.deque] = {}
        # Reply channel tracking: instance → "topic" | "private"
        # 記錄每個 instance 最後一次收到使用者訊息的來源
        # - 私聊自然對話 → "private"
        # - 私聊 @mention 其他 agent → "topic"（回覆到 topic）
        # - 群組 topic 直接發 → "topic"
        self._reply_channel: dict[str, str] = {}
        # [1.4.0] instance → 「使用者發問所在的 topic」。
        #
        # 為什麼需要它：原本回覆的目的地是**agent 的歸屬**
        # （`_resolve_output_topic`：自己的 topic，或 worker 所屬 leader 的 topic），
        # 而不是**對話發生的地方**。使用者在 General 跟入口 agent 講話、入口再
        # 派工出去，回覆就跑到被派工者的 topic —— 使用者留在 General 看不到答案。
        #
        # inbound 的 `message_thread_id` 一直有被讀到（`telegram.py`），
        # 但只用來判斷「誰該處理」，沒有留下來當回覆目的地。
        #
        # 判準：**有沒有人正在那個 topic 等。**
        #   有（使用者發問、以及由該次發問派工出去的下游）→ 回原 topic
        #   沒有（排程、自主輸出）→ 維持歸屬 topic，「歸類」的價值不變
        # 兩者服務的是不同情境，所以不衝突。
        # [1.4.2] 值是 `("topic", topic_id)` 或 `("private", chat_id)` ——
        # 原本只存 topic id，於是「私訊問卻回群組 topic」修不了。
        # 「回到你問的地方」本來就該涵蓋私訊，兩者是同一個概念，
        # 用兩個平行的 dict 去記必然漂移。
        self._origin_topic: dict[str, tuple[str, int]] = {}

        # [team-agent 2026-07-30] Decision loop — lazy-init after _build_app
        self.decision_mgr = None  # type: ignore[assignment]
        self.app = self._build_app()
        self._init_decision_mgr()

    def _origin_routing_on(self) -> bool:
        """[1.4.1] `communication.reply_to_origin` —— 預設 False。

        單一判斷點：`/api/send` 的傳遞與 `/api/reply` 的覆蓋都問這裡。
        兩處各自判斷必然漂移（1.3.3 的 `restart.flag` 就是兩份實作不一致的下場）。
        """
        cfg = getattr(self.daemon, "config", None)
        comm = getattr(cfg, "communication", None) if cfg is not None else None
        return bool(getattr(comm, "reply_to_origin", False))

    # [team-agent 2026-07-30] Decision loop helpers ─────────────────────────
    def _init_decision_mgr(self) -> None:
        """Initialise DecisionManager. Called once after _build_app."""
        try:
            from .decision_manager import DecisionManager
            self.decision_mgr = DecisionManager(daemon_api=self)
            # Also expose to daemon so _global_health_loop can use it
            if hasattr(self.daemon, 'decision_mgr'):
                self.daemon.decision_mgr = self.decision_mgr
            log.info("✅ DecisionManager initialised")
        except Exception as exc:
            log.warning("DecisionManager init failed (non-fatal): %s", exc)
            self.decision_mgr = None

    # [ark-agent 2026-08-06] v1.1.0 Group Topic Routing 輔助方法 ──────────────
    def _resolve_output_topic(self, instance: str) -> tuple[int | None, str | None]:
        """解析 instance 的輸出 topic。

        worker 有 group → 回 (所屬 leader 的 topic_id, leader 名)；
        否則回 (instance 自己的 topic_id, None)，維持 v1.0.5 行為。

        Author: ark-agent
        """
        cfg = self.daemon.config.instances.get(instance) if hasattr(self.daemon, "config") else None
        if cfg and (getattr(cfg, "role", "worker") or "worker") == "worker" and getattr(cfg, "group", None):
            leader = cfg.group
            return self._topic_map.get(leader), leader
        return self._topic_map.get(instance), None

    async def _send_group_marker_to_general(self, instance: str, group_leader: str, err: object) -> None:
        """組 topic 發送失敗時，退回 General topic 並標記來源與目標（FR-3）。

        Author: ark-agent
        """
        if not self.tg:
            return
        codename = self.tg._CODENAMES.get(instance, instance) if hasattr(self.tg, "_CODENAMES") else instance
        general_tid = getattr(self.tg.config, "general_topic_id", 1)
        marker = f"⚠️ [{_html_escape(codename)}→{_html_escape(group_leader)} topic 發送失敗: {_html_escape(str(err))}]"
        try:
            await self.tg._send_to_topic(general_tid, marker, parse_mode="HTML")
        except Exception as exc2:
            log.error("group fallback to General also failed for %s: %s", instance, exc2)

    def _leader_for(self, worker_name: str) -> str | None:
        """回傳 worker 應回報/升級/CC 的對象（唯一正解 helper）。

        解析順序（§7 + v1.1.9 A/D）：
        1. worker 的 group → 所屬 group leader（多組架構下唯一正確）
        2. general_topic 持有者（總機/catch-all 協調者）
        3. 第一個 role==leader（最後退路）

        Author: ark-agent
        """
        insts = self.daemon.config.instances if hasattr(self.daemon, "config") else {}
        cfg = insts.get(worker_name)
        if cfg and getattr(cfg, "group", None):
            return cfg.group
        # fallback 1：general_topic 持有者（總機）
        # [1.2.20] 只找本體成員 —— 衍生 session 不會是總機
        for n, ic in insts.items():
            if SessionKey.is_session(n):
                continue
            if getattr(ic, "general_topic", False):
                return n
        # fallback 2：第一個 leader
        for n, ic in insts.items():
            if ic.role == "leader":
                return n
        return None

    def owner_chat_id(self) -> int | None:
        """私訊通知的目標 chat_id —— **依 role 推導，不寫死 instance 名**。

        [1.2.26] 原本 `notify_paddy` 與 `send_l3_escalation_card` 都寫死
        `_private_chat_map.get("ark-agent")`。那是 nana 的入口名 ——
        **實測 aiops 的入口是 `admin-agent`、director 是 `tech-agent`**，
        兩者一律拿不到值、直接 return，**緊急通知從來沒送出過**，
        而且 log 還印「ark-agent has no private_chat_id configured」
        （對它們來說連這句話都是錯的：它們沒有 ark-agent）。

        本方法沿用套件內既有的正確 pattern（見 `/api/reply` 的 admin fallback）：
        優先 `role == "admin"`，找不到就取任何已綁定 private_chat 的 instance。

        Author: ark-agent（1.2.26）
        """
        for name, cid in self._private_chat_map.items():
            cfg = self.daemon.config.instances.get(name) if hasattr(self.daemon, "config") else None
            if cfg and getattr(cfg, "role", "") == "admin":
                return cid
        # 沒有 admin 綁私訊時，任何已綁定的都比「什麼都不送」好
        return next(iter(self._private_chat_map.values()), None)

    def notify_paddy(self, text: str, buttons: list[str] | None = None) -> None:
        """Send an urgent notification to the owner's private chat (fire-and-forget)."""
        if not self.tg:
            log.warning("notify_paddy: no telegram adapter, dropping message")
            return
        paddy_chat_id: int | None = self.owner_chat_id()
        if not paddy_chat_id:
            log.warning(
                "notify_paddy: 沒有任何 instance 綁定 private_chat → 通知無處可送。"
                " 請在 team.yaml 為入口 instance 設 private_chat。"
            )
            return
        import asyncio as _asyncio

        async def _send() -> None:
            try:
                if buttons:
                    from telegram import InlineKeyboardButton, InlineKeyboardMarkup

                    def _make_btn(b: str) -> InlineKeyboardButton:
                        # If button text already contains ':', treat as callback_data directly
                        # e.g. "hang:restart:ceo-agent" → label = "🔁 重啟 ceo" + real callback
                        if ":" in b:
                            parts = b.split(":")
                            if parts[0] == "hang" and parts[1] == "restart":
                                label = f"🔁 重啟 {parts[2].replace('-agent', '')}"
                            else:
                                label = b
                            return InlineKeyboardButton(label, callback_data=b)
                        return InlineKeyboardButton(b, callback_data=f"paddy_action:{b}")

                    kb = InlineKeyboardMarkup([[_make_btn(b) for b in buttons]])
                    await self.tg._send_to_private(paddy_chat_id, text, reply_markup=kb)
                else:
                    await self.tg._send_to_private(paddy_chat_id, text)
            except Exception as exc:
                log.warning("notify_paddy send error: %s", exc)

        try:
            loop = _asyncio.get_event_loop()
            loop.create_task(_send())
        except RuntimeError:
            log.warning("notify_paddy: no running event loop")

    def unlock_task(self, task_id: str) -> None:
        """Unlock a task blocked by a decision. No-op until aibi TaskStore is integrated."""
        log.info("unlock_task(%s) — no-op (aibi TaskStore not yet integrated)", task_id)

    def _build_app(self) -> FastAPI:
        app = FastAPI(
            title="ark-team-agent Daemon API",
            version=__version__,
            description="Internal API for team MCP communication and dashboard.",
        )

        # ── Dashboard API ─────────────────────────────────────────
        from .dashboard_api import router as dashboard_router, init as dashboard_init
        from .task_board import TaskBoard
        from .config import get_home
        dashboard_init(self.daemon, TaskBoard(get_home() / "tasks"))
        app.include_router(dashboard_router)

        # ── Wiki API ─────────────────────────────────────────────
        from .wiki_api import router as wiki_router, init as wiki_init
        wiki_init(get_home() / "knowledge")
        app.include_router(wiki_router)

        # ── Chat API (Web SSE) ────────────────────────────────────
        from .chat_api import router as chat_router, init as chat_init
        chat_init(self.daemon, self)
        app.include_router(chat_router)

        # ── Docs API ─────────────────────────────────────────────
        from .docs_api import router as docs_router, init as docs_init
        docs_init(get_home() / "docs")
        app.include_router(docs_router)

        # ── CORS (for Next.js dev) ────────────────────────────────
        from fastapi.middleware.cors import CORSMiddleware
        app.add_middleware(
            CORSMiddleware,
            allow_origins=["*"],
            allow_methods=["*"],
            allow_headers=["*"],
        )

        # ── Static Dashboard (Next.js export) ─────────────────────
        # ── POST /api/send ────────────────────────────────────────
        @app.post("/api/send")
        async def send_message(req: SendRequest) -> dict[str, Any]:
            instance = req.instance.strip()
            message = req.message
            source = req.source

            if not instance:
                raise HTTPException(status_code=400, detail="empty instance name")

            # [1.4.0] origin topic 的傳遞與清除 —— 這是「回原處」能解決回報問題的關鍵。
            # 使用者在 General 對入口 agent 發問，入口再 `send_to_instance` 派工給
            # worker：worker 這一側**從來沒收到過使用者訊息**，所以它的
            # `_reply_channel` 是預設值 `topic` → 回自己的 topic。
            # 讓 origin 沿著派工鏈傳遞，下游才知道「有人在 General 等」。
            if not self._origin_routing_on():
                pass                      # [1.4.1] 未啟用 → 完全不碰 origin 狀態
            elif source in ("scheduler", "system"):
                # 自主工作，沒有人在等 → 清掉可能殘留的 origin，回歸屬 topic
                self._origin_topic.pop(instance, None)
                if self._reply_channel.get(instance) == "origin":
                    self._reply_channel[instance] = "topic"
            elif source and source in self._origin_topic:
                self._origin_topic[instance] = self._origin_topic[source]
                self._reply_channel[instance] = "origin"

            # Permission check: role-based source restriction
            if source and hasattr(self.daemon, "config"):
                src_cfg = self.daemon.config.instances.get(source)
                if src_cfg:
                    role = src_cfg.role or "worker"
                    tgt_cfg = self.daemon.config.instances.get(instance)
                    tgt_role = (tgt_cfg.role or "worker") if tgt_cfg else "worker"

                    if role == "admin":
                        pass  # admin 可以發給任何人
                    elif role == "manager":
                        if tgt_role not in ("admin", "manager", "leader"):
                            raise HTTPException(status_code=403, detail=f"{source} (manager) can only send to admin, manager or leader")
                    elif role == "worker":
                        if tgt_role == "leader":
                            pass  # worker → leader 永遠允許
                        elif tgt_role == "worker":
                            # P2P: 檢查設定
                            p2p = self.daemon.config.communication.p2p
                            if not p2p.enabled or p2p.emergency_mode:
                                # [1.1.9 C] 403 附替代路徑，避免 agent 自行發明繞道
                                _ldr = self._leader_for(source) or "你的 leader"
                                raise HTTPException(
                                    status_code=403,
                                    detail=(f"P2P 已停用。請改用 send_to_instance 發給 {_ldr}，"
                                            f"由其代為協調 {instance}。"),
                                )
                            # Round limit: 同一對 agent 最多 max_rounds 輪
                            pair_key = tuple(sorted([source, instance]))
                            rounds = self._p2p_rounds.get(pair_key, 0) + 1
                            if rounds > p2p.max_rounds:
                                # [ark-agent 2026-08-07] v1.1.6：超輪升級 → 發 General topic（唯一、協調者都看得到）
                                # 不再發給某個 leader（多 leader 團隊無唯一 leader，會歧義/噪音）
                                escalate_msg = (
                                    f"[P2P 升級] {source} 和 {instance} 已對話 {rounds-1} 輪（上限 {p2p.max_rounds}）。"
                                    f"\n議題：{message[:80]}\n請協調。"
                                )
                                if self.tg:
                                    try:
                                        _gt = getattr(self.tg.config, "general_topic_id", 1)
                                        await self.tg._send_to_topic(_gt, escalate_msg)
                                    except Exception as _e:  # noqa: BLE001
                                        log.warning("P2P escalation to General failed: %s", _e)
                                raise HTTPException(
                                    status_code=403,
                                    detail=f"P2P round limit ({p2p.max_rounds}) exceeded between {source} and {instance}. Escalated to General.",
                                )
                            self._p2p_rounds[pair_key] = rounds
                            # [ark-agent 2026-08-07] v1.1.6：CC 預設關；開啟時也發 General（不挑 leader）
                            if p2p.cc_leader and self.tg:
                                cc_msg = f"[P2P {rounds}/{p2p.max_rounds}] {source} → {instance}: {message[:100]}"
                                try:
                                    _gt = getattr(self.tg.config, "general_topic_id", 1)
                                    await self.tg._send_to_topic(_gt, cc_msg)
                                except Exception as _e:  # noqa: BLE001
                                    log.warning("P2P CC to General failed: %s", _e)
                        else:
                            # [1.4.6] 這行原本重複了兩次，第二行是永遠不會執行的死碼。
                            # 無害，但它是「這段被複製貼上過」的訊號 —— 而複製貼上正是
                            # 兩份實作漂移的起點。
                            _ldr = self._leader_for(source) or "你的 leader"
                            raise HTTPException(
                                status_code=403,
                                detail=(f"{source}（worker）不能直接發給 {tgt_role} —— "
                                        f"請改用 send_to_instance 發給 {_ldr}（你的 leader）由其轉呈，"
                                        f"或用 log_to_leader 私下回報。"),
                            )

            # [team-agent 2026-07-30] Decision loop — intercept decision-manager channel
            if instance == "decision-manager":
                if self.decision_mgr is not None:
                    feedback = self.decision_mgr.handle_request_message(message, sender=source or "unknown")
                    # Send feedback back to the requester
                    if source and source != "user":
                        asyncio.create_task(self.daemon.send_message(source, feedback))
                    return {"ok": True, "channel": "decision-manager"}
                else:
                    log.warning("send_message: decision-manager not ready, dropping")
                    return {"ok": False, "error": "decision-manager not initialised"}

            # 跨團隊轉發：ga:agent-name → GA Team port（預設 23031，可用 CROSS_TEAM_PORT 覆寫）
            _cross_port = int(os.environ.get("CROSS_TEAM_PORT", "23031"))
            if instance.startswith("ga:"):
                target_name = instance[3:]
                import urllib.request as _ur
                _url = f"http://127.0.0.1:{_cross_port}/api/send"
                _data = json.dumps({"instance": target_name, "message": message, "source": source}).encode()
                try:
                    _req = _ur.Request(_url, data=_data, headers={"Content-Type": "application/json"})
                    with _ur.urlopen(_req, timeout=5) as _resp:
                        _result = json.loads(_resp.read())
                    log.info("🌐 CROSS-TEAM %s → ga:%s「%s」", source, target_name, message[:50])
                    return _result
                except Exception as e:
                    log.warning("🌐 CROSS-TEAM FAIL → ga:%s: %s", target_name, e)
                    return {"ok": False, "error": f"cross-team failed: {e}"}

            # [1.2.0 N1] 派工輸出約束：送往此 instance 的訊息自動包夾 task_prefix/suffix（空=no-op）
            _tcfg = self.daemon.config.instances.get(instance) if hasattr(self.daemon, "config") else None
            if _tcfg:
                _pre = getattr(_tcfg, "task_prefix", "")
                _suf = getattr(_tcfg, "task_suffix", "")
                _pre = _pre if isinstance(_pre, str) else ""
                _suf = _suf if isinstance(_suf, str) else ""
                if _pre or _suf:
                    message = "\n".join(p for p in (_pre, message, _suf) if p)

            # [1.2.2 N4] 派工脈絡注入：使用者續問（source 非 team instance）送往有最近派工的 instance
            # → 前置一行「你上一步請 X 處理 Y」，讓 orchestrator 承接「繼續/照這方向」。注入一次即消耗。
            _insts = self.daemon.config.instances if hasattr(self.daemon, "config") else {}
            if source not in _insts and hasattr(self.daemon, "_dispatch_context"):
                import time as _t4
                _ctx = self.daemon._dispatch_context(instance, _t4.time())
                if _ctx:
                    message = f"{_ctx}\n{message}"

            # [1.2.16] agent 間訊息：發起方的回覆走 reply() 路由回去，
            # 沒有人在等接收方的「下一輪」→ 回覆後進 IDLE
            ok = await self.daemon.send_message(instance, message, source="peer")
            # [1.5.0] 傳遞 TTL
            if hasattr(req, 'ttl_minutes') and req.ttl_minutes > 0:
                ok = await self.daemon.send_message(instance, message, source="peer", ttl_minutes=req.ttl_minutes)
            else:
                ok = await self.daemon.send_message(instance, message, source="peer")
            # [1.1.13] 記錄 peer 等待：source 為 team instance 時 → 追蹤等 target 回覆（逾時 nudge）。
            # _record_pending_reply 自帶「source/target 皆 instance」守衛，user/web 來源不會被記。
            if ok and source and hasattr(self.daemon, "_record_pending_reply"):
                self.daemon._record_pending_reply(source, instance)
            # [1.2.2 N4] 記錄派工脈絡：source 為 team instance 派給 target → 供其下一輪續問注入。
            if ok and source and hasattr(self.daemon, "_record_dispatch"):
                self.daemon._record_dispatch(source, instance, message)
            # [team-agent 2026-05-15] 統一 log 格式：emoji + source → target + 摘要
            if source and source != "user" and not source.startswith("user:"):
                log.info("📤 SEND %s → %s「%s」", source, instance, message[:50])
            else:
                log.info("📨 USER → %s「%s」", instance, message[:50])

            # [team-agent 2026-05-20] Web Chat 來源：記錄 session_id 到 _web_source_map
            # 格式：web:{session_id[:8]}，reply() 時路由到 web reply queue
            if source.startswith("web:"):
                session_id = source[4:]  # 去掉 "web:" 前綴
                self._web_source_map[instance] = session_id
                log.info("🌐 WEB SOURCE %s → session:%s", instance, session_id)

            return {"ok": ok}

        # ── POST /api/cancel（取消待投遞的訊息）────────────────────
        @app.post("/api/cancel")
        async def cancel_message(request: Request) -> dict[str, Any]:
            """取消尚未投遞的訊息。msg_id 從 send_message 回傳值取得。"""
            body = await request.json()
            msg_id = body.get("msg_id", "").strip()
            if not msg_id:
                raise HTTPException(status_code=400, detail="msg_id is required")
            self.daemon._msg_cancelled.add(msg_id)
            log.info("🚫 訊息已標記取消：%s", msg_id)
            return {"ok": True, "cancelled": msg_id}

        # ── POST /api/reply ───────────────────────────────────────
        @app.post("/api/reply")
        async def send_reply(req: ReplyRequest) -> dict[str, Any]:
            instance = req.instance
            text = req.text

            # Decorate followup messages with a visual marker
            kind = req.kind if req.kind in ("primary", "followup") else "primary"
            if kind == "followup":
                text = f"↪️ {text}"

            log.info("💬 REPLY %s「%s」(%s)", instance, req.text[:50], kind)

            # [team-agent 2026-07-30] Decision loop hook — inspect before routing
            # Returns None (non-decision msg, proceed) or error str (send back to decider)
            # Either way the original message continues down the routing tree (留痕)
            if self.decision_mgr is not None:
                _dm_error = self.decision_mgr.inspect(text, sender=instance)
                if _dm_error:
                    # Retire the error message back to the decider asynchronously
                    asyncio.create_task(
                        self.daemon.send_message(instance, _dm_error)
                    )

            # P1: Mark instance as AWAITING_REPLY (agent replied, waiting for user)
            # [1.2.16] 依 inbound 來源分流 —— AWAITING_REPLY 的語意是「**有人在等我回話**」，
            # 但原本不論來源一律套用：排程跑完、agent 間任務做完也都會進去。後果是
            # hang 偵測被關掉（`daemon.py` 兩處明寫 `!= AWAITING_REPLY`），真掛死的 agent
            # 要等安全網 4-6 小時才會被看見；同時 decision rule 1/4 會誤報。
            # 非互動來源改進 IDLE：不通報、不套決策規則，但 crash 偵測照常。
            from .daemon import InstanceStatus
            state = self.daemon.instances.get(instance)
            if state and state.status == InstanceStatus.RUNNING:
                _src = getattr(state, "last_inbound_source", "user") or "user"
                _interactive = _src == "user" or _src.startswith("web")
                state.status = (InstanceStatus.AWAITING_REPLY if _interactive
                                else InstanceStatus.IDLE)
                log.debug("Instance %s: RUNNING → %s (reply sent, source=%s)",
                          instance, state.status.value, _src)

            # ✅ Stop typing + reaction (before routing — must run regardless of channel)
            if self.tg:
                self.tg._stop_typing(instance)
                asyncio.create_task(self.tg._finish_reaction(instance, success=True))

            # ── [1.4.8] dispatch 路由：有 headless 呼叫端在等這一則 ──
            # 放在 Web Chat 之前：dispatch 的等待者是**同步阻塞在 HTTP 請求上**的，
            # 交不出去就是逾時；web 佇列則可以事後輪詢，優先權較低。
            _dw = self._dispatch_waiters.get(instance)
            if _dw:
                _fut = None
                while _dw:
                    _cand = _dw.popleft()
                    if not _cand.done():          # 已 cancel／已逾時的跳過
                        _fut = _cand
                        break
                if not _dw:
                    self._dispatch_waiters.pop(instance, None)
                if _fut is not None:
                    _fut.set_result(text)
                    log.info("📡 DISPATCH REPLY %s「%s」", instance, text[:50])
                    return {"ok": True, "channel": "dispatch"}
                # 等待者都不在了（全數逾時）→ 不 return，讓這則走正常管道，
                # 否則使用者永遠看不到 agent 其實有回話。

            # ── Web Chat 路由：source 以 "web:" 開頭 ──────────────
            # 從 /api/send 的 source 欄位取得 session_id
            # 格式：web:{session_id[:8]}
            # 存入 web reply queue，由 /api/web-reply/{session_id} 輪詢取回
            web_session_id = self._web_source_map.get(instance)
            if web_session_id:
                queue = _web_queue(web_session_id)
                queue.append({"text": text, "kind": kind})
                log.info("🌐 WEB REPLY %s → session:%s「%s」", instance, web_session_id, text[:50])
                # 清除 source map（一次性，回覆後重置）
                self._web_source_map.pop(instance, None)
                return {"ok": True, "channel": "web"}

            # ── Telegram 路由 ─────────────────────────────────────
            if not self.tg:
                # TG 尚未就緒（啟動中），短暫等待後重試一次
                import asyncio as _aio
                await _aio.sleep(3)
                if not self.tg:
                    log.warning("💬 REPLY %s: no telegram adapter and no web session", instance)
                    return {"ok": False, "error": "no output channel"}

            send_text = _format_reply_html(instance, text, self.tg, style=req.style, template=req.template)
            send_kwargs = {"parse_mode": "HTML"}

            # 根據最後訊息來源決定回覆管道
            # - "private": 回私聊（私聊自然對話，無 @mention）
            # - "topic" 或未設定: 回 topic（私聊 @mention 或群組 topic 直接發）
            reply_channel = self._reply_channel.get(instance, "topic")

            private_chat_id = self._private_chat_map.get(instance)
            # [ark-agent 2026-08-06] v1.1.0：worker 有 group → 解析成所屬 leader 的 topic
            topic_id, group_leader = self._resolve_output_topic(instance)

            # [1.4.0] 有人在等的話，回到他問的地方 —— 覆蓋歸屬路由。
            # `group_leader` 一併清掉：那是「組內歸類」的語意，
            # 但這次是在回答一個具體的人，不該再走組 topic 的 fallback 標記。
            # [1.4.2] origin 現在也可能是私訊（`("private", chat_id)`）。
            if reply_channel == "origin" and self._origin_routing_on():
                _origin = self._origin_topic.get(instance)
                if _origin:
                    _kind, _dest = _origin
                    if _kind == "private":
                        # 私訊問 → 回同一個私訊視窗。用 origin 記下的 chat_id，
                        # **不是** `_private_chat_map[instance]` —— 被派工的 worker
                        # 通常沒有自己的 `private_chat` 設定，靠它會查不到而退回 topic。
                        await self.tg._send_to_private(_dest, send_text, **send_kwargs)
                        return {"ok": True, "channel": "private:origin"}
                    topic_id, group_leader = _dest, None

            if reply_channel == "private" and private_chat_id:
                # 私聊自然對話 → 回私聊
                if hasattr(self.tg, "_processing_messages"):
                    proc_info = self.tg._processing_messages.pop(instance, None)
                    if proc_info:
                        try:
                            chat_id, msg_id = proc_info
                            await self.tg._app.bot.edit_message_text(
                                chat_id=chat_id, message_id=msg_id,
                                text=send_text, **send_kwargs
                            )
                            return {"ok": True}
                        except Exception:
                            pass
                await self.tg._send_to_private(private_chat_id, send_text, **send_kwargs)
                return {"ok": True}

            # [ark-agent 2026-08-06] v1.1.0：group worker 但所屬 leader topic 未就緒 → General 標記（FR-3）
            if group_leader and not topic_id:
                await self._send_group_marker_to_general(instance, group_leader, "leader topic unavailable")
                return {"ok": True}

            if topic_id:
                # @mention 或群組 topic → 回 topic
                edited = False
                if self.tg and hasattr(self.tg, "_output_trackers"):
                    tracker = self.tg._output_trackers.get(instance)
                    if tracker and tracker.message_id:
                        try:
                            await self.tg._app.bot.edit_message_text(
                                chat_id=self.tg.config.group_id,
                                message_id=tracker.message_id,
                                text=send_text, **send_kwargs
                            )
                            tracker.reset()
                            edited = True
                        except Exception:
                            pass
                if not edited:
                    # [ark-agent 2026-08-06] v1.1.0：發到組 topic 失敗 → 退回 General 並標記（FR-3）
                    if group_leader:
                        try:
                            await self.tg._send_to_topic(topic_id, send_text, **send_kwargs)
                        except Exception as exc:
                            log.warning("group topic send failed %s→%s: %s", instance, group_leader, exc)
                            await self._send_group_marker_to_general(instance, group_leader, exc)
                    else:
                        await self.tg._send_to_topic(topic_id, send_text, **send_kwargs)
                return {"ok": True}

            # 沒有 topic 也沒有 private → fallback 到私聊
            if private_chat_id:
                await self.tg._send_to_private(private_chat_id, send_text, **send_kwargs)
                return {"ok": True}

            # Fallback: route to admin's private chat with [codename] prefix
            admin_chat_id = None
            codename = self.tg._CODENAMES.get(instance, instance) if self.tg else instance
            for name, cid in self._private_chat_map.items():
                admin_cfg = self.daemon.config.instances.get(name) if hasattr(self.daemon, "config") else None
                if admin_cfg and getattr(admin_cfg, "role", "") == "admin":
                    admin_chat_id = cid
                    break

            # 純私聊模式 fallback：找不到 admin 的 private_chat 時，用任何已綁定的 chat_id
            if not admin_chat_id and self._private_chat_map:
                admin_chat_id = next(iter(self._private_chat_map.values()))

            if admin_chat_id and self.tg:
                prefixed_html = f"<b>{_html_escape(codename)}</b>\n{_html_escape(text)}"
                await self.tg._send_to_private(admin_chat_id, prefixed_html, parse_mode="HTML")
                return {"ok": True}

            raise HTTPException(
                status_code=404, detail="no topic or private chat for instance"
            )

        # ── POST /api/reply-photo ─────────────────────────────────
        @app.post("/api/reply-photo")
        async def send_reply_photo(req: dict[str, Any] = Body(...)) -> dict[str, Any]:
            """發送圖片給 instance 對應的 Telegram 頻道。"""
            instance = req.get("instance", "")
            photo_path = req.get("photo_path", "")
            caption = req.get("caption", "")

            if not photo_path or not Path(photo_path).exists():
                raise HTTPException(status_code=400, detail="photo_path not found")

            if not self.tg:
                return {"ok": False, "error": "no telegram adapter"}

            private_chat_id = self._private_chat_map.get(instance)
            if private_chat_id:
                await self.tg._send_photo_to_private(private_chat_id, photo_path, caption)
                return {"ok": True}

            # [ark-agent 2026-08-06] v1.1.0：worker 有 group → 進所屬 leader 的 topic（FR-5）
            topic_id, group_leader = self._resolve_output_topic(instance)
            if topic_id:
                if group_leader:
                    try:
                        await self.tg._send_photo_to_topic(topic_id, photo_path, caption)
                    except Exception as exc:
                        await self._send_group_marker_to_general(instance, group_leader, exc)
                else:
                    await self.tg._send_photo_to_topic(topic_id, photo_path, caption)
                return {"ok": True}
            if group_leader:
                await self._send_group_marker_to_general(instance, group_leader, "leader topic unavailable")
                return {"ok": True}

            # Fallback to admin private chat
            for name, cid in self._private_chat_map.items():
                admin_cfg = self.daemon.config.instances.get(name) if hasattr(self.daemon, "config") else None
                if admin_cfg and getattr(admin_cfg, "role", "") == "admin":
                    await self.tg._send_photo_to_private(cid, photo_path, caption)
                    return {"ok": True}

            # 純私聊模式 fallback
            if self._private_chat_map:
                fallback_cid = next(iter(self._private_chat_map.values()))
                await self.tg._send_photo_to_private(fallback_cid, photo_path, caption)
                return {"ok": True}

            raise HTTPException(status_code=404, detail="no channel for instance")
        @app.post("/api/reply-file")
        async def send_reply_file(req: dict[str, Any] = Body(...)) -> dict[str, Any]:
            """發送檔案給 instance 對應的 Telegram 頻道。"""
            instance = req.get("instance", "")
            file_path = req.get("file_path", "")
            caption = req.get("caption", "")

            if not file_path or not Path(file_path).exists():
                raise HTTPException(status_code=400, detail="file_path not found")

            if not self.tg:
                return {"ok": False, "error": "no telegram adapter"}

            private_chat_id = self._private_chat_map.get(instance)
            if private_chat_id:
                await self.tg._send_document_to_private(private_chat_id, file_path, caption)
                return {"ok": True}

            # [ark-agent 2026-08-06] v1.1.0：worker 有 group → 進所屬 leader 的 topic（FR-5）
            topic_id, group_leader = self._resolve_output_topic(instance)
            if topic_id:
                if group_leader:
                    try:
                        await self.tg._send_document_to_topic(topic_id, file_path, caption)
                    except Exception as exc:
                        await self._send_group_marker_to_general(instance, group_leader, exc)
                else:
                    await self.tg._send_document_to_topic(topic_id, file_path, caption)
                return {"ok": True}
            if group_leader:
                await self._send_group_marker_to_general(instance, group_leader, "leader topic unavailable")
                return {"ok": True}

            # Fallback to admin private chat
            for name, cid in self._private_chat_map.items():
                admin_cfg = self.daemon.config.instances.get(name) if hasattr(self.daemon, "config") else None
                if admin_cfg and getattr(admin_cfg, "role", "") == "admin":
                    await self.tg._send_document_to_private(cid, file_path, caption)
                    return {"ok": True}

            # 純私聊模式 fallback
            if self._private_chat_map:
                fallback_cid = next(iter(self._private_chat_map.values()))
                await self.tg._send_document_to_private(fallback_cid, file_path, caption)
                return {"ok": True}

            raise HTTPException(status_code=404, detail="no channel for instance")

        # ── GET /api/web-reply/{session_id} ──────────────────────
        @app.get("/api/web-reply/{session_id}")
        async def get_web_reply(session_id: str) -> dict[str, Any]:
            """輪詢 Web Chat 回覆佇列。

            Web Chat 在發訊後輪詢此端點，直到取得回覆。
            回傳 {"replies": [...], "pending": bool}
            """
            queue = _web_reply_queues.get(session_id)
            if not queue:
                return {"replies": [], "pending": False}

            replies = list(queue)
            queue.clear()
            return {"replies": replies, "pending": False}

        # ── DELETE /api/web-reply/{session_id} ───────────────────
        @app.delete("/api/web-reply/{session_id}")
        async def clear_web_reply(session_id: str) -> dict[str, Any]:
            """清除 Web Chat 回覆佇列（session 結束時呼叫）。"""
            _cleanup_web_queue(session_id)
            return {"ok": True}

        # ── POST /api/log ─────────────────────────────────────────
        @app.post("/api/log")
        async def log_to_leader(req: LogRequest) -> dict[str, Any]:
            """Private channel for agents to log errors/context to leader without user visibility."""
            if not self.tg:
                raise HTTPException(status_code=503, detail="no telegram adapter")

            # [1.1.9 A+D] 用 _leader_for：worker 有 group→所屬 group leader，
            # 否則 general_topic 持有者（總機）。取代原本一律找 general_topic 的錯誤邏輯。
            leader_name = self._leader_for(req.source or req.instance)

            if not leader_name:
                raise HTTPException(status_code=404, detail="no leader found")

            topic_id = self._topic_map.get(leader_name)
            if not topic_id:
                raise HTTPException(status_code=404, detail="leader has no topic")

            # [1.2.9] 顯示代號而非 raw instance 名（原本一律印 `[sec-agent]`，與其他
            # 5 處出口的 _CODENAMES 慣例不一致；所有團隊都受影響，非單一團隊設定問題）
            _src = req.source or req.instance
            _cn = self.tg._CODENAMES.get(_src, _src) if hasattr(self.tg, "_CODENAMES") else _src
            formatted = f"🔒 <b>{_html_escape(_cn)}</b>\n{_md_to_html(req.text)}"

            # [1.3.1] private-only fallback：group_id=0 時 topic 不可用，改走 private_chat
            _group_id = getattr(self.tg.config, "group_id", 0) if self.tg else 0
            sent = False
            if _group_id:
                try:
                    await self.tg._send_to_topic(topic_id, formatted, parse_mode="HTML")
                    sent = True
                except Exception as _topic_err:
                    log.warning("log_to_leader topic send failed (%s), trying private fallback", _topic_err)

            if not sent:
                # Fallback: leader 的 private_chat → 團隊 owner → 任一（保底）
                #
                # 🔴 [1.4.6] 中間那層原本寫死 `"admin-agent"`。那是 1.2.26 修過的
                # 同一個缺陷家族（`notify_paddy()` 寫死 `ark-agent`）**倖存下來的兄弟**：
                #   slot / fish / paddy / aiops → 入口叫 admin-agent ✅ 碰巧命中
                #   nana → `ark-agent`、director → `tech-agent`   ❌ 這層直接落空
                # 它沒有炸掉只是因為第三層「任一 private_chat」在單人部署下剛好是同一個人
                # —— 多個 private_chat 時就會挑到錯的人。
                #
                # 1.2.26 就是為這件事加了 `owner_chat_id()`（依 role 推導），只是這處沒改到。
                # CI 沒抓到是因為 `BANNED` 只加了 `ark-agent`，沒加 `admin-agent`（本版補上）。
                _fallback_cid = (
                    self._private_chat_map.get(leader_name)
                    or self.owner_chat_id()
                    or next(iter(self._private_chat_map.values()), None)
                )
                if _fallback_cid:
                    await self.tg._send_to_private(_fallback_cid, formatted, parse_mode="HTML")
                    sent = True
                else:
                    # No delivery channel available — log only, don't fail
                    log.warning("log_to_leader: no delivery channel (no topic, no private_chat)")

            # [team-agent 2026-05-15] log_to_leader 也要進 INFO log
            log.info("🔒 LOG %s → leader「%s」", req.source or req.instance, req.text[:50])
            return {"ok": True, "delivered": sent}

        # ── GET /api/status ───────────────────────────────────────
        @app.get("/api/status")
        async def get_status() -> dict[str, Any]:
            status = {"ok": True, "instances": self.daemon.get_status()}
            # [v1.1.3 P1-6] 暴露降級狀態（避免靜默降級）
            dg = getattr(self.daemon, "degraded", None)
            if dg:
                status["degraded"] = list(dg)
            # Include watchdog heartbeat if available
            from .config import get_home
            hb_path = get_home() / "state" / "watchdog_heartbeat"
            if hb_path.exists():
                try:
                    status["watchdog"] = hb_path.read_text(encoding="utf-8").strip()
                except OSError:
                    pass
            return status

        # ── GET /api/instances ────────────────────────────────────
        @app.get("/api/instances")
        async def get_instances() -> dict[str, Any]:
            """Detailed instance info combining config + runtime state."""
            return {"ok": True, "instances": self.daemon.get_instances_detail()}

        # ── GET /api/v1/agents（外部整合用）────────────────────────
        @app.get("/api/v1/agents")
        async def get_agents_list() -> dict[str, Any]:
            """列出可用 agents（供 ark-bot-agent 整合用）。

            [1.4.8] 原本呼叫 `self.daemon.get_instance_status(name)` —— **`Daemon`
            沒有這個方法**，所以這個端點從 `e611315` 加進來就一直回 **HTTP 500**。
            而消費端 `TeamClient.list_agents()` 是 `except Exception: return []`
            → **拿到空清單而不是錯誤**，靜默失效。

            狀態改由 `get_status()`（唯一的狀態出口）查，不另組一份。
            """
            _status = {row["name"]: row["status"] for row in self.daemon.get_status()}
            agents = []
            for name, ic in self.daemon.config.instances.items():
                agents.append({
                    "id": name,
                    "role": ic.role,
                    "codename": getattr(ic, "codename", "") or "",
                    # 沒有 runtime state 的（尚未建立）回 "unknown"，不要讓整個端點炸
                    "status": _status.get(name, "unknown"),
                })
            return {"ok": True, "agents": agents}

        # ── POST /api/v1/dispatch（外部整合用）─────────────────────
        #
        # [1.4.8] 這個端點**從加進來（e611315）就沒有一次成功過**：
        #   1.4.7 之前 —— `Request` 沒 import → 422（已修）
        #   1.4.7      —— 呼叫 `self.daemon.send_and_wait()`，而 `Daemon` 沒有這個方法
        #                 → AttributeError 被 `except Exception` 吃掉 → **HTTP 200 帶 error**
        #
        # 🔴 「HTTP 200 帶 error」= 以回傳值表示失敗。只看 HTTP status 的呼叫端會把
        #    「方法不存在」當成功。所以本版同時修三件事：
        #      ① 真的實作「送出 + 等回覆」（沿用 reply 佇列的形狀，見 `_dispatch_waiters`）
        #      ② **失敗一律用對應的 HTTP status code**（400/404/503/504/500）
        #      ③ 回傳體加 `status` 欄位分辨失敗種類 —— `ok: false` 只說「失敗了」，
        #         說不出「服務沒開 / 目標不存在 / agent 沒回」，呼叫端無法決定要不要重試
        @app.post("/api/v1/dispatch")
        async def dispatch_message(request: Request, response: Response) -> dict[str, Any]:
            """接收外部訊息並派工給指定 agent（或預設 leader），等待該次回覆。

            Body: {"message": str, "target": str?, "session_id": str?, "timeout": int?}
            Response: {"ok": bool, "status": str, "reply": str, "agent_id": str,
                       "elapsed_ms": int, "error": str?}

            `status` 取值（呼叫端請以此分流，不要解析 `error` 字串）：

            | status | HTTP | 意思 | 可重試 |
            |---|---|---|---|
            | `ok` | 200 | 拿到回覆 | — |
            | `invalid_request` | 400 | body 不合法（如 message 空） | ❌ |
            | `unknown_agent` | 404 | target 不在團隊裡 | ❌ |
            | `no_agents` | 503 | 團隊一個 instance 都沒有 | ❌ |
            | `queued` | 202 | agent 未就緒，訊息已存入 overflow 待投遞 | ❌ 會重複投遞 |
            | `send_failed` | 503 | 訊息送不進去（agent 起不來／已停用） | ✅ |
            | `timeout` | 504 | 送進去了，但等不到這一則的回覆 | ✅ |
            | `internal_error` | 500 | 未預期例外 | ✅ |
            """
            import time as _time

            def _fail(status: str, http: int, error: str, *,
                      agent_id: str = "", t0: float | None = None) -> dict[str, Any]:
                response.status_code = http
                return {
                    "ok": False,
                    "status": status,
                    "error": error,
                    "reply": "",
                    "agent_id": agent_id,
                    "elapsed_ms": int((_time.time() - t0) * 1000) if t0 else 0,
                }

            try:
                body = await request.json()
            except Exception:
                return _fail("invalid_request", 400, "body must be valid JSON")
            if not isinstance(body, dict):
                return _fail("invalid_request", 400, "body must be a JSON object")

            message = str(body.get("message") or "").strip()
            if not message:
                return _fail("invalid_request", 400, "message is required")

            _instances = self.daemon.config.instances
            target = str(body.get("target") or "").strip()
            if not target:
                # 預設走 leader（由 leader 自行分派）
                for name, ic in _instances.items():
                    if ic.role == "leader":
                        target = name
                        break
            if not target:
                # fallback: 第一個 instance
                target = next(iter(_instances), "")
            if not target:
                return _fail("no_agents", 503, "team has no instances")
            if target not in _instances:
                return _fail("unknown_agent", 404, f"agent '{target}' not found",
                             agent_id=target)

            # timeout 可由呼叫端指定（1–600s），預設 120s
            try:
                timeout = float(body.get("timeout") or 120)
            except (TypeError, ValueError):
                return _fail("invalid_request", 400, "timeout must be a number",
                             agent_id=target)
            timeout = max(1.0, min(timeout, 600.0))

            session_id = str(body.get("session_id") or "").strip()
            t0 = _time.time()

            # 🔴 先登記等待者**再**送訊息 —— 反過來的話，agent 秒答時
            # reply 會在登記完成前抵達，找不到等待者就走去 TG，而這裡等到逾時。
            fut: asyncio.Future[str] = asyncio.get_running_loop().create_future()
            self._dispatch_waiters.setdefault(target, collections.deque()).append(fut)

            def _drop_waiter() -> None:
                dq = self._dispatch_waiters.get(target)
                if dq is None:
                    return
                try:
                    dq.remove(fut)
                except ValueError:
                    pass
                if not dq:
                    self._dispatch_waiters.pop(target, None)

            try:
                # source="dispatch" 落在 `/api/reply` 的**非互動**分流 → 回覆後進 IDLE。
                # 這是對的：dispatch 是一次性請求，回完就沒有下一輪，
                # 不該進 AWAITING_REPLY（那個語意是「使用者還在對話中」）。
                ok = await self.daemon.send_message(target, message, source="dispatch")
                if not ok:
                    _drop_waiter()
                    return _fail("send_failed", 503,
                                 f"could not deliver message to '{target}'",
                                 agent_id=target, t0=t0)

                # 🔴 `send_message` 對「agent 未就緒」會**存進 overflow 並回 True**
                # （見 daemon.py「Deferring message」）—— 那是刻意的（不丟訊息），
                # 但對 dispatch 來說「已排隊」不等於「這次拿得到回覆」。
                # 不特別處理的話會白等到 504，而 504 標示可重試 → 呼叫端重試就變重複投遞。
                if f"deferred_message:{target}" in (getattr(self.daemon, "degraded", None) or []):
                    _drop_waiter()
                    response.status_code = 202
                    log.info("📡 DISPATCH QUEUED %s（agent 未就緒，訊息存入 overflow）", target)
                    return {
                        "ok": False,
                        "status": "queued",
                        "error": f"'{target}' not ready; message queued for later delivery",
                        "reply": "",
                        "agent_id": target,
                        "elapsed_ms": int((_time.time() - t0) * 1000),
                    }

                log.info("📡 DISPATCH → %s（session=%s, timeout=%.0fs）「%s」",
                         target, session_id or "-", timeout, message[:50])
                reply = await asyncio.wait_for(asyncio.shield(fut), timeout=timeout)
                return {
                    "ok": True,
                    "status": "ok",
                    "reply": reply,
                    "agent_id": target,
                    "elapsed_ms": int((_time.time() - t0) * 1000),
                }
            except (asyncio.TimeoutError, TimeoutError):
                _drop_waiter()
                fut.cancel()
                log.warning("📡 DISPATCH TIMEOUT %s（%.0fs）", target, timeout)
                return _fail("timeout", 504,
                             f"no reply from '{target}' within {timeout:.0f}s",
                             agent_id=target, t0=t0)
            except asyncio.CancelledError:
                _drop_waiter()
                raise
            except Exception as e:
                _drop_waiter()
                fut.cancel()
                log.error("📡 DISPATCH FAIL %s: %s", target, e)
                return _fail("internal_error", 500, str(e), agent_id=target, t0=t0)

        # ── GET /api/health ───────────────────────────────────────
        @app.get("/api/health")
        async def get_health() -> dict[str, Any]:
            """Comprehensive health check — system + per-instance metrics."""
            import time as _time
            instances = self.daemon.get_status()
            running = sum(1 for i in instances if i["status"] == "running")
            # [1.2.0 N3] alive = running + awaiting_reply（awaiting_reply 是活著在等回覆，非死）
            # [1.2.16] 補 idle —— 做完沒待辦同樣是活著。漏了會讓 /api/health 的 alive
            # 隨 agent 完工而下降，外部監控會誤判成 agent 掉了。
            alive = sum(1 for i in instances
                        if i["status"] in ("running", "awaiting_reply", "idle"))
            total = len(instances)

            health: dict[str, Any] = {
                "ok": running > 0,
                "version": __import__("ark_team_agent").__version__,
                "python": __import__("sys").version.split()[0],
                "uptime_s": _time.time() - (self.team_manager._started_at if self.team_manager else 0),
                "instances": {"running": running, "alive": alive, "total": total},
                "degraded": list(getattr(self.daemon, "degraded", []) or []),  # [v1.1.3 P1-6]
                "memory_mb": {},
                "overflow_pending": {},
            }

            # Per-instance RSS (if psutil available)
            try:
                import psutil
                for state in self.daemon.instances.values():
                    if state.process and state.process.pid:
                        try:
                            rss = psutil.Process(state.process.pid).memory_info().rss / (1024 * 1024)
                            health["memory_mb"][state.config.name] = round(rss, 1)
                        except (psutil.NoSuchProcess, psutil.AccessDenied):
                            pass
            except ImportError:
                pass

            # Overflow queue counts
            for name in self.daemon.instances:
                count = self.daemon._overflow.count_pending(name)
                if count > 0:
                    health["overflow_pending"][name] = count

            # Cost guard
            if self.daemon.cost_guard:
                cg = self.daemon.cost_guard
                health["cost"] = {
                    "spent_today_usd": round(cg.spent_today(), 2),
                    "daily_limit_usd": cg.daily_limit_usd,
                    "paused": any(cg.is_paused(n) for n in self.daemon.instances),
                }

            # Heartbeat staleness
            from .heartbeat import is_heartbeat_stale
            from .config import get_state_dir as _gsd
            health["heartbeat_stale"] = is_heartbeat_stale(_gsd())

            return health

        # ── GET /api/output/{name} ────────────────────────────────
        @app.get("/api/output/{name}")
        async def get_output(name: str, lines: int = 200) -> dict[str, Any]:
            """Last N lines of output for the given instance."""
            if name not in self.daemon.instances:
                raise HTTPException(status_code=404, detail=f"unknown instance: {name}")

            state = self.daemon.instances.get(name)
            if not state or not state.process:
                return {"ok": True, "instance": name, "lines": 0, "output": ""}

            output = state.process.capture(lines=lines)
            return {
                "ok": True,
                "instance": name,
                "lines": len(output.splitlines()),
                "output": output,
            }

        # ── GET /api/config ───────────────────────────────────────
        @app.get("/api/config")
        async def get_config() -> dict[str, Any]:
            """Team config summary (without secrets)."""
            return {"ok": True, "config": self.daemon.get_config_summary()}

        # ── GET /api/events ───────────────────────────────────────
        @app.get("/api/events/summary")
        async def get_events_summary() -> dict[str, Any]:
            """Today's event counts by type and instance."""
            import time as _t
            from .event_log import get_event_log
            midnight = _t.time() - (_t.time() % 86400)  # approx today start
            events = get_event_log().query(since=midnight - 28800, limit=500)  # TZ offset ~8h
            by_type: dict[str, int] = {}
            by_instance: dict[str, int] = {}
            for e in events:
                by_type[e.type] = by_type.get(e.type, 0) + 1
                by_instance[e.instance] = by_instance.get(e.instance, 0) + 1
            return {"ok": True, "total": len(events), "by_type": by_type, "by_instance": by_instance}

        @app.get("/api/events")
        async def get_events(
            instance: str | None = None,
            event_type: str | None = None,
            since: float | None = None,
            limit: int = 100,
        ) -> dict[str, Any]:
            """Query recent events from the event log."""
            from .event_log import get_event_log
            events = get_event_log().query(
                instance=instance,
                event_type=event_type,
                since=since,
                limit=limit,
            )
            return {
                "ok": True,
                "events": [
                    {
                        "id": e.id,
                        "timestamp": e.timestamp,
                        "instance": e.instance,
                        "type": e.type,
                        "detail": e.detail,
                        "source": e.source,
                    }
                    for e in events
                ],
            }

        # ── GET /api/costs ────────────────────────────────────────
        @app.get("/api/costs")
        async def get_costs() -> dict[str, Any]:
            """Today's spend per instance and team total."""
            cg = getattr(self.daemon, "cost_guard", None)
            if not cg:
                return {
                    "ok": True,
                    "enabled": False,
                    "today": {},
                    "total_usd": 0.0,
                    "daily_limit_usd": 0.0,
                }
            today = cg.get_today_all()
            return {
                "ok": True,
                "enabled": True,
                "today": today,
                "total_usd": sum(today.values()),
                "daily_limit_usd": cg.daily_limit_usd,
                "warn_at_percentage": cg.warn_pct,
                "paused_instances": [n for n in today if cg.is_paused(n)],
                "per_instance_limits": cg._per_instance_limits,
            }

        # ── POST /api/costs/spend ─────────────────────────────────
        @app.post("/api/costs/spend")
        async def record_spend(req: SpendRequest) -> dict[str, Any]:
            """Record spend for an instance. Agent-reportable or manual.

            Since Kiro CLI does not expose per-call cost to stdout, agents can
            self-report estimated spend here (or an external tool can call this
            after parsing AWS billing data).
            """
            cg = getattr(self.daemon, "cost_guard", None)
            if not cg:
                raise HTTPException(status_code=503, detail="cost_guard not enabled")
            if req.amount_usd < 0:
                raise HTTPException(status_code=400, detail="amount_usd must be >= 0")
            await cg.add_spend(req.instance, req.amount_usd)
            return {
                "ok": True,
                "instance": req.instance,
                "amount_usd": req.amount_usd,
                "today_total": cg.get_today_spend(req.instance),
                "is_paused": cg.is_paused(req.instance),
            }

        # ── POST /api/reload ──────────────────────────────────────
        @app.post("/api/reload")
        async def reload_config() -> dict[str, Any]:
            """Reload team.yaml. Returns summary of added/removed instances or errors."""
            if not self.team_manager:
                raise HTTPException(status_code=503, detail="team_manager not available")
            result = await self.team_manager.reload_config()
            return result

        # ── POST /api/instances/{name}/restart ─────────────────────
        @app.post("/api/instances/{name}/restart")
        async def restart_instance(name: str) -> dict[str, Any]:
            """Restart a single agent instance."""
            if name not in self.daemon.instances:
                raise HTTPException(status_code=404, detail=f"unknown instance: {name}")
            try:
                await self.daemon.restart_instance(name)
                return {"ok": True, "instance": name, "message": f"{name} restarted"}
            except Exception as e:
                return {"ok": False, "instance": name, "error": str(e)}

        # ── POST /api/restart-service ─────────────────────────────
        @app.post("/api/restart-service")
        async def restart_service() -> dict[str, Any]:
            """觸發整個服務重啟。

            [1.3.3] 改走 `restart.request_restart()`（與 TG `/restart` 同一個入口）。
            回應**據實反映**這次退出後會不會被拉起 —— 原本一律回
            「will restart in ~3s」，但在沒有 supervisor 的環境那是謊話：
            SIGTERM 只會讓服務關掉不再起來。
            """
            from .restart import request_restart
            r = request_restart(delay=0.5, source="api:/api/restart-service")
            r["message"] = (
                f"服務即將重啟（{r['mechanism']}：{r['why']}）"
                if r["will_restart"] else
                f"⚠️ 服務即將**停止且不會自動起來** —— {r['why']}"
            )
            return r

        # ── WS /ws/output/{name} ──────────────────────────────────
        # [1.2.9] design 早有定義（team-web-dashboard-design.md:122）但未實作 → drift 補齊
        @app.websocket("/ws/events")
        async def ws_events(websocket: WebSocket) -> None:
            """Stream team events in real time（輪詢 event log，只推新增事件）。"""
            await websocket.accept()
            from .event_log import get_event_log
            _log = get_event_log()
            try:
                # 初始回填最近 20 筆（新到舊）
                initial = _log.query(limit=20)
                await websocket.send_json({
                    "type": "initial",
                    "events": [
                        {"timestamp": e.timestamp, "instance": e.instance,
                         "type": e.type, "detail": e.detail, "source": e.source}
                        for e in initial
                    ],
                })
                last_ts = initial[0].timestamp if initial else 0.0
                while True:
                    await asyncio.sleep(2)
                    fresh = [e for e in _log.query(limit=50) if e.timestamp > last_ts]
                    if fresh:
                        last_ts = max(e.timestamp for e in fresh)
                        for e in sorted(fresh, key=lambda x: x.timestamp):
                            await websocket.send_json({
                                "type": "event",
                                "event": {"timestamp": e.timestamp, "instance": e.instance,
                                          "type": e.type, "detail": e.detail, "source": e.source},
                            })
            except WebSocketDisconnect:
                log.debug("WebSocket disconnected: /ws/events")

        @app.websocket("/ws/output/{name}")
        async def ws_output(websocket: WebSocket, name: str) -> None:
            """Stream instance output in real time."""
            await websocket.accept()

            if name not in self.daemon.instances:
                await websocket.send_json({"error": f"unknown instance: {name}"})
                await websocket.close()
                return

            # Send initial backlog
            state = self.daemon.instances.get(name)
            last_len = 0
            if state and state.process:
                initial = state.process.capture(lines=50)
                await websocket.send_json({"type": "initial", "output": initial})
                last_len = len(state.process.capture(lines=500))

            try:
                while True:
                    await asyncio.sleep(1)
                    state = self.daemon.instances.get(name)
                    if not state or not state.process:
                        await websocket.send_json({"type": "stopped"})
                        break

                    full = state.process.capture(lines=500)
                    if len(full) > last_len:
                        new_text = full[last_len:]
                        last_len = len(full)
                        await websocket.send_json({"type": "chunk", "output": new_text})
            except WebSocketDisconnect:
                log.debug("WebSocket disconnected: %s", name)
            except Exception as e:
                log.warning("WebSocket error for %s: %s", name, e)
                try:
                    await websocket.close()
                except Exception:
                    pass

        # ── GET /api/skill-growth ─────────────────────────────────
        @app.get("/api/skill-growth")
        async def get_skill_growth(instance: str | None = None) -> dict[str, Any]:
            """Get skill growth detector stats."""
            if not self.tg or not hasattr(self.tg, "_skill_growth"):
                return {"ok": True, "enabled": False, "instances": {}}
            detector = self.tg._skill_growth
            if instance:
                return {
                    "ok": True,
                    "enabled": detector.config.enabled,
                    "instance": instance,
                    "stats": detector.get_stats(instance),
                }
            # All instances
            stats = {}
            for name in self.daemon.instances:
                stats[name] = detector.get_stats(name)
            return {
                "ok": True,
                "enabled": detector.config.enabled,
                "instances": stats,
            }

        # ── Static Dashboard (Next.js export) — MUST be last (catch-all) ──
        from fastapi.staticfiles import StaticFiles
        from fastapi.responses import FileResponse
        dashboard_out = get_home() / "apps" / "team-dashboard" / "out"
        if dashboard_out.exists():
            app.mount("/_next", StaticFiles(directory=str(dashboard_out / "_next")), name="next_static")

            @app.get("/")
            async def serve_root():
                root_html = dashboard_out / "index.html"
                if root_html.exists():
                    return FileResponse(str(root_html), media_type="text/html")
                return {"message": "Dashboard not built. Run: cd apps/team-dashboard && npm run build"}

            @app.get("/{path:path}")
            async def serve_dashboard(path: str):
                # Skip API routes — let FastAPI handle them
                if path.startswith("api/") or path.startswith("ws/"):
                    raise HTTPException(status_code=404, detail="Not found")
                html_file = dashboard_out / path / "index.html"
                if html_file.exists():
                    return FileResponse(str(html_file), media_type="text/html")
                direct = dashboard_out / path
                if direct.exists() and direct.is_file():
                    return FileResponse(str(direct))
                root_html = dashboard_out / "index.html"
                if root_html.exists():
                    return FileResponse(str(root_html), media_type="text/html")
                raise HTTPException(status_code=404, detail="Not found")

        return app

    async def start(self, port: int | None = None) -> None:
        """Start uvicorn as a background task."""
        from .constants import DEFAULT_TEAM_AGENT_PORT
        if port is None:
            port = DEFAULT_TEAM_AGENT_PORT
        config = uvicorn.Config(
            self.app,
            host="127.0.0.1",
            port=port,
            log_level="warning",
            access_log=False,
        )
        self._uvicorn_server = uvicorn.Server(config)
        self._server_task = asyncio.create_task(self._uvicorn_server.serve())
        # Wait for server to actually start (uvicorn signals started=True after binding)
        for _ in range(50):  # max 5s
            if self._uvicorn_server.started:
                break
            await asyncio.sleep(0.1)
        log.info("Daemon API listening on 127.0.0.1:%d", port)

    async def stop(self) -> None:
        if self._uvicorn_server:
            self._uvicorn_server.should_exit = True
        if self._server_task:
            try:
                await asyncio.wait_for(self._server_task, timeout=5)
            except asyncio.TimeoutError:
                self._server_task.cancel()
                try:
                    await self._server_task
                except (asyncio.CancelledError, Exception):
                    pass
