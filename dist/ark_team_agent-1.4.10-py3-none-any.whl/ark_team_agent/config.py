"""team.yaml configuration loading and validation."""
from __future__ import annotations

import difflib
import logging
import os
import re
from dataclasses import dataclass, field, fields as dc_fields
from pathlib import Path
from typing import Any

import yaml

log = logging.getLogger(__name__)

DEFAULT_HOME = Path.home() / ".ark-team-agent"


def get_home() -> Path:
    """Find team home directory: env var → walk up for team.yaml → default."""
    if env := os.environ.get("ARK_TEAM_AGENT_HOME"):
        return Path(env)
    cwd = Path.cwd()
    for p in [cwd, *cwd.parents]:
        if (p / "team.yaml").exists():
            return p
    return DEFAULT_HOME


def get_state_dir() -> Path:
    """Central directory for all SQLite state files (events, sessions, costs)."""
    d = get_home() / "state"
    d.mkdir(parents=True, exist_ok=True)
    return d


@dataclass
class ScheduledJobConfig:
    """A single scheduled job definition from scheduler.yaml."""
    target: str = ""
    prompt: str = ""
    cron: str = ""
    name: str = ""
    enabled: bool = True
    timezone: str = ""


@dataclass
class SchedulerConfig:
    """Top-level scheduler configuration."""
    timezone: str = "Asia/Taipei"
    jobs: list[ScheduledJobConfig] = field(default_factory=list)


def load_scheduler_config(path: Path | None = None) -> SchedulerConfig:
    """Load scheduler.yaml from config directory."""
    if path is None:
        path = get_home() / "scheduler.yaml"
    if not path.exists():
        return SchedulerConfig()

    raw = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    sc = SchedulerConfig(timezone=raw.get("timezone", "Asia/Taipei"))

    for i, job_raw in enumerate(raw.get("jobs", [])):
        if not isinstance(job_raw, dict):
            continue
        job = ScheduledJobConfig(
            target=job_raw.get("target", ""),
            prompt=job_raw.get("prompt", ""),
            cron=job_raw.get("cron", ""),
            name=job_raw.get("name", f"job-{i}"),
            enabled=job_raw.get("enabled", True),
            timezone=job_raw.get("timezone", ""),
        )
        sc.jobs.append(job)

    return sc


@dataclass
class CostGuardConfig:
    daily_limit_usd: float = 0
    warn_at_percentage: int = 80
    timezone: str = "Asia/Taipei"
    per_instance_limits: dict[str, float] = field(default_factory=dict)


@dataclass
class HangDetectorConfig:
    enabled: bool = True
    timeout_minutes: int = 60
    escalation_minutes: int = 180
    active_start_hour: int = 9   # 只在此時段內觸發通知
    active_end_hour: int = 21
    auto_restart: bool = False   # [1.5.0] escalation 後自動重啟卡住的 agent


@dataclass
class StartupConfig:
    concurrency: int = 3
    stagger_delay_ms: int = 2000


@dataclass
class RestartPolicy:
    max_retries: int = 10
    backoff: str = "exponential"
    reset_after: int = 300
    health_check_interval_ms: int = 30000
    # [1.2.14 P3] 崩潰迴圈治理 —— `max_retries` 是「**連續**失敗」上限，但只要 agent
    # 重啟後產出任何 output，`crash_count` 就歸零（daemon 的活動偵測），因此
    # 「崩潰→重啟→印啟動訊息→再崩潰」的迴圈**永遠到不了 max_retries**。
    # 實測 director 2026-07-31~08-12 累積 2421 筆 crash，每一筆都是 crash_count=1。
    # 故改以**時間窗內的崩潰次數**判定迴圈，與活動偵測無關。
    crash_window_minutes: int = 60   # 觀察窗
    max_crashes_per_window: int = 5  # 窗內達此次數 → 進冷卻（不等 max_retries）
    max_cooldowns: int = 3           # 冷卻這麼多次仍在崩 → 停止自動重啟 + 通報


@dataclass
class InstanceConfig:
    name: str = ""
    working_directory: str = ""
    description: str = ""
    display_name: str = ""
    tags: list[str] = field(default_factory=list)
    topic_id: int | str | None = None
    general_topic: bool = False
    private_chat: int | None = None
    role: str = "worker"  # manager | leader | worker
    # [ark-agent 2026-08-06] v1.1.0 Group Topic Routing：worker 專用，所屬 leader 的 instance 名
    group: str | None = None  # 設定後 worker 輸出改發該 leader 的 topic；None=維持 v1.0.5 行為
    backend: str = "kiro-cli"
    model: str | None = None
    model_failover: list[str] = field(default_factory=list)
    skip_permissions: bool = True
    # [ark-agent 2026-08-07] skip_resume：None=依 role 自動（admin/manager → resume，其餘 → fresh）；
    # team.yaml 可逐一覆寫（true=不 --resume 開新對話；false=--resume 接續）
    skip_resume: bool | None = None
    # [ark-agent 2026-08-07] v1.1.3 P2-8：明示 SOUL/BRAIN 範本（如 analyst/researcher）；
    # None=依 role 預設（不再一律套 coder）
    template: str | None = None
    system_prompt: str | None = None
    # [1.2.0 N1] 派工輸出約束：送往此 instance 的訊息自動包夾（如「≤3000字/只給結論」）。空=no-op。
    task_prefix: str = ""
    task_suffix: str = ""
    restart_policy: RestartPolicy = field(default_factory=RestartPolicy)
    cost_guard: CostGuardConfig | None = None
    startup_timeout_ms: int = 60000
    log_level: str = "info"
    auto_start: bool = True  # False = 僅列入成員表，不啟動 subprocess
    persistent: bool = True  # False = lazy spawn（需求才啟）+ idle 後自動回收
    idle_timeout_minutes: int = 60  # persistent=False 時，idle 多久後自動停止（0=不回收）
    # [1.2.13 P1] MCP 掛載（宣告式）：指向 TeamConfig.mcp_servers 的名稱。
    # 實際掛載 = (defaults.mcp ∪ mcp) − mcp_exclude（ADR-006，union 而非覆寫 ——
    # 覆寫語意會讓「只想多加一個」變成必須重列全部，漏列是靜默失敗）
    mcp: list[str] = field(default_factory=list)
    mcp_exclude: list[str] = field(default_factory=list)
    # [claude-code 2026-08-06] 多使用者私訊隔離（admin-multi-user-isolation）
    multi_user: bool = False  # True = 依 user 動態衍生 session instance（name#user_id），per-user 獨立 subprocess
    max_user_sessions: int = 5  # multi_user 時同時最多幾個使用者 session（達上限 LRU 回收 idle）
    session_idle_timeout_minutes: int = 30  # session 閒置多久後回收（0=不回收）


@dataclass
class ChannelConfig:
    bot_token_env: str = "TELEGRAM_BOT_TOKEN"
    group_id: int = 0
    general_topic_id: int = 1
    poll_interval: float = 3.0


@dataclass
class AccessConfig:
    mode: str = "locked"
    allowed_users: list[int] = field(default_factory=list)


@dataclass
class P2PConfig:
    """Peer-to-peer communication settings."""
    enabled: bool = False
    # [ark-agent 2026-08-07] v1.1.6：預設關閉每輪 CC（純噪音，多 leader 團隊更糟）；要稽核軌跡再 opt-in
    cc_leader: bool = False
    daily_limit_per_agent: int = 10
    max_rounds: int = 3          # 同一對 agent 最多 N 輪，超過升級 → General topic
    emergency_mode: bool = False


@dataclass
class KiroFilesPolicy:
    """Policy for .kiro/ file generation per instance."""

    # 工作區根目錄（**不是 .kiro/ 底下**）
    # [1.2.19] agents_md 回歸，但**語意不同**：
    #   舊（1.2.18 移除）＝把根目錄的 AGENTS.md「同步／複製」到各 agent 的 steering/
    #   新＝在各 agent 的 **working_directory 根目錄**產生一份導覽檔，
    #       給**非 Kiro** 的 agent（Claude Code / Codex / 其他 CLI）看 ——
    #       Kiro 會自動載入 .kiro/steering/，它們不會。
    # 本意相同（讓每個 agent 都有 AGENTS.md），這次是把實作做對。
    agents_md: str = "once"           # once | always | skip

    # steering/
    team_md: str = "once"             # always | symlink | once | skip（預設 once：第一次建立後由專案維護，重啟不覆寫）
    soul_md: str = "once"             # once | always | template | skip
    memory_md: str = "once"           # once | skip

    # settings/
    mcp_json: str = "always"          # always | once | skip

    # agents/
    agent_json: str = "once"          # once | always | template | skip

    # prompts/
    prompts_policy: str = "once"      # once | always | template | skip
    prompts_source: str | None = None

    # skills/
    # [1.2.12] 新增 sync —— once 只在目錄不存在時複製，skill 修好也不會下發（既有 agent
    # 永久停在首次部署版本）。sync 逐檔比對內容，有差異才覆寫，且**不刪除** agent 自行
    # 新增的檔案。預設仍為 once，維持既有行為不變。
    skills_policy: str = "once"       # once | sync | skip
    skills_source: str | None = None

    # [1.2.18] 已移除 agents_md / shared_wiki / private_wiki —— 三者的實作早已拿掉
    # （backend.py 零引用），設定卻還在，讀設定的人會以為它有效。
    # **新架構：每個 agent 獨立運作與發展，只有知識庫共用**，
    # 而知識庫共用是靠 `wiki_query` MCP 工具，不是 symlink/複製檔案。


@dataclass
class CommunicationConfig:
    """Communication policy settings."""
    p2p: P2PConfig = field(default_factory=P2PConfig)
    # [1.1.9 E] ToolTracker 顯示模式：False=人性化單行階段（預設），True=完整工具序列（維運用）
    tool_detail: bool = False
    # [1.1.13] send_to_instance peer 回覆逾時（分）：A 請 B 後 N 分無回覆 → 主動 nudge A。0=關閉。
    peer_reply_timeout_minutes: int = 15
    # [1.2.2 N4] 派工脈絡保留（分）：orchestrator 派工後，N 分內的續問注入「上一步派給誰」。0=關閉。
    dispatch_context_ttl_minutes: int = 30
    # [1.5.0] 轉派訊息預設 TTL（分）：超過此時間未投遞則自動丟棄。0=不過期。
    default_msg_ttl_minutes: int = 15
    # [1.4.1] 回覆是否回到「使用者發問的那個 topic」（含由該次發問派工出去的下游）。
    #
    # **預設 False —— 既有部署行為不變。** 1.4.0 曾讓它無條件生效，那是錯的：
    # 它改變的是「訊息出現在哪裡」，屬於各團隊的動線習慣，不該由套件替它們決定。
    # 實測 aiops(6) / director(4) / slot(8) / fish 都用 `group` 欄位把 worker 輸出
    # 收攏到組 leader 的 topic —— 那是刻意的架構，而 1.4.0 在互動情境下把它拿掉了，
    # 且**沒有任何開關可以關**。
    #
    # 開了之後：使用者在哪個 topic 發問，回覆就回那裡（`group` 的歸類在該次互動中讓位）。
    # 沒開：維持歸屬路由（agent 自己的 topic，或 worker 所屬 leader 的 topic）。
    #
    # 適合開的情境：扁平 topic 或純私訊架構（沒有 `group`），或使用者習慣在 General 對話。
    # 適合維持關的情境：三層 group 架構 —— 組內對話的連續性靠的就是共用 leader topic。
    reply_to_origin: bool = False


@dataclass
class McpServerConfig:
    """[1.2.13 P1] MCP server 宣告（team.yaml 的 `mcp_servers`）。

    設計要點：
    - `command` 相對值由 backend 解析為絕對路徑（systemd PATH 不含 venv/bin）
    - `env` 經 wrapper script 生效 —— Kiro CLI **忽略** mcp.json 的 env 欄位
    - `enabled=False` 為使用者刻意停用，**不記 degraded**（ADR-007）

    Author: ark-agent（1.2.13）
    """
    name: str = ""
    command: str = ""
    args: list[str] = field(default_factory=list)
    env: dict[str, str] = field(default_factory=dict)
    enabled: bool = True

    def to_entry(self) -> dict[str, Any]:
        """轉成 backend 消費的 dict（與手寫 mcp.json 條目同形）。"""
        return {"command": self.command, "args": list(self.args), "env": dict(self.env)}


@dataclass
class TeamConfig:
    instances: dict[str, InstanceConfig] = field(default_factory=dict)
    # [1.2.13 P1] MCP server 全域宣告（單一真相）；未設＝維持現況（只有 team/fetch）
    mcp_servers: dict[str, McpServerConfig] = field(default_factory=dict)
    defaults: dict[str, Any] = field(default_factory=dict)
    startup: StartupConfig = field(default_factory=StartupConfig)
    cost_guard: CostGuardConfig = field(default_factory=CostGuardConfig)
    hang_detector: HangDetectorConfig = field(default_factory=HangDetectorConfig)
    channel: ChannelConfig = field(default_factory=ChannelConfig)
    access: AccessConfig = field(default_factory=AccessConfig)
    communication: CommunicationConfig = field(default_factory=CommunicationConfig)
    kiro_files: KiroFilesPolicy = field(default_factory=KiroFilesPolicy)
    project_roots: dict[str, str] = field(default_factory=dict)
    # [ark-agent 2026-08-07] v1.1.3 P1-4：TEAM.md 指揮鏈/協作流程可選設定；未設則省略該段
    team_doc: dict[str, str] = field(default_factory=dict)
    # [1.2.0 N2] 知識庫櫃子搜尋順序（如 [shared, hoyeah, self]）；空=沿用現行掃描順序
    knowledge_search_order: list[str] = field(default_factory=list)
    # [1.2.23] 私訊路由設定。**在此之前這個欄位不存在** —— `telegram.py` 用
    # `getattr(config, "private_chat_routing", {})` 讀，於是永遠拿到 `{}`，
    # `keyword_routes` 從未生效過一次（nana 宣告了 3 群 20 個關鍵字，全是死的）。
    # 沒被發現是因為主路徑（入口 agent 用提詞做 LLM 意圖分類）正常 ——
    # 壞掉的是備援，而備援壞了沒有任何症狀。
    #
    # 欄位語意（`mode` 決定**套件**做什麼，其餘兩個是給 agent 提詞看的）：
    #   mode: keyword    → 套件用 keyword_routes 決定目標
    #   mode: 其他/未設  → 套件不介入，一律送 bound_instance（入口 agent 自己判斷）
    #   fallback / confidence_threshold → **套件不解讀**。confidence 是 agent 的
    #     LLM 判斷結果，不會回傳給套件，套件無從得知該不該降級。
    #     這兩個值由 agent 的 steering（如 intent-classify.md）自行遵循。
    private_chat_routing: dict[str, Any] = field(default_factory=dict)
    health_port: int = field(default_factory=lambda: _default_port())
    # [1.5.0] 部署模式：full（預設，含 TG）/ headless（只跑 Daemon + API，不啟動 TG）
    mode: str = "full"


def _default_port() -> int:
    # Env var override → constants fallback
    if env := os.environ.get("TEAM_AGENT_PORT"):
        return int(env)
    from .constants import DEFAULT_TEAM_AGENT_PORT
    return DEFAULT_TEAM_AGENT_PORT


def _tokens(name: str) -> set[str]:
    """欄位名的詞素集合，單複數正規化（`sessions` → `session`）。"""
    return {t.rstrip("s") for t in re.split(r"[_\-]", name) if t}


def _suggest_field(unknown: str, known: list[str]) -> list[str]:
    """對拼錯的欄位名給建議，**先比詞素再比字面**。

    純字面相似度在這裡會給錯答案 —— 實測 `resume_session` 的
    `difflib.get_close_matches` 首選是 `max_user_sessions`（共同子串多），
    而正解是 `skip_resume`。兩者都含一個共同詞素，但比例不同：

        skip_resume       ∩ {resume, session} = {resume}  → 1/2 = 0.50  ✅
        max_user_sessions ∩ {resume, session} = {session} → 1/3 = 0.33

    所以依「交集 ÷ 候選詞素數」排序：詞素少而命中的欄位更可能是使用者想寫的那個。
    完全沒有共同詞素時才退回字面相似度。

    Author: ark-agent（1.2.24）
    """
    want = _tokens(unknown)
    scored: list[tuple[float, str]] = []
    for cand in known:
        ct = _tokens(cand)
        if hit := (want & ct):
            scored.append((len(hit) / len(ct), cand))
    if scored:
        scored.sort(key=lambda x: (-x[0], x[1]))
        return [c for _, c in scored[:2]]
    return difflib.get_close_matches(unknown, known, n=2, cutoff=0.6)


def _merge_instance(raw: dict[str, Any], defaults: dict[str, Any], name: str,
                    project_roots: dict[str, str] | None = None) -> InstanceConfig:
    merged = {**defaults, **raw}
    cg = merged.pop("cost_guard", None)
    rp = merged.pop("restart_policy", None)
    merged.pop("startup", None)
    merged.pop("hang_detector", None)
    merged.pop("daily_summary", None)
    merged.pop("webhooks", None)
    project = merged.pop("project", None)

    # Resolve project → working_directory
    if project and project_roots and project in project_roots:
        merged.setdefault("working_directory", project_roots[project])

    # [1.2.13 P1 / ADR-006] mcp 走 union 而非覆寫。
    # `merged = {**defaults, **raw}` 對 list 是整份取代 —— 若 instance 寫了 mcp，
    # defaults.mcp 會被整份丟掉，「只想多加一個」就變成必須重列全部（漏列是靜默失敗）。
    _mcp_union: list[str] = []
    for _src in (defaults.get("mcp") or [], raw.get("mcp") or []):
        for _s in _src:
            if _s not in _mcp_union:
                _mcp_union.append(_s)
    _mcp_excl = list(raw.get("mcp_exclude") or defaults.get("mcp_exclude") or [])
    merged["mcp"] = [m for m in _mcp_union if m not in _mcp_excl]
    merged["mcp_exclude"] = _mcp_excl

    ic = InstanceConfig(name=name)
    # [1.2.24] 未知欄位以前是**靜默跳過**（`if hasattr` 為假就沒事發生）——
    # 設定檔寫了、載入時被丟掉、沒有任何訊息。實測代價：aiops 的 9 個 instance
    # 全部寫 `resume_session: true`（正確名是 `skip_resume`，且語意相反），
    # 於是 ic-agent 與 6 個 worker 的實際行為與設定意圖**相反**（開新對話 vs 接續），
    # 而且持續了整段時間都沒有任何訊號。
    #
    # 這是本專案反覆修過的缺陷家族（宣告了沒接上）中最隱蔽的一種 ——
    # 前面幾例是「欄位對但沒讀」，這是「**欄位名拼錯**」。用一道通用警告攔下所有拼錯，
    # 比逐個支援錯誤的別名正確。
    _unknown = [k for k in merged if not hasattr(ic, k)]
    for k, v in merged.items():
        if hasattr(ic, k):
            setattr(ic, k, v)
    if _unknown:
        _known = sorted(f.name for f in dc_fields(InstanceConfig))
        for k in _unknown:
            _near = _suggest_field(k, _known)
            log.warning(
                "team.yaml instance %r 的欄位 %r 不存在 → **已忽略**（設定不會生效）。%s",
                name, k,
                f"你是不是想寫 {' 或 '.join(repr(c) for c in _near)}？" if _near
                else "請對照 InstanceConfig 的欄位名。",
            )
    if cg and isinstance(cg, dict):
        ic.cost_guard = CostGuardConfig(**cg)
    if rp and isinstance(rp, dict):
        ic.restart_policy = RestartPolicy(**rp)
    if not ic.working_directory:
        ic.working_directory = str(get_home() / name)
    else:
        wd = Path(ic.working_directory).expanduser()
        if not wd.is_absolute():
            wd = get_home() / wd
        ic.working_directory = str(wd)
    return ic


def load_team_config(path: Path | None = None) -> TeamConfig:
    if path is None:
        path = get_home() / "team.yaml"
    if not path.exists():
        raise FileNotFoundError(f"Team config not found: {path}")

    raw = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    defaults = raw.get("defaults", {})

    fc = TeamConfig()
    # Support both top-level and defaults.* for global sections (top-level takes priority)
    if "startup" in raw:
        fc.startup = StartupConfig(**raw["startup"])
    elif "startup" in defaults:
        fc.startup = StartupConfig(**defaults["startup"])

    if "cost_guard" in raw:
        fc.cost_guard = CostGuardConfig(**raw["cost_guard"])
    elif "cost_guard" in defaults:
        fc.cost_guard = CostGuardConfig(**defaults["cost_guard"])

    if "hang_detector" in raw:
        fc.hang_detector = HangDetectorConfig(**raw["hang_detector"])
    elif "hang_detector" in defaults:
        fc.hang_detector = HangDetectorConfig(**defaults["hang_detector"])

    # [1.2.13 P1] MCP server 宣告（top-level 優先，其次 defaults，比照上方各段慣例）
    _mcp_raw = raw.get("mcp_servers") or defaults.get("mcp_servers") or {}
    for _sname, _sraw in (_mcp_raw or {}).items():
        if not isinstance(_sraw, dict):
            raise ValueError(f"mcp_servers.{_sname} 必須是 mapping，實得 {type(_sraw).__name__}")
        fc.mcp_servers[_sname] = McpServerConfig(
            name=_sname,
            command=str(_sraw.get("command") or ""),
            args=[str(a) for a in (_sraw.get("args") or [])],
            env={str(k): str(v) for k, v in (_sraw.get("env") or {}).items()},
            enabled=bool(_sraw.get("enabled", True)),
        )

    # Communication (P2P + tool_detail)
    comm_raw = raw.get("communication", {})
    if comm_raw:
        p2p_raw = comm_raw.get("p2p", {})
        fc.communication = CommunicationConfig(
            p2p=P2PConfig(**p2p_raw) if p2p_raw else P2PConfig(),
            tool_detail=bool(comm_raw.get("tool_detail", False)),
            peer_reply_timeout_minutes=int(comm_raw.get("peer_reply_timeout_minutes", 15)),
            reply_to_origin=bool(comm_raw.get("reply_to_origin", False)),
            dispatch_context_ttl_minutes=int(comm_raw.get("dispatch_context_ttl_minutes", 30)),
        )

    # kiro_files policy
    kf_raw = raw.get("kiro_files", {})
    if kf_raw:
        kf = KiroFilesPolicy()
        steering_raw = kf_raw.get("steering", {})
        if steering_raw:
            if "team_context_md" in steering_raw:
                kf.team_md = steering_raw["team_context_md"]
            if "team_md" in steering_raw:
                kf.team_md = steering_raw["team_md"]
            if "role_md" in steering_raw:
                kf.soul_md = steering_raw["role_md"]
            if "agents_md" in steering_raw:
                kf.agents_md = steering_raw["agents_md"]
            if "soul_md" in steering_raw:
                kf.soul_md = steering_raw["soul_md"]
            if "memory_md" in steering_raw:
                kf.memory_md = steering_raw["memory_md"]
        settings_raw = kf_raw.get("settings", {})
        if settings_raw:
            if "mcp_json" in settings_raw:
                kf.mcp_json = settings_raw["mcp_json"]
        agents_raw = kf_raw.get("agents", {})
        if agents_raw:
            if "agent_json" in agents_raw:
                kf.agent_json = agents_raw["agent_json"]
        prompts_raw = kf_raw.get("prompts", {})
        if prompts_raw:
            if "policy" in prompts_raw:
                kf.prompts_policy = prompts_raw["policy"]
            if "source" in prompts_raw:
                kf.prompts_source = prompts_raw["source"]
        skills_raw = kf_raw.get("skills", {})
        if skills_raw:
            if "policy" in skills_raw:
                kf.skills_policy = skills_raw["policy"]
            if "source" in skills_raw:
                kf.skills_source = skills_raw["source"]
        # [1.2.18] kiro_files.knowledge 區塊已移除 —— shared_wiki / private_wiki
        # 的實作早就拿掉了（backend.py 零引用）。新架構下 agent 各自獨立，
        # 知識庫共用走 `wiki_query` MCP 工具，不靠 symlink/複製。
        # 舊 team.yaml 若仍留著這段，解析時直接忽略（不報錯，不影響啟動）。
        fc.kiro_files = kf

    fc.health_port = raw.get("health_port", _default_port())
    # [1.5.0] 部署模式：env var 優先 → yaml → 預設 "full"
    fc.mode = os.environ.get("ARK_TEAM_MODE") or raw.get("mode", "full")
    fc.project_roots = raw.get("project_roots", {})
    # [1.2.0 N2] 知識庫搜尋順序（top-level 或 defaults）
    fc.knowledge_search_order = list(
        raw.get("knowledge_search_order", defaults.get("knowledge_search_order", []))
    )
    fc.team_doc = raw.get("team_doc", {}) or {}  # [v1.1.3 P1-4]
    # [1.2.23] 私訊路由 —— 原本 TeamConfig 沒有這個欄位，整段設定被靜默丟棄。
    fc.private_chat_routing = raw.get("private_chat_routing", {}) or {}

    # Channel (Telegram) — support both "channel:" and "telegram:" keys
    ch = raw.get("channel", {}) or raw.get("telegram", {})
    if ch:
        ch_keys = {f.name for f in dc_fields(ChannelConfig)}
        fc.channel = ChannelConfig(**{k: v for k, v in ch.items() if k in ch_keys})

    # Access control
    ac = raw.get("access", {})
    if ac:
        ac_keys = {f.name for f in dc_fields(AccessConfig)}
        fc.access = AccessConfig(**{k: v for k, v in ac.items() if k in ac_keys})

    raw_instances = raw.get("instances", {})
    if isinstance(raw_instances, list):
        for item in raw_instances:
            name = item.pop("name", None)
            if name:
                fc.instances[name] = _merge_instance(item, defaults, name, fc.project_roots)
    elif isinstance(raw_instances, dict):
        for name, inst_raw in raw_instances.items():
            fc.instances[name] = _merge_instance(inst_raw or {}, defaults, name, fc.project_roots)

    return fc


def validate_config(config: TeamConfig) -> list[str]:
    """Validate a TeamConfig, returning a list of error messages (empty if valid)."""
    import re
    errors: list[str] = []

    # At least one instance
    if not config.instances:
        errors.append("No instances defined")

    for name, ic in config.instances.items():
        # Valid name
        if not re.match(r"^[A-Za-z0-9_-]+$", name):
            errors.append(f"Invalid instance name: {name!r} (letters/numbers/_/- only)")

        # Working directory set
        if not ic.working_directory:
            errors.append(f"{name}: working_directory is required")

        # Model name format (if specified)
        if ic.model and not re.match(r"^[A-Za-z0-9._:/-]+$", ic.model):
            errors.append(f"{name}: invalid model name {ic.model!r}")

        # Role must be valid
        if ic.role not in ("admin", "manager", "leader", "worker"):
            errors.append(f"{name}: invalid role {ic.role!r} (must be admin/manager/leader/worker)")

        # [ark-agent 2026-08-06] v1.1.0 group 欄位：須指向同 team 內存在的 leader
        if ic.group is not None:
            target = config.instances.get(ic.group)
            if target is None:
                errors.append(f"{name}: group {ic.group!r} not found in team")
            elif target.role != "leader":
                errors.append(f"{name}: group {ic.group!r} must reference a leader (got role={target.role!r})")

        # Restart policy sanity
        if ic.restart_policy.max_retries < 0:
            errors.append(f"{name}: restart_policy.max_retries must be >= 0")
        if ic.restart_policy.health_check_interval_ms < 1000:
            errors.append(f"{name}: restart_policy.health_check_interval_ms must be >= 1000")

    # Cost guard sanity
    if config.cost_guard.daily_limit_usd < 0:
        errors.append("cost_guard.daily_limit_usd must be >= 0")
    if not (0 <= config.cost_guard.warn_at_percentage <= 100):
        errors.append("cost_guard.warn_at_percentage must be in [0, 100]")
    # Validate per_instance_limits keys reference real instances
    for pil_name in config.cost_guard.per_instance_limits:
        if pil_name not in config.instances:
            errors.append(f"cost_guard.per_instance_limits: unknown instance {pil_name!r}")

    # Hang detector sanity
    if config.hang_detector.timeout_minutes < 1:
        errors.append("hang_detector.timeout_minutes must be >= 1")

    # Health port sanity
    if not (1 <= config.health_port <= 65535):
        errors.append(f"health_port must be in [1, 65535], got {config.health_port}")

    # Topic/private_chat uniqueness
    topic_ids: dict[int, str] = {}
    for name, ic in config.instances.items():
        if ic.topic_id is not None:
            tid = int(ic.topic_id)
            if tid in topic_ids:
                errors.append(f"topic_id {tid} duplicated between {topic_ids[tid]!r} and {name!r}")
            topic_ids[tid] = name

    # [1.2.13 P1 / ADR-006] mcp 與 mcp_exclude 引用的名稱必須已宣告 ——
    # 打錯字若靜默失效，症狀是「少一個工具」而沒有任何錯誤，最難察覺。
    # `fetch` 是套件注入的內建 server，允許在 mcp_exclude 中引用以停用。
    # [1.2.20] multi_user 語意檢查 —— 設定靜默無效是最難察覺的錯誤
    #
    # 註：「instance 名不得含 `~`」不需另加檢查 —— 上方的名稱正則
    # `^[A-Za-z0-9_-]+$` 已經擋掉。這裡留註解說明它現在多了一層意義：
    # `~` 是衍生 session 的分隔符，本體名若含它會與 session key 混淆。
    # （衍生 session 名確實含 `~`，但它們是執行期才加進 config.instances 的，
    #   `validate_config` 在載入期跑，兩者不會相遇。）
    for name, ic in config.instances.items():
        if getattr(ic, "multi_user", False) and not ic.private_chat:
            errors.append(
                f"instance {name!r}: multi_user=true 但未設 private_chat —— "
                "衍生 session 只在私訊路由時觸發，這個設定永遠不會生效"
            )
        _limit = getattr(ic, "max_user_sessions", 5)
        if _limit < 1:
            errors.append(
                f"instance {name!r}: max_user_sessions 必須 >= 1，得到 {_limit}"
            )

    _BUILTIN_MCP = {"fetch", "team"}
    for name, ic in config.instances.items():
        for field_name in ("mcp", "mcp_exclude"):
            for sname in getattr(ic, field_name, []) or []:
                if sname in config.mcp_servers or sname in _BUILTIN_MCP:
                    continue
                errors.append(
                    f"instance {name!r}: {field_name} 引用的 {sname!r} 未在 mcp_servers 宣告"
                )

    # mcp_servers 各項必須有 command（enabled=False 者不檢查 —— 停用中不需可用）
    for sname, sc in config.mcp_servers.items():
        if sc.enabled and not sc.command:
            errors.append(f"mcp_servers.{sname}: command 不可為空")

    return errors


# [ark-agent 2026-08-07] v1.1.3 貫穿性 C：語意檢查（改名後忘同步 → 啟動即擋）
def validate_scheduler_targets(config: TeamConfig, scheduler: "SchedulerConfig") -> list[str]:
    """scheduler 每個 job 的 target 必須是有效 instance（`_builtin:` 除外）。"""
    errors: list[str] = []
    for job in scheduler.jobs:
        target = job.target or ""
        if target.startswith("_builtin:"):
            continue
        if target not in config.instances:
            errors.append(f"scheduler job {job.name!r}: target {target!r} 不是有效 instance")
    return errors


def validate_matrix_owners(config: TeamConfig, matrix: dict) -> list[str]:
    """authority-matrix L2 各域的 owner/first/final/fallback 必須是有效 instance。

    跳過範本佔位符（`<...>`）—— 範本尚未填值不視為錯誤。
    """
    errors: list[str] = []
    l2 = (matrix.get("levels") or {}).get("L2") or {}
    for domain, cfg in l2.items():
        if not isinstance(cfg, dict):
            continue
        for key in ("owner", "first", "final", "fallback"):
            v = cfg.get(key)
            if not v or (isinstance(v, str) and v.startswith("<")):
                continue  # 未設或佔位符 → 跳過
            if v not in config.instances:
                errors.append(f"authority-matrix L2.{domain}.{key}: {v!r} 不是有效 instance")
    return errors
