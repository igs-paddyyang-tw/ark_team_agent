"""team manager — high-level multi-instance orchestration."""
from __future__ import annotations

import asyncio
import logging
import os
import signal
import sys
import time
from pathlib import Path

from .config import TeamConfig, get_home, load_team_config
from .daemon import Daemon, InstanceStatus

try:
    import uvicorn
except ImportError:
    uvicorn = None  # type: ignore[assignment]

log = logging.getLogger(__name__)


class TeamManager:
    """Top-level team orchestrator wrapping the Daemon."""

    def __init__(self, config: TeamConfig) -> None:
        self.config = config
        self.daemon = Daemon(config)
        self._started_at: float = 0

    # ── Team lifecycle ─────────────────────────────────────────

    async def start(self) -> dict[str, bool]:
        self._started_at = time.time()
        log.info("Starting team (%d instances)…", len(self.config.instances))
        results = await self.daemon.start_all()
        ok = sum(1 for v in results.values() if v)
        log.info("Team ready: %d/%d instances running", ok, len(results))
        return results

    async def stop(self) -> None:
        log.info("Stopping team…")
        await self.daemon.stop_all()
        log.info("Team stopped")

    async def restart(self, name: str | None = None) -> None:
        if name:
            await self.daemon.restart_instance(name)
        else:
            for n in list(self.config.instances):
                await self.daemon.restart_instance(n)

    # ── Instance operations ─────────────────────────────────────

    async def start_instance(self, name: str) -> None:
        await self.daemon.start_instance(name)

    async def stop_instance(self, name: str) -> None:
        await self.daemon.stop_instance(name)

    async def send_to_instance(self, name: str, text: str) -> bool:
        return await self.daemon.send_message(name, text)

    # ── Status ──────────────────────────────────────────────────

    def status(self) -> dict:
        instances = self.daemon.get_status()
        running = sum(1 for i in instances if i["status"] == "running")
        return {
            "uptime": time.time() - self._started_at if self._started_at else 0,
            "total": len(instances),
            "running": running,
            "instances": instances,
        }

    def list_instances(self) -> list[dict]:
        return self.daemon.get_status()

    # ── Config reload ───────────────────────────────────────────

    async def reload_config(self, path: Path | None = None) -> dict:
        """Reload team.yaml with schema validation + failure rollback.

        Returns a dict with reload summary:
          {"ok": bool, "errors": [...], "added": [...], "removed": [...]}

        On validation failure, old config is kept untouched.
        """
        from .config import validate_config

        try:
            new_config = load_team_config(path)
        except Exception as e:
            log.error("Config load failed: %s", e)
            return {"ok": False, "errors": [f"Load failed: {e}"],
                    "added": [], "removed": []}

        # Validate before touching any instance
        errors = validate_config(new_config)
        if errors:
            log.error("Config validation failed: %s", errors)
            return {"ok": False, "errors": errors, "added": [], "removed": []}

        old_names = set(self.config.instances)
        new_names = set(new_config.instances)

        # Snapshot for rollback
        old_config = self.config
        added: list[str] = []
        removed: list[str] = []
        started_new: list[str] = []

        try:
            # Remove instances no longer in config
            for name in old_names - new_names:
                log.info("Removing instance %s", name)
                await self.daemon.stop_instance(name)
                self.daemon.instances.pop(name, None)
                removed.append(name)

            # Activate new config
            self.config = new_config
            self.daemon.config = new_config

            # Start newly-added instances
            for name in new_names - old_names:
                log.info("Adding instance %s", name)
                try:
                    await self.daemon.start_instance(name)
                    started_new.append(name)
                    added.append(name)
                except Exception as e:
                    log.warning("Failed to start new instance %s: %s", name, e)
                    added.append(name)  # still reported as attempted

            log.info("Config reloaded (+%d -%d)", len(added), len(removed))

            # Update DaemonAPI routing maps (private_chat / topic)
            if hasattr(self, "_daemon_api") and self._daemon_api:
                self._daemon_api._private_chat_map = {
                    n: ic.private_chat for n, ic in new_config.instances.items() if ic.private_chat
                }
                self._daemon_api._topic_map = {
                    n: int(ic.topic_id) for n, ic in new_config.instances.items() if ic.topic_id is not None
                }

            return {"ok": True, "errors": [], "added": added, "removed": removed}

        except Exception as e:
            # Best-effort rollback
            log.error("Reload failed mid-way, rolling back: %s", e)
            self.config = old_config
            self.daemon.config = old_config
            # Try to stop any new instances we started
            for name in started_new:
                try:
                    await self.daemon.stop_instance(name)
                    self.daemon.instances.pop(name, None)
                except Exception:
                    pass
            return {
                "ok": False,
                "errors": [f"Reload failed, rolled back: {e}"],
                "added": [],
                "removed": [],
            }


def _should_auto_create_topic(ic) -> bool:
    """判斷 instance 是否需自動建立 forum topic（v1.1.0）。

    有 group 歸屬的 worker 不建自己的 topic — 輸出改走所屬 leader 的 topic。
    general_topic 的 instance 綁定 General，不另建 topic（v1.1.1 P1-7）。

    Author: ark-agent
    """
    return (ic.topic_id is None
            and not ic.private_chat
            and not getattr(ic, "group", None)
            and not getattr(ic, "general_topic", False))


def _pick_trigger_instance(config) -> str | None:
    """啟動/重啟後要自動觸發的入口 instance（v1.1.8）。

    多 leader 架構下不挑「第一個 leader」（會漏其他組）。
    改為優先 general_topic 入口（唯一的協調者），退回第一個 leader，再退回第一個 admin/manager。

    Author: ark-agent
    """
    insts = config.instances
    for name, ic in insts.items():
        if getattr(ic, "general_topic", False):
            return name
    for name, ic in insts.items():
        if ic.role == "leader":
            return name
    for name, ic in insts.items():
        if (ic.role or "") in ("admin", "manager"):
            return name
    return None


async def run_team(config_path: Path | None = None) -> None:
    """Main entry point — load config, start team, handle signals."""
    # [1.3.1] 補 logging —— `run_team()` 原本完全不設，而它是 README 教大家用的
    # **公開入口**（各部署的 `start.py` 就是 `asyncio.run(run_team(...))`）。
    #
    # 後果：root logger 沒有 handler、level 停在預設 WARNING →
    # **所有 INFO 全部消失**，只有 WARNING+ 靠 Python 的 lastResort 漏到 stderr。
    #
    # 實測（2026-08-17）：aiops / director / paddy 三個服務（共 21 個 agent）的
    # journal 近一小時只有 7 行、**0 行 INFO**，而走 CLI 入口的 nana 有 238 行。
    # 看不到的包括：`⏰ scheduler` 觸發、agent 就緒／崩潰、MCP 掛載與預檢、
    # degraded 告警細節 —— 等於整個團隊在盲飛，而 `/api/health` 看起來很健康。
    #
    # ⚠️ `if not handlers` 的判斷不可省：CLI 入口（`cli.main()`）已經呼叫過
    # `_setup_logging()`，無條件覆蓋會踩掉它與使用者自訂的設定。
    if not logging.getLogger().handlers:
        from .json_logging import setup_logging
        setup_logging(level=os.environ.get("ARK_LOG_LEVEL", "INFO"),
                      json_mode=os.environ.get("ARK_JSON_LOG", "").lower() in ("1", "true", "yes"))
        log.info("logging 由 run_team() 初始化（level=%s）—— "
                 "呼叫端未設 handler。要調整用 ARK_LOG_LEVEL／ARK_JSON_LOG。",
                 os.environ.get("ARK_LOG_LEVEL", "INFO"))

    # Load .env from ark_team_agent_HOME (override inherited env vars)
    env_file = get_home() / ".env"
    if env_file.exists():
        for line in env_file.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                os.environ[k.strip()] = v.strip()
        log.info("Loaded .env from %s", env_file)

    config = load_team_config(config_path)

    # [ark-agent 2026-08-07] v1.1.3 貫穿性 C：啟動時語意檢查（scheduler.target / matrix owner 須為有效 instance）
    # best-effort：檔案不存在或載入失敗不阻斷啟動，只記警告
    _semantic_warn: list[str] = []
    try:
        from .config import load_scheduler_config, validate_scheduler_targets
        _semantic_warn += validate_scheduler_targets(config, load_scheduler_config())
    except FileNotFoundError:
        pass
    except Exception as e:  # noqa: BLE001
        log.warning("scheduler target 檢查略過：%s", e)
    try:
        import yaml as _yaml
        from .config import validate_matrix_owners
        _mx = get_home() / "config" / "authority-matrix.yml"
        if _mx.exists():
            _semantic_warn += validate_matrix_owners(
                config, _yaml.safe_load(_mx.read_text(encoding="utf-8")) or {}
            )
    except Exception as e:  # noqa: BLE001
        log.warning("matrix owner 檢查略過：%s", e)
    for _w in _semantic_warn:
        log.warning("⚠️ 設定語意檢查：%s", _w)

    manager = TeamManager(config)
    tg_adapter = None

    loop = asyncio.get_running_loop()
    stop_event = asyncio.Event()

    def _handle_stop() -> None:
        log.info("Received stop signal")
        stop_event.set()

    def _handle_reload() -> None:
        asyncio.ensure_future(manager.reload_config(config_path))

    if sys.platform != "win32":
        for sig in (signal.SIGTERM, signal.SIGINT):
            loop.add_signal_handler(sig, _handle_stop)
        loop.add_signal_handler(signal.SIGHUP, _handle_reload)

    # [1.3.3] 開場就把「誰會拉起我」講出來，並清掉上一輪的殘留 flag。
    # 為什麼要記 log：實測有人回報「TG 重啟壞了 —— 寫 flag 但沒人讀」，
    # 結論是錯的（Linux 靠 SIGTERM + systemd），但**推論完全合理** ——
    # 程式碼裡看得到 flag 的讀取者，而那些讀取者在現行部署裡沒在跑，
    # 加上磁碟躺著幾天前的殘留 flag。這一行 log 讓下一個人不用猜。
    from .restart import clear_stale_flag, describe_supervisor
    log.info("重啟機制：%s", describe_supervisor())
    clear_stale_flag(reason="啟動")

    # Write PID
    pid_file = get_home() / "team.pid"
    pid_file.parent.mkdir(parents=True, exist_ok=True)
    pid_file.write_text(str(os.getpid()))

    # Pre-declare variables referenced in finally block
    daemon_api = None
    cleanup_task: asyncio.Task | None = None
    cost_reset_task: asyncio.Task | None = None
    daily_summary_task: asyncio.Task | None = None
    heartbeat_task: asyncio.Task | None = None
    website_server: asyncio.Task | None = None

    try:
        # Start Daemon API FIRST (team MCP needs port ready before agents start)
        from .api import DaemonAPI
        topic_map = {n: int(ic.topic_id) for n, ic in config.instances.items() if ic.topic_id is not None}
        private_chat_map = {n: ic.private_chat for n, ic in config.instances.items() if ic.private_chat}
        daemon_api = DaemonAPI(manager.daemon, topic_map=topic_map, private_chat_map=private_chat_map,
                               team_manager=manager)
        manager._daemon_api = daemon_api  # for reload to update routing maps
        daemon_api.tg = None  # will be set after Telegram starts
        await daemon_api.start(port=config.health_port)
        log.info("Daemon API started on port %d (before agents)", config.health_port)

        # Start team-website (Admin Dashboard + Landing + Wiki + Chat)
        website_port = config.health_port + 300  # 23030 → 23330
        try:
            website_dir = get_home() / "apps" / "team-website"
            if (website_dir / "src" / "main.py").exists():
                import sys as _sys
                # Add website dir to path so 'src' package is importable
                if str(website_dir) not in _sys.path:
                    _sys.path.insert(0, str(website_dir))
                # Ensure DAEMON_API_URL points to our daemon
                os.environ["DAEMON_API_URL"] = f"http://127.0.0.1:{config.health_port}"
                # Change cwd temporarily for template/static resolution
                _prev_cwd = os.getcwd()
                os.chdir(str(website_dir))
                try:
                    from src.main import app as website_app  # noqa: E402
                finally:
                    os.chdir(_prev_cwd)

                website_config = uvicorn.Config(
                    website_app,
                    host="127.0.0.1",
                    port=website_port,
                    log_level="warning",
                    access_log=False,
                )
                _website_uvicorn = uvicorn.Server(website_config)
                website_server = asyncio.create_task(_website_uvicorn.serve())
                for _ in range(30):
                    if _website_uvicorn.started:
                        break
                    await asyncio.sleep(0.1)
                log.info("Team Website started on port %d", website_port)
            else:
                log.debug("Team Website not found at %s, skipping", website_dir)
        except Exception as e:
            log.warning("Failed to start Team Website: %s", e)

        # Start heartbeat loop (freeze detection for external watchdog)
        from .heartbeat import heartbeat_loop
        from .config import get_state_dir
        heartbeat_task = asyncio.create_task(heartbeat_loop(get_state_dir()))

        # Now start agents (MCP server can reach daemon API)
        await manager.start()

        # Start Telegram bot if channel is configured AND mode is not headless
        tg_adapter = None
        if config.channel.bot_token_env and config.mode != "headless":
            try:
                from .telegram import TelegramAdapter, TelegramConfig
                tg_cfg = TelegramConfig(
                    bot_token_env=config.channel.bot_token_env,
                    group_id=config.channel.group_id or 0,
                    general_topic_id=config.channel.general_topic_id,
                    allowed_users=config.access.allowed_users,
                    mode=config.access.mode,
                )
                tg_adapter = TelegramAdapter(tg_cfg, manager.daemon)

                # Initialize SQLite message store for persistent outbox
                from .message_store import MessageStore
                from .config import get_state_dir
                msg_store = MessageStore(
                    send_fn=lambda **kw: tg_adapter._app.bot.send_message(**kw),
                    db_path=str(get_state_dir() / "message_queue.db"),
                )
                tg_adapter._message_store = msg_store
                # Bind topic_id → instance and private_chat → instance
                for name, ic in config.instances.items():
                    if ic.topic_id is not None and config.channel.group_id:
                        tg_adapter.bind_topic(int(ic.topic_id), name, general=ic.general_topic)
                    if ic.private_chat:
                        tg_adapter.bind_private_chat(name, ic.private_chat)
                await tg_adapter.start()
                # [ark-agent 2026-08-07] v1.1.3 P1-6：啟動前預檢 bot 群組權限 → 降級清單 + 明確告警
                try:
                    _pf = await tg_adapter.preflight_check()
                    for _w in _pf:
                        if _w not in manager.daemon.degraded:
                            manager.daemon.degraded.append(_w)
                        log.warning("⚠️ 降級告警（preflight）：%s", _w)
                except Exception as e:  # noqa: BLE001
                    log.warning("preflight_check 略過：%s", e)
                # Start persistent message store drain loop
                await msg_store.start()
                # Auto-create forum topics for instances without topic_id
                # Persist topic mappings to state/topics.json to avoid orphan topics on restart
                if config.channel.group_id:
                    import json as _json
                    _topic_state_path = get_home() / "state" / "topics.json"
                    _saved_topics: dict[str, int] = {}
                    if _topic_state_path.exists():
                        try:
                            _saved_topics = _json.loads(_topic_state_path.read_text(encoding="utf-8"))
                        except Exception:
                            _saved_topics = {}

                    _topics_changed = False
                    for name, ic in config.instances.items():
                        # [ark-agent 2026-08-06] v1.1.1 P1-7：general_topic instance 自動綁 General，不建新 topic
                        if getattr(ic, "general_topic", False) and ic.topic_id is None:
                            ic.topic_id = config.channel.general_topic_id or 1
                            tg_adapter.bind_topic(int(ic.topic_id), name, general=True)
                            log.info("Bound general_topic instance %s to General topic %s", name, ic.topic_id)
                            continue
                        # [ark-agent 2026-08-06] v1.1.0：有 group 歸屬的 worker 不建自己的 topic，輸出走所屬 leader 的 topic
                        if _should_auto_create_topic(ic):
                            # Check persisted state first
                            if name in _saved_topics:
                                tid = _saved_topics[name]
                                ic.topic_id = tid
                                tg_adapter.bind_topic(tid, name, general=ic.general_topic)
                                log.info("Restored topic %d for %s from state", tid, name)
                            else:
                                # Build display name from description (emoji + short name)
                                display_name = ic.description.split("—")[0].strip() if ic.description and "—" in ic.description else name
                                tid = await tg_adapter.create_topic_for_instance(name, display_name)
                                if tid:
                                    ic.topic_id = tid
                                    _saved_topics[name] = tid
                                    _topics_changed = True

                    # Persist updated state
                    if _topics_changed or not _topic_state_path.exists():
                        _topic_state_path.parent.mkdir(parents=True, exist_ok=True)
                        _topic_state_path.write_text(
                            _json.dumps(_saved_topics, indent=2, ensure_ascii=False),
                            encoding="utf-8",
                        )
                    # Sync restored/new topics to DaemonAPI routing map
                    if daemon_api:
                        daemon_api._topic_map = {
                            n: int(ic.topic_id) for n, ic in config.instances.items() if ic.topic_id is not None
                        }
                tg_adapter.start_output_polling()
                # Wire hang detection callbacks
                manager.daemon.on_hang_detected = tg_adapter.notify_hang
                manager.daemon.on_hang_escalated = tg_adapter.notify_hang_escalation
                manager.daemon.on_instance_recovered = tg_adapter.notify_recovery

                # Start team scheduler
                from .scheduler import TeamScheduler
                from .config import load_scheduler_config
                sched_config = load_scheduler_config()
                # [1.2.6] 注入專案根（team.yaml 就是從這讀的）→ scheduler 不必自行推導
                from .config import get_home as _get_home
                scheduler = TeamScheduler(manager.daemon, config=sched_config,
                                          project_root=_get_home())
                scheduler.start()
                log.info("Telegram bot connected (group=%s)", config.channel.group_id or "private-only")

                # 🔴 [1.4.7] **立刻 link，不要等到這個函式尾端。**
                #
                # 原本 `daemon_api.tg = tg_adapter` 在整段啟動流程的最後才執行，
                # 而下面那個刻意的 `sleep(10)`（等重啟中的 agent 安定才發啟動訊息）
                # 就落在中間 —— 那 10 秒內 agent 已經在跑、已經可以回覆，
                # 但 `DaemonAPI.tg` 還是 None → 回覆被丟掉。
                #
                # 實測（paddy 2026-08-19 01:25）：
                #   01:25:02 Telegram bot connected
                #   01:25:03 WARNING 💬 REPLY leader-agent: no telegram adapter  ← 訊息掉了
                #   01:25:12 Daemon API: Telegram adapter linked
                # `/api/reply` 的重試只等 3 秒，而缺口是 10 秒 → **必然失敗**。
                #
                # 那個 sleep 是為了「發啟動訊息的時機」，與「adapter 可不可用」無關。
                # 沒有理由在這段時間扣住這個參照。（尾端仍會再指派一次，冪等。）
                daemon_api.tg = tg_adapter
                tg_adapter._daemon_api = daemon_api
                log.info("Daemon API: Telegram adapter linked（啟動訊息前）")

                # Send startup messages — wait for in-flight restarts to settle
                # (agents that failed first attempt may be restarting via _health_loop)
                await asyncio.sleep(10)
                status = manager.daemon.get_status()

                # Build codenames dynamically from instance descriptions
                # Format: "{emoji} {代號} — {職稱}" → startup shows "{emoji} {代號} {職稱}"
                from .telegram import TelegramAdapter
                _dyn_codenames, _dyn_titles = TelegramAdapter._build_codenames(config)

                def _get_startup_codename(name: str) -> str:
                    """Startup display: codename + full title.
                    e.g. "👑 KIRO" + "技術長" → "👑 KIRO 技術長"
                    """
                    if name in _dyn_codenames:
                        cn = _dyn_codenames[name]
                        title = _dyn_titles.get(name, "")
                        return f"{cn} {title}".strip() if title else cn
                    return f"🤖 {name}"

                TITLES = {}

                def _build_lines(exclude_names=(), only_names=None, *, show_title: bool = True):
                    out = []
                    for s in status:
                        if s["name"] in exclude_names:
                            continue
                        if only_names and s["name"] not in only_names:
                            continue
                        n = s["name"]
                        codename = _get_startup_codename(n)
                        st = s["status"]
                        st_icon = {"running": "🟢", "stopped": "⚪", "crashed": "🔴", "starting": "🟡", "paused": "⏸"}.get(st, "❓")
                        out.append(f"  {codename}  {st_icon}")
                    return out

                def _startup_msg(lines, running, total, failed_names=None):
                    import datetime as _dt_s
                    try:
                        from zoneinfo import ZoneInfo
                        tz = ZoneInfo(config.cost_guard.timezone)
                    except Exception:
                        tz = None
                    now_str = _dt_s.datetime.now(tz=tz).strftime("%H:%M:%S")

                    # 預算資訊
                    budget_str = ""
                    if config.cost_guard.daily_limit_usd > 0:
                        budget_str = f"\n💰 今日預算：<b>${config.cost_guard.daily_limit_usd:.2f}</b> 可用"

                    if failed_names:
                        # 部分失敗版本
                        ok_names = [s["name"] for s in status if s["name"] not in failed_names and s["name"] in {s2["name"] for s2 in status}]
                        ok_codenames = " · ".join(
                            _dyn_codenames.get(n, n).split("（")[0].strip() for n in ok_names
                        )
                        fail_codenames = " · ".join(
                            f"<b>{_dyn_codenames.get(n, n).split('（')[0].strip()}（{n.replace('-agent','')}）</b>"
                            for n in failed_names
                        )
                        msg = (
                            f"⚠️ <b>AI Team 就緒（{running}/{total}）</b>\n\n"
                            f"✅ 正常：{ok_codenames}\n"
                            f"❌ 失敗：{fail_codenames}\n\n"
                            f"💡 失敗的 agent 30 秒後自動重啟，或傳 /restart 強制全員重啟"
                        )
                        return msg

                    # 按 role 分組顯示
                    mgmt_names, leader_names, worker_names = [], [], []
                    for inst_name, ic in config.instances.items():
                        cn = _dyn_codenames.get(inst_name, inst_name).split("（")[0].strip()
                        r = getattr(ic, "role", "worker")
                        if r in ("admin", "manager"):
                            mgmt_names.append(cn)
                        elif r == "leader":
                            leader_names.append(cn)
                        else:
                            worker_names.append(cn)

                    group_block = ""
                    if mgmt_names:
                        group_block += f"👑 <b>指揮層</b>　{' · '.join(mgmt_names)}\n"
                    if leader_names:
                        group_block += f"📋 <b>專案層</b>　{' · '.join(leader_names)}\n"
                    if worker_names:
                        group_block += f"⚙️ <b>執行層</b>　{' · '.join(worker_names)}\n"

                    # [v1.1.5 FR-5] 移除語意混亂的「MCP 工具：N 個 agent」行；入口代號去硬編碼
                    _entry = tg_adapter._entry_codename() if tg_adapter else "管家"
                    msg = (
                        f"✅ <b>AI Team 就緒</b> — {running}/{total} 全員到位\n\n"
                        f"{group_block}"
                        f"{budget_str}"
                        f"\n🕐 啟動時間：{now_str}\n\n"
                        f"<i>直接在私訊跟{_entry}說話，或用 @mention 指定 agent</i>"
                    )
                    return msg

                # 1. Group topic notification (group mode only)
                if config.channel.group_id:
                    # 系統通知包含所有 agent（不排除有 private_chat 的）
                    group_names = set(config.instances.keys())
                    group_lines = _build_lines(exclude_names=set())
                    group_running = sum(1 for s in status if s["status"] in ("running", "awaiting_reply", "idle") and s["name"] in group_names)
                    # [2026-07-29] 只計算真正異常的狀態（排除 awaiting_reply，避免誤報）
                    _FAILED_STATUSES = {"crashed", "stopped"}
                    group_failed = [s["name"] for s in status
                                    if s["status"] in _FAILED_STATUSES and s["name"] in group_names]

                    # 系統通知送到 General Topic（thread_id=1）
                    general_tid = config.channel.general_topic_id or 1
                    try:
                        await tg_adapter._send_to_topic(
                            general_tid,
                            _startup_msg(group_lines, group_running, len(group_names), group_failed),
                            parse_mode="HTML",
                        )
                    except Exception:
                        pass

                # 2. Private chat notification — 每個 chat_id 只送一次（去重）
                notified_chats: set[int] = set()
                for name, ic in config.instances.items():
                    if ic.private_chat and ic.private_chat not in notified_chats:
                        notified_chats.add(ic.private_chat)
                        try:
                            all_lines = _build_lines(show_title=False)
                            total_running = sum(1 for s in status if s["status"] in ("running", "awaiting_reply", "idle"))
                            total_failed = [s["name"] for s in status if s["status"] in {"crashed", "stopped"}]
                            await tg_adapter._send_to_private(
                                ic.private_chat,
                                _startup_msg(all_lines, total_running, len(status), total_failed),
                                parse_mode="HTML",
                            )
                        except Exception:
                            pass

                # 3. Auto-trigger 入口 instance（v1.1.8：優先 general_topic，多 leader 不挑第一個）
                leader_instance = _pick_trigger_instance(config)

                if leader_instance:
                    from datetime import datetime
                    try:
                        from zoneinfo import ZoneInfo
                        tz = ZoneInfo(config.cost_guard.timezone)
                    except Exception:
                        tz = None
                    today = datetime.now(tz).strftime("%Y-%m-%d")

                    is_restart = False
                    try:
                        from .event_log import get_event_log, EventType
                        today_starts = get_event_log().query(
                            instance=leader_instance,
                            event_type=EventType.START.value,
                            limit=5,
                        )
                        is_restart = len(today_starts) > 1
                    except Exception:
                        pass

                    # 重啟時補送 General Topic 重啟通知（取代啟動通知）
                    if is_restart and config.channel.group_id and tg_adapter:
                        general_tid = config.channel.general_topic_id or 1
                        restart_msg = (
                            f"🔄 <b>AI Team 重啟完成</b> — {total_running}/{len(status)}\n\n"
                            f"📋 團隊正在讀取進度，恢復前次工作中...\n\n"
                            f"<i>如有任務中斷，請重新說明需求</i>"
                        )
                        try:
                            await tg_adapter._send_to_topic(
                                general_tid, restart_msg, parse_mode="HTML",
                            )
                        except Exception:
                            pass

                    if is_restart:
                        prompt = (
                            "🔄 服務已重啟。請先判斷是否有『中斷、需接續』的任務：\n"
                            "1. 讀取 memory.md / 任務板，檢查有無未完成且需接續的項目\n"
                            "2. 有中斷任務 → 繼續追蹤，並用 reply 簡短回報接續了什麼\n"
                            "3. 無中斷任務 → 保持安靜，**不需 reply**（避免無意義通報噪音）\n"
                            "不需要重新派工。"
                        )
                    else:
                        prompt = (
                            f"📋 新的一天開始（{today}）：\n"
                            "1. query_team_status 確認全員狀態\n"
                            "2. 讀取 memory.md 確認昨日進度與今日計劃\n"
                            "3. 依優先序發派今日任務\n"
                            "4. 更新 memory.md 記錄派工內容\n"
                            "完成後用 reply 回報今日計劃摘要。"
                        )

                    try:
                        await manager.daemon.send_message(leader_instance, prompt)
                        log.info("Auto-triggered leader (%s): %s",
                                 "restart" if is_restart else "first-boot", leader_instance)
                    except Exception as e:
                        log.warning("Failed to auto-trigger leader: %s", e)
            except Exception as e:
                log.error("Failed to start Telegram bot: %s", e)

        # Daemon API already started above, just set tg reference
        # [1.4.7] 這裡保留為**冪等收尾** —— 正常路徑已在 TG 連上時就 link 過了
        # （見上方註解）。這一次覆蓋同樣的值，用途是涵蓋「TG 啟動拋例外」的分支。
        daemon_api.tg = tg_adapter
        if tg_adapter:
            tg_adapter._daemon_api = daemon_api
        log.info("Daemon API: Telegram adapter linked（收尾確認）")

        # Start event log cleanup loop (purge > 30 days)
        from .event_log import get_event_log
        cleanup_task = asyncio.create_task(get_event_log().cleanup_loop(interval_hours=6))

        # Start CostGuard if daily limit is configured
        cost_reset_task: asyncio.Task | None = None
        cost_guard = None
        if config.cost_guard.daily_limit_usd > 0:
            from .config import get_state_dir
            from .cost_guard import CostGuard
            cost_guard = CostGuard(
                db_path=get_state_dir() / "costs.db",
                daily_limit_usd=config.cost_guard.daily_limit_usd,
                warn_at_percentage=config.cost_guard.warn_at_percentage,
                tz_name=config.cost_guard.timezone,
                per_instance_limits=config.cost_guard.per_instance_limits,
            )
            manager.daemon.cost_guard = cost_guard

            async def _on_pause(instance: str, spent: float) -> None:
                await manager.daemon.pause_instance(instance)
                if tg_adapter:
                    await tg_adapter.notify_cost_pause(instance, spent)

            async def _on_resume(instance: str) -> None:
                await manager.daemon.resume_instance(instance)
                # [v1.1.5 FR-3 / N8] 移除午夜成本恢復推播（預期行為＋N7 已預告恢復時間，凌晨推播是純噪音）
                # 恢復仍會執行（resume_instance），只是不再主動發訊息。

            cost_guard.on_pause = _on_pause
            cost_guard.on_resume = _on_resume
            if tg_adapter:
                cost_guard.on_warn = tg_adapter.notify_cost_warn
            cost_reset_task = asyncio.create_task(cost_guard.reset_loop())
            log.info("Cost guard active: $%.2f/day, warn at %d%%",
                     config.cost_guard.daily_limit_usd,
                     config.cost_guard.warn_at_percentage)

        # Start daily summary loop (posts to General Topic at 21:00 local time)
        daily_summary_task: asyncio.Task | None = None
        if tg_adapter:
            from .daily_summary import run_daily_summary_loop

            # 每日摘要送到 General Topic
            summary_topic: int = config.channel.general_topic_id or 1

            if summary_topic and config.channel.group_id:
                async def _send_summary(text: str) -> None:
                    try:
                        await tg_adapter._send_to_topic(summary_topic, text, parse_mode="HTML")
                    except Exception as e:
                        log.warning("Failed to post daily summary: %s", e)

                daily_summary_task = asyncio.create_task(
                    run_daily_summary_loop(
                        event_log=get_event_log(),
                        cost_guard=cost_guard,
                        send_callback=_send_summary,
                        hour=21,
                        minute=0,
                        tz_name=config.cost_guard.timezone,
                    )
                )
                log.info("Daily summary scheduled at 21:00 %s", config.cost_guard.timezone)

        if sys.platform == "win32":
            # Windows: poll for stop_event + restart.flag + config hot-reload
            restart_flag = get_home() / "restart.flag"
            config_file = (config_path or get_home() / "team.yaml")
            last_mtime = config_file.stat().st_mtime if config_file.exists() else 0
            reload_cooldown = 0.0
            while not stop_event.is_set():
                # Check restart.flag for graceful shutdown (watchdog writes this)
                if restart_flag.exists():
                    log.info("restart.flag detected — initiating graceful shutdown")
                    try:
                        restart_flag.unlink()
                    except OSError:
                        pass
                    break
                # Hot-reload: detect team.yaml changes
                if config_file.exists():
                    current_mtime = config_file.stat().st_mtime
                    if current_mtime > last_mtime and time.time() > reload_cooldown:
                        log.info("team.yaml changed — triggering hot reload")
                        last_mtime = current_mtime
                        reload_cooldown = time.time() + 10  # cooldown 10s
                        result = await manager.reload_config(config_path)
                        if result["ok"]:
                            log.info("Hot reload success: +%d -%d", len(result["added"]), len(result["removed"]))
                        else:
                            log.warning("Hot reload failed: %s", result["errors"])
                await asyncio.sleep(1)
        else:
            await stop_event.wait()
    except KeyboardInterrupt:
        log.info("Ctrl+C received")
    except asyncio.CancelledError:
        log.info("Task cancelled")
    finally:
        if tg_adapter:
            try:
                await tg_adapter.stop()
            except Exception:
                pass
        if daemon_api:
            try:
                await daemon_api.stop()
            except Exception:
                pass
        if cleanup_task:
            try:
                cleanup_task.cancel()
            except Exception:
                pass
        if cost_reset_task:
            try:
                cost_reset_task.cancel()
            except Exception:
                pass
        if daily_summary_task:
            try:
                daily_summary_task.cancel()
            except Exception:
                pass
        if heartbeat_task:
            try:
                heartbeat_task.cancel()
            except Exception:
                pass
        if website_server:
            try:
                website_server.cancel()
            except Exception:
                pass
        await manager.stop()
        pid_file.unlink(missing_ok=True)
        # [1.3.3] 收尾清 flag —— 但 **wrapper 環境不能清**：那份 flag 正是要給
        # start-team.sh 的 while loop 讀的，清了它就不會重啟。
        try:
            from .restart import clear_stale_flag, detect_supervisor
            if not detect_supervisor()[2]:      # consumed=False → 沒人要讀
                clear_stale_flag(reason="收尾")
        except Exception:  # noqa: BLE001 — 收尾不可因此拋例外
            pass

        # Suppress Windows ProactorEventLoop GC warnings on unclosed transports
        if sys.platform == "win32":
            await asyncio.sleep(0.1)  # let pending callbacks drain
            import gc
            gc.collect()
