"""路徑定位工具 — 取代不可靠的 `.parent` 層數推導。

[1.2.6] 依 `docs/reports/2026-08-10-project-root-resolution-bug.md`：

用「數幾層 `.parent`」定位專案根，在**原始碼樹**與 **site-packages** 兩種佈局下深度不同，
同一個數字不可能同時正確，且失效時不拋例外（安靜指向 `.venv/lib/python3.x`）。

本模組提供兩件事：
- `find_project_root()` — 哨兵（預設 `team.yaml`）向上搜尋；找不到**拋錯**，不回傳猜測值
- `package_asset()` — 定位隨套件發布的資產（與部署方式無關）

**套件不該從自身位置反推使用者的專案根** —— 呼叫端已知專案根時應注入；
未注入才退回 `resolve_project_root()`（env `ARK_TEAM_AGENT_HOME` → cwd 向上找哨兵）。
"""
from __future__ import annotations

from pathlib import Path

DEFAULT_SENTINEL = "team.yaml"


def find_project_root(start: Path | str, sentinel: str = DEFAULT_SENTINEL) -> Path:
    """由 start 向上搜尋含哨兵檔的目錄，回傳專案根。

    找不到就拋 RuntimeError —— 靜默取得錯誤的根目錄正是本缺陷的成因。

    Author: ark-agent
    """
    origin = Path(start).resolve()
    base = origin if origin.is_dir() else origin.parent
    for candidate in (base, *base.parents):
        if (candidate / sentinel).exists():
            return candidate
    raise RuntimeError(
        f"找不到專案根：自 {origin} 向上搜尋不到哨兵檔 {sentinel!r}"
    )


def resolve_project_root(explicit: Path | str | None = None,
                         sentinel: str = DEFAULT_SENTINEL) -> Path:
    """解析專案根：明示注入 > `ARK_TEAM_AGENT_HOME` > cwd 向上找哨兵。

    **不使用** `Path(__file__)` 起點 —— 套件安裝在 site-packages，向上永遠找不到 team.yaml。
    """
    if explicit:
        return Path(explicit).resolve()
    import os
    if env := os.environ.get("ARK_TEAM_AGENT_HOME"):
        return Path(env).resolve()
    return find_project_root(Path.cwd(), sentinel)


def package_asset(*parts: str) -> Path | None:
    """定位隨套件發布的資產（如 `scripts/task_screenshot.py`）。

    以本模組所在的套件目錄為基準（site-packages 與原始碼樹皆正確），
    不存在時回 None 由呼叫端決定 fallback。
    """
    p = Path(__file__).resolve().parent.joinpath(*parts)
    return p if p.exists() else None
