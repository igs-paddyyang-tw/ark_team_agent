"""AuditLogger — 所有操作自動記錄到 audit 表。

透過 EventBus global subscriber 攔截所有事件，寫入 SQLite audit_events 表。
提供查詢介面供 Admin Dashboard 使用。
"""
from __future__ import annotations

import logging
import sqlite3
import time
import uuid
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import Iterator

log = logging.getLogger(__name__)


@dataclass
class AuditRecord:
    """審計記錄。"""

    id: str
    actor_type: str  # system / agent / human
    actor_id: str
    action: str
    resource_type: str  # agent / task / cost / system
    resource_id: str
    detail: str
    timestamp: float


class AuditLogger:
    """SQLite-backed 審計日誌。"""

    _SCHEMA = """
    CREATE TABLE IF NOT EXISTS audit_events (
        id TEXT PRIMARY KEY,
        actor_type TEXT NOT NULL DEFAULT 'system',
        actor_id TEXT NOT NULL DEFAULT '',
        action TEXT NOT NULL,
        resource_type TEXT NOT NULL DEFAULT '',
        resource_id TEXT NOT NULL DEFAULT '',
        detail TEXT NOT NULL DEFAULT '',
        timestamp REAL NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_audit_ts ON audit_events(timestamp);
    CREATE INDEX IF NOT EXISTS idx_audit_action ON audit_events(action);
    CREATE INDEX IF NOT EXISTS idx_audit_actor ON audit_events(actor_id);
    """

    def __init__(self, db_path: Path) -> None:
        self._path = db_path
        self._init_db()

    def _init_db(self) -> None:
        self._path.parent.mkdir(parents=True, exist_ok=True)
        with self._connect() as conn:
            conn.executescript(self._SCHEMA)
            conn.execute("PRAGMA journal_mode=WAL")

    @contextmanager
    def _connect(self) -> Iterator[sqlite3.Connection]:
        conn = sqlite3.connect(self._path, timeout=5.0)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
            conn.commit()
        finally:
            conn.close()

    def record(
        self,
        action: str,
        *,
        actor_type: str = "system",
        actor_id: str = "",
        resource_type: str = "",
        resource_id: str = "",
        detail: str = "",
    ) -> None:
        """寫入一筆審計記錄。"""
        record_id = uuid.uuid4().hex[:8]
        ts = time.time()
        try:
            with self._connect() as conn:
                conn.execute(
                    "INSERT INTO audit_events "
                    "(id, actor_type, actor_id, action, resource_type, resource_id, detail, timestamp) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                    (record_id, actor_type, actor_id, action, resource_type, resource_id, detail, ts),
                )
        except Exception as e:
            log.warning("AuditLogger.record failed: %s", e)

    def query(
        self,
        *,
        actor_id: str | None = None,
        action: str | None = None,
        resource_type: str | None = None,
        since: float | None = None,
        limit: int = 100,
    ) -> list[AuditRecord]:
        """查詢審計記錄。"""
        clauses: list[str] = []
        params: list = []
        if actor_id:
            clauses.append("actor_id = ?")
            params.append(actor_id)
        if action:
            clauses.append("action LIKE ?")
            params.append(f"%{action}%")
        if resource_type:
            clauses.append("resource_type = ?")
            params.append(resource_type)
        if since is not None:
            clauses.append("timestamp >= ?")
            params.append(since)

        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        sql = f"SELECT * FROM audit_events {where} ORDER BY timestamp DESC LIMIT ?"
        params.append(limit)

        with self._connect() as conn:
            rows = conn.execute(sql, params).fetchall()

        return [
            AuditRecord(
                id=r["id"],
                actor_type=r["actor_type"],
                actor_id=r["actor_id"],
                action=r["action"],
                resource_type=r["resource_type"],
                resource_id=r["resource_id"],
                detail=r["detail"],
                timestamp=r["timestamp"],
            )
            for r in rows
        ]

    def count(self, since: float | None = None) -> int:
        """計數。"""
        sql = "SELECT COUNT(*) FROM audit_events"
        params: tuple = ()
        if since is not None:
            sql += " WHERE timestamp >= ?"
            params = (since,)
        with self._connect() as conn:
            return conn.execute(sql, params).fetchone()[0]

    def purge_older_than(self, days: int = 90) -> int:
        """清理超過 N 天的記錄。"""
        cutoff = time.time() - days * 86400
        with self._connect() as conn:
            cursor = conn.execute("DELETE FROM audit_events WHERE timestamp < ?", (cutoff,))
            return cursor.rowcount


# ── EventBus handler ──────────────────────────────────────────

# 事件類型 → 審計 action 映射
_ACTION_MAP = {
    "start": "agent.started",
    "stop": "agent.stopped",
    "crash": "agent.crashed",
    "restart": "agent.restarted",
    "message": "message.sent",
    "reply": "message.replied",
    "hang": "agent.hang_detected",
    "cost_warn": "cost.warning",
    "error": "system.error",
}


async def on_bus_event(event) -> None:
    """EventBus global subscriber：將事件轉為審計記錄。

    Args:
        event: BusEvent instance
    """
    action = _ACTION_MAP.get(event.type)
    if not action:
        action = f"event.{event.type}"

    audit = get_audit_logger()
    audit.record(
        action=action,
        actor_type="agent" if event.instance else "system",
        actor_id=event.instance or event.source,
        resource_type=_infer_resource_type(event.type),
        resource_id=event.instance,
        detail=event.detail[:500],
    )


def _infer_resource_type(event_type: str) -> str:
    """從事件類型推斷資源類型。"""
    if event_type in ("start", "stop", "crash", "restart", "hang"):
        return "agent"
    if event_type in ("message", "reply"):
        return "message"
    if event_type in ("cost_warn",):
        return "cost"
    return "system"


# ── Module-level singleton ────────────────────────────────────────

_instance: AuditLogger | None = None


def get_audit_logger(db_path: Path | None = None) -> AuditLogger:
    """Get or create the singleton AuditLogger."""
    global _instance
    if _instance is None:
        if db_path is None:
            from .config import get_state_dir
            db_path = get_state_dir() / "audit.db"
        _instance = AuditLogger(db_path)
    return _instance


def reset_audit_singleton() -> None:
    """Test helper。"""
    global _instance
    _instance = None
