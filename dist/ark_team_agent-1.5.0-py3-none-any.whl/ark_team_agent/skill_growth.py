"""SkillGrowthDetector — detect complex tasks and suggest saving as Skill."""
from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field

log = logging.getLogger(__name__)

# Default thresholds
_DEFAULT_TOOL_THRESHOLD = 15
_DEFAULT_DIVERSITY_RATIO = 0.5
_DEFAULT_COOLDOWN = 3600  # 1 hour between suggestions per instance


@dataclass
class GrowthConfig:
    """Configuration for skill growth detection."""

    tool_threshold: int = _DEFAULT_TOOL_THRESHOLD
    diversity_ratio: float = _DEFAULT_DIVERSITY_RATIO
    cooldown_seconds: float = _DEFAULT_COOLDOWN
    enabled: bool = True


@dataclass
class _SessionState:
    """Per-instance tracking state."""

    tool_count: int = 0
    tool_names: list[str] = field(default_factory=list)
    last_suggestion_time: float = 0
    declined: bool = False  # user said "不用" this session


class SkillGrowthDetector:
    """Detect complex task completion and suggest saving as Skill.

    Integrates with ToolTracker output to count tool calls per instance.
    When threshold is reached and diversity is high enough, signals that
    a suggestion should be sent.

    Usage:
        detector = SkillGrowthDetector()
        detector.on_tool_call("my-agent", "Write")
        detector.on_tool_call("my-agent", "Bash")
        ...
        if detector.should_suggest("my-agent"):
            msg = detector.get_suggestion("my-agent")
            # send msg to agent or user
            detector.mark_suggested("my-agent")
    """

    def __init__(self, config: GrowthConfig | None = None) -> None:
        self.config = config or GrowthConfig()
        self._states: dict[str, _SessionState] = {}

    def _get_state(self, instance: str) -> _SessionState:
        if instance not in self._states:
            self._states[instance] = _SessionState()
        return self._states[instance]

    def on_tool_call(self, instance: str, tool_name: str) -> None:
        """Record a tool call for the given instance."""
        if not self.config.enabled:
            return
        state = self._get_state(instance)
        state.tool_count += 1
        state.tool_names.append(tool_name)
        # Cap stored names to avoid unbounded growth
        if len(state.tool_names) > 100:
            state.tool_names = state.tool_names[-50:]

    def should_suggest(self, instance: str) -> bool:
        """Check if we should suggest saving as Skill."""
        if not self.config.enabled:
            return False

        state = self._get_state(instance)

        # User declined this session
        if state.declined:
            return False

        # Not enough tool calls
        if state.tool_count < self.config.tool_threshold:
            return False

        # Cooldown check
        now = time.time()
        if state.last_suggestion_time and (now - state.last_suggestion_time) < self.config.cooldown_seconds:
            return False

        # Diversity check: high diversity = complex task (not just repeating one tool)
        names = state.tool_names
        if not names:
            return False
        unique_ratio = len(set(names)) / len(names)
        return unique_ratio >= self.config.diversity_ratio

    def get_suggestion(self, instance: str) -> str:
        """Generate the suggestion message for the agent."""
        state = self._get_state(instance)
        unique_tools = set(state.tool_names)
        return (
            f"[Skill Growth] 剛才的任務使用了 {state.tool_count} 個步驟"
            f"（{len(unique_tools)} 種工具），"
            f"要把這個流程存為 Skill 嗎？"
            f"存為 Skill 後可一鍵重複執行。"
            f"\n\n回覆「好」開始建立，或「不用」跳過。"
        )

    def mark_suggested(self, instance: str) -> None:
        """Mark that we've made a suggestion (for cooldown tracking)."""
        state = self._get_state(instance)
        state.last_suggestion_time = time.time()

    def mark_declined(self, instance: str) -> None:
        """User declined — don't suggest again this session."""
        state = self._get_state(instance)
        state.declined = True

    def reset(self, instance: str) -> None:
        """Reset state for an instance (e.g., on session end or new task)."""
        self._states.pop(instance, None)

    def reset_all(self) -> None:
        """Reset all instance states."""
        self._states.clear()

    def get_stats(self, instance: str) -> dict:
        """Get current stats for an instance (for debugging/API)."""
        state = self._get_state(instance)
        unique = set(state.tool_names)
        return {
            "tool_count": state.tool_count,
            "unique_tools": len(unique),
            "diversity_ratio": len(unique) / len(state.tool_names) if state.tool_names else 0,
            "declined": state.declined,
            "threshold": self.config.tool_threshold,
        }
