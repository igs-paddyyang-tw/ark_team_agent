"""LLM Tool MCP Server — 讓 AI Agent 透過 MCP 呼叫外部 LLM 執行文字處理任務。"""
from __future__ import annotations

import argparse
import json
import os
import sys
import logging

log = logging.getLogger(__name__)

# ── LLM Provider 抽象 ─────────────────────────────────────────────

_provider: str = "gemini"
_api_key: str = ""
_model: str = ""
_base_url: str = ""


def _default_model() -> str:
    """依 provider 回傳預設模型名稱。"""
    defaults = {
        "gemini": "gemini-2.5-flash",
        "openai": "gpt-4.1-mini",
        "openrouter": "google/gemini-2.5-flash",
        "ollama": "llama3.1:8b",
    }
    return defaults.get(_provider, "gemini-2.5-flash")


def _call_gemini(prompt: str, system: str = "", temperature: float = 0.3,
                 max_tokens: int = 2048) -> str:
    """呼叫 Gemini API（generativelanguage.googleapis.com）。"""
    import urllib.request
    import urllib.error

    model = _model or _default_model()
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={_api_key}"

    contents = []
    if system:
        contents.append({"role": "user", "parts": [{"text": f"[System instruction]\n{system}"}]})
        contents.append({"role": "model", "parts": [{"text": "Understood."}]})
    contents.append({"role": "user", "parts": [{"text": prompt}]})

    body = json.dumps({
        "contents": contents,
        "generationConfig": {
            "temperature": temperature,
            "maxOutputTokens": max_tokens,
        },
    }).encode("utf-8")

    req = urllib.request.Request(url, data=body, method="POST",
                                headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            data = json.loads(resp.read())
            candidates = data.get("candidates", [])
            if candidates:
                parts = candidates[0].get("content", {}).get("parts", [])
                return "".join(p.get("text", "") for p in parts)
            return f"[LLM Error] No candidates: {json.dumps(data, ensure_ascii=False)[:200]}"
    except urllib.error.HTTPError as e:
        body_err = e.read().decode("utf-8", errors="replace")[:300]
        return f"[LLM Error] HTTP {e.code}: {body_err}"
    except (urllib.error.URLError, TimeoutError, OSError) as e:
        return f"[LLM Error] Network: {e}"


def _call_openai_compatible(prompt: str, system: str = "", temperature: float = 0.3,
                            max_tokens: int = 2048) -> str:
    """呼叫 OpenAI-compatible API（OpenAI / OpenRouter / Ollama / vLLM）。"""
    import urllib.request
    import urllib.error

    model = _model or _default_model()

    base = _base_url
    if not base:
        if _provider == "openrouter":
            base = "https://openrouter.ai/api/v1"
        elif _provider == "ollama":
            base = "http://localhost:11434/v1"
        else:
            base = "https://api.openai.com/v1"

    url = f"{base}/chat/completions"

    messages = []
    if system:
        messages.append({"role": "system", "content": system})
    messages.append({"role": "user", "content": prompt})

    body = json.dumps({
        "model": model,
        "messages": messages,
        "temperature": temperature,
        "max_tokens": max_tokens,
    }).encode("utf-8")

    headers: dict[str, str] = {"Content-Type": "application/json"}
    if _api_key:
        headers["Authorization"] = f"Bearer {_api_key}"

    req = urllib.request.Request(url, data=body, method="POST", headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            data = json.loads(resp.read())
            choices = data.get("choices", [])
            if choices:
                return choices[0].get("message", {}).get("content", "")
            return f"[LLM Error] No choices: {json.dumps(data, ensure_ascii=False)[:200]}"
    except urllib.error.HTTPError as e:
        body_err = e.read().decode("utf-8", errors="replace")[:300]
        return f"[LLM Error] HTTP {e.code}: {body_err}"
    except (urllib.error.URLError, TimeoutError, OSError) as e:
        return f"[LLM Error] Network: {e}"


def _call_llm(prompt: str, system: str = "", temperature: float = 0.3,
              max_tokens: int = 2048) -> str:
    """統一呼叫入口，依 _provider 分派。含指數退避 retry（最多 3 次）。"""
    import time as _time

    last_err = ""
    for attempt in range(3):
        if attempt > 0:
            _time.sleep(2 ** attempt)  # 2s, 4s backoff
        try:
            if _provider == "gemini":
                result = _call_gemini(prompt, system, temperature, max_tokens)
            else:
                result = _call_openai_compatible(prompt, system, temperature, max_tokens)
            # Retry on transient errors (network / 5xx)
            if result.startswith("[LLM Error] Network") or "[LLM Error] HTTP 5" in result:
                last_err = result
                continue
            return result
        except Exception as e:
            last_err = f"[LLM Error] Exception: {e}"
            continue
    return last_err or "[LLM Error] All retries exhausted"


# ── MCP Tool Definitions ──────────────────────────────────────────

def _get_tools() -> list[dict]:
    return [
        {
            "name": "llm_summarize",
            "description": "使用外部 LLM 摘要一段文字。輸入長文，回傳精簡摘要。",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "text": {"type": "string", "description": "要摘要的文字"},
                    "max_length": {"type": "integer", "description": "摘要最大字數（預設 200）", "default": 200},
                    "language": {"type": "string", "description": "輸出語言（預設 zh-TW）", "default": "zh-TW"},
                },
                "required": ["text"],
            },
        },
        {
            "name": "llm_translate",
            "description": "使用外部 LLM 翻譯文字。",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "text": {"type": "string", "description": "要翻譯的文字"},
                    "target_language": {"type": "string", "description": "目標語言（如 en, zh-TW, ja）"},
                    "style": {"type": "string", "description": "翻譯風格（formal/casual/technical）", "default": "formal"},
                },
                "required": ["text", "target_language"],
            },
        },
        {
            "name": "llm_analyze",
            "description": "使用外部 LLM 分析文字，可指定分析面向（情感、意圖、關鍵字、分類等）。",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "text": {"type": "string", "description": "要分析的文字"},
                    "aspect": {"type": "string", "description": "分析面向（sentiment/intent/keywords/classify/custom）"},
                    "labels": {
                        "type": "array", "items": {"type": "string"},
                        "description": "分類標籤列表（aspect=classify 時必填）",
                    },
                    "custom_instruction": {"type": "string", "description": "自訂分析指令（aspect=custom 時必填）"},
                },
                "required": ["text", "aspect"],
            },
        },
        {
            "name": "llm_generate",
            "description": "使用外部 LLM 根據 prompt 產生文字（通用生成工具）。",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "prompt": {"type": "string", "description": "生成指令"},
                    "system": {"type": "string", "description": "系統提示詞（可選）", "default": ""},
                    "temperature": {"type": "number", "description": "創意度 0.0~1.0（預設 0.3）", "default": 0.3},
                    "max_tokens": {"type": "integer", "description": "最大回傳 token 數（預設 2048）", "default": 2048},
                },
                "required": ["prompt"],
            },
        },
        {
            "name": "llm_rewrite",
            "description": "使用外部 LLM 改寫文字（改善語氣、修正文法、精簡、擴寫）。",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "text": {"type": "string", "description": "原始文字"},
                    "instruction": {"type": "string", "description": "改寫指令（如：更精簡、更正式、修正文法、擴寫到 500 字）"},
                    "language": {"type": "string", "description": "輸出語言（預設保持原文語言）", "default": ""},
                },
                "required": ["text", "instruction"],
            },
        },
    ]


# ── Tool Handlers ─────────────────────────────────────────────────

def _handle_tool(name: str, args: dict) -> str:
    """路由並執行 LLM 工具。"""
    try:
        if name == "llm_summarize":
            text = args["text"]
            max_length = args.get("max_length", 200)
            language = args.get("language", "zh-TW")
            system = f"你是專業的文字摘要助手。用{language}回答，摘要不超過{max_length}字。只輸出摘要，不加前綴。"
            return _call_llm(text, system=system, temperature=0.1, max_tokens=max_length * 2)

        elif name == "llm_translate":
            text = args["text"]
            target = args["target_language"]
            style = args.get("style", "formal")
            system = (
                f"你是專業翻譯。將輸入翻譯成 {target}，風格為 {style}。"
                f"只輸出翻譯結果，不加解釋或前綴。保留程式碼區塊不翻譯。"
            )
            return _call_llm(text, system=system, temperature=0.1, max_tokens=len(text) * 3)

        elif name == "llm_analyze":
            text = args["text"]
            aspect = args["aspect"]
            if aspect == "sentiment":
                system = "分析以下文字的情感傾向（正面/負面/中性），給出信心度百分比和簡短理由。用 JSON 格式回覆。"
            elif aspect == "intent":
                system = "分析以下文字的使用者意圖，列出主要意圖和可能的次要意圖。用 JSON 格式回覆。"
            elif aspect == "keywords":
                system = "從以下文字提取 5-10 個關鍵字/短語，依重要性排序。用 JSON array 格式回覆。"
            elif aspect == "classify":
                labels = args.get("labels", [])
                if not labels:
                    return "[Error] aspect=classify 需要提供 labels 參數"
                system = f"將以下文字分類到以下標籤之一：{json.dumps(labels, ensure_ascii=False)}。回覆格式：{{\"label\": \"...\", \"confidence\": 0.95, \"reason\": \"...\"}}"
            elif aspect == "custom":
                custom = args.get("custom_instruction", "")
                if not custom:
                    return "[Error] aspect=custom 需要提供 custom_instruction 參數"
                system = custom
            else:
                system = f"從 {aspect} 的角度分析以下文字，給出結構化結果。"
            return _call_llm(text, system=system, temperature=0.1)

        elif name == "llm_generate":
            prompt = args["prompt"]
            system = args.get("system", "")
            temperature = args.get("temperature", 0.3)
            max_tokens = args.get("max_tokens", 2048)
            return _call_llm(prompt, system=system, temperature=temperature, max_tokens=max_tokens)

        elif name == "llm_rewrite":
            text = args["text"]
            instruction = args["instruction"]
            language = args.get("language", "")
            lang_hint = f"用{language}輸出。" if language else "保持原文語言。"
            system = f"你是文字改寫助手。依照指令改寫文字：{instruction}。{lang_hint}只輸出改寫結果，不加解釋。"
            return _call_llm(text, system=system, temperature=0.2, max_tokens=len(text) * 3)

        else:
            return f"[Error] Unknown tool: {name}"

    except KeyError as e:
        return f"[Error] Missing required argument: {e}"
    except Exception as e:
        return f"[Error] {type(e).__name__}: {e}"


# ── JSON-RPC stdio loop ───────────────────────────────────────────

def _respond(msg_id: int | str | None, result: dict | None, error: dict | None = None) -> None:
    resp: dict = {"jsonrpc": "2.0", "id": msg_id}
    if error:
        resp["error"] = error
    else:
        resp["result"] = result
    sys.stdout.write(json.dumps(resp, ensure_ascii=True) + "\n")
    sys.stdout.flush()


def main() -> None:
    global _provider, _api_key, _model, _base_url

    parser = argparse.ArgumentParser(description="LLM Tool MCP Server")
    parser.add_argument("--provider", default=os.environ.get("LLM_PROVIDER", "gemini"),
                        help="LLM provider: gemini/openai/openrouter/ollama")
    parser.add_argument("--model", default=os.environ.get("LLM_MODEL", ""),
                        help="Model name (留空使用 provider 預設)")
    parser.add_argument("--base-url", default=os.environ.get("LLM_BASE_URL", ""),
                        help="OpenAI-compatible base URL (ollama/vLLM 等)")
    args = parser.parse_args()

    _provider = args.provider
    _model = args.model
    _base_url = args.base_url

    # API key 從環境變數讀取
    key_env_map = {
        "gemini": "GEMINI_API_KEY",
        "openai": "OPENAI_API_KEY",
        "openrouter": "OPENROUTER_API_KEY",
        "ollama": "",  # Ollama 不需要 key
    }
    key_env = key_env_map.get(_provider, "LLM_API_KEY")
    _api_key = os.environ.get(key_env, os.environ.get("LLM_API_KEY", ""))

    if not _api_key and _provider != "ollama":
        sys.stderr.write(f"[llm-tool-mcp] Warning: No API key found (checked {key_env}, LLM_API_KEY)\n")
        sys.stderr.flush()

    # PYTHONUTF8=1 由 process.py 設定，Python 自動使用 UTF-8
    # 直接使用 sys.stdin/sys.stdout（不重新開啟 fd，避免 pipe 模式衝突）

    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            msg = json.loads(line)
        except json.JSONDecodeError:
            continue

        method = msg.get("method", "")
        params = msg.get("params", {})
        msg_id = msg.get("id")

        if method == "initialize":
            _respond(msg_id, {
                "protocolVersion": "2024-11-05",
                "capabilities": {"tools": {"listChanged": False}},
                "serverInfo": {"name": "llm-tool-mcp", "version": "0.1.0"},
            })
        elif method == "tools/list":
            _respond(msg_id, {"tools": _get_tools()})
        elif method == "tools/call":
            result = _handle_tool(params.get("name", ""), params.get("arguments", {}))
            _respond(msg_id, {"content": [{"type": "text", "text": result}]})
        elif method == "notifications/initialized":
            pass
        else:
            _respond(msg_id, None, error={"code": -32601, "message": f"Unknown method: {method}"})


if __name__ == "__main__":
    main()
