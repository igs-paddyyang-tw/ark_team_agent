"""Internal heartbeat — daemon writes timestamp every 30s to detect freezes.

External watchdog can check staleness of state/heartbeat to detect:
- Process alive but event loop frozen (deadlock)
- Process alive but blocked on I/O

If heartbeat is >90s stale, watchdog should force-restart.
"""
from __future__ import annotations

import asyncio
import logging
import time
from pathlib import Path

log = logging.getLogger(__name__)

HEARTBEAT_INTERVAL = 30  # seconds
HEARTBEAT_FILE = "heartbeat"


async def heartbeat_loop(state_dir: Path) -> None:
    """Background task — writes unix timestamp to state/heartbeat every 30s."""
    hb_path = state_dir / HEARTBEAT_FILE
    state_dir.mkdir(parents=True, exist_ok=True)
    while True:
        try:
            hb_path.write_text(str(int(time.time())), encoding="utf-8")
        except OSError:
            pass
        await asyncio.sleep(HEARTBEAT_INTERVAL)


def is_heartbeat_stale(state_dir: Path, max_age_s: int = 90) -> bool:
    """Check if heartbeat file is stale (>max_age_s old). For external watchdog."""
    hb_path = state_dir / HEARTBEAT_FILE
    if not hb_path.exists():
        return True
    try:
        ts = int(hb_path.read_text(encoding="utf-8").strip())
        return (time.time() - ts) > max_age_s
    except (ValueError, OSError):
        return True
