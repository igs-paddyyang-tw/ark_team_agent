"""team MCP Server — provides cross-agent communication tools to Kiro CLI."""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
import urllib.error
import urllib.request

from .session_key import SessionKey

try:
    from .constants import DEFAULT_TEAM_AGENT_PORT
except ImportError:
    DEFAULT_TEAM_AGENT_PORT = 13030


def _api(method: str, path: str, data: dict | None = None, *,
         max_retries: int = 3, connect_timeout: float = 5.0, read_timeout: float = 10.0) -> dict:
    """Call Daemon API with retry + exponential backoff.

    Retries on network errors and 5xx responses. 4xx responses propagate immediately.
    """
    url = f"http://127.0.0.1:{_port}{path}"
    body = json.dumps(data, ensure_ascii=True).encode("utf-8") if data else None
    headers = {"Content-Type": "application/json"} if body else {}

    last_error: Exception | None = None
    for attempt in range(max_retries + 1):
        try:
            req = urllib.request.Request(url, data=body, method=method, headers=headers)
            with urllib.request.urlopen(req, timeout=read_timeout) as resp:
                return json.loads(resp.read())
        except urllib.error.HTTPError as e:
            # 4xx client errors: do not retry (our bug or invalid input)
            if 400 <= e.code < 500:
                try:
                    return json.loads(e.read())
                except Exception:
                    return {"ok": False, "error": f"HTTP {e.code}: {e.reason}"}
            # 5xx: retry
            last_error = e
        except (urllib.error.URLError, TimeoutError, OSError) as e:
            # Network errors: retry
            last_error = e

        if attempt < max_retries:
            # Exponential backoff: 0.5s, 1s, 2s
            delay = 0.5 * (2 ** attempt)
            time.sleep(delay)

    return {"ok": False, "error": f"Daemon API unreachable after {max_retries + 1} attempts: {last_error}"}


_port = DEFAULT_TEAM_AGENT_PORT
_instance = "unknown"
_role = "worker"
_allowed_targets: list[str] = []


def main() -> None:
    global _port, _instance, _role, _allowed_targets
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=DEFAULT_TEAM_AGENT_PORT)
    parser.add_argument("--instance", default="unknown")
    parser.add_argument("--role", default="worker")
    parser.add_argument("--allowed-targets", default="", nargs="?")
    parser.add_argument("--home", default="")
    args = parser.parse_args()
    _port = args.port
    _instance = args.instance
    _role = args.role
    _allowed_targets = [t for t in args.allowed_targets.split(",") if t]
    if args.home:
        os.environ["ARK_TEAM_AGENT_HOME"] = args.home

    # PYTHONUTF8=1 由 process.py 設定，Python 自動使用 UTF-8
    # 直接使用 sys.stdin/sys.stdout（不重新開啟 fd，避免 pipe 模式衝突）

    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            msg = json.loads(line)
        except json.JSONDecodeError:
            continue

        method = msg.get("method", "")
        params = msg.get("params", {})
        msg_id = msg.get("id")

        if method == "initialize":
            _respond(msg_id, {
                "protocolVersion": "2024-11-05",
                "capabilities": {"tools": {"listChanged": False}},
                "serverInfo": {"name": "team-mcp", "version": "0.11.0"},
            })
        elif method == "tools/list":
            _respond(msg_id, {"tools": _get_tools()})
        elif method == "tools/call":
            # Rate limiting: delay if over budget (prevents upstream 429 cascade)
            allowed, wait = _rate_limiter.check()
            if not allowed:
                time.sleep(min(wait + 0.5, 10.0))  # Cap at 10s to avoid blocking too long
            _rate_limiter.record()
            result = _handle_tool(params.get("name", ""), params.get("arguments", {}))
            _respond(msg_id, {"content": [{"type": "text", "text": result}]})
        elif method == "notifications/initialized":
            pass
        else:
            _respond(msg_id, None, error={"code": -32601, "message": f"Unknown method: {method}"})


def _respond(msg_id, result, error=None) -> None:
    resp = {"jsonrpc": "2.0", "id": msg_id}
    if error:
        resp["error"] = error
    else:
        resp["result"] = result
    sys.stdout.write(json.dumps(resp, ensure_ascii=True) + "\n")
    sys.stdout.flush()


# ── Rate Limiter (sliding window) ────────────────────────────────

class _RateLimiter:
    """Per-instance sliding window rate limiter for MCP tool calls.

    Prevents agent from overwhelming the API with rapid-fire tool calls,
    which triggers upstream rate limits (429) and cascading failures.
    """

    def __init__(self, max_calls: int = 20, window_seconds: float = 60.0) -> None:
        self._max = max_calls
        self._window = window_seconds
        self._timestamps: list[float] = []

    def check(self) -> tuple[bool, float]:
        """Return (allowed, wait_seconds). If not allowed, wait_seconds > 0."""
        now = time.time()
        cutoff = now - self._window
        # Prune old entries
        self._timestamps = [t for t in self._timestamps if t > cutoff]
        if len(self._timestamps) >= self._max:
            # How long until the oldest entry expires
            wait = self._timestamps[0] - cutoff
            return False, wait
        return True, 0.0

    def record(self) -> None:
        """Record a successful tool call."""
        self._timestamps.append(time.time())


_rate_limiter = _RateLimiter(max_calls=20, window_seconds=60.0)


def _check_target(instance: str) -> str | None:
    """Return error message if target is not allowed, None if OK."""
    if not _allowed_targets:
        return None  # no restriction
    if instance not in _allowed_targets:
        return f"權限不足：{_instance} 無法操控 {instance}"
    return None


def _handle_tool(name: str, args: dict) -> str:
    try:
        if name == "send_to_instance":
            err = _check_target(args["instance"])
            if err:
                return err
            payload: dict = {
                "instance": args["instance"], "message": args["message"], "source": _instance,
            }
            if args.get("ttl_minutes"):
                payload["ttl_minutes"] = int(args["ttl_minutes"])
            r = _api("POST", "/api/send", payload)
            return f"已發送到 {args['instance']}" if r.get("ok") else f"發送失敗: {r}"

        elif name == "delegate_task":
            err = _check_target(args["instance"])
            if err:
                return err
            msg = f"📋 委派任務：{args['task']}"
            r = _api("POST", "/api/send", {
                "instance": args["instance"], "message": msg, "source": _instance,
            })
            return f"已委派給 {args['instance']}" if r.get("ok") else f"委派失敗: {r}"

        elif name == "reply":
            kind = args.get("kind", "primary")
            if kind not in ("primary", "followup"):
                kind = "primary"
            style = args.get("style", "chat")
            if style not in ("chat", "report"):
                style = "chat"
            template = args.get("template", "")  # [1.2.0 N4] 具名 TG 模板
            r = _api("POST", "/api/reply", {
                "instance": _instance, "text": args["text"], "kind": kind, "style": style,
                "template": template,
            }, read_timeout=30.0)
            return "已回覆" if r.get("ok") else f"回覆失敗: {r}"

        elif name == "log_to_leader":
            r = _api("POST", "/api/log", {"instance": _instance, "source": _instance, "text": args["text"]},
                     read_timeout=30.0)
            return "已記錄" if r.get("ok") else f"記錄失敗: {r}"

        elif name == "query_team_status":
            r = _api("GET", "/api/status")
            import time as _time
            now = _time.time()
            visible = []
            for s in r.get("instances", []):
                if _allowed_targets and s["name"] not in _allowed_targets and s["name"] != _instance:
                    continue
                visible.append(s)

            if not visible:
                return "無 instance"

            def _idle_str(last_act: float) -> str:
                idle_sec = now - last_act
                if idle_sec < 60:
                    return f"{int(idle_sec)}s"
                elif idle_sec < 3600:
                    return f"{int(idle_sec / 60)}m"
                else:
                    return f"{int(idle_sec / 3600)}h"

            # Semantic grouping: available / busy / offline
            # available = running or awaiting_reply (can accept work)
            # busy = running with recent activity < 2min (actively processing)
            # offline = stopped, crashed, paused, starting
            available = []
            busy = []
            offline = []
            for s in visible:
                status = s["status"]
                if status in ("stopped", "crashed", "paused"):
                    offline.append(s)
                elif status == "starting":
                    offline.append(s)
                # [1.2.16] idle 也是健康狀態（做完沒待辦）
                elif status in ("running", "awaiting_reply", "idle"):
                    last_act = s.get("last_activity", 0)
                    idle_sec = (now - last_act) if last_act else 9999
                    if idle_sec < 120 and status == "running":
                        busy.append(s)
                    else:
                        available.append(s)

            lines = []

            # Offline/crashed — always show individually (critical)
            if offline:
                for s in offline:
                    icons = {"stopped": "⚪", "crashed": "🔴", "paused": "⏸️", "starting": "🟡"}
                    icon = icons.get(s["status"], "❓")
                    labels = {"crashed": "已崩潰", "stopped": "已停止",
                              "paused": "已暫停", "starting": "啟動中"}
                    label = labels.get(s["status"], s["status"])
                    crash_tag = ""
                    crashes = s.get("crash_count", 0)
                    if crashes > 0:
                        crash_tag = f" ⚠️×{crashes}"
                    lines.append(f"{icon} {s['name']} — {label}{crash_tag}")

            # Busy — show individually with duration
            if busy:
                for s in busy:
                    last_act = s.get("last_activity", 0)
                    dur = f"（處理中 {_idle_str(last_act)}）" if last_act else ""
                    lines.append(f"⚡ {s['name']}{dur}")

            # Separator + available summary
            if (offline or busy) and available:
                lines.append("─────")
            lines.append(f"✅ 可用（{len(available)}）：{'全員就緒' if not offline and not busy else '就緒'}")

            return "\n".join(lines)

        elif name == "record_spend":
            r = _api("POST", "/api/costs/spend", {
                "instance": _instance,
                "amount_usd": float(args.get("amount_usd", 0)),
                "note": args.get("note", ""),
            })
            if r.get("ok"):
                return f"已記錄 ${r['amount_usd']:.4f}，今日累計 ${r['today_total']:.2f}"
            return f"記錄失敗: {r}"

        elif name == "create_task":
            from pathlib import Path
            from .config import get_home
            tasks_dir = get_home() / "tasks"
            from .task_board import TaskBoard
            board = TaskBoard(tasks_dir)
            task = board.create_task(
                title=args["title"],
                assignee=args["assignee"],
                priority=args.get("priority", "medium"),
                depends_on=args.get("depends_on", []),
                description=args.get("description", ""),
            )
            return f"✅ 任務已建立：{task.id}（→ {task.assignee}）"

        elif name == "update_task":
            from pathlib import Path
            from .config import get_home
            tasks_dir = get_home() / "tasks"
            from .task_board import TaskBoard
            board = TaskBoard(tasks_dir)
            task = board.update_status(
                args["task_id"], args["status"],
                note=args.get("note", ""),
                summary=args.get("summary", ""),
                metadata=args.get("metadata"),
            )
            if task:
                return f"✅ 任務 {task.id} → {task.status}"
            return f"❌ 找不到任務：{args['task_id']}"

        elif name == "list_tasks":
            from pathlib import Path
            from .config import get_home
            tasks_dir = get_home() / "tasks"
            from .task_board import TaskBoard
            board = TaskBoard(tasks_dir)
            status_filter = args.get("status")
            return board.summary() if not status_filter else "\n".join(
                f"• {t.title} → {t.assignee} [{t.priority}]"
                for t in board.list_tasks(status=status_filter)
            ) or f"無 {status_filter} 任務"

        elif name == "broadcast_all":
            message = args["message"]
            r = _api("GET", "/api/status")
            sent = []
            failed = []
            for s in r.get("instances", []):
                inst_name = s["name"]
                if inst_name == _instance:
                    continue  # don't send to self
                # [1.2.20] 廣播的語意是「團隊成員」，衍生 session 不算 ——
                # 否則同一個人開了 3 個 session 就會收到 3 份。
                # 這裡不能用 daemon.entity_instances()（MCP server 是獨立進程，
                # 只能透過 HTTP API），所以直接用 SessionKey 判斷。
                if SessionKey.is_session(inst_name):
                    continue
                result = _api("POST", "/api/send", {
                    "instance": inst_name, "message": message, "source": _instance,
                })
                if result.get("ok"):
                    sent.append(inst_name)
                else:
                    failed.append(inst_name)
            summary = f"✅ 已廣播給 {len(sent)} 個 agent"
            if failed:
                summary += f"（{len(failed)} 個失敗：{', '.join(failed)}）"
            return summary

        elif name == "wiki_query":
            return _handle_wiki_query(args)

        elif name == "wiki_ingest":
            return _handle_wiki_ingest(args)

        elif name == "reply_task_image":
            return _handle_reply_task_image(args)

        elif name == "reply_file":
            return _handle_reply_file(args)

        elif name == "smart_delegate":
            return _handle_smart_delegate(args)

        elif name == "decision_digest":
            return _handle_decision_digest(args)

        elif name == "decision_overturn":
            return _handle_decision_overturn(args)

        else:
            return f"未知工具: {name}"
    except Exception as e:
        return f"錯誤: {e}"


def _get_tools() -> list[dict]:
    """Return tools based on role."""
    # admin / leader: all tools
    # manager: all tools except create_task
    # worker: reply + send_to_instance + query_team_status + log_to_leader + record_spend + list_tasks + update_task + wiki_query
    if _role in ("admin", "leader"):
        return _ALL_TOOLS
    if _role == "manager":
        return [t for t in _ALL_TOOLS if t["name"] != "create_task"]
    # worker
    return [t for t in _ALL_TOOLS
            if t["name"] in ("reply", "send_to_instance", "query_team_status", "log_to_leader",
                             "record_spend", "list_tasks", "update_task", "wiki_query", "wiki_ingest",
                             "reply_task_image", "reply_file")]


def _iter_wiki_dirs(search_paths, order=None):
    """[v1.1.4 R1] 枚舉可搜的 wiki 目錄：每個 search_path 的 `<path>/wiki`
    以及其下一層命名櫃子 `<path>/*/wiki`（去櫃子名硬編碼）。

    [1.2.0 N2] order：櫃子名優先序（如 `[shared, hoyeah]`）；列入者優先、其餘維持字母序在後。
    未設則沿用 v1.1.4 字母序。程式仍不寫死任何櫃子名（順序由設定提供）。

    Author: ark-agent
    """
    from pathlib import Path as _P
    order = order or []

    def _rank(d):
        cab = d.parent.name  # <root>/<cabinet>/wiki → cabinet 名
        try:
            return (0, order.index(cab))
        except ValueError:
            return (1, 0)  # 未列入 order → 排後面（保持字母序）

    seen: set = set()
    for root in search_paths:
        cabinets = sorted(_P(root).glob("*/wiki"))
        if order:
            cabinets = sorted(cabinets, key=_rank)  # stable：ordered 在前，其餘字母序
        candidates = [root / "wiki"] + cabinets
        for d in candidates:
            if d.is_dir() and d not in seen:
                seen.add(d)
                yield d


def _handle_wiki_query(args: dict) -> str:
    """Search wiki knowledge base using keyword matching."""
    import os
    from pathlib import Path

    query = args.get("query", "").lower()
    scope = args.get("scope", "self")
    top_k = args.get("top_k", 3)

    if not query:
        return "請提供搜尋關鍵字"

    # Determine search paths
    search_paths: list[Path] = []
    home = os.environ.get("ARK_TEAM_AGENT_HOME", "")
    if not home:
        # Fallback: try to find team_home
        from pathlib import Path as P
        for candidate in [P.cwd(), P.cwd().parent]:
            if (candidate / "team.yaml").exists():
                home = str(candidate)
                break
    if not home:
        home = str(Path.home() / ".ark-team-agent")

    home_path = Path(home)

    if scope in ("shared", "all"):
        shared = home_path / "knowledge" / "shared"
        if shared.exists():
            search_paths.append(shared)
        # Legacy: root knowledge/ for backward compat
        root_kb = home_path / "knowledge"
        if root_kb.exists() and root_kb not in search_paths:
            search_paths.append(root_kb)
    if scope in ("self", "all"):
        # [1.2.26] 移除 `if _instance == "ark-agent"` 特例 —— 它加入的
        # `knowledge/ark-agent/` 與下方 fallback 的 `knowledge/{_instance}`
        # **是同一個路徑**，且那個 fallback 有 `not in search_paths` 去重。
        # 也就是說這個分支對 ark-agent 是重複的、對其他部署是死碼
        # （它們沒有叫 ark-agent 的 instance）。
        # 優先：agent 工作目錄下的 knowledge/（各 agent 私有）
        agent_kb = home_path / "agents" / _instance / "knowledge"
        if agent_kb.exists():
            search_paths.append(agent_kb)
        # Fallback：根目錄 knowledge/{instance}/（歷史相容）
        private = home_path / "knowledge" / _instance
        if private.exists() and private not in search_paths:
            search_paths.append(private)

    if not search_paths:
        return "知識庫尚未建立"

    # Search: scan wiki/ pages for keyword matches
    results: list[tuple[float, str, str, str]] = []  # (score, title, path, summary)
    keywords = query.split()

    # [v1.1.4 R1] 掃所有櫃子的 wiki/（含 <path>/*/wiki），不寫死櫃子名
    # [1.2.0 N2] 搜尋順序由 team.yaml knowledge_search_order 決定（best-effort 讀取）
    _order: list = []
    try:
        import yaml as _yaml
        _raw = _yaml.safe_load((home_path / "team.yaml").read_text(encoding="utf-8")) or {}
        _order = list(_raw.get("knowledge_search_order", []))
    except Exception:  # noqa: BLE001 — 讀不到順序不影響搜尋
        _order = []
    scanned_dirs = 0
    for wiki_dir in _iter_wiki_dirs(search_paths, order=_order):
        scanned_dirs += 1
        for md_file in wiki_dir.rglob("*.md"):
            try:
                content = md_file.read_text(encoding="utf-8", errors="replace")
                content_lower = content.lower()

                # BM25-like scoring: count keyword hits
                score = sum(content_lower.count(kw) for kw in keywords)
                if score == 0:
                    continue

                # Extract title from frontmatter or first heading
                title = md_file.stem
                for line in content.split("\n"):
                    if line.startswith("title:"):
                        title = line.split(":", 1)[1].strip().strip('"')
                        break
                    if line.startswith("# "):
                        title = line[2:].strip()
                        break

                # Summary: first non-frontmatter paragraph (max 100 chars)
                in_frontmatter = False
                summary = ""
                for line in content.split("\n"):
                    if line.strip() == "---":
                        in_frontmatter = not in_frontmatter
                        continue
                    if in_frontmatter:
                        continue
                    if line.strip() and not line.startswith("#"):
                        summary = line.strip()[:100]
                        break

                # [v1.1.4] 相對 home 顯示完整櫃子路徑（如 knowledge/hoyeah/wiki/xxx.md）
                try:
                    rel_path = str(md_file.relative_to(home_path))
                except ValueError:
                    rel_path = str(md_file)
                results.append((score, title, rel_path, summary))
            except (OSError, UnicodeDecodeError):
                continue

    if not results:
        # [v1.1.4 R3] 帶診斷：區分「真沒有」與「櫃子/raw 沒被掃」，治靜默降級
        raw_cnt = 0
        for p in search_paths:
            raw_cnt += len(list(p.glob("raw/*.md"))) + len(list(p.glob("*/raw/*.md")))
        if scanned_dirs == 0:
            hint = "（⚠️ 未掃到任何 wiki/ 目錄，請確認知識庫結構）"
        elif raw_cnt:
            hint = f"（提示：偵測到 {raw_cnt} 篇 raw/ 尚未 ingest，暫不可搜；請跑 wiki_ingest 提煉）"
        else:
            hint = ""
        return f"未找到與「{query}」相關的知識{hint}"

    # Sort by score descending, take top_k
    results.sort(key=lambda x: x[0], reverse=True)
    top = results[:top_k]

    lines = []
    for score, title, path, summary in top:
        lines.append(f"📄 **{title}**（{path}）")
        if summary:
            lines.append(f"   {summary}")
        lines.append("")

    return "\n".join(lines).strip()


def _contained_path(candidate: str, *roots) -> "Path | None":
    """把 candidate 解析成絕對路徑，並確認它落在 roots 其中之一底下。

    用於所有接收「外部提供路徑」的 MCP 工具。呼叫端可能是 LLM，其輸入
    可能受提詞注入影響，因此不能信任 —— 必須做封閉檢查（containment），
    只做 `exists()` 是不夠的。

    Args:
        candidate: 外部提供的路徑字串（可為相對或絕對）
        roots: 允許的根目錄，任一即可

    Returns:
        通過檢查的絕對路徑；若無法解析或落在所有 roots 之外則回傳 None。

    Author: claude-code
    """
    from pathlib import Path

    try:
        resolved = Path(candidate).expanduser().resolve()
    except (OSError, RuntimeError, ValueError):
        return None
    for root in roots:
        try:
            if resolved.is_relative_to(Path(root).resolve()):
                return resolved
        except (OSError, RuntimeError, ValueError):
            continue
    return None


def _handle_wiki_ingest(args: dict) -> str:
    """Ingest a raw file into wiki: read raw → create wiki page → update index + log.
    
    ⚠️ 排程專用：只有 admin/leader 可以執行 ingest（worker 應寫 raw/ 而非呼叫此工具）。
    """
    import os
    from pathlib import Path
    from datetime import date

    source_path = args.get("source_path", "")
    target_category = args.get("target_category", "")
    target_scope = args.get("scope", "self")  # self or shared

    if not source_path:
        return "請提供 source_path（raw/ 下的檔案路徑）"

    # Only leader/admin can execute ingest (wiki/ is schedule-only)
    if _role not in ("admin", "leader"):
        return "⛔ 權限不足：wiki_ingest 只有 admin/leader 可執行。請把內容寫到 raw/ 即可，排程會自動 ingest。"

    # Determine wiki root
    home = os.environ.get("ARK_TEAM_AGENT_HOME", "")
    if not home:
        from pathlib import Path as P
        for candidate in [P.cwd(), P.cwd().parent]:
            if (candidate / "team.yaml").exists():
                home = str(candidate)
                break
    if not home:
        home = str(Path.home() / ".ark-team-agent")

    home_path = Path(home)
    if target_scope == "shared":
        # 共用書架：knowledge/shared/
        wiki_root = home_path / "knowledge" / "shared"
    else:
        # [1.2.26] 原本是 `elif _instance == "ark-agent"` —— 寫死 nana 的入口名，
        # 其他部署永遠走 else（死分支）。改為**看哪個櫃子實際存在**：
        # working_directory 在專案根的 agent（如 nana 的 ark-agent）沒有
        # `agents/{name}/`，它的櫃子是 `knowledge/{name}/`。
        # 用存在性判斷不需要讀 team.yaml，且對任何部署都成立。
        _own_shelf = home_path / "knowledge" / _instance
        wiki_root = (_own_shelf if _own_shelf.exists()
                     else home_path / "agents" / _instance / "knowledge")

    wiki_root.mkdir(parents=True, exist_ok=True)

    # [claude-code 2026-08-05] Find source file — 加上路徑封閉檢查
    # 原本是 `wiki_root/"raw"/source_path`，source_path 含 ../ 即可跳出 raw/；
    # 且 fallback 為 `Path(source_path)`，等同明確允許任意絕對路徑。
    # source_path 來自 LLM 呼叫，可能受提詞注入影響，必須限制在 raw/ 底下。
    raw_root = (wiki_root / "raw").resolve()
    raw_file = _contained_path(str(raw_root / source_path), raw_root)
    if raw_file is None:
        # 也接受呼叫端直接給絕對路徑，但仍必須落在 raw/ 底下
        raw_file = _contained_path(source_path, raw_root)
    if raw_file is None:
        return f"⛔ 來源路徑必須位於 `{raw_root}` 底下：{source_path}"
    if not raw_file.exists():
        return f"找不到來源檔案：{source_path}"

    # Read source
    try:
        content = raw_file.read_text(encoding="utf-8", errors="replace")
    except OSError as e:
        return f"讀取失敗：{e}"

    # Create wiki page
    today = str(date.today())
    page_name = raw_file.stem
    wiki_dir = wiki_root / "wiki"
    if target_category:
        wiki_dir = wiki_dir / target_category
    wiki_dir.mkdir(parents=True, exist_ok=True)

    page_path = wiki_dir / f"{page_name}.md"
    # Generate frontmatter + content summary
    page_content = (
        f"---\n"
        f"title: \"{page_name}\"\n"
        f"type: source\n"
        f"tags: [ingested]\n"
        f"sources: [raw/{source_path}]\n"
        f"created: {today}\n"
        f"updated: {today}\n"
        f"status: seedling\n"
        f"---\n\n"
        f"# {page_name}\n\n"
        f"> 匯入自 `raw/{source_path}`\n\n"
        f"{content[:2000]}\n"
    )
    page_path.write_text(page_content, encoding="utf-8")

    # [claude-code 2026-08-05] Update index.md — 改用 O_APPEND 取代 fcntl.flock
    # fcntl 僅 POSIX 可用，Windows 會 ImportError（本專案仍支援 Windows）。
    # 原始問題是 read → check → write 整檔非原子，並行 ingest 會互相覆蓋；
    # 改用附加模式後由 O_APPEND 保證寫入不交錯、不會遺失他人的行
    # （殘留風險僅為極少見的重複一行，無害），與下方 log.md 的寫法一致。
    index_path = wiki_root / "index.md"
    if not index_path.exists():
        index_path.write_text(
            f"# 知識庫索引\n\n> 最後更新：{today}\n\n## wiki/ 頁面\n\n",
            encoding="utf-8",
        )
    if f"[[{page_name}]]" not in index_path.read_text(encoding="utf-8"):
        with open(index_path, "a", encoding="utf-8") as f:
            f.write(f"- [[{page_name}]]\n")

    # Update log.md — create if missing, always append
    log_path = wiki_root / "log.md"
    if not log_path.exists():
        log_path.write_text(
            "# 操作日誌\n\n> append-only，禁止刪除舊記錄。\n\n---\n\n",
            encoding="utf-8",
        )
    with open(log_path, "a", encoding="utf-8") as f:
        f.write(f"- **{today}** | ingest | `{source_path}` → `wiki/{target_category}/{page_name}.md`\n")

    rel = str(page_path.relative_to(wiki_root))
    return f"✅ 已匯入：{rel}（來源：{source_path}）"


def _handle_reply_task_image(args: dict) -> str:
    """產生任務板截圖並透過 Telegram 發送圖片。"""
    import subprocess
    import sys
    from pathlib import Path

    status = args.get("status", None)
    title = args.get("title", "任務板")

    # [1.2.6] 呼叫 task_screenshot.py 產生截圖。
    # 原用 parent×3 推導，pip 安裝時會指到 .venv/lib/python3.x → 工具永遠失敗。
    # 改為：套件內建資產優先（與部署方式無關）→ 退回專案 scripts/（原始碼樹相容）。
    from .paths import package_asset, resolve_project_root
    script = package_asset("scripts", "task_screenshot.py")
    if script is None:
        try:
            _cand = resolve_project_root() / "scripts" / "task_screenshot.py"
            script = _cand if _cand.exists() else None
        except Exception:  # noqa: BLE001 — 找不到專案根不該讓工具拋例外
            script = None
    if script is None:
        return "❌ 找不到 task_screenshot.py（套件內建資產與專案 scripts/ 皆無）"

    import tempfile
    output = Path(tempfile.gettempdir()) / "ark_task_board.png"
    cmd = [sys.executable, str(script), "--output", str(output), "--title", title]
    if status:
        cmd.extend(["--status", status])

    result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
    if result.returncode != 0:
        return f"❌ 截圖失敗：{result.stderr[:200]}"

    if not output.exists():
        return "❌ 截圖檔案未產生"

    # 透過 API 發送圖片
    r = _api("POST", "/api/reply-photo", {
        "instance": _instance,
        "photo_path": str(output),
        "caption": title,
    }, read_timeout=30.0)

    if r.get("ok"):
        return "✅ 任務板圖片已發送"
    return f"❌ 發送失敗：{r}"


def _handle_reply_file(args: dict) -> str:
    """發送產出檔案給使用者的 Telegram（限交付物目錄）。"""
    import os
    from pathlib import Path

    file_path = args.get("file_path", "")
    caption = args.get("caption", "")

    if not file_path:
        return "❌ 請提供 file_path"

    # [claude-code 2026-08-05] 路徑白名單
    # 原本接受任意絕對路徑（docstring 自述「發送任意檔案」），而 file_path
    # 來自 LLM 呼叫、可能受提詞注入影響 —— 等同任意檔案外洩管道
    # （.env / secrets/ / ~/.ssh 皆可送出）。改為只允許交付物目錄。
    home = os.environ.get("ARK_TEAM_AGENT_HOME", "")
    if not home:
        for candidate in [Path.cwd(), Path.cwd().parent]:
            if (candidate / "team.yaml").exists():
                home = str(candidate)
                break
    if not home:
        home = str(Path.home() / ".ark-team-agent")
    home_path = Path(home)

    allowed_roots = [
        home_path / sub for sub in ("output", "artifacts", "docs", "knowledge")
    ]
    if _instance:
        agent_dir = home_path / "agents" / _instance
        allowed_roots += [
            agent_dir / sub for sub in ("output", "artifacts", "docs", "knowledge", "scripts")
        ]

    target = _contained_path(file_path, *allowed_roots)
    if target is None:
        allowed = "、".join(str(r.relative_to(home_path)) for r in allowed_roots)
        return (
            f"⛔ 只能發送交付物目錄下的檔案：{file_path}\n"
            f"允許的目錄（相對於 {home_path}）：{allowed}"
        )
    if not target.exists():
        return f"❌ 檔案不存在: {file_path}"

    r = _api("POST", "/api/reply-file", {
        "instance": _instance,
        "file_path": str(target),
        "caption": caption,
    }, read_timeout=30.0)

    if r.get("ok"):
        return f"✅ 檔案已發送: {Path(file_path).name}"
    return f"❌ 發送失敗: {r}"


def _handle_smart_delegate(args: dict) -> str:
    """智慧派工：A2A Router（能力匹配 + DAG + FeedbackLoop）。"""
    import asyncio

    from .a2a_protocol import TaskHandoff
    from .a2a_router import A2ARouter
    from .config import load_team_config, get_home

    title = args.get("title", "")
    if not title:
        return "❌ title 為必填"

    # 載入 config
    home = get_home()
    config = load_team_config(home / "team.yaml")

    # spawn_fn: 透過 Daemon API 發訊息並等待回覆
    async def spawn_fn(agent_name: str, message: str) -> str | None:
        r = _api("POST", "/api/send", {
            "instance": agent_name,
            "message": message,
            "source": _instance,
        })
        if r.get("ok"):
            return r.get("response", "sent")
        return None

    # 建構 TaskHandoff
    handoff = TaskHandoff(
        task_id="",  # A2ARouter 會自動生成
        from_agent=_instance,
        to_agent=args.get("to_agent", "auto"),
        title=title,
        context=args.get("context", ""),
        acceptance_criteria=args.get("acceptance_criteria", ""),
        depends_on=args.get("depends_on", []),
        loop_back=args.get("loop_back", "") or None,
        priority=args.get("priority", 3),
    )

    # 執行（同步 MCP 中跑 async）
    router = A2ARouter(config, spawn_fn)
    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            # 在已有 event loop 中（MCP server 通常是 sync stdio）
            # 用 new loop
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor() as pool:
                result = pool.submit(asyncio.run, router.dispatch(handoff)).result()
        else:
            result = asyncio.run(router.dispatch(handoff))
    except Exception as e:
        return f"❌ smart_delegate 失敗: {e}"

    return result


_ALL_TOOLS = [
    {
        "name": "send_to_instance",
        "description": "向指定的 agent instance 發送訊息。用於分派任務或溝通。",
        "inputSchema": {
            "type": "object",
            "properties": {
                "instance": {"type": "string", "description": "目標 instance 名稱"},
                "message": {"type": "string", "description": "要發送的訊息內容"},
            },
            "required": ["instance", "message"],
        },
    },
    {
        "name": "delegate_task",
        "description": "委派任務給指定的 agent instance。會自動加上任務格式前綴。",
        "inputSchema": {
            "type": "object",
            "properties": {
                "instance": {"type": "string", "description": "目標 instance 名稱"},
                "task": {"type": "string", "description": "任務描述"},
            },
            "required": ["instance", "task"],
        },
    },
    {
        "name": "log_to_leader",
        "description": "把錯誤、過程細節、內部訊息私下發給綱手（pm-agent），使用者不可見。遇到錯誤或需要協調時使用，不要用 reply 把錯誤丟給使用者。",
        "inputSchema": {
            "type": "object",
            "properties": {
                "text": {"type": "string", "description": "要記錄的內容（錯誤訊息、過程說明）"},
            },
            "required": ["text"],
        },
    },
    {
        "name": "reply",
        "description": (
            "回覆使用者。訊息會發送到你所屬的 Telegram topic 或私聊。\n"
            "⚠️ 這是唯一會送到 Telegram 的工具。你的思考、工具呼叫、send_to_instance 內容都不會被使用者看到。\n"
            "📏 長度限制：primary ≤ 150 字、followup ≤ 100 字（style=report 時可放寬至 500 字）。\n"
            "🚫 禁貼：git/shell stdout、檔案列表、commit SHA、下屬 agent 的 raw 回報文字。\n"
            "✅ 應給：結論一句話 + 下一步問句（引導使用者決策）。\n"
            "kind='primary'（預設）為主訊息，kind='followup' 為補充訊息（會加 ↪️ 前綴）。\n"
            "style='chat'（預設）口語模式（Hi 開頭）；style='report' 結構化報告模式（排程/聯合報告用，自控格式）。\n"
            "建議用法：主結論用 primary，下一步建議／輔助說明用 followup 分兩次呼叫，形成自然對話節奏。"
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "text": {"type": "string", "description": "回覆內容（繁體中文，≤ 150 字）"},
                "kind": {
                    "type": "string",
                    "enum": ["primary", "followup"],
                    "default": "primary",
                    "description": "primary=主訊息；followup=補充訊息（加 ↪️ 前綴）",
                },
                "style": {
                    "type": "string",
                    "enum": ["chat", "report"],
                    "default": "chat",
                    "description": "chat=口語（加 header）；report=結構化報告（自控格式，不加 header）",
                },
                "template": {
                    "type": "string",
                    "enum": ["", "news-daily", "status-report", "ops-report", "task-dispatch", "error-alert"],
                    "default": "",
                    "description": "[v1.2.0] 具名 TG 模板：套固定標題格式（body 仍走 markdown）。空=default 現行格式",
                },
            },
            "required": ["text"],
        },
    },
    {
        "name": "query_team_status",
        "description": "查詢團隊 agent instance 的狀態。",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "record_spend",
        "description": (
            "（選用）回報自己估計的本次 API 消費（美元）。Kiro CLI 目前不直接暴露成本，"
            "此工具讓 agent 可依 token 數估算後主動回報，供 cost_guard 追蹤每日用量。"
            "若有 80% 警告或達每日上限會自動暫停。"
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "amount_usd": {"type": "number", "description": "本次消費金額（美元）"},
                "note": {"type": "string", "description": "選填備註（例：'opus-4 完成 GDD 撰寫'）"},
            },
            "required": ["amount_usd"],
        },
    },
    {
        "name": "create_task",
        "description": "在任務板建立新任務。Leader 派工時使用，會自動產生 tasks/items/*.md 檔案。",
        "inputSchema": {
            "type": "object",
            "properties": {
                "title": {"type": "string", "description": "任務標題"},
                "assignee": {"type": "string", "description": "指派的 agent instance 名稱"},
                "priority": {"type": "string", "enum": ["low", "medium", "high", "critical"], "default": "medium"},
                "depends_on": {"type": "array", "items": {"type": "string"}, "description": "依賴的任務 ID 列表（選填）"},
                "description": {"type": "string", "description": "任務需求描述"},
            },
            "required": ["title", "assignee"],
        },
    },
    {
        "name": "update_task",
        "description": "更新任務狀態。完成任務時提供 summary + metadata 做結構化交接（Handoff）。",
        "inputSchema": {
            "type": "object",
            "properties": {
                "task_id": {"type": "string", "description": "任務 ID"},
                "status": {"type": "string", "enum": ["pending", "in_progress", "completed", "blocked", "failed"]},
                "note": {"type": "string", "description": "備註（選填）"},
                "summary": {"type": "string", "description": "結構化交接摘要（完成時必填，≤200字）：改了什麼、如何驗證"},
                "metadata": {"type": "object", "description": "交接 metadata（選填）：changed_files, verification, residual_risk, retry_notes", "properties": {"changed_files": {"type": "array", "items": {"type": "string"}, "description": "變更的檔案清單"}, "verification": {"type": "array", "items": {"type": "string"}, "description": "驗證方式（指令或測試）"}, "residual_risk": {"type": "array", "items": {"type": "string"}, "description": "殘餘風險"}, "retry_notes": {"type": "string", "description": "重試提示"}}},
            },
            "required": ["task_id", "status"],
        },
    },
    {
        "name": "list_tasks",
        "description": "列出任務板上的任務。可依狀態篩選。",
        "inputSchema": {
            "type": "object",
            "properties": {
                "status": {"type": "string", "enum": ["pending", "in_progress", "completed", "blocked", "failed"], "description": "篩選狀態（選填，不填列出全部）"},
            },
        },
    },
    {
        "name": "broadcast_all",
        "description": "廣播訊息給所有 agent（排除自己）。用於全員通知。",
        "inputSchema": {
            "type": "object",
            "properties": {
                "message": {"type": "string", "description": "要廣播的訊息內容"},
            },
            "required": ["message"],
        },
    },
    {
        "name": "wiki_query",
        "description": "搜尋知識庫。預設搜自己的私有知識，指定 scope=shared 搜團隊共用。",
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "搜尋關鍵字或問題"},
                "scope": {
                    "type": "string",
                    "enum": ["self", "shared", "all"],
                    "default": "self",
                    "description": "self=自己私有（預設）、shared=團隊共享、all=全部",
                },
                "top_k": {"type": "integer", "default": 3, "description": "回傳結果數量"},
            },
            "required": ["query"],
        },
    },
    {
        "name": "wiki_ingest",
        "description": "將 raw/ 資料匯入 Wiki 知識庫（萃取 → 建頁 → 更新 index + log）。僅 leader/admin 可對 shared 執行。",
        "inputSchema": {
            "type": "object",
            "properties": {
                "source_path": {"type": "string", "description": "raw/ 下的來源檔案路徑"},
                "target_category": {"type": "string", "description": "目標分類目錄（選填）"},
                "scope": {
                    "type": "string",
                    "enum": ["shared", "self"],
                    "default": "self",
                    "description": "寫入目標：shared=團隊共享、self=自己私有",
                },
            },
            "required": ["source_path"],
        },
    },
    {
        "name": "reply_task_image",
        "description": "將任務板渲染為手機友善圖片並發送給使用者。適合需要視覺化呈現任務狀態時使用。",
        "inputSchema": {
            "type": "object",
            "properties": {
                "status": {
                    "type": "string",
                    "enum": ["pending", "in_progress", "completed", "blocked", "failed"],
                    "description": "篩選狀態（選填，不填顯示全部）",
                },
                "title": {"type": "string", "default": "任務板", "description": "圖片標題"},
            },
        },
    },
    {
        "name": "reply_file",
        "description": "發送檔案給使用者（支援任何檔案類型：.html/.pdf/.docx/.png/.csv 等）。檔案必須存在於本機磁碟。",
        "inputSchema": {
            "type": "object",
            "properties": {
                "file_path": {"type": "string", "description": "要發送的檔案絕對路徑"},
                "caption": {"type": "string", "default": "", "description": "檔案附帶說明文字（選填）"},
            },
            "required": ["file_path"],
        },
    },
    {
        "name": "smart_delegate",
        "description": "智慧派工：自動匹配最佳 agent + DAG 依賴管理 + 失敗自動修復。適合多步任務或不確定該派給誰時使用。",
        "inputSchema": {
            "type": "object",
            "properties": {
                "title": {"type": "string", "description": "任務標題"},
                "context": {"type": "string", "default": "", "description": "任務背景說明（≤500字）"},
                "to_agent": {"type": "string", "default": "auto", "description": "指定 agent 或 'auto' 自動匹配"},
                "depends_on": {
                    "type": "array",
                    "items": {"type": "string"},
                    "default": [],
                    "description": "依賴的 task_id 列表（這些完成後才執行）",
                },
                "acceptance_criteria": {"type": "string", "default": "", "description": "驗收條件"},
                "loop_back": {"type": "string", "default": "", "description": "完成後由誰驗收（feedback loop）"},
                "priority": {"type": "integer", "default": 3, "description": "1=urgent 2=high 3=normal 4=low"},
            },
            "required": ["title"],
        },
    },
    # [ark-agent 2026-07-30] Decision Loop tools
    {
        "name": "decision_digest",
        "description": "讀取 DecisionStore 指定日期的拍板紀錄，回傳結構化日報資料。供 ark daily-decision-digest skill 使用。",
        "inputSchema": {
            "type": "object",
            "properties": {
                "date": {"type": "string", "description": "查詢日期 YYYY-MM-DD，預設 yesterday"},
            },
            "required": [],
        },
    },
    {
        "name": "decision_overturn",
        "description": "翻案一筆 Decision Record。原因必填，翻案後通知原決策者與 requester，並寫知識回饋。",
        "inputSchema": {
            "type": "object",
            "properties": {
                "decision_id": {"type": "string", "description": "要翻案的 DR id，如 DR-20260730-01"},
                "reason": {"type": "string", "description": "翻案原因（必填，空字串拒絕）"},
            },
            "required": ["decision_id", "reason"],
        },
    },
]


# ── Decision tool handlers ────────────────────────────────────────────────────

def _handle_decision_digest(args: dict) -> str:
    """Read yesterday's (or specified date's) decision records for daily digest."""
    from datetime import datetime, timedelta, timezone
    from pathlib import Path
    import sqlite3, json

    date_str = args.get("date", "yesterday")
    tz = timezone.utc
    if date_str == "yesterday":
        target = (datetime.now(tz) - timedelta(days=1)).date()
    else:
        try:
            target = datetime.strptime(date_str, "%Y-%m-%d").date()
        except ValueError:
            return f"❌ 日期格式錯誤，請用 YYYY-MM-DD，收到：{date_str!r}"

    start = f"{target}T00:00:00+00:00"
    end = f"{target}T23:59:59+00:00"

    import os as _os
    from pathlib import Path as _Path
    try:
        from .config import get_home as _get_home
        db_path = _get_home() / "state" / "decisions.db"
    except Exception:
        _home = _os.environ.get("ARK_TEAM_AGENT_HOME", str(_Path.home() / ".ark-team-agent"))
        db_path = _Path(_home) / "state" / "decisions.db"
    if not db_path.exists():
        return f"昨日無拍板（decisions.db 尚未建立）。"

    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    records = conn.execute(
        "SELECT * FROM decision_records WHERE decided_at >= ? AND decided_at <= ? ORDER BY decided_at",
        (start, end),
    ).fetchall()
    escalated = conn.execute(
        "SELECT * FROM decision_requests WHERE state='escalated'",
    ).fetchall()
    conn.close()

    if not records and not escalated:
        return f"昨日無拍板（{target}）。"

    lines = [f"📋 拍板日報 {target}"]
    if records:
        lines.append(f"\n✅ 已拍板（{len(records)} 筆）")
        for r in records:
            status_note = "（已翻案）" if r["status"] == "overturned" else ""
            lines.append(
                f"• {r['decision_id']} | {r['decided_by']} | verdict={r['verdict']} "
                f"| {r['rationale'][:40]}... {status_note}"
                f"  [overturn:{r['decision_id']}]"
            )
    if escalated:
        lines.append(f"\n⏸ 待你決定 L3（{len(escalated)} 筆）")
        for e in escalated:
            lines.append(f"• {e['req_id']} | {e['requester']} | {e['question'][:50]}...")

    return "\n".join(lines)


def _handle_decision_overturn(args: dict) -> str:
    """Overturn a decision record. Notifies parties and writes knowledge feedback."""
    decision_id = args.get("decision_id", "").strip()
    reason = args.get("reason", "").strip()

    if not decision_id:
        return "❌ decision_id 必填。"
    if not reason:
        return "❌ 翻案原因必填 — 這是最高價值的訓練訊號，請說明 Paddy 希望的方向。"

    from pathlib import Path
    import sqlite3
    import os as _os2

    try:
        from .config import get_home as _get_home2
        db_path = _get_home2() / "state" / "decisions.db"
    except Exception:
        _home2 = _os2.environ.get("ARK_TEAM_AGENT_HOME", str(Path.home() / ".ark-team-agent"))
        db_path = Path(_home2) / "state" / "decisions.db"
    if not db_path.exists():
        return "❌ decisions.db 不存在。"

    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row

    # Get record
    rec = conn.execute(
        "SELECT * FROM decision_records WHERE decision_id=?", (decision_id,)
    ).fetchone()
    if not rec:
        conn.close()
        return f"❌ 找不到 Decision Record：{decision_id}"
    if rec["status"] != "effective":
        conn.close()
        return f"⚠️ {decision_id} 狀態為 {rec['status']}，無法翻案。"

    # Get request for requester info
    req = conn.execute(
        "SELECT * FROM decision_requests WHERE req_id=?", (rec["req_id"],)
    ).fetchone()
    requester = req["requester"] if req else None

    # Update status
    from datetime import datetime, timezone
    now = datetime.now(timezone.utc).isoformat()
    conn.execute(
        "UPDATE decision_records SET status='overturned', overturn_reason=? WHERE decision_id=?",
        (reason, decision_id),
    )
    conn.execute(
        "INSERT INTO decision_events VALUES (?,?,?,?)",
        (now, rec["req_id"], "decision_overturned",
         f'{{"decision_id":"{decision_id}","reason":"{reason}"}}'),
    )
    conn.commit()
    conn.close()

    # Notify parties via send_to_instance
    decided_by = rec["decided_by"]
    feedback = []
    if requester:
        feedback.append(
            _api("POST", "/api/send", {
                "instance": requester,
                "message": (
                    f"⚠️ Paddy 翻案了 {decision_id}\n"
                    f"原決定：{rec['verdict']} — {rec['rationale']}\n"
                    f"翻案原因：{reason}\n"
                    f"請停止依原 verdict 執行，等待進一步指示。"
                ),
                # [1.2.26] 原本寫死 "ark-agent"（nana 的入口名）。source 是「這則訊息
                # 來自誰」，實際呼叫本工具的是當前 instance —— 用全域 _instance。
                "source": _instance,
            })
        )
    if decided_by and decided_by != requester:
        feedback.append(
            _api("POST", "/api/send", {
                "instance": decided_by,
                "message": (
                    f"⚠️ Paddy 翻案了你的決定 {decision_id}\n"
                    f"原決定：{rec['verdict']} — {rec['rationale']}\n"
                    f"翻案原因：{reason}\n"
                    f"請更新 BRAIN.md 記錄此方針修正。"
                ),
                "source": _instance,
            })
        )

    # Write knowledge feedback via DecisionManager
    try:
        r = _api("POST", "/api/send", {
            "instance": "decision-manager",
            "message": (
                f"write_knowledge_feedback\n"
                f"decision_id: {decision_id}\n"
                f"req_id: {rec['req_id']}\n"
                f"original_owner: {decided_by}\n"
                f"verdict: {rec['verdict']}（已翻案：{reason}）\n"
                f"rationale: Paddy 翻案 — {reason}\n"
                f"decided_by: Paddy"
            ),
            "source": _instance,
        })
    except Exception:
        pass

    return (
        f"✅ 已翻案 {decision_id}\n"
        f"原因：{reason}\n"
        f"已通知：{decided_by}{'、' + requester if requester and requester != decided_by else ''}"
    )


if __name__ == "__main__":
    main()
