"""Team scheduler — asyncio-based scheduled tasks driven by scheduler.yaml."""
from __future__ import annotations

import asyncio
import logging
import re
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

from apscheduler.triggers.cron import CronTrigger

from .config import ScheduledJobConfig, SchedulerConfig, load_scheduler_config

log = logging.getLogger(__name__)


# [claude-code 2026-08-05] 手寫 cron 解析器已移除，改用 apscheduler 的 CronTrigger。
#
# 舊實作 _parse_cron 只回傳 (minute_set, hour_set)，第 3/4/5 欄（日、月、星期）
# 解析後直接丟棄，docstring 也自述 "only minute + hour used"。後果是
# "0 18 * * 1"（每週一）實際每天觸發，"30 8 * * 1-5"（平日）週末照跑。
# apscheduler 早已是本專案依賴，直接改用它並順帶取得完整 cron 語意。

_CRON_DOW_NAMES = ("sun", "mon", "tue", "wed", "thu", "fri", "sat")


def _normalize_dow(field: str) -> str:
    """把標準 cron 的星期數字轉成 APScheduler 認得的名稱。

    ⚠️ 兩者的數字語意差一天：
      - 標準 cron：0 = 週日（7 也是週日）
      - APScheduler：0 = 週一

    直接把數字傳給 `CronTrigger.from_crontab()` 會讓所有排程偏移一天
    （"* * 1" 會變成週二）。名稱形式在兩邊一致，故統一轉成名稱。
    範圍、列舉、步進皆原樣保留（"1-5" → "mon-fri"、"1-5/2" → "mon-fri/2"）。
    注意步進值（"/" 之後）是次數不是星期，不可轉換。

    Author: claude-code
    """
    def convert(token: str) -> str:
        head, sep, step = token.partition("/")
        head = re.sub(r"\d+", lambda m: _CRON_DOW_NAMES[int(m.group()) % 7], head)
        return head + sep + step

    return ",".join(convert(t) for t in field.split(","))


def _to_crontab(cron: str) -> str:
    """把本專案支援的排程語法正規化為標準 5 欄位 crontab。

    支援格式：
      - "hourly:MM"    → 每小時 :MM
      - "daily:HH:MM"  → 每天 HH:MM（MM 可省略，預設 0）
      - 標準 5 欄位 crontab（星期以標準 cron 語意解讀，見 _normalize_dow）

    Raises:
        ValueError: 無法解析時。

    Author: claude-code
    """
    cron = cron.strip()

    if cron.startswith("hourly:"):
        mm = int(cron.split(":")[1])
        return f"{mm} * * * *"

    if cron.startswith("daily:"):
        parts = cron.split(":")
        hh = int(parts[1])
        mm = int(parts[2]) if len(parts) > 2 else 0
        return f"{mm} {hh} * * *"

    fields = cron.split()
    if len(fields) == 5:
        fields[4] = _normalize_dow(fields[4])
        return " ".join(fields)

    raise ValueError(f"無法解析的 cron 設定：{cron!r}")


def _cron_matches(cron: str, now: datetime, tz: ZoneInfo | None = None) -> bool:
    """判斷 `now` 所在的那一分鐘是否符合 cron 設定。

    naive datetime 會以 tz（或系統時區）解讀，以相容既有呼叫端與測試。

    Author: claude-code
    """
    try:
        expr = _to_crontab(cron)
    except (ValueError, IndexError) as e:
        log.warning("Invalid cron %r: %s", cron, e)
        return False

    if now.tzinfo is None and tz is not None:
        now = now.replace(tzinfo=tz)

    minute = now.replace(second=0, microsecond=0)
    try:
        trigger = CronTrigger.from_crontab(expr, timezone=now.tzinfo or tz)
        # get_next_fire_time 回傳「嚴格晚於 now」的下一次，故往前退一分鐘再問
        next_fire = trigger.get_next_fire_time(None, minute - timedelta(minutes=1))
    except (ValueError, TypeError) as e:
        log.warning("Invalid cron %r (crontab=%r): %s", cron, expr, e)
        return False

    return next_fire is not None and next_fire.replace(second=0, microsecond=0) == minute


def _expand_prompt(prompt: str, now: datetime) -> str:
    """Replace {date} placeholder with current date string."""
    return prompt.replace("{date}", now.strftime("%Y-%m-%d"))


class TeamScheduler:
    """Asyncio-based scheduler for team-agent periodic tasks.

    Reads job definitions from scheduler.yaml (via SchedulerConfig).
    Each job specifies: target instance, prompt text, and cron timing.
    """

    def __init__(self, daemon, config: SchedulerConfig | None = None,
                 project_root: "Path | str | None" = None) -> None:
        self.daemon = daemon
        self.config = config or load_scheduler_config()
        # [1.2.6] 專案根改為可注入（呼叫端已知 team.yaml 位置）；未注入才由
        # resolve_project_root() 解析（env → cwd 向上找哨兵）。不再用 .parent 層數推導。
        self._project_root = project_root
        self._task: asyncio.Task | None = None
        self._last_key: int = -1  # prevent duplicate fire in same minute

    def start(self) -> None:
        if not self.config.jobs:
            log.info("TeamScheduler: no jobs configured, skipping")
            return
        enabled = [j for j in self.config.jobs if j.enabled]
        log.info("TeamScheduler started (%d jobs, %d enabled)", len(self.config.jobs), len(enabled))
        self._task = asyncio.create_task(self._run())

    def stop(self) -> None:
        if self._task:
            self._task.cancel()
            self._task = None
        log.info("TeamScheduler stopped")

    def reload(self, config: SchedulerConfig | None = None) -> None:
        """Hot-reload scheduler config."""
        self.stop()
        self.config = config or load_scheduler_config()
        self.start()

    async def _run(self) -> None:
        while True:
            try:
                await asyncio.sleep(30)  # tick every 30s
                tz = ZoneInfo(self.config.timezone)
                now = datetime.now(tz)
                key = now.hour * 100 + now.minute

                if key == self._last_key:
                    continue
                self._last_key = key

                for job in self.config.jobs:
                    if not job.enabled:
                        continue
                    await self._check_and_fire(job, now)

            except asyncio.CancelledError:
                return
            except Exception as e:
                log.warning("Scheduler tick error: %s", e)

    async def _check_and_fire(self, job: ScheduledJobConfig, now: datetime) -> None:
        """Check if job should fire at current time, and send if so."""
        # [claude-code 2026-08-05] job.timezone 現在會影響「是否觸發」，不只 {date}
        # 舊實作先用全域時區比對 cron，比對通過後才讀 job.timezone 重算 job_now，
        # 而 job_now 只用於展開 {date} —— 設定者以為改了執行時間，實際沒有。
        if job.timezone:
            job_tz = ZoneInfo(job.timezone)
            job_now = datetime.now(job_tz)
        else:
            job_tz = ZoneInfo(self.config.timezone) if self.config.timezone else None
            job_now = now

        if not _cron_matches(job.cron, job_now, job_tz):
            return

        # Built-in jobs (target starts with _builtin:)
        if job.target.startswith("_builtin:"):
            builtin_name = job.target.split(":", 1)[1]
            if builtin_name == "spec-validator":
                await self.run_spec_validator()
            elif builtin_name == "memory-consolidate":
                self.run_memory_consolidate(job_now)  # [1.2.4 N5-B1]（同步檔案操作）
            elif builtin_name == "output-ttl":
                self.run_output_ttl(job_now)  # [1.2.7]（同步、只提醒不刪）
            elif builtin_name == "ingest-queue":
                await self.run_ingest_queue(job, job_now)  # [1.4.0]（機械產清單 → 派給 agent）
            else:
                log.warning("Unknown builtin job: %s", builtin_name)
            return

        prompt = _expand_prompt(job.prompt, job_now)
        await self._send(job.target, prompt, job.name)

    async def _send(self, instance: str, msg: str, job_name: str) -> None:
        try:
            # [1.2.16] 標記來源 —— 排程任務沒有「使用者下一步」，回覆後應進 IDLE 而非
            # AWAITING_REPLY（後者會關掉 hang 偵測，真掛死時 4-6 小時無人知）
            ok = await self.daemon.send_message(instance, msg, source="scheduler")
            log.info("⏰ %s → %s (ok=%s)", job_name, instance, ok)
        except Exception as e:
            log.warning("Scheduler [%s] send failed to %s: %s", job_name, instance, e)

    async def run_ingest_queue(self, job=None, now=None) -> str:
        """[1.4.0] 把「請沉澱知識」從開放式任務變成有明確輸入的清單。

        ## 為什麼需要這個

        既有的知識沉澱是**排程提醒 agent 自己去做**：
        「今天有產出的話，請把學到的寫進 `knowledge/raw/`」。
        那是一個**沒有明確輸入的任務** —— agent 收到後得自己回想今天學到什麼，
        而它的 session 可能已經 compact 過，回想不了。實測六個部署的
        `knowledge/raw/` 多數停在建團初期，之後幾乎沒有新增。

        更糟的是**下游會回報成功**：ingest job 掃自己指定的路徑、找不到新檔、
        回報「新增 0 篇」—— 看起來一切正常。**掃不到東西卻回報成功 = 假綠燈。**

        ## 這個 job 做什麼

        **機械掃出「還沒被 ingest 的檔案」，把清單當成任務內容發出去。**
        自己不做萃取（那需要 LLM），只負責讓任務有界：

            現在： 「請沉澱知識」                    → agent 不知道從哪開始
            之後： 「這 3 個檔還沒 ingest：A、B、C」  → 有明確輸入

        判斷「還沒被 ingest」的依據是 **檔名沒出現在該櫃子的 `index.md`**
        —— 刻意不用 mtime 或狀態檔：
        - mtime 會因為 `git pull`／`cp` 而全體更新，一次噴出幾百個假新檔
        - 狀態檔會與實際 index 漂移，而 `index.md` 本來就是知識庫的真相來源

        ## 設定

        ```yaml
        - name: ingest-queue
          cron: "0 22 * * *"
          target: _builtin:ingest-queue
          prompt: "writer-agent"        # ← 收清單的 agent（留空則自動找）
        ```

        `batch`（預設 5）在 `prompt` 用 `agent:N` 指定，例如 `writer-agent:3`。
        **上限存在的理由**：一次丟 309 個檔跟丟 0 個一樣沒用 —— 都會讓 agent
        不知從何下手。分批才會真的動起來。

        Author: ark-agent（1.4.0）
        """
        from pathlib import Path

        target, batch = self._ingest_target_and_batch(job)
        if not target:
            log.warning("ingest-queue：找不到可派工的 agent（需 role=worker/leader 或明確指定）")
            return "no target"

        pending = self._scan_pending_ingest(limit=batch)
        if not pending:
            log.info("ingest-queue：沒有待 ingest 的檔案（%s 已是最新）", target)
            return "nothing pending"

        listing = "\n".join(f"{i}. {rel}" for i, rel in enumerate(pending, 1))
        prompt = (
            f"📚 知識 ingest 佇列（機械掃出，共 {len(pending)} 個尚未在 index.md 出現的檔案）：\n"
            f"{listing}\n\n"
            "請**逐一**處理：讀檔 → 萃取成 wiki 頁面（含 frontmatter + [[wikilink]]）"
            "→ 同步該櫃子的 index.md → append log.md。\n"
            "🚫 不要自己去找別的檔案 —— 這份清單就是本次的全部工作範圍。\n"
            "做不完的部分直接說「剩 N 個未處理」，下次排程會再列出來。\n"
            'reply 回報：處理幾個、新增幾篇（≤ 100 字，不要列檔名清單），style="report"。'
        )
        await self._send(target, prompt, getattr(job, "name", "ingest-queue"))
        log.info("ingest-queue：派 %d 個檔給 %s", len(pending), target)
        return f"queued {len(pending)} → {target}"

    def _ingest_target_and_batch(self, job) -> tuple[str | None, int]:
        """從 `prompt` 取 `agent` 或 `agent:N`；未指定則挑第一個 worker（其次 leader）。"""
        raw = (getattr(job, "prompt", "") or "").strip()
        batch = 5
        target: str | None = None
        if raw:
            head = raw.splitlines()[0].strip()
            if ":" in head:
                name, _, num = head.rpartition(":")
                if num.isdigit():
                    target, batch = name.strip(), max(1, int(num))
                else:
                    target = head
            else:
                target = head
        insts = getattr(getattr(self.daemon, "config", None), "instances", {}) or {}
        if target and target in insts:
            return target, batch
        if target:
            log.warning("ingest-queue：指定的 %s 不在 instances，改自動挑選", target)
        for want in ("worker", "leader"):
            for name, ic in insts.items():
                if (getattr(ic, "role", "") or "") == want:
                    return name, batch
        return None, batch

    def _scan_pending_ingest(self, *, limit: int = 5) -> list[str]:
        """掃出「檔名沒出現在同櫃 index.md」的 raw 檔案，回相對專案根的路徑。

        掃描範圍是**所有 `knowledge/*/raw/` 與 `knowledge/raw/`**，
        含各 instance 的 working_directory 底下那份 ——
        ⚠️ 這一點是刻意的：實測有個部署的 ingest 提詞只寫
        `agents/*/knowledge/raw/`，而 309 個待萃取的原始檔在**根目錄的**
        `knowledge/github/raw/` → **永遠不在掃描範圍內，而 job 照樣回報成功。**
        路徑寫死在提詞裡就會發生這種事，所以改由套件掃。
        """
        from pathlib import Path

        # ⚠️ `self._project_root` 是**注入的值（可能是 None）**，不是函式 ——
        # 要經 `resolve_project_root()` 才是實際路徑（同 run_spec_validator 的用法）。
        from .paths import resolve_project_root
        root = Path(resolve_project_root(self._project_root))
        roots: list[Path] = [root / "knowledge"]
        insts = getattr(getattr(self.daemon, "config", None), "instances", {}) or {}
        for ic in insts.values():
            wd = getattr(ic, "working_directory", "") or ""
            if wd:
                k = Path(wd) / "knowledge"
                if k.resolve() != (root / "knowledge").resolve():
                    roots.append(k)

        SKIP = {".git", "archive", "memory-archive", "node_modules", "__pycache__"}
        out: list[str] = []
        seen: set[str] = set()
        for kroot in roots:
            if not kroot.is_dir():
                continue
            for raw_dir in sorted(kroot.rglob("raw")):
                if not raw_dir.is_dir() or any(part in SKIP for part in raw_dir.parts):
                    continue
                # index.md 找同櫃（raw 的上一層），沒有就往上一層找
                index_text = ""
                for cand in (raw_dir.parent / "index.md", kroot / "index.md"):
                    if cand.is_file():
                        try:
                            index_text += cand.read_text(encoding="utf-8", errors="ignore")
                        except OSError:
                            pass
                for f in sorted(raw_dir.rglob("*")):
                    # follow_symlinks 預設 True 會走進外部 repo；這裡只收檔案本身，
                    # 是否要跟隨由部署自己用 symlink 決定（與 reply_file 的封閉檢查無關）
                    if not f.is_file() or f.suffix.lower() not in (".md", ".txt", ".json", ".yaml", ".yml"):
                        continue
                    if any(part in SKIP for part in f.parts):
                        continue
                    if f.stem in index_text:      # 檔名已登記 → 視為已 ingest
                        continue
                    try:
                        rel = str(f.relative_to(root))
                    except ValueError:
                        rel = str(f)
                    if rel in seen:
                        continue
                    seen.add(rel)
                    out.append(rel)
                    if len(out) >= limit:
                        return out
        return out

    def run_output_ttl(self, now=None) -> str:
        """[1.2.7] Output 超期提醒（取經 hoyeah #15）：**只提醒不刪除**。

        依 BRAIN.md 的 Output 分類 TTL 掃各 instance 的 `output/`：
        `reports/` `drafts/` 30 天、`exports/` 14 天、`skills/` 7 天。
        超期檔數記 `degraded[output_ttl_overdue:<n>]` + log，由使用者決定清理。

        Author: ark-agent
        """
        from pathlib import Path
        from datetime import datetime, timezone

        _now = now or datetime.now(timezone.utc)
        TTL_DAYS = {"reports": 30, "drafts": 30, "exports": 14, "skills": 7}
        overdue: list[str] = []
        insts = getattr(getattr(self.daemon, "config", None), "instances", {}) or {}
        for name, ic in insts.items():
            out = Path(getattr(ic, "working_directory", "") or "") / "output"
            if not out.is_dir():
                continue
            for sub, days in TTL_DAYS.items():
                d = out / sub
                if not d.is_dir():
                    continue
                n = 0
                for f in d.rglob("*"):
                    if not f.is_file():
                        continue
                    try:
                        age = (_now.timestamp() - f.stat().st_mtime) / 86400
                    except OSError:
                        continue
                    if age > days:
                        n += 1
                if n:
                    overdue.append(f"{name}/output/{sub}:{n}")

        if overdue:
            total = sum(int(x.rsplit(":", 1)[1]) for x in overdue)
            summary = f"output-ttl: {total} 個超期檔待清理（{', '.join(overdue[:6])}）"
            note = f"output_ttl_overdue:{total}"
            if hasattr(self.daemon, "degraded"):
                # 汰換舊的同類標記（數量會變）
                self.daemon.degraded[:] = [
                    x for x in self.daemon.degraded if not str(x).startswith("output_ttl_overdue:")
                ]
                self.daemon.degraded.append(note)
        else:
            summary = "output-ttl: 無超期檔"
            if hasattr(self.daemon, "degraded"):
                self.daemon.degraded[:] = [
                    x for x in self.daemon.degraded if not str(x).startswith("output_ttl_overdue:")
                ]
        log.info("⏰ %s", summary)
        return summary

    def run_memory_consolidate(self, now=None) -> str:
        """[1.2.4 N5-B1] 純機械記憶治理（無 LLM）：

        對每個 instance：

        1. `memory/daily/*.md` 檔名日期（或 mtime）> 14 天者**搬移**到
           `memory/daily/archive/`（非破壞性，不刪除）
        2. **[1.2.20]** `.kiro/steering/MEMORY.md` 的日期分節 > 14 天者搬到
           `knowledge/raw/memory-archive/YYYY-MM.md`，原處留指標
        3. `memory.md` 超過軟上限（~2000 tokens）則記 degraded 提醒整理
           （不做破壞性截斷 —— 智慧摘要交給 prompt job）

        **為什麼補上第 2 項**：`.kiro/steering/MEMORY.md` 是 **always-on 載入**的檔案，
        每次對話都吃 context，而它自己寫著「> 2 週的段落移到 knowledge/」——
        原本沒有任何機制執行。實測 ark-agent 636 行、pm-agent 626 行。
        相對地第 3 項的 `memory/memory.md` 實測只有 45 行，**根本不是問題所在**。

        Author: ark-agent
        """
        from pathlib import Path
        from datetime import datetime, timezone
        import re as _re

        from .memory_archive import archive_memory_sections

        _now = now or datetime.now(timezone.utc)
        _now_naive = _now.replace(tzinfo=None)
        ARCHIVE_DAYS = 14
        SOFT_CAP_BYTES = 8000  # ~2000 tokens 粗估
        archived = 0
        sections_archived = 0
        oversized: list[str] = []
        insts = getattr(getattr(self.daemon, "config", None), "instances", {}) or {}
        for name, ic in insts.items():
            base = Path(getattr(ic, "working_directory", "") or "")
            daily = base / "memory" / "daily"
            if daily.is_dir():
                for md in daily.glob("*.md"):
                    age = None
                    m = _re.match(r"(\d{4})-(\d{2})-(\d{2})", md.stem)
                    if m:
                        try:
                            fdate = datetime(int(m[1]), int(m[2]), int(m[3]))
                            age = (_now_naive - fdate).days
                        except ValueError:
                            age = None
                    if age is None:
                        age = (_now.timestamp() - md.stat().st_mtime) / 86400
                    if age > ARCHIVE_DAYS:
                        arch = daily / "archive"
                        arch.mkdir(parents=True, exist_ok=True)
                        try:
                            md.rename(arch / md.name)
                            archived += 1
                        except OSError as e:
                            log.debug("memory-consolidate archive failed %s: %s", md, e)
            # [1.2.20] always-on 的 steering/MEMORY.md 才是 context 膨脹的來源
            try:
                sec_n, _titles = archive_memory_sections(
                    base / ".kiro" / "steering" / "MEMORY.md",
                    base / "knowledge" / "raw" / "memory-archive",
                    today=_now_naive.date(),
                    keep_days=ARCHIVE_DAYS,
                )
                sections_archived += sec_n
            except Exception as e:      # 歸檔失敗不得中斷整個 job
                log.warning("memory-consolidate: steering 歸檔失敗 %s: %s", name, e)

            mem = base / "memory" / "memory.md"
            try:
                if mem.is_file() and mem.stat().st_size > SOFT_CAP_BYTES:
                    oversized.append(name)
            except OSError:
                pass

        summary = (f"memory-consolidate: 歸檔 {archived} 筆 daily log"
                   f"、{sections_archived} 個 MEMORY.md 段落")
        if oversized:
            summary += f"；memory.md 超標待整理: {', '.join(oversized)}"
            note = f"memory_oversized:{','.join(sorted(oversized))}"
            if hasattr(self.daemon, "degraded") and note not in self.daemon.degraded:
                self.daemon.degraded.append(note)
        log.info("⏰ %s", summary)
        return summary

    def _digest_shelf(self, project_root: Path) -> Path | None:
        """drift 日誌／索引的寫入目標知識庫 —— **依 role 推導，不寫死 instance 名**。

        [1.3.1] 原本寫死 nana 的 `cto-agent`：
            `agents/cto-agent/knowledge/` → fallback `knowledge/cto-agent/`
        其他部署沒有這個 instance，於是 drift 日誌**永遠寫不進去**。
        1.2.6 補了 degraded 告警讓它不再靜默，但沒治根。

        現在的順序：第一個 `admin` → 第一個 `manager` → None。

        ⚠️ **用 `working_directory`，不要猜 `agents/{name}`** —— 各部署的佈局不同：
        nana 是 `agents/<name>/`，aiops 的 agent 目錄**直接在專案根下**。
        更糟的是 aiops 還有一個殘留的 `agents/` 目錄（裡面有 `itom-agent/`），
        猜路徑會撞上它 → 把 drift 日誌寫進**沒人在用的目錄**。
        （第一版就是這樣寫的，實測 aiops 的 admin 是 `admin-agent` 卻推導到
        `agents/itom-agent/knowledge`，才發現。）

        `working_directory` 已由 config loader 解析成絕對路徑，是唯一可靠的來源。
        另留一條 fallback：`working_directory` 就是專案根的 agent（如 nana 的
        `ark-agent`）沒有自己的目錄，它的櫃子是 `knowledge/{name}/`。

        回 None 代表**連 admin／manager 都沒有知識庫目錄** —— 呼叫端會記 degraded。

        Author: ark-agent（1.3.1）
        """
        from pathlib import Path   # 本檔慣例：函式內 import（模組層級沒有 pathlib）

        cfg = getattr(self.daemon, "config", None)
        insts = getattr(cfg, "instances", None) if cfg is not None else None
        if not insts:
            return None
        for want in ("admin", "manager"):
            for name, ic in insts.items():
                if (getattr(ic, "role", "") or "") != want:
                    continue
                wd = getattr(ic, "working_directory", None)
                cands: list[Path] = []
                if wd:
                    _wd = Path(wd)
                    try:
                        _is_root = _wd.resolve() == project_root.resolve()
                    except OSError:
                        _is_root = False
                    # wd 是專案根 → 用自己的櫃子（不能用 knowledge/ 那層，那是共用的）
                    cands.append(project_root / "knowledge" / name if _is_root
                                 else _wd / "knowledge")
                cands.append(project_root / "knowledge" / name)   # 歷史相容
                for cand in cands:
                    if cand.is_dir():
                        return cand
        return None

    async def run_spec_validator(self) -> str:
        """Run code-spec validator and return summary. Can be triggered by scheduler or manually."""
        from pathlib import Path
        from datetime import date as _date

        try:
            from .code_spec_validator.validator import validate_project
            from .paths import resolve_project_root
            # [1.2.6] 原 parent×3 在 pip 安裝時指到 .venv/lib/python3.x → 掃錯目錄。
            # 改為注入優先、否則 env/哨兵解析。
            project_root = resolve_project_root(self._project_root)
            report = validate_project(project_root)
            log.info("⏰ spec-validator: %s", report.summary)

            # Phase 5: Update wiki log.md with drift result
            # [1.3.1] 目標改為**依 role 推導**（見 `_digest_shelf()`）。
            # 原本寫死 nana 的 `cto-agent` —— 其他部署沒有這個 instance，
            # 於是 drift 日誌永遠寫不進去（1.2.6 補了 degraded 告警，但沒治根）。
            _shelf = self._digest_shelf(project_root)
            wiki_log = (_shelf / "log.md") if _shelf else (project_root / "__no_digest_target__" / "log.md")
            today = str(_date.today())
            entry = f"- **{today}** | validate | spec-drift: {report.summary}\n"
            if wiki_log.exists():
                # append-only, no race on log.md (sequential writes safe)
                with open(wiki_log, "a", encoding="utf-8") as f:
                    f.write(entry)
            else:
                # [1.2.6] 原本目標寫死 nana 的 cto-agent，其他團隊無此路徑 →
                # 安靜什麼都不做，維運無從得知。改為明示 log + degraded。
                # [1.3.1] 目標已改依 role 推導，走到這裡代表**連 admin 的知識庫都沒有**。
                log.info("spec-validator: 找不到 drift 日誌目標（%s）—— "
                         "需要某個 admin／manager 有 knowledge/ 目錄，略過寫入", wiki_log)
                _note = "spec_validator_no_digest_target"
                if hasattr(self.daemon, "degraded") and _note not in self.daemon.degraded:
                    self.daemon.degraded.append(_note)

            # Ensure drift-report is in index.md
            # Use atomic read-check-write to reduce race window
            wiki_index = (_shelf / "index.md") if _shelf else (project_root / "__no_digest_target__" / "index.md")
            if wiki_index.exists():
                idx_content = wiki_index.read_text(encoding="utf-8")
                if "[[drift-report]]" not in idx_content:
                    # Write atomically: write to temp then replace
                    import tempfile as _tf
                    tmp = wiki_index.parent / f".index_tmp_{id(entry)}.md"
                    try:
                        tmp.write_text(idx_content + "- [[drift-report]] — Spec Drift 驗證報告\n", encoding="utf-8")
                        tmp.replace(wiki_index)
                    except Exception:
                        tmp.unlink(missing_ok=True)

            return report.summary
        except Exception as e:
            log.warning("Spec validator failed: %s", e)
            return f"❌ Validator error: {e}"
