"""Skill Extractor — auto-extract reusable skills from complex task completions.

After a multi-step task is completed, evaluate whether the workflow is worth
saving as a structured Skill document for future reuse.
"""
from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from datetime import date
from pathlib import Path

log = logging.getLogger(__name__)

_DEFAULT_MIN_STEPS = 5
_DEFAULT_COOLDOWN = 7200  # 2 hours between extractions per instance


@dataclass
class ExtractorConfig:
    """Configuration for skill extraction behavior."""

    min_steps: int = _DEFAULT_MIN_STEPS
    cooldown_seconds: float = _DEFAULT_COOLDOWN
    enabled: bool = True
    output_dir: str = "skills"  # relative to agent working_directory


@dataclass
class _ExtractorState:
    """Per-instance extraction tracking."""

    last_extraction_time: float = 0
    total_extractions: int = 0


# Template for auto-generated skill document
SKILL_TEMPLATE = """\
---
title: "{title}"
type: skill
tags: [{tags}]
created: {created}
trigger: "{trigger}"
status: draft
source: auto-extracted
---

# {title}

> 自動萃取自 {instance} 的工作流程（{step_count} 步驟）

## 觸發條件

{trigger_desc}

## 前置條件

{prerequisites}

## 步驟

{steps}

## 注意事項

{notes}

## 產出

{outputs}

---

*自動萃取：{created}*
"""

# Prompt to send to agent for extraction decision
EXTRACTION_PROMPT = (
    "🎓 [Skill Extraction] 剛才的任務完成了，使用了 {step_count} 個步驟"
    "（{tool_summary}）。\n\n"
    "請評估是否值得萃取為可重用的 Skill：\n"
    "- 這個流程未來會重複嗎？\n"
    "- 有明確的觸發條件嗎？\n"
    "- 步驟可以被標準化嗎？\n\n"
    "如果值得，請用以下格式回覆（直接寫檔）：\n"
    "1. 建立 `scripts/skills/<slug>.md`\n"
    "2. 包含：觸發條件、前置條件、步驟（numbered）、注意事項、預期產出\n\n"
    "如果不值得，繼續工作即可。"
)


class SkillExtractor:
    """Evaluate completed tasks and suggest or auto-generate Skill documents.

    Works with SkillGrowthDetector output — when a complex task is detected,
    the extractor provides the prompt or generates a skill template.

    Usage:
        extractor = SkillExtractor()
        if extractor.should_extract("my-agent", step_count=12, tools=["Write", "Bash", ...]):
            prompt = extractor.get_extraction_prompt(step_count=12, tools=["Write", "Bash"])
            # send prompt to agent
            extractor.mark_extracted("my-agent")
    """

    def __init__(self, config: ExtractorConfig | None = None) -> None:
        self.config = config or ExtractorConfig()
        self._states: dict[str, _ExtractorState] = {}

    def _get_state(self, instance: str) -> _ExtractorState:
        if instance not in self._states:
            self._states[instance] = _ExtractorState()
        return self._states[instance]

    def should_extract(self, instance: str, step_count: int, tools: list[str]) -> bool:
        """Determine if a completed task warrants skill extraction."""
        if not self.config.enabled:
            return False

        if step_count < self.config.min_steps:
            return False

        # Diversity check: at least 3 different tool types
        unique_tools = set(tools)
        if len(unique_tools) < 3:
            return False

        # Cooldown check
        state = self._get_state(instance)
        now = time.time()
        if state.last_extraction_time and (now - state.last_extraction_time) < self.config.cooldown_seconds:
            return False

        return True

    def get_extraction_prompt(self, step_count: int, tools: list[str]) -> str:
        """Generate the extraction prompt to send to the agent."""
        unique = set(tools)
        tool_summary = ", ".join(sorted(unique)[:5])
        if len(unique) > 5:
            tool_summary += f" +{len(unique) - 5}"
        return EXTRACTION_PROMPT.format(
            step_count=step_count,
            tool_summary=tool_summary,
        )

    def generate_skill_file(
        self,
        *,
        title: str,
        instance: str,
        step_count: int,
        trigger: str = "",
        trigger_desc: str = "（待補充）",
        prerequisites: str = "- 無特殊前置條件",
        steps: str = "1. （待補充）",
        notes: str = "- 自動萃取，需人工 review 確認",
        outputs: str = "- （待補充）",
        tags: str = "auto-extracted",
        output_path: Path | None = None,
    ) -> Path:
        """Generate a skill markdown file from the template."""
        content = SKILL_TEMPLATE.format(
            title=title,
            instance=instance,
            step_count=step_count,
            trigger=trigger or title,
            trigger_desc=trigger_desc,
            prerequisites=prerequisites,
            steps=steps,
            notes=notes,
            outputs=outputs,
            tags=tags,
            created=str(date.today()),
        )

        if output_path is None:
            slug = _slugify(title)
            output_path = Path(self.config.output_dir) / f"{slug}.md"

        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(content, encoding="utf-8")
        log.info("Generated skill file: %s", output_path)
        return output_path

    def mark_extracted(self, instance: str) -> None:
        """Mark that an extraction was performed."""
        state = self._get_state(instance)
        state.last_extraction_time = time.time()
        state.total_extractions += 1
        log.info("Skill extracted for %s (total: %d)", instance, state.total_extractions)

    def reset(self, instance: str) -> None:
        """Reset state for an instance."""
        self._states.pop(instance, None)

    def get_stats(self, instance: str) -> dict:
        """Get extraction stats for an instance."""
        state = self._get_state(instance)
        return {
            "total_extractions": state.total_extractions,
            "min_steps": self.config.min_steps,
            "cooldown_seconds": self.config.cooldown_seconds,
            "enabled": self.config.enabled,
        }


def _slugify(text: str) -> str:
    """Convert title to URL-safe slug."""
    import re
    slug = re.sub(r"[^\w\u4e00-\u9fff-]", "-", text)
    slug = re.sub(r"-+", "-", slug).strip("-")
    return slug[:50]
