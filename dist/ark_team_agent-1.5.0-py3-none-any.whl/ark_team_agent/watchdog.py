"""WatchdogDaemon — 外層守護，監控主 Daemon 進程並在崩潰時自動重啟。

用法：
    py -m ark_team_agent.watchdog

功能：
- 啟動並監控 `ark_team_agent team start` 子進程
- 崩潰時指數退避重啟（2s → 4s → ... → 最大 300s）
- 連續 10 次崩潰 → 冷卻 10 分鐘 → 自動恢復
- 正常退出（exit 0）不重啟
- 寫入 heartbeat 檔案供外部監控
- restart.flag 觸發立即重啟（跳過退避）

> 🔴 **[1.3.3] 這是「可選的替代 supervisor」，不是必要元件。**
>
> 本模組**沒有任何地方 import 它** —— 只能用 `python -m ark_team_agent.watchdog`
> 手動啟動。實測六個生產部署**都沒有跑它**（用 systemd `Restart=always`）。
>
> 這件事害人過：有人看到本檔會讀 `restart.flag`，就推論「TG 重啟功能是靠 watchdog」，
> 於是找不到 watchdog 進程時得出「重啟壞了」的結論。**實際上 Linux 靠的是
> SIGTERM + systemd。** 三種 supervisor 的對照見 `restart.py` 的模組 docstring。
>
> 只有真的跑起本模組時，`restart.flag` 才會被消費 ——
> 所以 `_spawn()` 會給子進程設 `ARK_TEAM_AGENT_WRAPPER=1`，讓套件知道該寫 flag。
"""
from __future__ import annotations

import logging
import os
import signal
import subprocess
import sys
import time
from pathlib import Path

log = logging.getLogger(__name__)

MAX_RESTART = 10
COOLDOWN_SECONDS = 600
MAX_BACKOFF = 300
HEARTBEAT_FILE = "state/watchdog_heartbeat"


class WatchdogDaemon:
    """監控主 Daemon 進程的外層守護。"""

    def __init__(
        self,
        max_restart: int = MAX_RESTART,
        cooldown: float = COOLDOWN_SECONDS,
        heartbeat_path: str = HEARTBEAT_FILE,
    ) -> None:
        self._max_restart = max_restart
        self._cooldown = cooldown
        self._heartbeat_path = Path(heartbeat_path)
        self._consecutive_failures = 0
        self._running = True
        self._proc: subprocess.Popen | None = None

    def run(self) -> None:
        """主迴圈：啟動 → 監控 → 崩潰重啟。"""
        self._setup_signals()
        self._heartbeat_path.parent.mkdir(parents=True, exist_ok=True)
        log.info("Watchdog 啟動")

        while self._running:
            self._write_heartbeat("starting")
            self._proc = self._spawn()
            if self._proc is None:
                log.error("無法啟動主進程，30s 後重試")
                self._wait(30)
                continue

            log.info("主進程已啟動 (PID %d)", self._proc.pid)
            self._write_heartbeat(f"running pid={self._proc.pid}")

            exit_code = self._proc.wait()
            self._proc = None

            if not self._running:
                log.info("Watchdog 收到停止信號")
                break

            # 檢查 restart.flag（主動要求重啟，不算崩潰）
            home = os.environ.get("ARK_TEAM_AGENT_HOME", ".")
            flag = Path(home) / "restart.flag"
            if flag.exists():
                flag.unlink(missing_ok=True)
                log.info("restart.flag 偵測到，立即重啟（不算崩潰）")
                self._consecutive_failures = 0
                self._wait(3)
                continue

            if exit_code == 0:
                log.info("主進程正常退出 (code 0)")
                self._consecutive_failures = 0
                break

            # 崩潰
            self._consecutive_failures += 1
            log.warning(
                "主進程崩潰 (code %d)，連續 %d/%d",
                exit_code, self._consecutive_failures, self._max_restart,
            )
            self._write_heartbeat(f"crashed code={exit_code} count={self._consecutive_failures}")

            if self._consecutive_failures >= self._max_restart:
                log.error("連續崩潰達上限，冷卻 %ds", self._cooldown)
                self._write_heartbeat("cooldown")
                self._wait(self._cooldown)
                self._consecutive_failures = 0
                continue

            delay = min(2 ** self._consecutive_failures, MAX_BACKOFF)
            log.info("等待 %ds 後重啟...", delay)
            self._wait(delay)

        self._write_heartbeat("stopped")
        log.info("Watchdog 已停止")

    def stop(self) -> None:
        self._running = False
        if self._proc and self._proc.poll() is None:
            log.info("終止主進程 (PID %d)...", self._proc.pid)
            self._proc.terminate()
            try:
                self._proc.wait(timeout=15)
            except subprocess.TimeoutExpired:
                self._proc.kill()
                self._proc.wait()

    def _spawn(self) -> subprocess.Popen | None:
        try:
            # [1.3.3] 明確告知子進程「有 supervisor 在讀 restart.flag」。
            # 少了這個變數，子進程會以為自己沒有 flag 消費者而不寫 flag →
            # 本模組就永遠等不到 restart.flag，TG 重啟會被誤判成崩潰重啟。
            env = {**os.environ, "ARK_TEAM_AGENT_WRAPPER": "1"}
            return subprocess.Popen(
                [sys.executable, "-m", "ark_team_agent", "team", "start"],
                cwd=os.environ.get("ARK_TEAM_AGENT_HOME", "."),
                env=env,
            )
        except OSError as e:
            log.error("啟動失敗: %s", e)
            return None

    def _setup_signals(self) -> None:
        if sys.platform != "win32":
            signal.signal(signal.SIGTERM, self._handle_signal)
            signal.signal(signal.SIGINT, self._handle_signal)
        else:
            signal.signal(signal.SIGINT, self._handle_signal)

    def _handle_signal(self, signum, frame) -> None:
        log.info("收到信號 %s，停止中...", signal.Signals(signum).name)
        self.stop()

    def _write_heartbeat(self, status: str) -> None:
        try:
            self._heartbeat_path.write_text(
                f"{time.strftime('%Y-%m-%d %H:%M:%S')} {status}\n",
                encoding="utf-8",
            )
        except OSError:
            pass

    def _wait(self, seconds: float) -> None:
        """可被中斷的等待。"""
        end = time.time() + seconds
        while self._running and time.time() < end:
            time.sleep(min(1, end - time.time()))


def main() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(name)s] %(levelname)s %(message)s",
    )
    wd = WatchdogDaemon()
    wd.run()


if __name__ == "__main__":
    main()
