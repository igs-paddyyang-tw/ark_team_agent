"""A2A AgentDiscovery — 能力匹配（skills + load + 同義詞）。"""
from __future__ import annotations

import logging

from .a2a_protocol import TaskHandoff
from .config import TeamConfig

log = logging.getLogger(__name__)

# 角色 → 關鍵字映射（用於自動匹配）
DEFAULT_SYNONYMS: dict[str, list[str]] = {
    "ai-dev-agent": [
        "ai", "llm", "prompt", "rag", "agent", "ml", "embedding",
        "gemini", "openai", "skill", "mcp", "設計", "架構",
    ],
    "coder-agent": [
        "api", "fastapi", "express", "python", "typescript", "code",
        "implement", "build", "開發", "實作", "寫", "修",
    ],
    "qa-agent": [
        "test", "pytest", "review", "quality", "bug", "fix",
        "測試", "驗證", "品質", "e2e",
    ],
    "security-agent": [
        "security", "audit", "vulnerability", "auth", "permission",
        "安全", "漏洞", "權限",
    ],
    "design-agent": [
        "ui", "ux", "design", "figma", "css", "tailwind", "frontend",
        "介面", "設計", "原型",
    ],
    "data-agent": [
        "data", "sql", "bigquery", "etl", "report", "dashboard",
        "報表", "分析", "指標", "數據",
    ],
    "architect-agent": [
        "architecture", "adr", "spec", "system design", "sa", "sd",
        "架構", "規格", "設計文件",
    ],
}


class AgentDiscovery:
    """根據任務內容匹配最佳 agent。"""

    def __init__(self, config: TeamConfig, synonyms: dict[str, list[str]] | None = None) -> None:
        self._config = config
        self._synonyms = synonyms or DEFAULT_SYNONYMS

    def match(self, task: TaskHandoff) -> str:
        """根據 task title + context 匹配最佳 worker agent。

        回傳 instance name。若無匹配則回傳原始 to_agent。
        """
        text_lower = (task.title + " " + task.context).lower()
        scores: list[tuple[str, float]] = []

        for name, inst_cfg in self._config.instances.items():
            # 跳過非 worker
            if inst_cfg.role in ("admin", "manager", "leader"):
                continue

            score = 0.0

            # 同義詞匹配
            for keyword in self._synonyms.get(name, []):
                if keyword in text_lower:
                    score += 1.0

            # description 關鍵字匹配
            desc_lower = inst_cfg.description.lower()
            for word in text_lower.split():
                if len(word) >= 3 and word in desc_lower:
                    score += 0.3

            scores.append((name, score))

        if not scores:
            return task.to_agent

        scores.sort(key=lambda x: -x[1])
        best_name, best_score = scores[0]

        if best_score > 0:
            log.info(
                "AgentDiscovery: %s → %s (score=%.1f)",
                task.title[:30], best_name, best_score,
            )
            return best_name

        # 無明確匹配 → 回傳原始值
        return task.to_agent
