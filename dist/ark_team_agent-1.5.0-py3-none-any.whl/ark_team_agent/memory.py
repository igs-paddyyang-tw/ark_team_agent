"""User memory — per-user preferences stored as markdown."""
from __future__ import annotations

import logging
import re
from datetime import datetime
from pathlib import Path

from .config import get_home

log = logging.getLogger(__name__)

MEMORY_DIR = "memory"


def _memory_path(user_id: int) -> Path:
    return get_home() / MEMORY_DIR / f"user_{user_id}.md"


def read(user_id: int) -> str:
    """Read user memory markdown. Returns empty string if not exists."""
    p = _memory_path(user_id)
    if p.exists():
        return p.read_text(encoding="utf-8")
    return ""


def write(user_id: int, content: str) -> None:
    """Write full memory markdown."""
    p = _memory_path(user_id)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content, encoding="utf-8")


def update_field(user_id: int, section: str, key: str, value: str) -> None:
    """Update a single field in a section. Creates file/section if needed."""
    content = read(user_id)
    if not content:
        content = _new_template(user_id)

    line = f"- {key}：{value}"
    pattern = re.compile(rf"^- {re.escape(key)}：.*$", re.MULTILINE)

    if pattern.search(content):
        content = pattern.sub(line, content)
    else:
        # Append to section
        sec_pattern = re.compile(rf"(## {re.escape(section)}\n)(.*?)(\n## |\Z)", re.DOTALL)
        m = sec_pattern.search(content)
        if m:
            insert_at = m.start(3)
            content = content[:insert_at] + line + "\n" + content[insert_at:]
        else:
            content += f"\n## {section}\n{line}\n"

    content = _update_timestamp(content)
    write(user_id, content)


def append_history(user_id: int, summary: str) -> None:
    """Append a line to 歷史摘要 section."""
    date = datetime.now().strftime("%Y-%m-%d")
    update_field(user_id, "歷史摘要", date, summary)


def clear(user_id: int) -> bool:
    """Delete user memory file."""
    p = _memory_path(user_id)
    if p.exists():
        p.unlink()
        return True
    return False


def get_preference(user_id: int, key: str) -> str | None:
    """Extract a preference value by key name."""
    content = read(user_id)
    m = re.search(rf"^- {re.escape(key)}：(.+)$", content, re.MULTILINE)
    return m.group(1).strip() if m else None


def _new_template(user_id: int) -> str:
    date = datetime.now().strftime("%Y-%m-%d")
    return (
        f"# Memory — User {user_id}\n\n"
        f"## 偏好\n- 語言：繁體中文\n\n"
        f"## 專案上下文\n\n"
        f"## 歷史摘要\n\n"
        f"---\n*最後更新：{date}*\n"
    )


def _update_timestamp(content: str) -> str:
    ts = datetime.now().strftime("%Y-%m-%d %H:%M")
    pattern = re.compile(r"\*最後更新：.*\*")
    if pattern.search(content):
        return pattern.sub(f"*最後更新：{ts}*", content)
    return content + f"\n---\n*最後更新：{ts}*\n"
