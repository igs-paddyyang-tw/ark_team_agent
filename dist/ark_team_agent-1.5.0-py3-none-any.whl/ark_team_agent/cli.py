"""CLI entry point — team start/stop/status/ls/attach/send."""
from __future__ import annotations

import time
import argparse
import asyncio
import json
import logging
import os
import signal
import sys
from pathlib import Path

from .config import get_home, load_team_config
from .daemon import Daemon
from .team import TeamManager, run_team
from .session_key import SessionKey


def _setup_logging(level: str = "INFO", json_mode: bool = False) -> None:
    from .json_logging import setup_logging
    setup_logging(level=level, json_mode=json_mode)


def _print_status(manager: TeamManager) -> None:
    s = manager.status()
    print(f"Team: {s['running']}/{s['total']} running  (uptime {s['uptime']:.0f}s)")
    for inst in s["instances"]:
        icon = {"running": "🟢", "stopped": "⚪", "crashed": "🔴", "starting": "🟡", "paused": "⏸"}.get(inst["status"], "❓")
        model = inst.get("model") or "auto"
        print(f"  {icon} {inst['name']:20s} {inst['status']:10s} model={model}  dir={inst['working_directory']}")


def _print_list(instances: list[dict]) -> None:
    for inst in instances:
        print(json.dumps(inst, indent=2))


# ── Sync wrappers for one-shot commands ─────────────────────

def _run_one_shot(config_path: Path | None, coro_factory) -> None:
    """Load config, create manager, run a single async operation, then exit."""
    config = load_team_config(config_path)
    manager = TeamManager(config)

    async def _go():
        await coro_factory(manager)

    asyncio.run(_go())


def cmd_team_start(args: argparse.Namespace) -> None:
    if args.instance:
        _run_one_shot(args.config, lambda m: m.start_instance(args.instance))
    else:
        try:
            asyncio.run(run_team(args.config))
        except KeyboardInterrupt:
            pass


def cmd_team_stop(args: argparse.Namespace) -> None:
    pid_file = get_home() / "team.pid"
    if pid_file.exists():
        try:
            pid = int(pid_file.read_text().strip())
            os.kill(pid, signal.SIGTERM)
            print("Stop signal sent")
            return
        except (ValueError, ProcessLookupError):
            pass
    # Fallback: stop via direct daemon
    if args.instance:
        _run_one_shot(args.config, lambda m: m.stop_instance(args.instance))
    else:
        _run_one_shot(args.config, lambda m: m.stop())


def cmd_team_restart(args: argparse.Namespace) -> None:
    _run_one_shot(args.config, lambda m: m.restart(args.instance))


def cmd_team_status(args: argparse.Namespace) -> None:
    config = load_team_config(args.config)
    manager = TeamManager(config)
    # Show config-based status (no running daemon needed)
    print(f"Team config: {len(config.instances)} instances defined")
    for name, ic in config.instances.items():
        model = ic.model or "auto"
        role = "dispatcher" if ic.general_topic else ic.description or ""
        print(f"  {name:20s} backend={ic.backend:10s} model={model:20s} {role}".encode("utf-8", errors="replace").decode("utf-8", errors="replace"))


def find_orphan_sessions(home: Path, known: set[str] | None = None,
                         min_age_days: float = 0.0) -> list[Path]:
    """找出 `instances/` 下無主的衍生 session 目錄。

    [1.2.20] 衍生 session 的設定只存在於記憶體（不進 `team.yaml`），
    重啟後就消失；但 `instances/<key>/` 目錄留在磁碟。沒有回收機制的話
    會長期累積無主目錄。

    `known` 是「目前仍有效」的 instance 名集合（通常從執行中的服務取得）。
    傳 `None` 表示「一律視為無主」—— 服務沒在跑時的離線盤點。

    **只回傳清單，不刪除任何東西**（呼叫端決定），因為誤刪的代價
    是使用者的對話歷史，而多留幾個空目錄沒有代價。
    """
    root = home / "instances"
    if not root.is_dir():
        return []
    cutoff = time.time() - min_age_days * 86400
    out: list[Path] = []
    for d in sorted(root.iterdir()):
        if not d.is_dir() or not SessionKey.is_session(d.name):
            continue
        if known is not None and d.name in known:
            continue
        if min_age_days > 0 and d.stat().st_mtime > cutoff:
            continue
        out.append(d)
    return out


def cmd_sessions(args: argparse.Namespace) -> None:
    """列出（或清除）無主的衍生 session 目錄。

    預設**只報告不刪除** —— 要真的刪必須加 `--purge`。
    """
    home = get_home()
    known: set[str] | None = None
    try:                                   # 服務在跑就以它的實際清單為準
        import json as _j, urllib.request as _u
        from .config import load_team_config
        port = load_team_config(home / "team.yaml").health_port
        with _u.urlopen(f"http://127.0.0.1:{port}/api/status", timeout=3) as r:
            known = {i["name"] for i in _j.load(r).get("instances", [])}
    except Exception:
        print("ℹ️  服務未回應 —— 改為離線盤點（所有 session 目錄都視為無主）")

    orphans = find_orphan_sessions(home, known, min_age_days=args.min_age_days)
    if not orphans:
        print("✅ 沒有無主的 session 目錄")
        return
    print(f"找到 {len(orphans)} 個無主 session 目錄：")
    for d in orphans:
        age = (time.time() - d.stat().st_mtime) / 86400
        print(f"  {d.name}  （最後修改 {age:.1f} 天前）")
    if not args.purge:
        print("\n加 --purge 才會實際刪除。刪除會失去該使用者的對話歷史（--resume 用的）。")
        return
    import shutil
    for d in orphans:
        shutil.rmtree(d, ignore_errors=True)
    print(f"\n🗑  已刪除 {len(orphans)} 個目錄")


def cmd_ls(args: argparse.Namespace) -> None:
    from .process import list_active
    active = list_active()
    if not active:
        print("No active ark-team-agent processes")
        return
    for name in active:
        print(f"  {name}")


def cmd_attach(args: argparse.Namespace) -> None:
    from .process import get
    mp = get(args.name)
    if not mp or not mp.is_alive():
        print(f"Instance {args.name} is not running. Use 'team start {args.name}' first.")
        return
    # Show recent output as a "peek" since we can't truly attach to a subprocess
    print(f"── Recent output from {args.name} (pid={mp.pid}) ──")
    print(mp.capture(lines=50))
    print(f"── End of capture. Use 'send {args.name} <msg>' to interact ──")


def cmd_send(args: argparse.Namespace) -> None:
    async def _send(m: TeamManager):
        ok = await m.send_to_instance(args.name, args.message)
        if not ok:
            print(f"Failed to send to {args.name}", file=sys.stderr)
            sys.exit(1)
        print(f"Sent to {args.name}")

    _run_one_shot(args.config, _send)


def cmd_init(args: argparse.Namespace) -> None:
    import shutil
    import yaml

    # [1.3.1] 入口 agent 名改為可指定（`--entry-name`），預設維持 `ark-agent` 向後相容。
    # 原本 13 處寫死，等於強迫每個新專案的入口都叫 nana 的名字。
    entry = getattr(args, "entry_name", None) or "ark-agent"  # hardcode-ok: --entry-name 的向後相容預設值（可用參數覆寫）

    home = get_home()
    home.mkdir(parents=True, exist_ok=True)
    team_yaml = home / "team.yaml"
    if team_yaml.exists() and not args.force:
        print(f"Config already exists: {team_yaml}")
        return

    # Copy team.yaml from bundled template
    tpl_dir = Path(__file__).parent / "templates"
    shutil.copy2(tpl_dir / "team.yaml", team_yaml)
    print(f"Created: {team_yaml}")

    # [1.3.1] `raw` 原本在本函式**第 350 行**才賦值，卻在第 319 行（產生 mcp.json 時）
    # 就被使用 → `UnboundLocalError: cannot access local variable 'raw'`。
    # 後果：**`ark-team-agent init` 在全新環境必定失敗**（rc=1），而它是 README 教
    # 大家建新專案的入口。實測 1.3.0 與更早版本都有這個問題 ——
    # 之所以沒被發現，是因為既有部署都不會再跑 init。
    # 讀取移到這裡（team.yaml 剛複製完成），下方原本的重複讀取已移除。
    raw = yaml.safe_load(team_yaml.read_text(encoding="utf-8")) or {}

    # README.md
    readme = home / "README.md"
    if not readme.exists():
        shutil.copy2(tpl_dir / "README.md", readme)
        print(f"Created: {readme}")

    # Root .kiro/steering/ — 全域 steering 檔案
    root_steering = home / ".kiro" / "steering"
    root_steering.mkdir(parents=True, exist_ok=True)

    # SOUL.md（專案層級定位）
    soul_md_dst = root_steering / "SOUL.md"
    if not soul_md_dst.exists():
        soul_md_dst.write_text(
            "# 🎯 專案定位\n\n"
            "> 本專案使用 ark_team_agent 套件部署 AI Agent 團隊。\n\n"
            "## 使命\n\n（請填入專案使命）\n\n"
            "## 核心規則\n\n- 所有回覆使用繁體中文\n- 結論先行、≤ 150 字\n",
            encoding="utf-8",
        )
        print(f"Created: {soul_md_dst}")

    # BRAIN.md（專案層級知識背景）
    brain_md_dst = root_steering / "BRAIN.md"
    if not brain_md_dst.exists():
        brain_md_dst.write_text(
            "# 🧠 專案知識背景\n\n"
            "> 團隊共用的領域知識與背景資訊。\n\n"
            "## 技術棧\n\n- Python 3.12+\n- ark_team_agent 套件\n- Telegram Bot\n\n"
            "## 業務背景\n\n（請填入業務背景）\n",
            encoding="utf-8",
        )
        print(f"Created: {brain_md_dst}")

    # CODE.md（程式碼規範）
    code_md_src = tpl_dir / "steering" / "CODE.md"
    code_md_dst = root_steering / "CODE.md"
    if not code_md_dst.exists() and code_md_src.exists():
        shutil.copy2(code_md_src, code_md_dst)
        print(f"Created: {code_md_dst}")

    # MEMORY.md（專案記憶）
    memory_md_src = tpl_dir / "steering" / "MEMORY.md"
    memory_md_dst = root_steering / "MEMORY.md"
    if not memory_md_dst.exists() and memory_md_src.exists():
        shutil.copy2(memory_md_src, memory_md_dst)
        print(f"Created: {memory_md_dst}")

    # TEAM.md（團隊組成 — 啟動後會被覆寫）
    team_md_dst = root_steering / "TEAM.md"
    if not team_md_dst.exists():
        team_md_dst.write_text(
            "# 團隊組成\n\n> 啟動後由套件自動更新。\n\n（尚未啟動）\n",
            encoding="utf-8",
        )
        print(f"Created: {team_md_dst}")

    # USER.md（使用者資訊）
    user_md_src = tpl_dir / "steering" / "USER.md"
    user_md_dst = root_steering / "USER.md"
    if not user_md_dst.exists() and user_md_src.exists():
        shutil.copy2(user_md_src, user_md_dst)
        print(f"Created: {user_md_dst}")

    # Root .kiro/agents/ — 主 Agent 配置
    root_agents_dir = home / ".kiro" / "agents"
    root_agents_dir.mkdir(parents=True, exist_ok=True)
    ark_agent_json = root_agents_dir / f"{entry}.json"
    if not ark_agent_json.exists():
        import json as _json
        _json_content = {
            "name": entry,
            "description": "🎯 團隊管家 — AI Agent 團隊指揮核心、意圖路由、知識查詢",
            "role": "orchestrator",
            "model": "auto",
            "tools": ["*"],
            "allowedTools": ["*"],
            "resources": [
                "file://.kiro/steering/**/*.md",
                "skill://.kiro/skills/**/SKILL.md",
            ],
            "welcomeMessage": "🎯 管家就緒。Team standby。",
        }
        ark_agent_json.write_text(_json.dumps(_json_content, indent=2, ensure_ascii=False), encoding="utf-8")
        print(f"Created: {ark_agent_json}")

    # Root .kiro/prompts/ — 意圖路由等提詞
    root_prompts_dir = home / ".kiro" / "prompts"
    root_prompts_dir.mkdir(parents=True, exist_ok=True)
    route_md = root_prompts_dir / "route-message.md"
    if not route_md.exists():
        route_md.write_text(
            "# 訊息路由\n\n"
            "收到使用者私訊後，**先讀 TEAM.md 取得最新 agent 職責表**，再判斷意圖並執行。\n\n"
            "## 規則\n\n"
            "1. TEAM.md 動態引用 — 以職責描述為準\n"
            "2. 能自己答就不派工 — knowledge_qa / chat 自己處理\n"
            "3. 有 @mention 優先 — 直接路由\n"
            "4. route_* 回覆簡短 — ≤ 30 字確認\n",
            encoding="utf-8",
        )
        print(f"Created: {route_md}")

    # Root .kiro/settings/mcp.json
    root_settings_dir = home / ".kiro" / "settings"
    root_settings_dir.mkdir(parents=True, exist_ok=True)
    root_mcp = root_settings_dir / "mcp.json"
    if not root_mcp.exists():
        import json as _json
        _port = raw.get("health_port", 33300)
        _mcp = {
            "mcpServers": {
                "team": {
                    "command": str(home / ".venv" / "bin" / "python3"),
                    "args": [
                        "-m", "ark_team_agent.team_mcp",
                        "--port", str(_port),
                        "--instance", entry,
                        "--role", "manager",
                        "--home", str(home),
                    ],
                }
            }
        }
        root_mcp.write_text(_json.dumps(_mcp, indent=2), encoding="utf-8")
        print(f"Created: {root_mcp}")

    # Root .kiro/skills/ — 複製核心 Skills
    root_skills_dir = home / ".kiro" / "skills"
    if not root_skills_dir.exists():
        skills_tpl = tpl_dir / "skills"
        if skills_tpl.exists():
            # [1.2.12] 排除 README.md —— 它是 templates/skills/ 的套件說明，
            # 不是 skill，複製進 .kiro/skills/ 只會讓 skill 清單多一個雜項
            shutil.copytree(skills_tpl, root_skills_dir,
                            ignore=shutil.ignore_patterns("README.md"))
            n = len([p for p in root_skills_dir.iterdir() if p.is_dir()])
            print(f"Created: {root_skills_dir}/ ({n} skills)")

    # Create agent steering from templates（`raw` 已在上方 team.yaml 複製後讀取）
    for name, inst in raw.get("instances", {}).items():
        wd = inst.get("working_directory", name)
        wd = Path(wd) if Path(wd).is_absolute() else home / wd
        wd.mkdir(parents=True, exist_ok=True)

        # Agent 私有 knowledge/ — 完整知識庫結構（schema/index/log + wiki/ + raw/）
        agent_kb = wd / "knowledge"
        agent_kb.mkdir(parents=True, exist_ok=True)
        for sub in ("wiki", "wiki/operations", "raw", "raw/decisions"):
            p = agent_kb / sub
            if not p.exists():
                p.mkdir(parents=True, exist_ok=True)
                (p / ".gitkeep").touch()
        for fname, content in [
            ("schema.md",
             f"# {name} 知識庫 Schema\n\n## 目錄結構\n\n```\nknowledge/\n├── schema.md\n"
             "├── index.md\n├── log.md\n├── wiki/\n└── raw/\n```\n\n"
             "## 核心規則\n\n- raw/：只進不改\n- wiki/：只由 ingest 產出，禁止手動寫\n"),
            ("index.md",
             f"# {name} 知識庫索引\n\n> 最後更新：請在每次 ingest 後更新\n\n"
             "## wiki/ 頁面\n\n（尚無頁面）\n\n## raw/ 素材\n\n（尚無素材）\n"),
            ("log.md",
             f"# 操作日誌（{name}/）\n\n> append-only，禁止刪除舊記錄。\n\n---\n\n"
             f"- **{__import__('datetime').date.today()}** | create | 初始化知識庫\n"),
        ]:
            fpath = agent_kb / fname
            if not fpath.exists():
                fpath.write_text(content, encoding="utf-8")

        # Agent docs/ — 含子目錄
        agent_docs = wd / "docs"
        agent_docs.mkdir(parents=True, exist_ok=True)
        for sub in ("specs", "designs", "plans", "reports"):
            p = agent_docs / sub
            if not p.exists():
                p.mkdir(parents=True, exist_ok=True)
                (p / ".gitkeep").touch()

        # Agent memory/ — 工作記憶目錄
        agent_mem = wd / "memory"
        agent_mem.mkdir(parents=True, exist_ok=True)
        (agent_mem / "daily").mkdir(exist_ok=True)
        mem_md = agent_mem / "memory.md"
        if not mem_md.exists():
            mem_md.write_text(
                f"# 🧠 {name} Memory\n\n> 工作記憶。只放「下個月還會有用的事實」。\n\n---\n\n",
                encoding="utf-8",
            )

        steering = wd / ".kiro" / "steering"
        steering.mkdir(parents=True, exist_ok=True)

        # Determine agent template name from instance config or name
        # Map instance names to template directories
        # [claude-code 2026-08-05] 去重：leader 目錄接手 tech-lead 詳細 SOUL
        role_map = {
            "leader": "leader",
            "dev": "coder",
            "qa": "tester",
        }
        # Try to find matching template
        agent_tpl_name = None
        for key, tpl_name in role_map.items():
            if key in name:
                agent_tpl_name = tpl_name
                break

        # Deploy SOUL.md from agent template
        if agent_tpl_name:
            agent_tpl_dir = tpl_dir / "agents" / agent_tpl_name
            if agent_tpl_dir.exists():
                # SOUL.md → .kiro/steering/SOUL.md
                soul_src = agent_tpl_dir / "SOUL.md"
                soul_dst = steering / "SOUL.md"
                if not soul_dst.exists() and soul_src.exists():
                    shutil.copy2(soul_src, soul_dst)
                    print(f"  {name}: SOUL.md")

                # agent.json → .kiro/agents/{name}.json
                agent_json_src = agent_tpl_dir / "agent.json"
                if agent_json_src.exists():
                    agents_dir = wd / ".kiro" / "agents"
                    agents_dir.mkdir(parents=True, exist_ok=True)
                    agent_json_dst = agents_dir / f"{name}.json"
                    if not agent_json_dst.exists():
                        shutil.copy2(agent_json_src, agent_json_dst)
                        print(f"  {name}: agent.json")

        # MEMORY.md
        memory_file = steering / "MEMORY.md"
        if not memory_file.exists():
            memory_tpl = tpl_dir / "steering" / "MEMORY.md"
            if memory_tpl.exists():
                content = memory_tpl.read_text(encoding="utf-8")
                content = content.replace("{project}", name).replace("{date}", "")
                memory_file.write_text(content, encoding="utf-8")
            else:
                memory_file.write_text(f"# 🧠 {name} Memory\n\n> 工作記憶\n\n---\n\n", encoding="utf-8")

        # USER.md (shared)
        user_file = steering / "USER.md"
        if not user_file.exists():
            user_tpl = tpl_dir / "steering" / "USER.md"
            if user_tpl.exists():
                shutil.copy2(user_tpl, user_file)

        # Skills — deploy core skills to all agents
        skills_tpl = tpl_dir / "skills"
        if skills_tpl.exists():
            for sd in skills_tpl.iterdir():
                if sd.is_dir():
                    dst = wd / ".kiro" / "skills" / sd.name
                    if not dst.exists():
                        shutil.copytree(sd, dst)
                        print(f"  {name}: skill {sd.name}")

    # .env.example
    env_example = home / ".env.example"
    if not env_example.exists():
        env_example.write_text(
            "TELEGRAM_BOT_TOKEN=your-token-here\n"
            "# GEMINI_API_KEY=your-key-here\n"
            "# ARK_TEAM_AGENT_HOME=/path/to/team-home\n"
        )

    # knowledge/ — 舊的 gitkeep 建立已移除，由下方完整結構取代
    knowledge_dir = home / "knowledge"
    knowledge_dir.mkdir(parents=True, exist_ok=True)

    # docs/ (global documents) — 含完整子目錄
    docs_dir = home / "docs"
    docs_dir.mkdir(parents=True, exist_ok=True)
    for sub in ("specs", "designs", "plans", "reports", "one-pagers", "references"):
        p = docs_dir / sub
        if not p.exists():
            p.mkdir(parents=True, exist_ok=True)
            (p / ".gitkeep").touch()
    print(f"Created: {docs_dir}/ (specs/ designs/ plans/ reports/ one-pagers/ references/)")

    # scheduler.yaml
    scheduler_yaml = home / "scheduler.yaml"
    if not scheduler_yaml.exists():
        scheduler_yaml.write_text(
            "timezone: Asia/Taipei\n\n"
            "jobs:\n"
            "  - name: hourly-progress\n"
            "    target: pm-agent\n"
            '    prompt: "⏰ 確認團隊狀態，query_team_status 後依計劃派工或追蹤。更新 memory.md。"\n'
            '    cron: "10 9-21 * * *"\n\n'
            "  - name: daily-summary\n"
            "    target: pm-agent\n"
            '    prompt: "📋 今日摘要：整理成果 + 明日計劃，reply 回報。"\n'
            '    cron: "daily:21:00"\n',
            encoding="utf-8",
        )
        print(f"Created: {scheduler_yaml}")

    # .gitignore
    gitignore = home / ".gitignore"
    if not gitignore.exists():
        gitignore.write_text(
            ".env\nstate/\n*.pid\n__pycache__/\n*.pyc\nnode_modules/\n"
        )
        print(f"Created: {gitignore}")

    # prompts/ (shared prompt templates)
    prompts_dir = home / "prompts"
    if not prompts_dir.exists():
        prompts_dir.mkdir(parents=True, exist_ok=True)
        (prompts_dir / "dispatch-feature.md").write_text(
            "# 功能開發派工\n\n📋 任務：{{title}}\n📄 Spec：{{spec_path}}\n🎯 DoD：{{dod}}\n📅 期限：{{deadline}}\n\n完成後用 reply 回報結論。\n",
            encoding="utf-8",
        )
        (prompts_dir / "dispatch-bugfix.md").write_text(
            "# Bug 修復派工\n\n🐛 問題：{{description}}\n📁 位置：{{file_path}}\n🎯 DoD：修復 + 回歸測試\n\n完成後用 reply 回報結論。\n",
            encoding="utf-8",
        )
        (prompts_dir / "daily-report.md").write_text(
            "# 每日回報\n\n📋 今日摘要：整理成果 + 明日計劃，reply 回報。\n",
            encoding="utf-8",
        )
        (prompts_dir / "review-pr.md").write_text(
            "# Code Review\n\n🔍 Review 對象：{{pr_path}}\n📋 檢查：spec 合規 + 程式碼品質 + 測試覆蓋\n\n完成後回報結果。\n",
            encoding="utf-8",
        )
        (prompts_dir / "learning-prompt.md").write_text(
            "# 學習整理\n\n📚 整理 knowledge/learning.md 中 ≥5 條的項目到 wiki/。\n遵守 Schema v3.0（frontmatter + index + log）。\n",
            encoding="utf-8",
        )
        print(f"Created: {prompts_dir}/ (5 templates)")

    # tasks/ (task board)
    tasks_dir = home / "tasks"
    if not tasks_dir.exists():
        tasks_dir.mkdir(parents=True, exist_ok=True)
        (tasks_dir / "items").mkdir(exist_ok=True)
        (tasks_dir / "board.json").write_text(
            '{"version":"1.0","updated_at":"","tasks":[]}\n',
            encoding="utf-8",
        )
        print(f"Created: {tasks_dir}/ (board.json + items/)")

    # Watchdog scripts
    bat_file = home / "start-team.bat"
    if not bat_file.exists():
        bat_file.write_text(
            "@echo off\nchcp 65001 >nul\n"
            "set ARK_TEAM_AGENT_HOME=%~dp0\nset ARK_TEAM_AGENT_WRAPPER=1\ncd /d %~dp0\n\n"
            ":loop\necho [%date% %time%] Starting team-agent...\n"
            "py -m ark_team_agent team start\n\n"
            'if exist "%ARK_TEAM_AGENT_HOME%restart.flag" (\n'
            '    del "%ARK_TEAM_AGENT_HOME%restart.flag"\n'
            "    echo [%date% %time%] Restart requested, restarting in 3s...\n"
            "    timeout /t 3 /nobreak >nul\n    goto loop\n)\n\n"
            "echo [%date% %time%] Team-agent exited without restart flag. Stopping.\n"
        )
        print(f"Created: {bat_file}")

    sh_file = home / "start-team.sh"
    if not sh_file.exists():
        sh_file.write_text(
            '#!/bin/bash\ncd "$(dirname "$0")"\n'
            'export ARK_TEAM_AGENT_HOME="${ARK_TEAM_AGENT_HOME:-$(pwd)}"\n'
            # [1.3.3] 讓套件知道「有 wrapper 在等 restart.flag」——
            # 沒有這個變數，systemd 與 wrapper 兩種環境從程式內部看起來一樣，
            # 套件就無法判斷該不該寫 flag（寫錯邊 = 重啟失效或殘留垃圾）。
            'export ARK_TEAM_AGENT_WRAPPER=1\n\n'
            "while true; do\n"
            '    echo "[$(date)] Starting team-agent..."\n'
            "    python3 -m ark_team_agent team start\n\n"
            '    if [ -f "$ARK_TEAM_AGENT_HOME/restart.flag" ]; then\n'
            '        rm -f "$ARK_TEAM_AGENT_HOME/restart.flag"\n'
            '        echo "[$(date)] Restart requested, restarting in 3s..."\n'
            "        sleep 3\n        continue\n    fi\n\n"
            '    echo "[$(date)] Team-agent exited without restart flag. Stopping."\n'
            "    break\ndone\n"
        )
        print(f"Created: {sh_file}")

    # [team-agent 2026-07-31] config/ — authority-matrix.yml (Decision Loop 必需)
    config_dir = home / "config"
    config_dir.mkdir(parents=True, exist_ok=True)
    matrix_dst = config_dir / "authority-matrix.yml"
    if not matrix_dst.exists():
        matrix_src = tpl_dir / "authority-matrix.yml"
        if matrix_src.exists():
            shutil.copy2(matrix_src, matrix_dst)
        else:
            # Fallback: write minimal matrix inline
            matrix_dst.write_text(
                "version: 1\nlevels:\n  L1:\n    desc: 可逆且只影響單一任務 → worker 自決\n"
                # 產出的 matrix 值全是 `<你的…>` 佔位符，使用者必須自己填。
                f"  L2:\n    # 請把 <...> 換成你的決策者 instance 名（例：admin-agent(admin)、{entry}(manager)）\n"  # hardcode-ok: 範本檔裡的舉例文字，非路由依據
                "    product: {owner: \"<你的產品決策者>\", fallback: \"<你的升級對象>\"}\n"
                "    tech:    {owner: \"<你的技術決策者>\", fallback: \"<你的升級對象>\"}\n"
                "    mixed:   {first: \"<先評估者>\", final: \"<終決者>\", fallback: \"<你的升級對象>\"}\n"
                "  L3:\n    triggers: [花費金錢, 刪除資料, 對外承諾]\n"
                "escalation:\n  remind_after: 30m\n  escalate_after: 60m\n"
                "overturn_window: 24h\n",
                encoding="utf-8",
            )
        print(f"Created: {matrix_dst}")

    # [team-agent 2026-07-31] memory/ — ark-agent 工作記憶結構
    memory_dir = home / "memory"
    memory_dir.mkdir(parents=True, exist_ok=True)
    memory_md = memory_dir / "memory.md"
    if not memory_md.exists():
        memory_md.write_text(
            f"# 🧠 {entry} Memory\n\n"
            "> 工作記憶。只放「下個月還會有用的事實」。上限 2000 tokens。\n\n---\n\n"
            "## 角色定位\n\n"
            f"- {entry}（私訊入口，意圖分類路由）\n\n"
            "## 關鍵路徑\n\n"
            "- 工作日誌：`memory/journal.md`\n"
            "- 意圖分類規則：`.kiro/steering/intent-classify.md`\n"
            "- 決策 DB：`state/decisions.db`\n\n"
            f"---\n\n*建立日期：{__import__('datetime').date.today()}*\n",
            encoding="utf-8",
        )
        print(f"Created: {memory_md}")
    journal_md = memory_dir / "journal.md"
    if not journal_md.exists():
        journal_md.write_text(
            "# 工作日誌\n\n"
            "> log_journal 意圖的寫入目標。格式：`- YYYY-MM-DD HH:MM：{內容}`\n\n---\n",
            encoding="utf-8",
        )
        print(f"Created: {journal_md}")
    daily_dir = memory_dir / "daily"
    daily_dir.mkdir(exist_ok=True)
    if not (daily_dir / ".gitkeep").exists():
        (daily_dir / ".gitkeep").touch()
        print(f"Created: {daily_dir}/ (daily log directory)")

    # [team-agent 2026-07-31] knowledge/ — 完整知識庫結構（含 Decision Loop 路徑）
    knowledge_dir = home / "knowledge"
    knowledge_dir.mkdir(parents=True, exist_ok=True)
    # ark-agent 櫃子（ark-agent 私有）
    ark_kb = knowledge_dir / entry
    ark_kb.mkdir(parents=True, exist_ok=True)
    # schema.md in ark-agent/
    schema_dst = ark_kb / "schema.md"
    if not schema_dst.exists():
        schema_src = tpl_dir / "authority-matrix.yml"  # reuse tpl_dir for base
        schema_dst.write_text(
            f"# {entry} 知識庫 Schema v3.1\n\n"
            f"## 目錄結構\n\n```\n{entry}/\n├── schema.md\n├── index.md\n"
            "├── log.md\n├── raw/\n└── wiki/\n```\n\n"
            "## 核心規則\n\n- raw/：只進不改\n- wiki/：只由 ingest 產出，禁止手動寫\n",
            encoding="utf-8",
        )
        print(f"Created: {schema_dst}")
    # index.md in ark-agent/
    index_dst = ark_kb / "index.md"
    if not index_dst.exists():
        index_dst.write_text(
            f"# {entry} 知識庫索引\n\n> 最後更新：請在每次 ingest 後更新\n\n"
            "## wiki/ 頁面\n\n（尚無頁面）\n\n## raw/ 素材\n\n（尚無素材）\n",
            encoding="utf-8",
        )
        print(f"Created: {index_dst}")
    # log.md in ark-agent/
    log_dst = ark_kb / "log.md"
    if not log_dst.exists():
        today = __import__("datetime").date.today()
        log_dst.write_text(
            f"# 操作日誌（{entry}/）\n\n> append-only，禁止刪除舊記錄。\n\n---\n\n"
            f"- **{today}** | create | 初始化 {entry} 知識庫（由 ark-team-agent init 產出）\n",
            encoding="utf-8",
        )
        print(f"Created: {log_dst}")
    # ark-agent/wiki/ + ark-agent/raw/
    for subdir in ("wiki", "wiki/operations", "raw", "raw/decisions"):
        p = ark_kb / subdir
        if not p.exists():
            p.mkdir(parents=True, exist_ok=True)
            (p / ".gitkeep").touch()
    # shared/ 書架
    shared_kb = knowledge_dir / "shared"
    shared_kb.mkdir(parents=True, exist_ok=True)
    shared_schema = shared_kb / "schema.md"
    if not shared_schema.exists():
        shared_schema.write_text(
            "# 共用知識庫 Schema v1.0\n\n"
            "## 目錄結構\n\n```\nshared/\n├── schema.md\n├── index.md\n"
            "├── log.md\n├── wiki/\n└── raw/\n    ├── decisions/\n    └── {agent-name}/\n```\n\n"
            "## 核心規則\n\n- wiki/：禁止手動寫，只由 weekly-knowledge-sync 晉升產出\n"
            "- raw/decisions/：DecisionManager 自動寫入\n",
            encoding="utf-8",
        )
    shared_index = shared_kb / "index.md"
    if not shared_index.exists():
        shared_index.write_text(
            "# 共用知識庫索引\n\n> 最後更新：請在每次晉升後更新\n\n"
            "## wiki/ 頁面\n\n（尚無頁面）\n\n## raw/ 素材\n\n### decisions/\n（尚無 DR 記錄）\n",
            encoding="utf-8",
        )
    shared_log = shared_kb / "log.md"
    if not shared_log.exists():
        today = __import__("datetime").date.today()
        shared_log.write_text(
            f"# 操作日誌（shared/）\n\n> append-only，禁止刪除舊記錄。\n\n---\n\n"
            f"- **{today}** | create | 初始化共用知識庫（由 ark-team-agent init 產出）\n",
            encoding="utf-8",
        )
    for subdir in ("wiki", "raw", "raw/decisions"):
        p = shared_kb / subdir
        if not p.exists():
            p.mkdir(parents=True, exist_ok=True)
            (p / ".gitkeep").touch()
    print(f"Created: {knowledge_dir}/ ({entry}/ + shared/ 完整結構)")

    print("\nNext steps:")
    print("  1. Edit team.yaml (optional: enable Telegram)")
    print("  2. Run /ark-kiro-init to customize each agent's .kiro/")
    print("  3. ark-team-agent team start")


# ── Kiro file management subcommands ─────────────────────────

def cmd_kiro_status(args: argparse.Namespace) -> None:
    """Show .kiro/ file status for all agents."""
    config = load_team_config(args.config)
    home = get_home()
    policy = config.kiro_files

    print(f"{'agent':<20s} {'file':<30s} {'policy':<10s} {'state'}")
    print("-" * 80)

    for name, ic in config.instances.items():
        if args.agent and args.agent != name:
            continue
        wd = Path(ic.working_directory)
        kiro_dir = wd / ".kiro"

        # Check each managed file
        _print_file_status(name, kiro_dir, "steering/agents.md", policy.agents_md)
        _print_file_status(name, kiro_dir, "steering/TEAM.md", policy.team_md)

        _print_file_status(name, kiro_dir, "steering/SOUL.md", policy.soul_md)
        _print_file_status(name, kiro_dir, "steering/MEMORY.md", policy.memory_md)
        _print_file_status(name, kiro_dir, "settings/mcp.json", policy.mcp_json)
        _print_file_status(name, kiro_dir, f"agents/{name}.json", policy.agent_json)

        # Check .meta.json for template status
        meta_path = kiro_dir / ".meta.json"
        if meta_path.exists():
            try:
                import json as _json
                meta = _json.loads(meta_path.read_text(encoding="utf-8"))
                for rel_key, entry in meta.get("files", {}).items():
                    if entry.get("user_modified"):
                        # Already printed above, but add template info
                        pass
            except (json.JSONDecodeError, OSError):
                pass


def _print_file_status(agent: str, kiro_dir: Path, rel_path: str, policy_val: str) -> None:
    """Print status of a single managed file."""
    target = kiro_dir / rel_path
    if target.exists():
        if target.is_symlink():
            state = "symlink"
        else:
            # Check if template-tracked
            meta_path = kiro_dir / ".meta.json"
            state = "ok"
            if meta_path.exists() and policy_val == "template":
                try:
                    meta = json.loads(meta_path.read_text(encoding="utf-8"))
                    entry = meta.get("files", {}).get(rel_path, {})
                    if entry.get("user_modified"):
                        state = "user_modified"
                        # Check if new template available
                        from .backend import KiroBackend
                        current_hash = KiroBackend._hash_content(target.read_text(encoding="utf-8"))
                        if current_hash != entry.get("template_hash", ""):
                            state = "user_modified (new template available)"
                except (json.JSONDecodeError, OSError):
                    pass
    else:
        state = "missing"

    print(f"  {agent:<18s} {rel_path:<30s} {policy_val:<10s} {state}")


def cmd_kiro_sync(args: argparse.Namespace) -> None:
    """Force sync template files (overwrite even if user modified)."""
    config = load_team_config(args.config)
    home = get_home()

    targets = []
    for name, ic in config.instances.items():
        if args.agent and args.agent != name:
            continue
        targets.append((name, ic))

    if not targets:
        print(f"No matching agent: {args.agent}")
        return

    from .backend import KiroBackend, KiroBackendConfig

    for name, ic in targets:
        inst_dir = home / "instances" / name
        backend = KiroBackend(str(inst_dir))
        cfg = KiroBackendConfig(
            working_directory=ic.working_directory,
            instance_name=name,
            instance_dir=str(inst_dir),
            instructions=ic.system_prompt,
            team_home=str(home),
            role=ic.role,
            kiro_files_policy=config.kiro_files,
        )

        if args.all or not args.file:
            # Force rewrite all template-tracked files
            meta_path = Path(ic.working_directory) / ".kiro" / ".meta.json"
            if meta_path.exists():
                try:
                    meta = json.loads(meta_path.read_text(encoding="utf-8"))
                    for rel_key in list(meta.get("files", {}).keys()):
                        meta["files"][rel_key]["user_modified"] = False
                        meta["files"][rel_key]["template_hash"] = ""  # Force re-write
                    meta_path.write_text(json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8")
                except (json.JSONDecodeError, OSError):
                    pass

            # Re-run write_config + write_agent_files
            backend.write_config(cfg)
            backend.write_team_context(cfg, config.instances)
            backend.write_agent_files(cfg)
            print(f"  ✅ {name}: synced all files")
        elif args.file:
            # Sync specific file
            meta_path = Path(ic.working_directory) / ".kiro" / ".meta.json"
            if meta_path.exists():
                try:
                    meta = json.loads(meta_path.read_text(encoding="utf-8"))
                    if args.file in meta.get("files", {}):
                        meta["files"][args.file]["user_modified"] = False
                        meta["files"][args.file]["template_hash"] = ""
                        meta_path.write_text(json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8")
                except (json.JSONDecodeError, OSError):
                    pass
            backend.write_config(cfg)
            backend.write_agent_files(cfg)
            print(f"  ✅ {name}: synced {args.file}")


def cmd_kiro_diff(args: argparse.Namespace) -> None:
    """Show diff between template source and current file."""
    import difflib
    config = load_team_config(args.config)
    home = get_home()

    ic = config.instances.get(args.agent)
    if not ic:
        print(f"Unknown agent: {args.agent}")
        return

    wd = Path(ic.working_directory)
    kiro_dir = wd / ".kiro"
    meta_path = kiro_dir / ".meta.json"

    if not meta_path.exists():
        print("No .meta.json found (template mode not active for this agent)")
        return

    try:
        meta = json.loads(meta_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        print("Failed to read .meta.json")
        return

    files_to_diff = {}
    if args.file:
        if args.file in meta.get("files", {}):
            files_to_diff[args.file] = meta["files"][args.file]
        else:
            print(f"File {args.file} not tracked in .meta.json")
            return
    else:
        files_to_diff = meta.get("files", {})

    for rel_key, entry in files_to_diff.items():
        target = kiro_dir / rel_key
        if not target.exists():
            print(f"\n--- {rel_key} ---")
            print("  (file missing)")
            continue

        current = target.read_text(encoding="utf-8").splitlines()
        # Try to find template source
        source_content = _find_template_source(home, args.agent, ic, rel_key)
        if source_content is None:
            print(f"\n--- {rel_key} ---")
            print("  (template source not found)")
            continue

        template_lines = source_content.splitlines()
        diff = difflib.unified_diff(
            template_lines, current,
            fromfile=f"template/{rel_key}",
            tofile=f"current/{rel_key}",
            lineterm="",
        )
        diff_text = "\n".join(diff)
        if diff_text:
            print(f"\n--- {rel_key} ---")
            print(diff_text)
        else:
            print(f"\n--- {rel_key} --- (identical)")


def _find_template_source(home: Path, agent_name: str, ic, rel_key: str) -> str | None:
    """Find the template source content for a given file."""
    if rel_key.startswith("steering/") and rel_key.endswith(".md"):
        filename = rel_key.split("/", 1)[1]
        if filename == "SOUL.md" and ic.system_prompt:
            return ic.system_prompt
        # Check root steering
        root_file = home / ".kiro" / "steering" / filename
        if root_file.exists():
            return root_file.read_text(encoding="utf-8")
    elif rel_key.startswith("agents/"):
        candidate = home / agent_name / ".kiro" / "agents" / rel_key.split("/", 1)[1]
        if candidate.exists():
            return candidate.read_text(encoding="utf-8")
    elif rel_key.startswith("prompts/"):
        candidate = home / "prompts" / rel_key.split("/", 1)[1]
        if candidate.exists():
            return candidate.read_text(encoding="utf-8")
    return None


def cmd_kiro_refresh(args: argparse.Namespace) -> None:
    """Regenerate all 'always' policy files without restarting the service."""
    config = load_team_config(args.config)
    home = get_home()

    from .backend import KiroBackend, KiroBackendConfig

    for name, ic in config.instances.items():
        inst_dir = home / "instances" / name
        backend = KiroBackend(str(inst_dir))

        role = ic.role or "worker"
        if role == "leader":
            allowed_targets = [n for n, c in config.instances.items() if c.role != "manager"]
        elif role == "manager":
            allowed_targets = [n for n, c in config.instances.items() if not c.private_chat]
        else:
            allowed_targets = []

        cfg = KiroBackendConfig(
            working_directory=ic.working_directory,
            instance_name=name,
            instance_dir=str(inst_dir),
            instructions=ic.system_prompt,
            team_api_port=config.health_port,
            team_home=str(home),
            role=role,
            allowed_targets=allowed_targets,
            kiro_files_policy=config.kiro_files,
        )
        backend.write_config(cfg)
        backend.write_team_context(cfg, config.instances)
        print(f"  ✅ {name}: refreshed 'always' files")

    print(f"\nDone. Refreshed {len(config.instances)} agents.")



def cmd_webbot_api(args: argparse.Namespace) -> None:
    """Run the webbot REST API (port 3030 by default)."""
    import uvicorn
    from ark_team_webbot.shared.config import load_config
    from ark_team_webbot.api.app import create_app

    cfg = load_config(args.webbot_config)
    app = create_app(cfg)
    host = cfg.api.host
    port = args.port or cfg.api.port
    print(f"Webbot API: http://{host}:{port}/docs")
    uvicorn.run(app, host=host, port=port, log_level="info")


def cmd_webbot_scheduler(args: argparse.Namespace) -> None:
    """Run the webbot APScheduler cron runner (no port)."""
    from ark_team_webbot.shared.config import load_config
    from ark_team_webbot.scheduler.runner import run_forever

    cfg = load_config(args.webbot_config)
    print(f"Webbot Scheduler: polling {cfg.team_agent.url}")
    run_forever(cfg)


def cmd_webbot_start(args: argparse.Namespace) -> None:
    """Run api (with embedded SPA) + scheduler concurrently in ONE process."""
    from ark_team_webbot.shared.config import load_config
    from ark_team_webbot.runner import run_all

    cfg = load_config(args.webbot_config)
    enable_api = not args.no_api
    enable_scheduler = not args.no_scheduler

    enabled_labels = []
    if enable_api:
        enabled_labels.append(f"api@{cfg.api.port}")
    if enable_scheduler:
        enabled_labels.append(f"scheduler (poll {cfg.team_agent.url})")

    print(f"Webbot start: {', '.join(enabled_labels) if enabled_labels else 'nothing enabled'}")
    run_all(cfg, enable_api=enable_api, enable_scheduler=enable_scheduler)


def main() -> None:
    parser = argparse.ArgumentParser(prog="ark-team-agent", description="Multi-agent Kiro CLI team manager")
    parser.add_argument("--config", type=Path, default=None, help="Path to team.yaml")
    parser.add_argument("--log-level", default="INFO")
    parser.add_argument("--json-log", action="store_true", help="Output logs as JSON (structured logging)")
    sub = parser.add_subparsers(dest="command")

    # team start
    p = sub.add_parser("team", help="Team management")
    team_sub = p.add_subparsers(dest="team_cmd")

    p_start = team_sub.add_parser("start", help="start team or instance")
    p_start.add_argument("instance", nargs="?", help="Instance name (optional)")

    p_stop = team_sub.add_parser("stop", help="Stop team or instance")
    p_stop.add_argument("instance", nargs="?")

    p_restart = team_sub.add_parser("restart", help="Restart team or instance")
    p_restart.add_argument("instance", nargs="?")

    team_sub.add_parser("status", help="Show team status")

    # Top-level commands
    sub.add_parser("ls", help="List active instance processes")

    p_sess = sub.add_parser("sessions", help="List orphan multi-user session dirs")
    p_sess.add_argument("--purge", action="store_true",
                        help="實際刪除（預設只報告）")
    p_sess.add_argument("--min-age-days", type=float, default=0.0,
                        help="只列出超過 N 天未修改的（預設 0 = 全部）")

    p_attach = sub.add_parser("attach", help="Peek recent output from an instance")
    p_attach.add_argument("name", help="Instance name")

    p_send = sub.add_parser("send", help="Send message to instance")
    p_send.add_argument("name", help="Instance name")
    p_send.add_argument("message", help="Message text")

    p_init = sub.add_parser("init", help="Create default team.yaml")
    p_init.add_argument("--force", action="store_true", help="Overwrite existing config")
    # [1.3.1] 入口 agent 名可指定 —— 原本 init 產出的 13 處內容全部寫死 `ark-agent`
    # （那是 nana 的名字）。新專案若想叫別的（如 aiops 的 `admin-agent`、
    # director 的 `tech-agent`），原本得手動改十幾個地方。
    p_init.add_argument("--entry-name", default="ark-agent", metavar="NAME",  # hardcode-ok: --entry-name 的向後相容預設值（可用參數覆寫）
                        help="入口 agent 的 instance 名（私訊管家／意圖路由），預設 ark-agent")  # hardcode-ok: --entry-name 的向後相容預設值（可用參數覆寫）

    # webbot sub-command (observability + future chatbot frontend)
    p_wb = sub.add_parser("webbot", help="Run the webbot services (api with SPA + scheduler)")
    p_wb.add_argument("--webbot-config", type=Path, default=None,
                      help="Path to webbot.yaml (default: ./webbot.yaml)")
    wb_sub = p_wb.add_subparsers(dest="webbot_cmd")

    p_wb_api = wb_sub.add_parser("api", help="REST/WS API with embedded SPA (default port 3030)")
    p_wb_api.add_argument("--port", type=int)

    wb_sub.add_parser("scheduler", help="APScheduler cron runner")

    p_wb_start = wb_sub.add_parser(
        "start",
        help="Run api + scheduler together in one process (recommended)",
    )
    p_wb_start.add_argument("--no-api", action="store_true", help="Skip the API server")
    p_wb_start.add_argument("--no-scheduler", action="store_true", help="Skip the Scheduler")

    # kiro sub-command (file policy management)
    p_kiro = sub.add_parser("kiro", help="Manage .kiro/ files across agents")
    kiro_sub = p_kiro.add_subparsers(dest="kiro_cmd")

    p_kiro_status = kiro_sub.add_parser("status", help="Show .kiro/ file status for all agents")
    p_kiro_status.add_argument("--agent", help="Filter by agent name")

    p_kiro_sync = kiro_sub.add_parser("sync", help="Force sync template files")
    p_kiro_sync.add_argument("--agent", help="Target agent name")
    p_kiro_sync.add_argument("--file", help="Target file (relative to .kiro/)")
    p_kiro_sync.add_argument("--all", action="store_true", help="Sync all template files")

    p_kiro_diff = kiro_sub.add_parser("diff", help="Show diff between template and current file")
    p_kiro_diff.add_argument("agent", help="Agent name")
    p_kiro_diff.add_argument("file", nargs="?", help="File path (relative to .kiro/)")

    kiro_sub.add_parser("refresh", help="Regenerate all 'always' policy files without restart")

    args = parser.parse_args()
    _setup_logging(args.log_level, json_mode=getattr(args, "json_log", False))

    # Propagate --config to sub-namespace
    if not hasattr(args, "config") or args.config is None:
        args.config = None

    if args.command == "team":
        dispatch = {
            "start": cmd_team_start,
            "stop": cmd_team_stop,
            "restart": cmd_team_restart,
            "status": cmd_team_status,
        }
        fn = dispatch.get(args.team_cmd)
        if fn:
            fn(args)
        else:
            parser.parse_args(["team", "--help"])
    elif args.command == "sessions":
        cmd_sessions(args)
    elif args.command == "ls":
        cmd_ls(args)
    elif args.command == "attach":
        cmd_attach(args)
    elif args.command == "send":
        cmd_send(args)
    elif args.command == "init":
        cmd_init(args)
    elif args.command == "webbot":
        wb_dispatch = {
            "api": cmd_webbot_api,
            "scheduler": cmd_webbot_scheduler,
            "start": cmd_webbot_start,
        }
        wb_fn = wb_dispatch.get(args.webbot_cmd)
        if wb_fn:
            wb_fn(args)
        else:
            parser.parse_args(["webbot", "--help"])
    elif args.command == "kiro":
        kiro_dispatch = {
            "status": cmd_kiro_status,
            "sync": cmd_kiro_sync,
            "diff": cmd_kiro_diff,
            "refresh": cmd_kiro_refresh,
        }
        kiro_fn = kiro_dispatch.get(args.kiro_cmd)
        if kiro_fn:
            kiro_fn(args)
        else:
            parser.parse_args(["kiro", "--help"])
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
