"""ark-team-agent: Python multi-agent team manager for Kiro CLI."""
__version__ = "1.5.0"
