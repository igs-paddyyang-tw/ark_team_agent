"""ECHO-inspired failure pattern memory — 跨 instance 失敗模式追蹤。

追蹤每個 instance 的 kiro-cli 層級錯誤（rate_limit, auth, network 等），
偵測重複失敗模式並觸發通知/事件。

[2026-06-15] 穩定性優化：移除方案 C（自動重啟/暫停），改為僅 log 警告。
暫時性錯誤（server_error/network_error）不應觸發自動重啟，避免雪崩。
"""
from __future__ import annotations

import time
from collections import deque
from dataclasses import dataclass, field


@dataclass
class FailureRecord:
    """單次失敗記錄。"""

    instance: str
    error_type: str
    message: str
    timestamp: float = field(default_factory=time.time)


class FailureMemory:
    """Per-instance 失敗模式記憶，偵測連續同類錯誤。

    僅追蹤 + 通知，不觸發自動重啟/暫停。
    """

    def __init__(self, max_records: int = 10, repeat_threshold: int = 2) -> None:
        self._records: dict[str, deque[FailureRecord]] = {}
        self._max = max_records
        self._threshold = repeat_threshold

    def record(self, instance: str, error_type: str, message: str) -> bool:
        """記錄一次失敗，回傳是否觸發重複模式警告。"""
        if instance not in self._records:
            self._records[instance] = deque(maxlen=self._max)
        self._records[instance].append(
            FailureRecord(instance=instance, error_type=error_type, message=message)
        )
        return self._is_repeating(instance)

    def _is_repeating(self, instance: str) -> bool:
        """連續 N 次同類錯誤 → True。"""
        records = self._records.get(instance)
        if not records or len(records) < self._threshold:
            return False
        recent = list(records)[-self._threshold:]
        return all(r.error_type == recent[0].error_type for r in recent)

    def consecutive_count(self, instance: str) -> int:
        """目前連續同類錯誤的次數。"""
        records = self._records.get(instance)
        if not records:
            return 0
        last_type = records[-1].error_type
        count = 0
        for r in reversed(records):
            if r.error_type == last_type:
                count += 1
            else:
                break
        return count

    def get_recent(self, instance: str, n: int = 5) -> list[FailureRecord]:
        """取得最近 N 筆失敗記錄。"""
        records = self._records.get(instance)
        if not records:
            return []
        return list(records)[-n:]

    def clear(self, instance: str) -> None:
        """清除指定 instance 的記錄（重啟後）。"""
        self._records.pop(instance, None)

    def summary(self, instance: str) -> str:
        """產出一行摘要，適合 Telegram 通知。"""
        records = self.get_recent(instance, self._threshold)
        if not records:
            return ""
        types = [r.error_type for r in records]
        if len(set(types)) == 1:
            return f"⚠️ {instance}: 連續 {len(records)} 次 [{types[0]}] — {records[-1].message}"
        return f"⚠️ {instance}: 最近 {len(records)} 次錯誤 — {records[-1].message}"
