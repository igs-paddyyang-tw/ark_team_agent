"""Wiki API endpoints — /api/wiki/* namespace."""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from fastapi import APIRouter, HTTPException, Query

router = APIRouter(prefix="/api/wiki", tags=["wiki"])

_knowledge_dir: Path | None = None


def init(knowledge_dir: Path) -> None:
    global _knowledge_dir
    _knowledge_dir = knowledge_dir


def _extract_title(content: str) -> str:
    """Extract title from frontmatter or first heading."""
    # Frontmatter title
    m = re.search(r'^title:\s*["\']?(.+?)["\']?\s*$', content, re.MULTILINE)
    if m:
        return m.group(1)
    # First markdown heading
    m = re.search(r'^#\s+(.+)$', content, re.MULTILINE)
    if m:
        return m.group(1)
    return ""


@router.get("/pages")
async def list_pages(scope: str | None = None) -> dict[str, Any]:
    """List all wiki .md pages under knowledge/."""
    if not _knowledge_dir or not _knowledge_dir.exists():
        return {"ok": True, "pages": []}

    pages: list[dict] = []
    for md in sorted(_knowledge_dir.rglob("*.md")):
        # Only include pages under wiki/ directories, skip raw/, schema.md, index.md, log.md
        rel = md.relative_to(_knowledge_dir).as_posix()
        if "/raw/" in rel or rel.startswith("raw/"):
            continue
        if "/wiki/" not in rel and not rel.startswith("wiki/"):
            continue  # 跳過 schema.md / index.md / log.md 等管理檔
        if scope and not rel.startswith(f"{scope}/"):
            continue

        title = _extract_title(md.read_text(encoding="utf-8", errors="ignore")[:500])
        pages.append({"path": rel, "title": title or md.stem})

    return {"ok": True, "pages": pages}


@router.get("/pages/{path:path}")
async def get_page(path: str) -> dict[str, Any]:
    """Read a wiki page raw markdown."""
    if not _knowledge_dir:
        raise HTTPException(status_code=503, detail="Knowledge dir not configured")

    file = _knowledge_dir / path
    if not file.exists() or not file.suffix == ".md":
        raise HTTPException(status_code=404, detail=f"Page not found: {path}")

    # Prevent path traversal
    try:
        file.resolve().relative_to(_knowledge_dir.resolve())
    except ValueError:
        raise HTTPException(status_code=403, detail="Access denied")

    content = file.read_text(encoding="utf-8", errors="ignore")
    return {"ok": True, "path": path, "content": content}


@router.get("/search")
async def search_pages(q: str = Query(..., min_length=1)) -> dict[str, Any]:
    """Full-text search across wiki pages."""
    if not _knowledge_dir or not _knowledge_dir.exists():
        return {"ok": True, "results": []}

    query = q.lower()
    results: list[dict] = []

    for md in _knowledge_dir.rglob("*.md"):
        rel = md.relative_to(_knowledge_dir).as_posix()
        if "/raw/" in rel or rel.startswith("raw/"):
            continue
        if "/wiki/" not in rel and not rel.startswith("wiki/"):
            continue  # 跳過管理檔

        content = md.read_text(encoding="utf-8", errors="ignore")
        if query not in content.lower():
            continue

        title = _extract_title(content[:500])
        # Extract snippet around match
        idx = content.lower().find(query)
        start = max(0, idx - 50)
        end = min(len(content), idx + len(query) + 100)
        snippet = content[start:end].replace("\n", " ").strip()

        results.append({"path": rel, "title": title or md.stem, "snippet": snippet})
        if len(results) >= 20:
            break

    return {"ok": True, "query": q, "results": results}
