"""Conversation log — per-instance 對話歷史（SQLite）。

提供以 instance 為索引的對話紀錄，可回溯「上次跟某 agent 聊了什麼」。
Session 過期時自動摘要寫入。
"""
from __future__ import annotations

import logging
import sqlite3
import time
from dataclasses import dataclass
from pathlib import Path

log = logging.getLogger(__name__)


@dataclass
class ConversationEntry:
    """一次對話摘要。"""

    instance: str
    user_id: int
    summary: str
    turn_count: int
    timestamp: float
    rowid: int | None = None


class ConversationLog:
    """SQLite-backed per-instance conversation history."""

    _SCHEMA = """
    CREATE TABLE IF NOT EXISTS conversations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        instance TEXT NOT NULL,
        user_id INTEGER NOT NULL,
        summary TEXT NOT NULL,
        turn_count INTEGER NOT NULL,
        timestamp REAL NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_conv_instance ON conversations(instance, timestamp DESC);
    CREATE INDEX IF NOT EXISTS idx_conv_user ON conversations(user_id, timestamp DESC);
    """

    def __init__(self, db_path: Path | str = "state/conversations.db") -> None:
        db_path = Path(db_path)
        db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(db_path), timeout=5.0)
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.executescript(self._SCHEMA)
        self._conn.commit()

    def record(self, instance: str, user_id: int, summary: str, turn_count: int) -> None:
        """記錄一段對話摘要。"""
        self._conn.execute(
            "INSERT INTO conversations (instance, user_id, summary, turn_count, timestamp) VALUES (?, ?, ?, ?, ?)",
            (instance, user_id, summary, turn_count, time.time()),
        )
        self._conn.commit()

    def query_by_instance(self, instance: str, limit: int = 10) -> list[ConversationEntry]:
        """查詢某 instance 的最近對話。"""
        rows = self._conn.execute(
            "SELECT id, instance, user_id, summary, turn_count, timestamp "
            "FROM conversations WHERE instance=? ORDER BY timestamp DESC LIMIT ?",
            (instance, limit),
        ).fetchall()
        return [
            ConversationEntry(
                rowid=r[0], instance=r[1], user_id=r[2],
                summary=r[3], turn_count=r[4], timestamp=r[5],
            )
            for r in rows
        ]

    def query_by_user(self, user_id: int, limit: int = 10) -> list[ConversationEntry]:
        """查詢某使用者的最近對話。"""
        rows = self._conn.execute(
            "SELECT id, instance, user_id, summary, turn_count, timestamp "
            "FROM conversations WHERE user_id=? ORDER BY timestamp DESC LIMIT ?",
            (user_id, limit),
        ).fetchall()
        return [
            ConversationEntry(
                rowid=r[0], instance=r[1], user_id=r[2],
                summary=r[3], turn_count=r[4], timestamp=r[5],
            )
            for r in rows
        ]

    def purge_older_than(self, days: int = 30) -> int:
        """清理超過 N 天的紀錄。"""
        cutoff = time.time() - (days * 86400)
        cursor = self._conn.execute("DELETE FROM conversations WHERE timestamp < ?", (cutoff,))
        self._conn.commit()
        return cursor.rowcount

    @staticmethod
    def summarize_session(session) -> str:
        """從 Session 物件萃取摘要（最後 3 輪的 user 訊息）。"""
        user_turns = [t for t in session.turns if t.role == "user"]
        if not user_turns:
            return "(無使用者訊息)"
        recent = user_turns[-3:]
        parts = [t.content[:80] for t in recent]
        return " → ".join(parts)
