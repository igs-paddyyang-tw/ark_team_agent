"""Session management for multi-turn conversations. SQLite-backed for persistence."""
from __future__ import annotations

import json
import logging
import sqlite3
import time
import uuid
from contextlib import contextmanager
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Iterator

log = logging.getLogger(__name__)


@dataclass
class Turn:
    role: str       # "user" | "assistant"
    content: str
    timestamp: float = field(default_factory=time.time)


@dataclass
class Session:
    user_id: int
    chat_id: int
    topic_id: int | None = None
    instance: str | None = None
    session_id: str = field(default_factory=lambda: uuid.uuid4().hex[:8])
    turns: list[Turn] = field(default_factory=list)
    status: str = "active"
    created_at: float = field(default_factory=time.time)
    last_active: float = field(default_factory=time.time)
    timeout: float = 300  # 5 min

    def add_turn(self, role: str, content: str) -> None:
        self.turns.append(Turn(role=role, content=content))
        if len(self.turns) > 20:
            self.turns = self.turns[-20:]
        self.last_active = time.time()

    def is_expired(self) -> bool:
        return (time.time() - self.last_active) > self.timeout

    def recent_context(self, n: int = 5) -> str:
        lines = []
        for t in self.turns[-n:]:
            label = "使用者" if t.role == "user" else "助理"
            lines.append(f"{label}：{t.content}")
        return "\n".join(lines)


# ── Session store backends ────────────────────────────────────────


class _NullStore:
    """No-op store — sessions stay in memory only."""

    def save(self, session: Session) -> None: ...
    def delete(self, user_id: int) -> None: ...
    def load_all(self) -> list[Session]: return []
    def purge_older_than(self, seconds: int) -> int: return 0


class _SqliteStore:
    """SQLite-backed persistence for sessions."""

    _SCHEMA = """
    CREATE TABLE IF NOT EXISTS sessions (
        user_id INTEGER PRIMARY KEY,
        chat_id INTEGER NOT NULL,
        topic_id INTEGER,
        instance TEXT,
        session_id TEXT NOT NULL,
        turns TEXT NOT NULL DEFAULT '[]',
        status TEXT NOT NULL DEFAULT 'active',
        created_at REAL NOT NULL,
        last_active REAL NOT NULL,
        timeout REAL NOT NULL DEFAULT 300
    );
    CREATE INDEX IF NOT EXISTS idx_sessions_last_active ON sessions(last_active);
    """

    def __init__(self, db_path: Path) -> None:
        self._path = db_path
        db_path.parent.mkdir(parents=True, exist_ok=True)
        with self._connect() as conn:
            conn.executescript(self._SCHEMA)
            conn.execute("PRAGMA journal_mode=WAL")

    @contextmanager
    def _connect(self) -> Iterator[sqlite3.Connection]:
        conn = sqlite3.connect(self._path, timeout=5.0)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
            conn.commit()
        finally:
            conn.close()

    def save(self, session: Session) -> None:
        turns_json = json.dumps([asdict(t) for t in session.turns], ensure_ascii=False)
        try:
            with self._connect() as conn:
                conn.execute(
                    """
                    INSERT INTO sessions
                      (user_id, chat_id, topic_id, instance, session_id, turns, status,
                       created_at, last_active, timeout)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ON CONFLICT(user_id) DO UPDATE SET
                      chat_id=excluded.chat_id,
                      topic_id=excluded.topic_id,
                      instance=excluded.instance,
                      session_id=excluded.session_id,
                      turns=excluded.turns,
                      status=excluded.status,
                      last_active=excluded.last_active,
                      timeout=excluded.timeout
                    """,
                    (
                        session.user_id, session.chat_id, session.topic_id, session.instance,
                        session.session_id, turns_json, session.status,
                        session.created_at, session.last_active, session.timeout,
                    ),
                )
        except Exception as e:
            log.warning("Failed to save session for user %s: %s", session.user_id, e)

    def delete(self, user_id: int) -> None:
        try:
            with self._connect() as conn:
                conn.execute("DELETE FROM sessions WHERE user_id = ?", (user_id,))
        except Exception as e:
            log.warning("Failed to delete session for user %s: %s", user_id, e)

    def load_all(self) -> list[Session]:
        try:
            with self._connect() as conn:
                rows = conn.execute("SELECT * FROM sessions").fetchall()
        except Exception as e:
            log.warning("Failed to load sessions: %s", e)
            return []

        sessions = []
        for r in rows:
            try:
                turns_data = json.loads(r["turns"] or "[]")
                turns = [Turn(**t) for t in turns_data]
                sessions.append(Session(
                    user_id=r["user_id"],
                    chat_id=r["chat_id"],
                    topic_id=r["topic_id"],
                    instance=r["instance"],
                    session_id=r["session_id"],
                    turns=turns,
                    status=r["status"],
                    created_at=r["created_at"],
                    last_active=r["last_active"],
                    timeout=r["timeout"],
                ))
            except Exception as e:
                log.warning("Failed to deserialize session user_id=%s: %s", r["user_id"], e)
        return sessions

    def purge_older_than(self, seconds: int) -> int:
        cutoff = time.time() - seconds
        try:
            with self._connect() as conn:
                cursor = conn.execute("DELETE FROM sessions WHERE last_active < ?", (cutoff,))
                return cursor.rowcount
        except Exception as e:
            log.warning("Session purge failed: %s", e)
            return 0


# ── SessionManager ────────────────────────────────────────────────


class SessionManager:
    """Per-user session store with optional SQLite persistence.

    If `db_path` is provided, sessions are persisted and restored on startup.
    Otherwise falls back to in-memory only (backward compatible).
    """

    def __init__(self, db_path: Path | None = None, on_expire=None) -> None:
        self._sessions: dict[int, Session] = {}
        self._store = _SqliteStore(db_path) if db_path else _NullStore()
        # Callback when session expires: fn(session) → called before deletion
        self._on_expire = on_expire
        # Restore non-expired sessions from disk
        for s in self._store.load_all():
            if not s.is_expired():
                self._sessions[s.user_id] = s
            else:
                self._store.delete(s.user_id)
        if isinstance(self._store, _SqliteStore):
            log.info("Session store loaded (%d active sessions)", len(self._sessions))

    def get_or_create(self, user_id: int, chat_id: int,
                      topic_id: int | None = None,
                      instance: str | None = None) -> Session:
        s = self._sessions.get(user_id)
        if s and not s.is_expired():
            # topic 切換時重設 instance 綁定與對話歷史
            if topic_id is not None and s.topic_id != topic_id:
                s.topic_id = topic_id
                s.instance = instance
                s.chat_id = chat_id
                s.turns = []
            s.last_active = time.time()
            self._store.save(s)
            return s
        # Expired or new
        if s:
            self._store.delete(user_id)
        s = Session(user_id=user_id, chat_id=chat_id,
                    topic_id=topic_id, instance=instance)
        self._sessions[user_id] = s
        self._store.save(s)
        return s

    def save(self, user_id: int) -> None:
        """Explicitly persist a session (useful after add_turn)."""
        s = self._sessions.get(user_id)
        if s:
            self._store.save(s)

    def reset(self, user_id: int) -> None:
        self._sessions.pop(user_id, None)
        self._store.delete(user_id)

    def complete(self, user_id: int) -> Session | None:
        s = self._sessions.pop(user_id, None)
        if s:
            s.status = "completed"
            self._store.delete(user_id)
        return s

    def cleanup_expired(self) -> int:
        expired = [uid for uid, s in self._sessions.items() if s.is_expired()]
        for uid in expired:
            s = self._sessions.pop(uid, None)
            if s and self._on_expire and s.turns:
                try:
                    self._on_expire(s)
                except Exception as e:
                    log.warning("on_expire callback failed for user %s: %s", uid, e)
            self._store.delete(uid)
        return len(expired)

    def purge_stale(self, hours: int = 24) -> int:
        """Delete sessions older than `hours` from both memory and disk."""
        return self._store.purge_older_than(hours * 3600)
