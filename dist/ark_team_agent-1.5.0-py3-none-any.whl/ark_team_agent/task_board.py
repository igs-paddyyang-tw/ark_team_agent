"""Task board — structured task management with board.json + items/*.md."""
from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any

log = logging.getLogger(__name__)


@dataclass
class TaskHandoff:
    """Structured handoff evidence for task completion (Hermes-inspired).

    Answers four questions:
    1. What changed? (summary)
    2. How was it verified? (verification)
    3. What can unblock/retry this? (retry_notes)
    4. What risk is still open? (residual_risk)
    """
    summary: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)
    # Standard metadata keys:
    # - changed_files: list[str]
    # - verification: list[str]
    # - residual_risk: list[str]
    # - retry_notes: str


@dataclass
class Task:
    """A single task on the board."""
    id: str = ""
    title: str = ""
    assignee: str = ""
    status: str = "pending"  # pending | in_progress | completed | blocked | failed
    priority: str = "medium"  # low | medium | high | critical
    depends_on: list[str] = field(default_factory=list)
    created_at: str = ""
    started_at: str | None = None
    completed_at: str | None = None
    due_at: str | None = None
    verified_by: str | None = None
    verified_at: str | None = None
    file: str = ""
    note: str = ""
    notes: list[dict] = field(default_factory=list)  # [{"at": iso, "text": "..."}]
    handoff: TaskHandoff | None = None


class TaskBoard:
    """CRUD operations on tasks/board.json + tasks/items/*.md."""

    def __init__(self, tasks_dir: Path) -> None:
        self.tasks_dir = tasks_dir
        self.board_path = tasks_dir / "board.json"
        self.items_dir = tasks_dir / "items"
        self.items_dir.mkdir(parents=True, exist_ok=True)

    def _load(self) -> dict[str, Any]:
        if not self.board_path.exists():
            return {"version": "1.0", "updated_at": "", "tasks": []}
        try:
            return json.loads(self.board_path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return {"version": "1.0", "updated_at": "", "tasks": []}

    def _save(self, data: dict[str, Any]) -> None:
        data["updated_at"] = datetime.now().isoformat()
        self.board_path.write_text(
            json.dumps(data, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    def _to_task(self, raw: dict) -> Task:
        handoff_raw = raw.get("handoff")
        handoff = None
        if handoff_raw and isinstance(handoff_raw, dict):
            handoff = TaskHandoff(
                summary=handoff_raw.get("summary", ""),
                metadata=handoff_raw.get("metadata", {}),
            )
        return Task(
            id=raw.get("id", ""),
            title=raw.get("title", ""),
            assignee=raw.get("assignee", ""),
            status=raw.get("status", "pending"),
            priority=raw.get("priority", "medium"),
            depends_on=raw.get("depends_on", []),
            created_at=raw.get("created_at", ""),
            started_at=raw.get("started_at"),
            completed_at=raw.get("completed_at"),
            due_at=raw.get("due_at"),
            verified_by=raw.get("verified_by"),
            verified_at=raw.get("verified_at"),
            file=raw.get("file", ""),
            note=raw.get("note", ""),
            notes=raw.get("notes", []),
            handoff=handoff,
        )

    # ── Read ──────────────────────────────────────────────────

    def list_tasks(self, status: str | None = None, assignee: str | None = None) -> list[Task]:
        """List all tasks, optionally filtered by status or assignee."""
        data = self._load()
        tasks = [self._to_task(t) for t in data.get("tasks", [])]
        if status:
            tasks = [t for t in tasks if t.status == status]
        if assignee:
            tasks = [t for t in tasks if t.assignee == assignee]
        return tasks

    def has_pending(self, assignee: str) -> bool:
        """Check if an assignee has any pending or in_progress tasks."""
        data = self._load()
        for t in data.get("tasks", []):
            if t.get("assignee") == assignee and t.get("status") in ("pending", "in_progress"):
                return True
        return False

    def list_active(self, completed_days: int = 7) -> list[Task]:
        """未完成任務 + 最近 N 天已完成。用於 TG 任務板顯示。"""
        from datetime import timedelta
        cutoff = (datetime.now() - timedelta(days=completed_days)).isoformat()
        all_tasks = self.list_tasks()
        return [
            t for t in all_tasks
            if t.status in ("pending", "in_progress", "blocked", "failed")
            or (t.status == "completed" and (t.completed_at or "") >= cutoff)
        ]

    def get_task(self, task_id: str) -> Task | None:
        """Get a single task by ID."""
        data = self._load()
        for t in data.get("tasks", []):
            if t.get("id") == task_id:
                return self._to_task(t)
        return None

    def get_blocked(self) -> list[Task]:
        """Get tasks that are blocked by unfinished dependencies."""
        data = self._load()
        completed_ids = {t["id"] for t in data.get("tasks", []) if t.get("status") == "completed"}
        blocked = []
        for t in data.get("tasks", []):
            if t.get("status") == "pending" and t.get("depends_on"):
                unmet = [d for d in t["depends_on"] if d not in completed_ids]
                if unmet:
                    blocked.append(self._to_task(t))
        return blocked

    def get_overdue(self, hours: int = 24) -> list[Task]:
        """Get in_progress tasks older than N hours."""
        data = self._load()
        threshold = time.time() - hours * 3600
        overdue = []
        for t in data.get("tasks", []):
            if t.get("status") == "in_progress" and t.get("created_at"):
                try:
                    created = datetime.fromisoformat(t["created_at"]).timestamp()
                    if created < threshold:
                        overdue.append(self._to_task(t))
                except (ValueError, OSError):
                    pass
        return overdue

    # ── Create ────────────────────────────────────────────────

    def create_task(
        self,
        title: str,
        assignee: str,
        *,
        priority: str = "medium",
        depends_on: list[str] | None = None,
        description: str = "",
    ) -> Task:
        """Create a new task and write its item file."""
        data = self._load()
        now = datetime.now()
        task_id = f"{now.strftime('%Y%m%d')}-{_slugify(title)}"

        # Ensure unique ID
        existing_ids = {t["id"] for t in data.get("tasks", [])}
        base_id = task_id
        counter = 1
        while task_id in existing_ids:
            task_id = f"{base_id}-{counter}"
            counter += 1

        item_file = f"items/{now.strftime('%Y-%m-%d')}-{_slugify(title)}.md"
        task_raw = {
            "id": task_id,
            "title": title,
            "assignee": assignee,
            "status": "pending",
            "priority": priority,
            "depends_on": depends_on or [],
            "created_at": now.isoformat(),
            "completed_at": None,
            "file": item_file,
            "note": "",
        }
        data.setdefault("tasks", []).append(task_raw)
        self._save(data)

        # Write item markdown
        item_path = self.tasks_dir / item_file
        item_path.parent.mkdir(parents=True, exist_ok=True)
        item_content = (
            f"# {title}\n\n"
            f"> ID: {task_id}\n"
            f"> 狀態: pending\n"
            f"> 指派: {assignee}\n"
            f"> 優先: {priority}\n"
            f"> 依賴: {', '.join(depends_on or []) or '無'}\n"
            f"> 建立: {now.isoformat()}\n"
            f"> 完成: —\n\n"
            f"## 需求\n{description or '（待填寫）'}\n\n"
            f"## 產出\n（完成後填寫）\n\n"
            f"## 備註\n\n"
        )
        item_path.write_text(item_content, encoding="utf-8")
        log.info("Task created: %s → %s", task_id, assignee)

        return self._to_task(task_raw)

    # ── Update ────────────────────────────────────────────────

    def delete_task(self, task_id: str) -> bool:
        """[1.2.9] 刪除任務。回傳是否有刪到（找不到回 False）。

        供 `DELETE /api/dashboard/board/{task_id}` 使用（design 早有定義、原未實作）。
        """
        data = self._load()
        tasks = data.get("tasks", [])
        remaining = [t for t in tasks if t.get("id") != task_id]
        if len(remaining) == len(tasks):
            return False
        data["tasks"] = remaining
        self._save(data)
        return True

    def update_status(self, task_id: str, status: str, *, note: str = "",
                      summary: str = "", metadata: dict | None = None) -> Task | None:
        """Update task status. Returns updated task or None if not found.

        When completing a task, provide summary + metadata for structured handoff.
        """
        data = self._load()
        for t in data.get("tasks", []):
            if t.get("id") == task_id:
                old_status = t.get("status")
                now = datetime.now()
                t["status"] = status

                # Auto-set started_at on first in_progress
                if status == "in_progress" and not t.get("started_at"):
                    t["started_at"] = now.isoformat()

                if status == "completed":
                    t["completed_at"] = now.isoformat()

                # Structured handoff (Hermes-inspired)
                if summary or metadata:
                    t["handoff"] = {
                        "summary": summary[:500] if summary else "",
                        "metadata": metadata or {},
                    }

                # Append note to notes list (with timestamp)
                if note:
                    t["note"] = note  # backward compat
                    t.setdefault("notes", []).append({"at": now.isoformat(), "text": note})

                self._save(data)
                log.info("Task %s → %s", task_id, status)

                # File lock management
                item_path = self.tasks_dir / t.get("file", "")
                if item_path.exists():
                    from .file_lock import FileLock
                    lock = FileLock()
                    assignee = t.get("assignee", "")
                    try:
                        if status == "in_progress" and old_status != "in_progress":
                            lock.acquire(str(item_path), assignee)
                        elif status in ("completed", "failed") and old_status == "in_progress":
                            lock.release(str(item_path), assignee)
                    except Exception:
                        # [team-agent 2026-05-18] Ensure .lock cleanup on any error
                        lock.release(str(item_path), assignee)
                elif old_status == "in_progress" and status in ("completed", "failed"):
                    # Release lock even if item file was deleted
                    item_path_str = str(self.tasks_dir / t.get("file", ""))
                    from .file_lock import FileLock
                    FileLock().release(item_path_str, t.get("assignee", ""))

                # Auto-unblock dependents
                if status == "completed":
                    self._check_unblock(data, task_id)

                return self._to_task(t)
        return None

    def _check_unblock(self, data: dict, completed_id: str) -> None:
        """Check if completing this task unblocks any pending tasks."""
        completed_ids = {t["id"] for t in data.get("tasks", []) if t.get("status") == "completed"}
        for t in data.get("tasks", []):
            if t.get("status") == "blocked" and t.get("depends_on"):
                unmet = [d for d in t["depends_on"] if d not in completed_ids]
                if not unmet:
                    t["status"] = "pending"
                    log.info("Task %s unblocked (dependency %s completed)", t["id"], completed_id)
        self._save(data)

    # ── Summary ───────────────────────────────────────────────

    def export_markdown(self, output_path: Path) -> None:
        """Export board.json to a structured markdown file."""
        tasks = self.list_tasks()
        now = datetime.now()
        lines = [
            "# 任務管理紀錄",
            "",
            "> 自動產出自 board.json，含時間、目標、成果產出。",
            "",
            "---",
            "",
            f"## 任務總覽（{now.strftime('%Y-%m-%d %H:%M')} 更新）",
            "",
            "| # | 任務 | 負責人 | 優先級 | 建立時間 | 完成時間 | 狀態 | 成果/備註 |",
            "|---|------|--------|--------|----------|----------|------|-----------|",
        ]
        icons = {"pending": "⏳", "in_progress": "🔄", "completed": "✅", "blocked": "🚫", "failed": "❌"}
        for i, t in enumerate(tasks, 1):
            created = t.created_at[:10] if t.created_at else "—"
            completed = t.completed_at[:10] if t.completed_at else "—"
            status_icon = icons.get(t.status, "•")
            note = t.note or "—"
            lines.append(
                f"| {i} | {t.title} | {t.assignee} | {t.priority} "
                f"| {created} | {completed} | {status_icon} | {note} |"
            )

        # Statistics
        by_status: dict[str, int] = {}
        for t in tasks:
            by_status[t.status] = by_status.get(t.status, 0) + 1
        total = len(tasks)
        done = by_status.get("completed", 0)
        pct = int(done / total * 100) if total else 0

        lines.extend([
            "",
            "---",
            "",
            "## 統計",
            "",
            f"- **總任務數：** {total}",
            f"- **已完成：** {done}（{pct}%）",
            f"- **進行中：** {by_status.get('in_progress', 0)}",
            f"- **待處理：** {by_status.get('pending', 0)}",
            f"- **阻塞：** {by_status.get('blocked', 0)}",
            f"- **失敗：** {by_status.get('failed', 0)}",
            "",
            "---",
            "",
            f"*自動產出：{now.strftime('%Y-%m-%d %H:%M')}*",
            "",
        ])

        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text("\n".join(lines), encoding="utf-8")
        log.info("Task management markdown exported to %s", output_path)

    def summary(self, codenames: dict[str, str] | None = None) -> str:
        """Human-readable summary of the board (未完成 + 最近 7 天已完成)."""
        tasks = self.list_active(completed_days=7)
        if not tasks:
            return "📋 任務板：空（無任務）"

        by_status: dict[str, list[Task]] = {}
        for t in tasks:
            by_status.setdefault(t.status, []).append(t)

        status_icons = {"pending": "⏳", "in_progress": "🔄", "completed": "✅", "blocked": "🚫", "failed": "❌"}
        priority_icons = {"critical": "🔴", "high": "🔴", "medium": "🟡", "low": "🟢"}
        _codenames = codenames or {}

        lines = [f"📋 任務板（{len(tasks)} 個）"]
        counts = {s: len(ts) for s, ts in by_status.items()}

        for status in ["in_progress", "pending", "blocked", "completed", "failed"]:
            items = by_status.get(status, [])
            if not items:
                continue
            label = {"in_progress": "進行中", "pending": "待派工", "blocked": "阻塞", "completed": "已完成", "failed": "失敗"}.get(status, status)
            lines.append(f"\n{status_icons.get(status, '•')} {label}（{len(items)}）")
            display_items = items if status != "completed" else items[-5:]
            for t in display_items[:8]:
                p = priority_icons.get(t.priority, "⚪")
                name = _codenames.get(t.assignee, t.assignee.replace("-agent", ""))
                dur = self._duration_str(t)
                verified = " ✓驗收" if t.verified_by else ""
                line = f"  {p} {t.title} → {name}"
                if dur:
                    line += f" ⏱️{dur}"
                line += verified
                lines.append(line)
            if len(items) > 8:
                lines.append(f"  ... +{len(items)-8} more")

        # Footer stats
        lines.append(f"\n📊 完成 {counts.get('completed', 0)} | 進行 {counts.get('in_progress', 0)} | 待派 {counts.get('pending', 0)} | 阻塞 {counts.get('blocked', 0)}")
        return "\n".join(lines)

    @staticmethod
    def _duration_str(t: Task) -> str:
        """Calculate human-readable duration."""
        start = t.started_at or t.created_at
        end = t.completed_at
        if not start:
            return ""
        try:
            s = datetime.fromisoformat(start)
            e = datetime.fromisoformat(end) if end else datetime.now()
            hours = (e - s).total_seconds() / 3600
            if hours < 1:
                return f"{int(hours * 60)}m"
            elif hours < 24:
                return f"{hours:.1f}h"
            else:
                return f"{hours / 24:.1f}d"
        except (ValueError, TypeError):
            return ""


def _slugify(text: str) -> str:
    """Convert title to URL-safe slug."""
    import re
    # Keep alphanumeric, Chinese chars, hyphens
    slug = re.sub(r"[^\w\u4e00-\u9fff-]", "-", text)
    slug = re.sub(r"-+", "-", slug).strip("-")
    return slug[:50]  # limit length
