"""Cost guard — daily spend tracking, warning, and auto-pause.

Design:
- Per-instance per-day spend rolling window (YYYY-MM-DD in configured timezone).
- Spend is added via `add_spend(instance, usd)`. Estimation is out of scope —
  integrate from Kiro CLI output parsing or token × price heuristics externally.
- When spend crosses `warn_at_percentage` of `daily_limit_usd`, emit a warning
  via `on_warn` callback (Telegram adapter wires this to a topic/chat message).
- When spend reaches 100% of limit, emit `on_pause` callback — daemon transitions
  the instance to PAUSED status. Resumes automatically at midnight (local tz).
"""
from __future__ import annotations

import asyncio
import logging
import sqlite3
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Awaitable, Callable, Iterator

try:
    from zoneinfo import ZoneInfo
except ImportError:  # pragma: no cover — Python < 3.9 not supported
    ZoneInfo = None  # type: ignore

log = logging.getLogger(__name__)


WarnCallback = Callable[[str, float, float], Awaitable[None]]   # (instance, spent, limit)
PauseCallback = Callable[[str, float], Awaitable[None]]         # (instance, spent)
ResumeCallback = Callable[[str], Awaitable[None]]               # (instance)


@dataclass
class DailySpend:
    instance: str
    date: str   # YYYY-MM-DD in tracker's timezone
    amount_usd: float


class CostGuard:
    """SQLite-backed daily spend tracker with warn/pause/resume callbacks."""

    _SCHEMA = """
    CREATE TABLE IF NOT EXISTS spends (
        instance TEXT NOT NULL,
        date TEXT NOT NULL,
        amount_usd REAL NOT NULL DEFAULT 0,
        warned INTEGER NOT NULL DEFAULT 0,
        paused INTEGER NOT NULL DEFAULT 0,
        PRIMARY KEY (instance, date)
    );
    CREATE INDEX IF NOT EXISTS idx_spends_date ON spends(date);
    """

    def __init__(
        self,
        db_path: Path,
        *,
        daily_limit_usd: float,
        warn_at_percentage: int = 80,
        tz_name: str = "Asia/Taipei",
        per_instance_limits: dict[str, float] | None = None,
    ) -> None:
        self._path = db_path
        self.daily_limit_usd = float(daily_limit_usd)
        self.warn_pct = int(warn_at_percentage)
        self._tz = self._resolve_tz(tz_name)
        self._write_lock = asyncio.Lock()
        self.on_warn: WarnCallback | None = None
        self.on_pause: PauseCallback | None = None
        self.on_resume: ResumeCallback | None = None
        # Per-instance budget overrides (instance_name → daily USD limit)
        self._per_instance_limits: dict[str, float] = per_instance_limits or {}
        self._init_db()

    @staticmethod
    def _resolve_tz(name: str):
        if ZoneInfo is None:
            return timezone.utc
        try:
            return ZoneInfo(name)
        except Exception:
            log.warning("Unknown timezone %s, falling back to UTC", name)
            return timezone.utc

    def _init_db(self) -> None:
        self._path.parent.mkdir(parents=True, exist_ok=True)
        with self._connect() as conn:
            conn.executescript(self._SCHEMA)
            conn.execute("PRAGMA journal_mode=WAL")

    @contextmanager
    def _connect(self) -> Iterator[sqlite3.Connection]:
        conn = sqlite3.connect(self._path, timeout=5.0)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
            conn.commit()
        finally:
            conn.close()

    # ── Time helpers ──────────────────────────────────────────────

    def today(self) -> str:
        return datetime.now(self._tz).strftime("%Y-%m-%d")

    def seconds_until_midnight(self) -> float:
        now = datetime.now(self._tz)
        tomorrow = (now + timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0)
        return (tomorrow - now).total_seconds()

    # ── Spend recording ──────────────────────────────────────────

    def _limit_for(self, instance: str) -> float:
        """Get effective daily limit for an instance (per-instance override or global)."""
        return self._per_instance_limits.get(instance, self.daily_limit_usd)

    async def add_spend(self, instance: str, amount_usd: float) -> None:
        """Record spend for the instance. Triggers warn/pause callbacks if thresholds crossed."""
        limit = self._limit_for(instance)
        if amount_usd <= 0 or limit <= 0:
            return
        date = self.today()

        async with self._write_lock:
            prev_total, warned, paused = await asyncio.to_thread(
                self._upsert_and_fetch, instance, date, amount_usd,
            )

        new_total = prev_total + amount_usd
        warn_threshold = limit * (self.warn_pct / 100.0)

        # Warn threshold crossed?
        if not warned and new_total >= warn_threshold and new_total < limit:
            await self._mark_warned(instance, date)
            log.warning("Cost warn for %s: $%.2f (≥ %d%% of $%.2f)",
                        instance, new_total, self.warn_pct, limit)
            if self.on_warn:
                try:
                    await self.on_warn(instance, new_total, limit)
                except Exception as e:
                    log.warning("on_warn failed for %s: %s", instance, e)

        # Pause threshold crossed?
        if not paused and new_total >= limit:
            await self._mark_paused(instance, date)
            log.error("Cost limit reached for %s: $%.2f / $%.2f — pausing",
                      instance, new_total, limit)
            if self.on_pause:
                try:
                    await self.on_pause(instance, new_total)
                except Exception as e:
                    log.warning("on_pause failed for %s: %s", instance, e)

    def _upsert_and_fetch(
        self, instance: str, date: str, delta: float,
    ) -> tuple[float, bool, bool]:
        """Insert-or-update spend row, returning pre-update values."""
        with self._connect() as conn:
            row = conn.execute(
                "SELECT amount_usd, warned, paused FROM spends WHERE instance=? AND date=?",
                (instance, date),
            ).fetchone()
            if row:
                prev = row["amount_usd"]
                conn.execute(
                    "UPDATE spends SET amount_usd = amount_usd + ? WHERE instance=? AND date=?",
                    (delta, instance, date),
                )
                return prev, bool(row["warned"]), bool(row["paused"])
            conn.execute(
                "INSERT INTO spends (instance, date, amount_usd) VALUES (?, ?, ?)",
                (instance, date, delta),
            )
            return 0.0, False, False

    async def _mark_warned(self, instance: str, date: str) -> None:
        await asyncio.to_thread(self._mark_flag, instance, date, "warned")

    async def _mark_paused(self, instance: str, date: str) -> None:
        await asyncio.to_thread(self._mark_flag, instance, date, "paused")

    def _mark_flag(self, instance: str, date: str, column: str) -> None:
        with self._connect() as conn:
            conn.execute(
                f"UPDATE spends SET {column} = 1 WHERE instance=? AND date=?",
                (instance, date),
            )

    # ── Queries ──────────────────────────────────────────────────

    def get_today_spend(self, instance: str) -> float:
        date = self.today()
        with self._connect() as conn:
            row = conn.execute(
                "SELECT amount_usd FROM spends WHERE instance=? AND date=?",
                (instance, date),
            ).fetchone()
        return row["amount_usd"] if row else 0.0

    def spent_today(self) -> float:
        """Total spend across all instances today."""
        all_spend = self.get_today_all()
        return sum(all_spend.values())

    def get_today_all(self) -> dict[str, float]:
        date = self.today()
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT instance, amount_usd FROM spends WHERE date=?",
                (date,),
            ).fetchall()
        return {r["instance"]: r["amount_usd"] for r in rows}

    def is_paused(self, instance: str) -> bool:
        date = self.today()
        with self._connect() as conn:
            row = conn.execute(
                "SELECT paused FROM spends WHERE instance=? AND date=?",
                (instance, date),
            ).fetchone()
        return bool(row and row["paused"])

    def get_range(self, since_days: int = 7) -> list[DailySpend]:
        """Get per-instance daily spend for the last N days."""
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT instance, date, amount_usd FROM spends ORDER BY date DESC LIMIT ?",
                (since_days * 50,),  # generous upper bound
            ).fetchall()
        return [
            DailySpend(instance=r["instance"], date=r["date"], amount_usd=r["amount_usd"])
            for r in rows
        ]

    # ── Midnight resume loop ─────────────────────────────────────

    async def reset_loop(self) -> None:
        """Background task — sleeps until midnight, then resumes paused instances."""
        while True:
            try:
                wait = self.seconds_until_midnight() + 5  # small grace period
                await asyncio.sleep(wait)
                # Find instances paused yesterday
                await self._resume_paused()
            except asyncio.CancelledError:
                return
            except Exception as e:
                log.warning("CostGuard reset loop error: %s", e)
                await asyncio.sleep(60)

    async def _resume_paused(self) -> None:
        today = self.today()
        # Query for any currently paused instances from previous days
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT DISTINCT instance FROM spends WHERE paused=1 AND date != ?",
                (today,),
            ).fetchall()
        for r in rows:
            instance = r["instance"]
            log.info("Auto-resuming %s after midnight rollover", instance)
            if self.on_resume:
                try:
                    await self.on_resume(instance)
                except Exception as e:
                    log.warning("on_resume failed for %s: %s", instance, e)
