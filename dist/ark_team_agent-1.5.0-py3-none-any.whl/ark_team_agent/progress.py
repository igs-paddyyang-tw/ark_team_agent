"""Progress reporter — detect stages from agent output, update Telegram message."""
from __future__ import annotations

import logging
import re
import time

log = logging.getLogger(__name__)

_ANSI = re.compile(r"\x1b\[[0-9;?]*[A-Za-z]|\x1b[=>]?\S*")

# Stage detection patterns (applied to ANSI-stripped output)
_STAGES: list[tuple[re.Pattern, str, str]] = [
    (re.compile(r"Reading|讀取|read_file|fs_read", re.I), "reading", "讀取檔案"),
    (re.compile(r"Writing|Created|Modified|wrote|fs_write", re.I), "writing", "撰寫程式碼"),
    (re.compile(r"Running|Executing|shell|bash|go run|npm|pip", re.I), "running", "執行命令"),
    (re.compile(r"Searching|grep|find|search", re.I), "searching", "搜尋"),
    (re.compile(r"Testing|test|spec|assert", re.I), "testing", "執行測試"),
]


class ProgressReporter:
    """
    Tracks agent output stages and builds a progress summary.

    Usage:
        reporter = ProgressReporter()
        reporter.feed(new_output_chunk)
        text = reporter.render()  # returns formatted progress string or None
    """

    def __init__(self) -> None:
        self._stages: list[dict] = []  # {"label": str, "status": "running"|"done", "time_ms": int}
        self._current: str | None = None
        self._current_start: float = 0
        self._last_render: str = ""
        self._started_at: float = time.time()

    def feed(self, raw: str) -> None:
        """Feed new output chunk, detect stage transitions."""
        clean = _ANSI.sub("", raw)

        for pattern, key, label in _STAGES:
            if pattern.search(clean):
                if self._current != key:
                    self._finish_current()
                    self._current = key
                    self._current_start = time.time()
                    self._stages.append({"key": key, "label": label, "status": "running", "time_ms": 0})
                break

    def finish(self) -> None:
        """Mark all stages as done."""
        self._finish_current()

    def _finish_current(self) -> None:
        if self._current and self._stages:
            last = self._stages[-1]
            if last["status"] == "running":
                last["status"] = "done"
                last["time_ms"] = int((time.time() - self._current_start) * 1000)
        self._current = None

    def render(self) -> str | None:
        """Render progress text. Returns None if nothing changed."""
        if not self._stages:
            return None

        # 只顯示最新一個階段，不累積
        s = self._stages[-1]
        if s["status"] == "running":
            text = f"⏳ {s['label']}..."
        else:
            ms = s["time_ms"]
            text = f"✅ {s['label']}（{ms/1000:.1f}s）" if ms > 1000 else f"✅ {s['label']}"

        if text == self._last_render:
            return None
        self._last_render = text
        return text

    def render_final(self) -> str:
        """Render final summary with total time."""
        self.finish()
        total = time.time() - self._started_at
        lines = self.render() or ""
        return f"{lines}\n\n✅ 完成！（{total:.1f} 秒）"

    @property
    def has_stages(self) -> bool:
        return len(self._stages) > 0
