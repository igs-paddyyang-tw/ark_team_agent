"""Daemon core — instance lifecycle, health monitoring, message delivery."""
from __future__ import annotations

import asyncio
import hashlib
import logging
import time
from dataclasses import dataclass, field
from datetime import datetime as _dt
from enum import Enum
from pathlib import Path

from .backend import KiroBackend, KiroBackendConfig
from .session_key import SessionKey
from .config import TeamConfig, InstanceConfig, get_home
from .event_log import EventType, get_event_log
from .failure_memory import FailureMemory
from .process import ManagedProcess, register, unregister

log = logging.getLogger(__name__)


def _base_skip_resume(ic: "InstanceConfig") -> bool:
    """skip_resume 基準值（v1.1.3）。

    team.yaml 顯式設定優先；未設（None）則依 role 自動：
    admin / manager → False（--resume 接續對話）；其餘 role → True（開新對話）。

    Author: ark-agent
    """
    v = getattr(ic, "skip_resume", None)
    if v is not None:
        return bool(v)
    return (getattr(ic, "role", "worker") or "worker") not in ("admin", "manager")


class InstanceStatus(str, Enum):
    STOPPED = "stopped"
    STARTING = "starting"
    RUNNING = "running"
    CRASHED = "crashed"
    PAUSED = "paused"
    AWAITING_REPLY = "awaiting_reply"
    # [1.2.16] 「做完了，沒有待辦」——與 AWAITING_REPLY 的差別是**沒有人在等**。
    # 原本只有兩個狀態，但實際有三種語意：
    #   AWAITING_REPLY 有人在等我回話 → 跳過 hang（等待是正常的）、套用決策規則
    #   RUNNING        我正在做事     → 閒置超時要通報
    #   IDLE           做完了、沒待辦 → 不通報（閒著是正常的），但 **crash 偵測照常**
    # 排程跑完的 agent 屬於第三種，硬塞進前兩種都會錯：塞 AWAITING_REPLY 會讓
    # hang 偵測被關掉（真掛死時 4-6 小時無人知），塞 RUNNING 則閒置 60 分就誤報。
    IDLE = "idle"


@dataclass
class InstanceState:
    config: InstanceConfig
    status: InstanceStatus = InstanceStatus.STOPPED
    process: ManagedProcess | None = None
    backend: KiroBackend | None = None
    crash_count: int = 0
    last_activity: float = 0
    # [1.4.7] **只由「agent 真的產出東西」更新** —— 與 `last_activity` 分開。
    #
    # 為什麼要分：`last_activity` 同時被 **inbound（訊息寫進 stdin）** 與
    # **output（產出增加）** 更新，也就是它混了「我收到東西」與「我做了事」兩種語意。
    # 而 hang 偵測要問的是後者。
    #
    # 實測後果（aiops，2026-08-19）：obs-agent 每小時發巡檢給 ic-agent，
    # ic-agent 從 23:30 起**再也沒有任何輸出**，但每次 inbound 都把 `last_activity`
    # 刷新到 <60 分鐘 → **hang 偵測（門檻 60m）永遠不會觸發**。
    # 帳面上它 `status=running`、`crash_count=0`、`halted=False`、進程活 15 小時 ——
    # 每一個指標都說它很好，而它已經 9 小時沒回過一句話。
    #
    # `last_activity` 的語意不改（idle eviction 要它 —— 剛收到工作的 agent 不該被回收）。
    last_output: float = 0
    last_task: str = ""  # [team-agent 2026-05-15] 最後收到的任務摘要（供 ToolTracker 顯示）
    # [1.5.1] 累計 output 字元數（估算 context 使用量，超閾值觸發 session reset）
    cumulative_output_chars: int = 0
    # [1.2.11] 崩潰鑑識：記住最後一次退出碼與分類，供 /api/status 與 event log 使用
    last_exit_code: int | None = None
    last_exit_cause: str = ""
    # [1.2.11] 主動停止旗標 —— stop/restart 走的是 terminate()/kill()（-15/-9），
    # 若不標記，每次 systemctl restart 都會被判成「疑似 OOM」的假訊號
    _stopping: bool = False
    # [1.2.16] 最後一則 inbound 的來源，決定 reply() 後要進 AWAITING_REPLY 還是 IDLE。
    # 只有互動來源（TG 使用者 / Web chat）才有人在等回話；排程與 agent 間訊息沒有。
    # 預設 "user" —— 未標記的呼叫端一律維持既有行為（保守，不改變現況）。
    last_inbound_source: str = "user"
    # [1.2.14 P3] 崩潰迴圈治理。`crash_count` 是「連續」計數，會被活動偵測歸零
    # （daemon 的「有新 output → 重置」），所以量不到「崩潰→重啟→再崩潰」的迴圈。
    # 以下三者**不受活動偵測影響**：
    # [1.2.14 P4] 啟動觀測：spawn → ready 秒數、Kiro 實際載入的 MCP server 數、
    # 套件宣告掛載的 server 名（用來算「全域設定貢獻了幾個」）
    last_startup_seconds: float | None = None
    mcp_loaded: int | None = None
    _mcp_declared: list[str] = field(default_factory=list)
    lifetime_crashes: int = 0                                   # 本次服務生命期總崩潰數（只增不減）
    crash_times: list[float] = field(default_factory=list)      # 觀察窗內的崩潰時間戳
    cooldown_count: int = 0                                     # 已進入冷卻幾次
    halted: bool = False                                        # True = 停止自動重啟，等人工介入
    _paste_lock: asyncio.Lock = field(default_factory=asyncio.Lock)
    _msg_queue: asyncio.Queue = field(default_factory=lambda: asyncio.Queue(maxsize=50))
    _queue_task: asyncio.Task | None = field(default=None, repr=False)

    @property
    def instance_dir(self) -> Path:
        return get_home() / "instances" / self.config.name


class Daemon:
    """Manages the lifecycle of all Kiro CLI instances."""

    def __init__(self, team_config: TeamConfig) -> None:
        self.config = team_config
        self.instances: dict[str, InstanceState] = {}
        self._health_tasks: dict[str, asyncio.Task] = {}
        # [ark-agent 2026-08-07] v1.1.3 P1-6：降級告警清單（啟動時發生但不致命的問題）
        # 由 preflight / topic 建立失敗等填入；health 端點暴露 → 讓「靜默降級」浮上來
        self.degraded: list[str] = []
        # Hang notification callback: async (instance_name: str, idle_seconds: float) -> None
        # Set by team.py after Telegram adapter is ready.
        self.on_hang_detected = None
        # Escalation callback: async (instance_name: str, idle_seconds: float) -> None
        self.on_hang_escalated = None
        # Recovery callback: async (instance_name: str) -> None
        # Called by health_loop after successful restart.
        self.on_instance_recovered = None
        # Track which instances we've already notified about to avoid spam
        self._hang_notified: set[str] = set()
        # Track which instances have been escalated (second threshold)
        self._hang_escalated: set[str] = set()
        # ECHO-inspired failure pattern memory
        self._failure_memory = FailureMemory()
        # Track last seen output hash per instance to avoid re-detecting same error
        self._last_output_hash: dict[str, str] = {}
        # [1.5.0] TTL + Cancel：追蹤佇列中訊息的過期時間和 ID
        self._msg_counter: int = 0
        self._msg_expiry: dict[str, dict[str, float]] = {}  # {instance: {msg_id: expire_at}}
        self._msg_cancelled: set[str] = set()  # 已取消的 msg_id
        # Track memory warnings to avoid spam
        self._memory_warned: set[str] = set()
        # Persistent overflow for backpressure-dropped messages
        from .message_overflow import MessageOverflow
        from .config import get_state_dir
        self._overflow = MessageOverflow(get_state_dir() / "message_overflow.db")
        # Cooldown tracking per instance (replaces per-task local variable)
        self._cooldown_until: dict[str, float] = {}
        # [1.1.13] peer 回覆逾時追蹤：sender → (target, deadline_epoch)。只追最近一筆（已知限制）。
        self._pending_reply: dict[str, tuple[str, float]] = {}
        # 已戳醒過的 sender（避免同一筆重複 nudge；record 新請求時清除）
        self._pending_reply_nudged: set[str] = set()
        # [1.2.2 N4] 派工脈絡：orchestrator → (target, 摘要, deadline_epoch)。只追最近一筆。
        self._last_dispatch: dict[str, tuple[str, str, float]] = {}
        # Single global health loop task (replaces per-instance _health_loop tasks)
        self._health_loop_task: asyncio.Task | None = None
        # Output count tracking for activity detection (GA-team pattern)
        self._last_output_count: dict[str, int] = {}
        # Optional CostGuard reference (set by team.py if daily_limit_usd > 0)
        self.cost_guard = None
        # [team-agent 2026-07-30] Decision loop — set by DaemonAPI after init
        self.decision_mgr = None
        # Track which decision requests have had reminders sent (prevent spam)
        self._decision_reminded: set[str] = set()
        # Track which awaiting_reply instances have been flagged for legacy-question
        self._legacy_question_flagged: set[str] = set()
        # Skill Extractor — auto-extract reusable skills
        from .skill_extractor import SkillExtractor, ExtractorConfig
        self._skill_extractor = SkillExtractor(ExtractorConfig())

    # ── Startup cleanup ─────────────────────────────────────────

    def _cleanup_stale_locks(self) -> None:
        """Remove leftover .lock files from tasks/items/ on startup."""
        from .file_lock import FileLock
        from .config import get_home
        tasks_dir = get_home() / "agents" / "tasks" / "items"
        if tasks_dir.exists():
            FileLock().cleanup_stale(tasks_dir, max_age_seconds=0)  # Remove all on startup

    # ── Instance lifecycle ──────────────────────────────────────

    # [claude-code 2026-08-06] 多使用者私訊隔離 — session instance 衍生
    @staticmethod
    def _session_key(name: str, user_id: int) -> str:
        """多使用者隔離的 session instance key（`實體名~user_id`）。

        [1.2.20] 生成與解析全部委派 `SessionKey` —— 分隔符不再出現在這裡。
        """
        return str(SessionKey(name, user_id))

    # ── 本體 vs 衍生 session 的單一出口 ──────────────────────────────────
    # [1.2.20] 需要「團隊成員清單」的地方一律用 entity_instances()。
    # 不要自己寫分隔符判斷 —— 實測 28 處列舉點只有 2 處記得過濾，
    # 而漏掉的那些會把 session 混進廣播、狀態列表與可派工對象。
    def entity_instances(self) -> dict[str, InstanceConfig]:
        """只含本體成員（排除衍生 session）。

        用於 TEAM.md 成員表、TG 清單、廣播對象、可派工對象 ——
        凡是語意為「團隊有哪些人」的地方。
        """
        return {n: c for n, c in self.config.instances.items()
                if not SessionKey.is_session(n)}

    def session_instances(self) -> dict[str, InstanceConfig]:
        """只含衍生 session（本體不列入）。"""
        return {n: c for n, c in self.config.instances.items()
                if SessionKey.is_session(n)}

    async def resolve_session(self, name: str, user_id: int) -> str:
        """對 multi_user instance，回傳並確保 spawn 對應 user 的 session instance key。

        非 multi_user（或未知）instance 直接回原 name，行為不變（零破壞）。
        lazy spawn：首次該 user 觸發時才啟動 subprocess。

        Author: claude-code
        """
        ic = self.config.instances.get(name)
        if not ic or not getattr(ic, "multi_user", False):
            return name
        key = self._session_key(name, user_id)
        state = self.instances.get(key)
        if state and state.status == InstanceStatus.RUNNING:
            state.last_activity = time.time()
            # [SESSION] 驗證用：同 user 復用既有 session，不重複 spawn
            log.info("[SESSION] reuse key=%s user=%s base=%s status=running", key, user_id, name)
            return key
        # 達 max_user_sessions 時先回收（LRU，跳過有人在等回覆的）
        await self._enforce_session_limit(name)
        if key not in self.config.instances:
            # [1.2.20] 設計 §8 的降級：衍生失敗**退回本體**，不讓私訊整條斷掉。
            # 這條路徑是使用者的私訊入口 —— 退回共用工作區（隔離失效）
            # 遠優於「完全收不到回覆」。
            try:
                self.config.instances[key] = self._derive_session_config(ic, key, user_id)
            except Exception as exc:
                log.warning("[SESSION] derive failed base=%s user=%s (%s) "
                            "→ 退回本體（隔離失效但服務不中斷）", name, user_id, exc)
                return name
        # [SESSION] 驗證用：lazy 產出新 kiro-cli session instance
        log.info("[SESSION] spawn key=%s user=%s base=%s dir=%s",
                 key, user_id, name, get_home() / "instances" / key)
        await self.start_instance(key)
        st = self.instances.get(key)
        if st:
            st.last_activity = time.time()
        # [SESSION] 驗證用：確認新 session 已進入啟動流程
        log.info("[SESSION] spawned key=%s user=%s status=%s",
                 key, user_id, st.status.value if st else "unknown")
        return key

    # ── 衍生 session 的工作區隔離 ────────────────────────────────────────
    def _derive_session_config(self, base: InstanceConfig, key: str,
                               user_id: int) -> InstanceConfig:
        """由本體設定衍生 per-user session 設定。

        [1.2.20] 原本只有 `replace(ic, name=key, multi_user=False)` ——
        **`working_directory` 與本體完全相同**，所以所有使用者的
        `memory/journal.md`、`memory/daily/` 都寫進同一個目錄。
        「多使用者隔離」其實只隔離了對話，沒隔離資料。

        現在每個 session 有自己的工作區 `<base_wd>/sessions/<user_id>/`：

        - **獨立**：`memory/`（本次要隔離的東西）、`output/`、`docs/` 等
        - **首次繼承**：`.kiro/steering/*.md`（人格與規範，**複製**不是 symlink）
        - **不建立**：`knowledge/` —— 跨 session 共用一律走 MCP `wiki_query`

        這正好對上架構定調：「每個 agent 都是獨立的運作與發展，
        共用的只有知識庫本身。」per-user session 是同一個 agent 的分身，
        套用同一條原則 —— 人格繼承一次後各自演進，知識不複製。

        放在 `sessions/<uid>/` 而非平行目錄的理由：① 一眼看得出歸屬
        ② 刪除本體時一併帶走 ③ 不污染 `agents/` 命名空間
        （`check_agent_dirs.py` 的孤兒檢查只掃 `agents/*`，不會誤報）。

        `multi_user=False` 是**防遞迴**的關鍵 —— 衍生設定若還帶 `True`，
        下一輪 `resolve_session` 會對它再衍生一層（`base~1~1`）。
        """
        import dataclasses

        wd = Path(base.working_directory) / "sessions" / str(user_id)
        self._copy_base_steering(base, wd)
        return dataclasses.replace(
            base, name=key, working_directory=str(wd), multi_user=False,
        )

    def _copy_base_steering(self, base: InstanceConfig, session_wd: Path) -> None:
        """首次建立 session 工作區時，從本體複製 `.kiro/steering/*.md`。

        用**複製**而非 symlink —— 2026-08-14 已全面移除 symlink 共用，
        因為它讓「獨立發展」變成假的（改一份等於改全部）。

        只複製不存在的檔案（`once` 語意），讓 session 可以自行補充筆記。
        `memory/` 完全不複製 —— 那是個人流水，複製就違反隔離目的。

        失敗只記 warning **不中斷** ——
        人格退化成範本版仍能服務，起不來就完全不能用。
        """
        import shutil

        src = Path(base.working_directory) / ".kiro" / "steering"
        if not src.is_dir():
            return
        dst = session_wd / ".kiro" / "steering"
        try:
            dst.mkdir(parents=True, exist_ok=True)
            copied = 0
            for f in sorted(src.glob("*.md")):
                target = dst / f.name
                if target.exists():
                    continue
                shutil.copy2(f, target)
                copied += 1
            if copied:
                log.info("[SESSION] steering inherited files=%d from=%s to=%s",
                         copied, src, dst)
        except OSError as exc:
            log.warning("[SESSION] steering copy failed (%s) —— "
                        "將由範本產生，人格可能退化：%s", exc, dst)

    async def _enforce_session_limit(self, base_name: str) -> None:
        """達 `max_user_sessions` 時 LRU 回收最久未活動的衍生 session。

        [1.2.20] 原本是空實作（`return`）—— 設定檔宣告了上限、呼叫端也如實呼叫，
        但**完全沒有生效**。每個 session 是一個獨立 kiro-cli 子進程，
        等於啟用 `multi_user` 後使用者數就是進程數。
        比「沒有上限」更糟的是：讀設定的人會以為有保護。

        ⚠️ **`AWAITING_REPLY` 永不回收** —— 那代表有使用者正在等這個 agent 回話，
        回收它等於當著使用者的面掛掉對話。這是 1.2.16 引入 `IDLE` 的價值兌現處：
        在那之前「回覆完」與「有人在等」都是 `AWAITING_REPLY`，
        **無法區分，也就無法安全回收**。

        找不到可回收者時**放行超額**並記錄警示 —— 寧可多一個進程，
        也不要砍掉正在進行的對話。

        回收成本低於直覺：`instances/<key>/` 目錄保留，該使用者下次發訊息時
        `--resume` 會接回原對話。這是進程回收，不是資料遺失。
        """
        base_cfg = self.config.instances.get(base_name)
        limit = getattr(base_cfg, "max_user_sessions", 5) if base_cfg else 5
        if limit < 1:          # 設定異常時不做回收，交給 validate_config 報錯
            return

        # 用 base_of 比對：對本體與 session 都成立，不必先判斷是哪一種
        live = [
            (n, st) for n, st in self.instances.items()
            if n != base_name and SessionKey.base_of(n) == base_name
            and st.status in (InstanceStatus.RUNNING, InstanceStatus.IDLE,
                              InstanceStatus.AWAITING_REPLY)
        ]
        if len(live) < limit:
            return

        evictable = [(n, st) for n, st in live
                     if st.status is not InstanceStatus.AWAITING_REPLY]
        if not evictable:
            log.warning(
                "[SESSION] over-limit base=%s live=%d limit=%d "
                "reason=all-awaiting-reply action=allow-overflow",
                base_name, len(live), limit)
            return

        victim, vst = min(evictable, key=lambda kv: kv[1].last_activity)
        log.info("[SESSION] evict key=%s status=%s idle=%.0fs live=%d limit=%d",
                 victim, vst.status.value, time.time() - vst.last_activity,
                 len(live), limit)
        await self.stop_instance(victim)

    async def start_instance(self, name: str, *, skip_resume: bool | None = None) -> None:
        ic = self.config.instances.get(name)
        if not ic:
            raise ValueError(f"Unknown instance: {name}")

        # Skip auto_start=False instances (e.g. cto-agent = this workspace)
        if not ic.auto_start:
            log.debug("Skipping %s (auto_start=False)", name)
            return

        state = self.instances.get(name)
        if state and state.status == InstanceStatus.RUNNING:
            log.warning("Instance %s already running", name)
            return

        if not state:
            state = InstanceState(config=ic)
            self.instances[name] = state

        state.status = InstanceStatus.STARTING
        state._stopping = False   # [1.2.11] 啟動即恢復崩潰偵測（清主動停止旗標）
        inst_dir = state.instance_dir
        inst_dir.mkdir(parents=True, exist_ok=True)
        Path(ic.working_directory).mkdir(parents=True, exist_ok=True)

        # [ark-agent 2026-08-07] skip_resume base：呼叫端強制 > team.yaml 顯式 > role 自動
        if skip_resume is None:
            skip_resume = _base_skip_resume(ic)

        # Auto-detect if MCP config changed → force clean session
        # (Kiro CLI only loads tools/list on new session, not on resume)
        if not skip_resume:
            skip_resume = self._should_skip_resume(name, inst_dir)

        # Compute allowed targets based on role
        role = ic.role or "worker"
        if role == "manager":
            if ic.private_chat:
                # Private manager (team-agent): only sees itself
                allowed_targets = []
            else:
                # Group manager (game-team-agent): sees all group members (read-only, no send)
                allowed_targets = [n for n, c in self.entity_instances().items()
                                   if not c.private_chat]
        elif role == "leader":
            # leaders can target all members (including manager for upward reporting)
            allowed_targets = list(self.entity_instances())
        else:
            allowed_targets = []  # workers can only reply, no send targets

        backend = KiroBackend(str(inst_dir))
        _mcp_kw = self._mcp_for(ic)
        cfg = KiroBackendConfig(
            working_directory=ic.working_directory,
            instance_name=name,
            instance_dir=str(inst_dir),
            skip_permissions=ic.skip_permissions,
            skip_resume=skip_resume,
            model=ic.model,
            instructions=ic.system_prompt,
            description=ic.description,  # [1.2.19] 根目錄 AGENTS.md 的代號來源
            template=getattr(ic, "template", None),  # [v1.1.3 P2-8] 明示範本
            team_doc=getattr(self.config, "team_doc", {}) or {},  # [v1.1.3 P1-4]
            team_api_port=self.config.health_port,
            team_home=str(get_home()),
            role=role,
            allowed_targets=allowed_targets,
            kiro_files_policy=self.config.kiro_files,
            **_mcp_kw,  # [1.2.13 P1] 宣告式 MCP：mcp_servers / mcp_disabled / mcp_prune
        )
        # [1.2.13] write_config 回傳 MCP 預檢的 degraded 註記 —— 併入 self.degraded
        # 供 /api/status 與 TG /status 顯示。同一 instance 的舊註記先清掉再寫入，
        # 讓「修好之後重啟」能自動汰除（比照 1.1.9 B 的 degraded 自癒慣例）。
        _mcp_notes = backend.write_config(cfg) or []
        _prefix = f":{name}:"
        self.degraded[:] = [
            d for d in self.degraded
            if not (d.startswith("mcp_") and (_prefix in d or d.endswith(f":{name}")))
        ]
        for _n in _mcp_notes:
            if _n not in self.degraded:
                self.degraded.append(_n)
        # [claude-code 2026-08-06] TEAM.md 只列實體成員，過濾衍生 session
        backend.write_team_context(cfg, self.entity_instances())
        backend.write_agent_files(cfg)

        mp = ManagedProcess(name=name)
        if state.process and state.process.is_alive():
            await state.process.kill()
            unregister(name)

        cmd = backend.build_command(cfg)
        await mp.start(cmd, cwd=ic.working_directory)
        register(mp)

        state.process = mp
        state.backend = backend
        # [1.2.14 P4] 記下本次宣告掛載的 server 名 —— 用來和 Kiro 實際載入數比對，
        # 差額即為全域 ~/.kiro/settings/mcp.json 貢獻的（套件預檢管不到那些）
        state._mcp_declared = sorted(_mcp_kw.get("mcp_servers") or {})

        ready = await self._wait_for_ready(state)
        if ready:
            state.status = InstanceStatus.RUNNING
            state.last_activity = time.time()
            self._hang_notified.discard(name)
            self._hang_escalated.discard(name)
            self._failure_memory.clear(name)
            log.info("Instance %s is ready (pid=%s)", name, mp.pid)
            await get_event_log().record(name, EventType.START, detail=f"pid={mp.pid}")
            # 啟動訊息佇列處理器（per-instance task，只管 stdin 寫入）
            state._queue_task = asyncio.create_task(self._queue_worker(name))
            # 確保全域 health loop 在跑
            self._ensure_health_loop()
        else:
            state.status = InstanceStatus.CRASHED
            log.error("Instance %s failed to start", name)
            await get_event_log().record(name, EventType.CRASH, detail="startup failed")

    async def stop_instance(self, name: str) -> None:
        state = self.instances.get(name)
        if not state or state.status == InstanceStatus.STOPPED:
            return
        # [1.2.11] 標記為主動停止 —— 我們自己 terminate()/kill()（-15/-9），
        # 不標記會被 classify_exit 誤判成「疑似 OOM」
        state._stopping = True
        # [1.2.14 P3] 人工介入的唯一訊號：自動重啟路徑只呼叫 start_instance，
        # 只有 stop / restart（CLI、API、TG）會走到這裡 → 在此解除 halt 並清迴圈記錄，
        # 否則被 halt 的 agent 連人工重啟都起不來。
        if state.halted or state.cooldown_count or state.crash_times:
            log.info("%s 人工停止 → 解除崩潰迴圈狀態（halted=%s, cooldowns=%d, 窗內=%d）",
                     name, state.halted, state.cooldown_count, len(state.crash_times))
        state.halted = False
        state.cooldown_count = 0
        state.crash_times.clear()
        self._cooldown_until.pop(name, None)
        self.degraded[:] = [
            d for d in self.degraded
            if not (d.startswith(f"crash_loop:{name}:") or d.startswith(f"crash_loop_halted:{name}:"))
        ]

        if state.process and state.backend and state.process.is_alive():
            try:
                await state.process.send_input(state.backend.quit_command())
                await asyncio.sleep(2)
            except (RuntimeError, OSError):
                pass

        if state.process:
            await state.process.kill()
            unregister(name)

        if state.backend:
            cfg = KiroBackendConfig(
                working_directory=state.config.working_directory,
                instance_name=name,
                instance_dir=str(state.instance_dir),
            )
            state.backend.cleanup(cfg)

        task = self._health_tasks.pop(name, None)
        if task:
            task.cancel()
            # Legacy: per-instance health tasks no longer created, but clean up any stale ones

        # 停止訊息佇列
        if state._queue_task:
            state._queue_task.cancel()
            state._queue_task = None

        state.status = InstanceStatus.STOPPED
        log.info("Instance %s stopped", name)
        await get_event_log().record(name, EventType.STOP)

    async def restart_instance(self, name: str) -> None:
        await self.stop_instance(name)
        await asyncio.sleep(1)
        await self.start_instance(name)
        await get_event_log().record(name, EventType.RESTART)

    async def pause_instance(self, name: str) -> None:
        """Pause instance (stop + mark status as PAUSED). Used by cost guard."""
        state = self.instances.get(name)
        if not state:
            return
        await self.stop_instance(name)
        # Mark as paused rather than stopped (different semantics)
        state.status = InstanceStatus.PAUSED
        log.info("Instance %s paused", name)

    async def resume_instance(self, name: str) -> None:
        """Resume from paused state by starting the instance."""
        state = self.instances.get(name)
        if not state or state.status != InstanceStatus.PAUSED:
            return
        log.info("Instance %s resuming from paused state", name)
        await self.start_instance(name)

    # ── Message delivery ────────────────────────────────────────

    async def send_message(self, name: str, text: str, *, source: str = "user", ttl_minutes: int = 0) -> str | bool:
        """送訊息給 agent。回傳 msg_id（成功）或 False（失敗）。

        [1.5.0] 新增 ttl_minutes：訊息存活時間（分鐘），0 = 不過期。
        投遞前若已過期或被取消，自動丟棄。
        """
        state = self.instances.get(name)
        if not state:
            log.warning("Cannot send to %s: not defined in team.yaml", name)
            return False

        # [2026-07-31] Lazy spawn: persistent=False agent が STOPPED なら自動起動
        ic = self.config.instances.get(name)
        if (
            ic
            and not ic.persistent
            and state.status == InstanceStatus.STOPPED
        ):
            log.info("Lazy spawn: starting non-persistent agent %s on demand", name)
            state.status = InstanceStatus.STARTING  # 防並行重複啟動
            try:
                await self.start_instance(name, skip_resume=True)
            except Exception as e:
                log.error("Lazy spawn failed for %s: %s", name, e)
                state.status = InstanceStatus.STOPPED
                return False
            # 等待啟動完成（最多 30s）
            import time as _t
            deadline = _t.time() + 30
            while _t.time() < deadline:
                if state.status in (InstanceStatus.RUNNING, InstanceStatus.AWAITING_REPLY,
                                    InstanceStatus.IDLE):
                    break
                await asyncio.sleep(1)

        if (state.status not in (InstanceStatus.RUNNING, InstanceStatus.AWAITING_REPLY,
                                 InstanceStatus.IDLE)
                or not state.process):
            # [1.1.9 B] 未就緒（如啟動窗口 STARTING）→ 存 overflow，_queue_worker 於 ready 後重播，
            # 避免啟動窗口內 agent 間訊息「假成功、實際遺失」。真正無法送達由 overflow 持久保留。
            log.warning("Deferring message to %s: status=%s → overflow (replay when ready)",
                        name, state.status.value)
            self._overflow.store(name, text)
            _note = f"deferred_message:{name}"
            if _note not in self.degraded:
                self.degraded.append(_note)
            return True  # queued for later delivery, not dropped

        # [1.1.9 B] 目標已就緒 → 清除先前的 deferred 標記（degraded 自癒）
        for _note in (f"deferred_message:{name}", f"restart_interrupted:{name}"):
            if _note in self.degraded:
                self.degraded.remove(_note)
        # [1.1.13] 收到 inbound → 視為所等回覆已到，解除 peer 等待追蹤
        self._pending_reply.pop(name, None)
        self._pending_reply_nudged.discard(name)
        # P1: AWAITING_REPLY → RUNNING on new message (agent resumes work)
        # [1.2.16] IDLE 同樣要轉回 RUNNING —— _queue_worker 只在 RUNNING 投遞訊息，
        # 漏了 IDLE 會讓閒著的 agent 收得到卻永遠不處理。
        if state.status in (InstanceStatus.AWAITING_REPLY, InstanceStatus.IDLE):
            _prev = state.status.value
            state.status = InstanceStatus.RUNNING
            log.debug("Instance %s: %s → RUNNING (new message)", name, _prev)
        # [1.2.16] 記下來源，供 reply() 判斷回覆後該進哪個狀態
        state.last_inbound_source = source
        try:
            # P1: Backpressure — queue 超過閾值時持久化到 overflow，不丟棄
            if state._msg_queue.qsize() >= 5:
                log.warning("Backpressure: %s queue at %d, persisting to overflow", name, state._msg_queue.qsize())
                self._overflow.store(name, text)
                return True  # stored, will replay later

            state._msg_queue.put_nowait(text)
            state.last_task = text[:60]
            log.debug("Queued message to %s (queue size=%d)", name, state._msg_queue.qsize())

            # [1.5.0] 追蹤 msg_id + TTL
            self._msg_counter += 1
            msg_id = f"msg-{self._msg_counter}"
            if ttl_minutes > 0:
                import time as _t
                expire_at = _t.time() + ttl_minutes * 60
                if name not in self._msg_expiry:
                    self._msg_expiry[name] = {}
                self._msg_expiry[name][msg_id] = expire_at

            return msg_id
        except asyncio.QueueFull:
            log.warning("Message queue full for %s, persisting to overflow", name)
            self._overflow.store(name, text)
            return True

    async def _queue_worker(self, name: str) -> None:
        """依序從佇列取出訊息並發送，確保不交錯。空閒時 replay overflow。"""
        state = self.instances[name]
        while True:
            try:
                # Try to get from in-memory queue first (with timeout to check overflow)
                try:
                    text = await asyncio.wait_for(state._msg_queue.get(), timeout=5.0)
                except asyncio.TimeoutError:
                    # Queue empty — replay overflow if any
                    pending = self._overflow.pending(name, limit=1)
                    if pending:
                        msg_id, text = pending[0]
                        if state.status == InstanceStatus.RUNNING and state.process:
                            async with state._paste_lock:
                                await state.process.send_input(text)
                                state.last_activity = time.time()
                            self._overflow.mark_delivered(msg_id)
                            log.debug("Replayed overflow msg #%d to %s", msg_id, name)
                            await asyncio.sleep(2.0)
                    continue

                if state.status == InstanceStatus.RUNNING and state.process:
                    # [1.5.0] TTL + Cancel 檢查：投遞前確認訊息未過期且未取消
                    import time as _t
                    _skip = False
                    _instance_expiry = self._msg_expiry.get(name, {})
                    # 檢查是否有任何過期的 msg（用 text hash 比對簡化版）
                    for _mid, _exp in list(_instance_expiry.items()):
                        if _t.time() > _exp:
                            log.info("⏰ TTL 過期，丟棄訊息 %s → %s", _mid, name)
                            _instance_expiry.pop(_mid, None)
                            _skip = True
                            break
                    # 檢查取消
                    if not _skip:
                        for _mid in list(self._msg_cancelled):
                            if _mid.startswith("msg-"):
                                # 簡化：取消最近一則
                                self._msg_cancelled.discard(_mid)
                                _skip = True
                                log.info("🚫 已取消訊息 %s → %s", _mid, name)
                                break
                    if _skip:
                        state._msg_queue.task_done()
                        continue

                    async with state._paste_lock:
                        await state.process.send_input(text)
                        state.last_activity = time.time()
                        self._hang_notified.discard(name)
                        self._hang_escalated.discard(name)
                    log.debug("Delivered message to %s", name)
                    # 動態訊息間隔：queue 越滿間隔越長（防止 stdin 壓力）
                    # [2026-07-29] 最小間隔從 1s 增加到 5s，避免連續 LLM 串流 pipe 壓力
                    qsize = state._msg_queue.qsize()
                    delay = 5.0 if qsize <= 2 else min(5.0 + qsize * 0.5, 10.0)
                    await asyncio.sleep(delay)
                state._msg_queue.task_done()
            except asyncio.CancelledError:
                return
            except RuntimeError as e:
                # P2: Pipe broken — 不立即標記 CRASHED，讓 health_loop 確認 process 是否真的死了
                # 只停止 queue worker，不改 status（避免誤判）
                log.warning("Queue worker pipe error for %s: %s (pausing queue, health_loop will decide)", name, e)
                try:
                    state._msg_queue.task_done()
                except ValueError:
                    pass
                # 等待一段時間看 process 是否恢復（可能只是暫時背壓）
                await asyncio.sleep(5)
                # 如果 process 確實死了，health_loop 會設 CRASHED 並重啟
                if not state.process or not state.process.is_alive():
                    log.warning("Queue worker confirmed %s is dead, requeueing message", name)
                    # [2026-07-29] pipe broken 後不丟訊息，存入 overflow 等重啟後 replay
                    try:
                        self._overflow.store(name, text)
                        log.info("Queue worker: stored undelivered msg to overflow for %s", name)
                    except Exception as oe:
                        log.warning("Queue worker: failed to store overflow for %s: %s", name, oe)
                    return
                # Process 還活著但 pipe 斷了 — 這才是真的需要重啟
                if state.process and state.process._pipe_broken:
                    log.warning("Queue worker: %s pipe confirmed broken, marking crashed", name)
                    state.status = InstanceStatus.CRASHED
                    return
                # 否則嘗試繼續（可能是暫時性錯誤）
                log.info("Queue worker: %s process still alive, resuming", name)
                continue
            except Exception as e:
                log.warning("Queue worker error for %s: %s", name, e)
                try:
                    state._msg_queue.task_done()
                except ValueError:
                    pass

    # ── Internal ────────────────────────────────────────────────

    async def _wait_for_ready(self, state: InstanceState, timeout: float | None = None) -> bool:
        timeout = timeout or state.config.startup_timeout_ms / 1000
        deadline = time.time() + timeout
        while time.time() < deadline:
            if not state.process or not state.process.is_alive():
                log.error("Instance %s process died during startup", state.config.name)
                return False

            output = state.process.capture(lines=50)
            log.debug("Instance %s output (%d chars): %s", state.config.name, len(output), output[-200:] if output else "(empty)")

            if KiroBackend.has_startup_dialog(output):
                log.info("Instance %s: dismissing trust dialog", state.config.name)
                try:
                    # Send Down arrow (ESC[B) to move to "Yes, I accept", then Enter
                    await state.process.send_input("\x1b[B")
                    await asyncio.sleep(0.3)
                    await state.process.send_input("")
                except (RuntimeError, OSError):
                    pass
                await asyncio.sleep(2)
                continue

            # [1.2.22] MCP 啟動失敗必須**先於** is_ready 判定 —— 否則會誤判成就緒。
            #
            # 實測（2026-08-13~14，9 次）：fetch server 起不來時，Kiro 等內部 timeout
            # （~20-25s）後**仍會印出讓 READY_PATTERN 命中的東西**。我們據此回報 ready、
            # 把 status 設成 RUNNING、啟動訊息佇列，4-30 秒後進程才以 rc=3 死掉 ——
            # 這段期間送進去的訊息全丟，而狀態看起來一切正常。
            # 那 9 次「22.0/26.0s 慢啟動」其實全是這個，慢只是它的副作用。
            #
            # `--require-mcp-startup` 保證 Kiro 必然退出，所以 return False 不會誤殺
            # 一個還能用的 agent —— 只是把「必死」提早認列為啟動失敗，讓
            # status=CRASHED 與重啟邏輯即刻接手，而不是先假裝就緒。
            # has_mcp_startup_failure 原本只用在 _on_exit 的**事後**歸因（本檔 ~890 行）。
            if KiroBackend.has_mcp_startup_failure(output):
                _prog = KiroBackend.mcp_progress(output)
                _at = f"{_prog[0]}/{_prog[1]}" if _prog else "?"
                log.error(
                    "Instance %s: MCP 啟動失敗（卡在第 %s 個 server）→ 不認列就緒。"
                    " Kiro 帶 --require-mcp-startup，此進程必然退出。",
                    state.config.name, _at,
                )
                _n = f"mcp_startup_failed:{state.config.name}:{_at}"
                if _n not in self.degraded:
                    self.degraded.append(_n)
                return False

            if KiroBackend.is_ready(output):
                # [1.2.14 P4] 啟動耗時與 MCP 載入數觀測。MCP server 由 Kiro 生、不是我們生，
                # 無法逐一計時；能量到的是「spawn → ready」的總時長，而 MCP 初始化是其中
                # 最大的變數（2026-08-11 實測：併發 2 個慢啟動 server 會超時死亡）。
                try:
                    _elapsed = timeout - (deadline - time.time())
                    _prog = KiroBackend.mcp_progress(output)
                    _loaded = _prog[1] if _prog else None
                    _ours = len(state._mcp_declared) if state._mcp_declared else 0
                    log.info("%s 就緒（%.1fs%s）", state.config.name, _elapsed,
                             f"，MCP {_loaded} 個" if _loaded else "")
                    state.last_startup_seconds = round(_elapsed, 1)
                    state.mcp_loaded = _loaded
                    # 逼近 timeout → 標記（慢啟動 MCP 疊加就是下一次 rc=3）
                    #
                    # [1.2.22] 閾值 0.5 → 0.75。2026-08-17 實測 nana 11 個 agent：
                    # 耗時呈**雙峰**，快群 2.0–10.0s、慢群 25.7–30.3s，中間無值，
                    # 且與 MCP 數無關（cto mcp=4 用 30.3s，architect mcp=3 只要 2.0s，
                    # data mcp=2 卻要 28.3s）。60s × 0.5 = 30s 正好切在慢群頂端 ——
                    # 報出來的不是「這個 agent 有問題」，而是「這次剛好越線 0.3s」。
                    # 慢群成因不是 MCP 疊加（假設已被數據推翻），是環境常態上緣。
                    # 提到 0.75（45s）後仍留 15s 告警餘裕，真的逼近才報。
                    # 各次耗時未被丟棄 —— `state.last_startup_seconds` 一直有記。
                    if _elapsed > timeout * 0.75:
                        _n = (f"slow_startup:{state.config.name}:{_elapsed:.0f}s"
                              f"/{timeout:.0f}s" + (f":mcp={_loaded}" if _loaded else ""))
                        if _n not in self.degraded:
                            self.degraded.append(_n)
                    # Kiro 載入數 > 套件管轄數 → 差額來自全域設定，套件預檢管不到
                    if _loaded is not None and _ours and _loaded > _ours + 2:  # +2 = team/fetch
                        _n = f"mcp_external_servers:{state.config.name}:{_loaded - _ours - 2}"
                        if _n not in self.degraded:
                            self.degraded.append(_n)
                except Exception as _oe:  # noqa: BLE001 — 觀測失敗不得影響啟動
                    log.debug("startup observability failed for %s: %s", state.config.name, _oe)
                return True

            err = KiroBackend.detect_error(output)
            if err:
                # 啟動期間允許暫時性錯誤（server_error/network_error），不立即放棄
                # 只有 auth_error/quota 才立即失敗（不可恢復）
                if err[0] in ("auth_error", "quota"):
                    log.error("Instance %s fatal error during startup: %s", state.config.name, err[1])
                    return False
                # 暫時性錯誤：繼續等待直到 timeout
                log.warning("Instance %s transient error during startup: %s (will retry)", state.config.name, err[1])

            await asyncio.sleep(2)
        log.error("Instance %s startup timeout (%.0fs)", state.config.name, timeout)
        return False

    async def _health_loop(self, name: str) -> None:
        """DEPRECATED — replaced by single _health_check_all loop."""
        pass

    def _ensure_health_loop(self) -> None:
        """確保全域 health loop task 在跑（只跑一個）。"""
        if not self._health_loop_task or self._health_loop_task.done():
            self._health_loop_task = asyncio.create_task(self._global_health_loop())

    async def _global_health_loop(self) -> None:
        """單一 health loop — 每 30 秒巡檢所有 instance（GA-team 架構）。"""
        interval = 30  # seconds
        cooldown_seconds = 600  # 達 max_retries 後冷卻 10 分鐘
        _overflow_cleanup_counter = 0

        while True:
            await asyncio.sleep(interval)

            # Periodic overflow cleanup (every ~10 min = 20 iterations)
            _overflow_cleanup_counter += 1
            if _overflow_cleanup_counter >= 20:
                _overflow_cleanup_counter = 0
                try:
                    removed = self._overflow.cleanup(max_age_hours=24)
                    if removed:
                        log.debug("Overflow cleanup: removed %d old entries", removed)
                except Exception:
                    pass

            for name, state in list(self.instances.items()):
                # 跳過未啟動或已暫停
                if state.status in (InstanceStatus.STOPPED, InstanceStatus.PAUSED):
                    continue

                # 冷卻中 — 等時間到再重啟
                cooldown_until = self._cooldown_until.get(name, 0)
                if cooldown_until > 0:
                    if time.time() < cooldown_until:
                        continue
                    # 冷卻結束
                    log.info("🔄 %s 冷卻結束，重置計數重新啟動（冷卻 %d 次，lifetime=%d）",
                             name, state.cooldown_count, state.lifetime_crashes)
                    state.crash_count = 0
                    self._cooldown_until.pop(name, None)
                    self._failure_memory.clear(name)
                    # [1.2.14 P3] **不清 crash_times** —— 清了等於讓迴圈原地復活：
                    # 下一次崩潰又從 1 起算，永遠達不到窗內門檻。保留讓它快速再次升級，
                    # 而窗內記錄會隨時間自然過期（agent 真的穩定下來就自動歸零）。
                    # 同理 cooldown_count 也保留，由 stop_instance（人工介入）才清。
                    _stale = f"crash_loop:{name}:"
                    self.degraded[:] = [d for d in self.degraded if not d.startswith(_stale)]
                    # Soft-pause（rate limit）: process 還活著就不重啟
                    if state.process and state.process.is_alive():
                        log.info("🔄 %s process still alive after cooldown, resuming monitoring", name)
                        continue
                    try:
                        await self.start_instance(name, skip_resume=True)
                    except Exception as e:
                        log.error("Failed to restart %s after cooldown: %s", name, e)
                    continue

                # 崩潰偵測
                if not state.process or not state.process.is_alive():
                    # [1.2.16] IDLE 納入 —— 閒著不代表可以死；crash 偵測必須照常
                    if state.status in (InstanceStatus.RUNNING, InstanceStatus.AWAITING_REPLY,
                                        InstanceStatus.IDLE):
                        # [1.2.11] 崩潰鑑識：退出碼與輸出尾巴在此刻還拿得到 ——
                        # 重啟會建新 ManagedProcess，_output_lines（deque 500）隨舊物件消失，
                        # 過此不錄即永久失去死因（原本只記 pid + crash_count，鑑別力為零）。
                        _pid = state.process.pid if state.process else None
                        _rc = None
                        _tail = ""
                        if state.process:
                            try:
                                _rc = state.process.proc.returncode if state.process.proc else None
                                _tail = state.process.capture(lines=200)
                            except Exception as _fe:  # noqa: BLE001 — 鑑識失敗不得影響重啟
                                log.debug("crash forensics failed for %s: %s", name, _fe)
                        _cause = self.classify_exit(_rc, intentional=state._stopping)
                        # [1.2.14 P4] rc=3 ＝ --require-mcp-startup 的「任一 server 失敗」。
                        # 原本只會記「self-exit(rc=3，多為上游/API 錯誤)」—— 那個歸因是錯的，
                        # 會讓人往 API 方向查。改為從輸出直接認出 MCP 失敗並記下卡在第幾個。
                        _mcp_note = ""
                        if _tail and KiroBackend.has_mcp_startup_failure(_tail):
                            _prog = KiroBackend.mcp_progress(_tail)
                            _at = f"{_prog[0]}/{_prog[1]}" if _prog else "?"
                            _cause = f"mcp-startup-failed（初始化到第 {_at} 個 server 就失敗）"
                            _mcp_note = f"mcp_startup_failed:{name}:{_at}"
                            if _prog:
                                _ours = len(getattr(state, "_mcp_declared", []) or []) or None
                                log.error(
                                    "%s 因 MCP 啟動失敗而退出（%s）。Kiro 載入 %d 個 server，"
                                    "其中套件管轄的只有一部分 —— 差額來自全域設定"
                                    "（~/.kiro/settings/mcp.json），套件的預檢管不到那些。",
                                    name, _at, _prog[1],
                                )
                            if _mcp_note not in self.degraded:
                                self.degraded.append(_mcp_note)
                        state.last_exit_code = _rc
                        state.last_exit_cause = _cause
                        log.warning("Instance %s process died (pid=%s, rc=%s, cause=%s)",
                                    name, _pid, _rc, _cause)
                        if _tail:
                            log.warning("Instance %s last output (tail):\n%s", name, _tail[-1500:])
                            # [1.5.0] 額外記錄開頭（錯誤訊息通常在前面）
                            if len(_tail) > 2000:
                                log.warning("Instance %s first output (head):\n%s", name, _tail[:500])
                        state.status = InstanceStatus.CRASHED
                        state.crash_count += 1
                        # [1.2.14 P3] 窗內計數 —— 不受活動偵測歸零影響，才量得到迴圈
                        _rp = state.config.restart_policy
                        _now = time.time()
                        _win = max(1, _rp.crash_window_minutes) * 60
                        state.lifetime_crashes += 1
                        state.crash_times.append(_now)
                        state.crash_times = [t for t in state.crash_times if _now - t <= _win]
                        _in_window = len(state.crash_times)
                        await get_event_log().record(
                            name, EventType.CRASH,
                            detail=(f"rc={_rc} cause={_cause} crash_count={state.crash_count} "
                                    f"in_window={_in_window}/{_rp.max_crashes_per_window}"
                                    f"({_rp.crash_window_minutes}min) lifetime={state.lifetime_crashes}"
                                    + (f"\n--- last output ---\n{_tail[-1500:]}" if _tail else "")
                                    + (f"\n--- first output ---\n{_tail[:500]}" if _tail and len(_tail) > 2000 else "")),
                        )

                    if state.status == InstanceStatus.CRASHED:
                        _rp = state.config.restart_policy
                        # [1.2.14 P3] 已停止自動重啟 → 不再嘗試，等人工 restart（stop 會清旗標）
                        if state.halted:
                            continue
                        # 窗內崩潰達門檻＝迴圈，直接進冷卻（不等 max_retries ——
                        # 那個門檻在有活動的迴圈裡永遠到不了）
                        _loop = len(state.crash_times) >= _rp.max_crashes_per_window
                        if not _loop and state.crash_count <= _rp.max_retries:
                            delay = min(2 ** state.crash_count, 300)
                            log.info("Restarting %s in %ds (attempt %d)", name, delay, state.crash_count)
                            await asyncio.sleep(delay)
                            try:
                                await self.start_instance(name, skip_resume=True)
                                # [1.1.12 報告C-3] 崩潰重啟以 skip_resume 開新對話 → 前一輪未完成的
                                # 對話遺失，等待方可能還在等。記入 degraded 供維運知悉（送達新訊自動汰換）。
                                _note = f"restart_interrupted:{name}"
                                if _note not in self.degraded:
                                    self.degraded.append(_note)
                                # [1.1.13] 重啟已丟失前一輪對話 → 清掉它作為 sender 的 peer 等待
                                self._pending_reply.pop(name, None)
                                self._pending_reply_nudged.discard(name)
                                # [2026-07-29] 重啟成功後通知使用者（恢復通知）
                                if self.on_instance_recovered:
                                    try:
                                        await self.on_instance_recovered(name)
                                    except Exception as re:
                                        log.debug("on_instance_recovered failed for %s: %s", name, re)
                            except Exception as e:
                                log.error("Failed to restart %s: %s", name, e)
                        else:
                            # [1.2.14 P3] 冷卻遞增 + 超過次數就停手。原本每次都固定冷卻
                            # 10 分鐘且冷卻結束無條件重啟 → 壞掉的 agent 可以無限循環。
                            state.cooldown_count += 1
                            _cd = min(cooldown_seconds * (2 ** (state.cooldown_count - 1)), 3600)
                            _why = (f"崩潰迴圈（{len(state.crash_times)} 次/"
                                    f"{_rp.crash_window_minutes} 分）" if _loop else "連續失敗達上限")
                            if state.cooldown_count > _rp.max_cooldowns:
                                state.halted = True
                                log.error(
                                    "🛑 %s 已冷卻 %d 次仍持續崩潰（%s，lifetime=%d，last rc=%s cause=%s）"
                                    "→ **停止自動重啟**，需人工 restart。",
                                    name, state.cooldown_count - 1, _why,
                                    state.lifetime_crashes, state.last_exit_code, state.last_exit_cause,
                                )
                                _note = f"crash_loop_halted:{name}:lifetime={state.lifetime_crashes}"
                                if _note not in self.degraded:
                                    self.degraded.append(_note)
                                await get_event_log().record(
                                    name, EventType.ERROR,
                                    detail=(f"auto-restart halted after {state.cooldown_count - 1} cooldowns; "
                                            f"{_why}; lifetime={state.lifetime_crashes}; "
                                            f"last rc={state.last_exit_code} cause={state.last_exit_cause}"),
                                )
                            else:
                                log.warning("Instance %s %s → 冷卻 %ds（第 %d 次）",
                                            name, _why, _cd, state.cooldown_count)
                                self._cooldown_until[name] = time.time() + _cd
                                _note = f"crash_loop:{name}:{len(state.crash_times)}/{_rp.crash_window_minutes}min"
                                if _note not in self.degraded:
                                    self.degraded.append(_note)
                                await get_event_log().record(
                                    name, EventType.ERROR,
                                    detail=(f"{_why}, cooldown {_cd}s (#{state.cooldown_count}); "
                                            f"lifetime={state.lifetime_crashes}"),
                                )
                            # 通知使用者（透過 hang callback）
                            if self.on_hang_detected:
                                try:
                                    await self.on_hang_detected(name, -1)  # -1 = cooldown signal
                                except Exception:
                                    pass
                    continue

                # Instance 正在運行 — 做 runtime 檢查
                # 記憶體監控 (RSS)
                if state.process and state.process.pid:
                    try:
                        import psutil
                        proc = psutil.Process(state.process.pid)
                        rss_mb = proc.memory_info().rss / (1024 * 1024)
                        if rss_mb > 800 and name not in self._memory_warned:
                            self._memory_warned.add(name)
                            log.warning("⚠️ %s memory high: %.0f MB", name, rss_mb)
                            await get_event_log().record(
                                name, EventType.ERROR,
                                detail=f"memory high: {rss_mb:.0f} MB",
                            )
                            if self.on_hang_detected:
                                try:
                                    await self.on_hang_detected(name, -2)  # -2 = memory warning
                                except Exception:
                                    pass
                        elif rss_mb <= 600:
                            self._memory_warned.discard(name)
                    except Exception:
                        pass  # psutil not installed or process gone

                # 有新 output → 重置 crash count（確定性活動偵測）
                if state.process:
                    current_count = state.process.output_count
                    last_count = self._last_output_count.get(name, 0)
                    if current_count > last_count:
                        # Agent 有在產出 → 活著且工作中
                        state.last_activity = time.time()
                        state.last_output = time.time()   # [1.4.7] hang 偵測只看這個
                        # [1.5.1] 累計 output 字元數（context 累積偵測用）
                        _new_chars = current_count - last_count
                        state.cumulative_output_chars += _new_chars
                        self._hang_notified.discard(name)
                        self._hang_escalated.discard(name)
                        if state.crash_count > 0:
                            state.crash_count = 0
                    self._last_output_count[name] = current_count

                # Runtime dialog 處理
                output = state.process.capture(lines=30)
                if KiroBackend.has_runtime_dialog(output):
                    log.info("Instance %s: dismissing runtime dialog", name)
                    try:
                        await state.process.send_input("\x1b[B")
                        await asyncio.sleep(0.3)
                        await state.process.send_input("")
                    except (RuntimeError, OSError):
                        pass

                # Error pattern 偵測（只 log，不自動重啟）
                _output_hash = hashlib.md5(output.encode()).hexdigest()
                if _output_hash != self._last_output_hash.get(name):
                    self._last_output_hash[name] = _output_hash
                    error = KiroBackend.detect_error(output)
                    if error:
                        err_type, err_msg = error
                        is_repeating = self._failure_memory.record(name, err_type, err_msg)
                        if is_repeating:
                            summary = self._failure_memory.summary(name)
                            log.warning("Failure pattern: %s", summary)
                            await get_event_log().record(
                                name, EventType.ERROR,
                                detail=f"repeated failure: {summary}",
                            )
                            # Rate limit cooldown: 連續 3 次 rate_limit → 軟暫停 90 秒（不 kill process）
                            if err_type == "rate_limit":
                                consecutive = self._failure_memory.consecutive_count(name)
                                if consecutive >= 3:
                                    cooldown_secs = 90
                                    log.warning("Rate limit cooldown: %s soft-pause %ds (consecutive=%d)", name, cooldown_secs, consecutive)
                                    self._cooldown_until[name] = time.time() + cooldown_secs
                                    # 不改 status、不 kill process — 讓 Kiro CLI 自己等 retry-after
                                    # 只是暫停 health loop 對它的 hang/error 偵測，避免雪崩
                                    await get_event_log().record(
                                        name, EventType.ERROR,
                                        detail=f"rate_limit soft-pause {cooldown_secs}s (consecutive={consecutive})",
                                    )
                                    # 通知使用者（輕量提示）
                                    if self.on_hang_detected:
                                        try:
                                            await self.on_hang_detected(name, -3)  # -3 = rate limit
                                        except Exception:
                                            pass

                # Hang detection — skip if agent is awaiting user reply
                # [1.4.7] 改看 `last_output`（只由「真的產出」更新），不是 `last_activity`
                # —— 後者會被 inbound 刷新，導致「一直收訊息但從不回覆」的 agent
                # 永遠不被判為 hang（實測 ic-agent 9 小時無輸出而帳面全綠）。
                # 尚無任何產出時（剛啟動）退回 last_activity，避免剛起來就被誤判。
                _hang_ref = state.last_output or state.last_activity
                if (
                    self.config.hang_detector.enabled
                    and _hang_ref
                    and name not in self._hang_notified
                    and self._is_active_hour()
                    and state.status not in (InstanceStatus.AWAITING_REPLY,
                                             InstanceStatus.IDLE)  # [1.2.16] 閒著不是掛住
                ):
                    idle_seconds = time.time() - _hang_ref
                    hang_threshold = self.config.hang_detector.timeout_minutes * 60
                    if idle_seconds > hang_threshold:
                        log.warning("Instance %s idle for %.0fs, notifying", name, idle_seconds)
                        self._hang_notified.add(name)
                        await get_event_log().record(name, EventType.HANG, detail=f"idle {idle_seconds:.0f}s")
                        ic = self.config.instances.get(name)
                        if ic and ic.role == "leader":
                            self._notify_managers_override(name, idle_seconds)
                        if self.on_hang_detected:
                            try:
                                await self.on_hang_detected(name, idle_seconds)
                            except Exception as e:
                                log.warning("Hang notification failed for %s: %s", name, e)

                # Escalation — also skip for AWAITING_REPLY (use double timeout as safety net)
                if (
                    self.config.hang_detector.enabled
                    and state.last_activity
                    and name in self._hang_notified
                    and name not in self._hang_escalated
                    and self._is_active_hour()
                    and state.status not in (InstanceStatus.AWAITING_REPLY,
                                             InstanceStatus.IDLE)  # [1.2.16] 閒著不是掛住
                ):
                    idle_seconds = time.time() - state.last_activity
                    escalation_threshold = self.config.hang_detector.escalation_minutes * 60
                    if idle_seconds > escalation_threshold:
                        log.warning("Instance %s escalated (idle %.0fs)", name, idle_seconds)
                        self._hang_escalated.add(name)
                        await get_event_log().record(name, EventType.HANG, detail=f"escalated {idle_seconds:.0f}s")
                        if self.on_hang_escalated:
                            try:
                                await self.on_hang_escalated(name, idle_seconds)
                            except Exception as e:
                                log.warning("Hang escalation failed for %s: %s", name, e)
                        # [1.5.0] auto_restart：escalation 後自動重啟
                        if self.config.hang_detector.auto_restart:
                            log.warning("Auto-restarting hung instance: %s (idle %.0fs)", name, idle_seconds)
                            await get_event_log().record(name, EventType.HANG, detail=f"auto-restart after {idle_seconds:.0f}s")
                            try:
                                await self.restart_instance(name)
                            except Exception as e:
                                log.error("Auto-restart failed for %s: %s", name, e)

                # [1.5.1] 喚醒失敗即重啟：通知後 wake_retry_minutes 仍無 output → 直接重啟
                # （不等 escalation 的完整時間）
                if (
                    self.config.hang_detector.enabled
                    and self.config.hang_detector.auto_restart
                    and name in self._hang_notified
                    and name not in self._hang_escalated
                    and self._is_active_hour()
                    and state.status == InstanceStatus.RUNNING
                ):
                    _wake_ref = state.last_output or state.last_activity
                    _since_notify = time.time() - _wake_ref
                    _wake_threshold = self.config.hang_detector.wake_retry_minutes * 60
                    if _since_notify > _wake_threshold:
                        log.warning("Wake retry failed for %s (%.0fs since notify), auto-restarting", name, _since_notify)
                        self._hang_escalated.add(name)
                        await get_event_log().record(name, EventType.HANG, detail=f"wake-retry-restart after {_since_notify:.0f}s")
                        try:
                            await self.restart_instance(name)
                        except Exception as e:
                            log.error("Wake-retry restart failed for %s: %s", name, e)

                # [1.5.1] 啟動零 output 偵測：啟動超過 N 分鐘但 last_output 仍為 0 → 啟動失敗
                if (
                    self.config.hang_detector.enabled
                    and self.config.hang_detector.auto_restart
                    and state.status == InstanceStatus.RUNNING
                    and state.last_output == 0
                    and state.last_activity > 0
                    and name not in self._hang_notified
                    and self._is_active_hour()
                ):
                    _since_start = time.time() - state.last_activity
                    _startup_threshold = self.config.hang_detector.startup_timeout_minutes * 60
                    if _since_start > _startup_threshold:
                        log.warning("Startup timeout: %s has zero output after %.0fs, restarting", name, _since_start)
                        await get_event_log().record(name, EventType.HANG, detail=f"startup-timeout {_since_start:.0f}s (zero output)")
                        try:
                            await self.restart_instance(name)
                        except Exception as e:
                            log.error("Startup-timeout restart failed for %s: %s", name, e)

                # [1.5.1] context 累積偵測：output chars 超過閾值 → 重啟（清 session）
                if (
                    self.config.hang_detector.context_limit_chars > 0
                    and state.cumulative_output_chars > self.config.hang_detector.context_limit_chars
                    and state.status == InstanceStatus.RUNNING
                ):
                    log.warning("Context limit reached for %s (%d chars), restarting with clean session",
                                name, state.cumulative_output_chars)
                    await get_event_log().record(name, EventType.HANG,
                                                 detail=f"context-reset {state.cumulative_output_chars} chars")
                    state.cumulative_output_chars = 0
                    try:
                        await self.restart_instance(name, skip_resume=True)
                    except Exception as e:
                        log.error("Context-reset restart failed for %s: %s", name, e)

                # ── [1.1.11 Bug2] AWAITING_REPLY 安全網 ───────────────────────
                # 原 escalation 註解宣稱「AWAITING_REPLY 用 double timeout 當安全網」，
                # 但實際整段跳過 → 卡在 awaiting_reply 的等待方（如等待已崩潰 peer 回覆者）
                # 永久不被 hang 偵測。這裡實作該安全網：超長等待（2× escalation）→ 非破壞性
                # 重置為 RUNNING（不動 process），交回 hang 偵測重新接管並通報，解除永久卡住。
                if self._is_active_hour() and self._awaiting_safety_net_due(state, time.time()):
                    awaiting_secs = time.time() - state.last_activity
                    log.warning(
                        "AWAITING_REPLY safety-net: %s stuck %.0fs (>2× escalation) → reset RUNNING",
                        name, awaiting_secs,
                    )
                    state.status = InstanceStatus.RUNNING
                    # 交回下一輪 hang 偵測通報此閒置 instance
                    self._hang_notified.discard(name)
                    self._hang_escalated.discard(name)
                    await get_event_log().record(
                        name, EventType.ERROR,
                        detail=f"awaiting_reply safety-net reset after {awaiting_secs:.0f}s stuck",
                    )

                # ── [1.1.13] peer 回覆逾時 → 主動 nudge 等待方（快速主動層，只戳一次）──
                # 與上方 awaiting 安全網互補：本層 peer_reply_timeout_minutes（預設 15 分）主動戳，
                # 安全網 2× escalation（數小時）兜底。只對走過 send_to_instance 的 peer 等待生效。
                _target = self._peer_reply_due(name, time.time())
                if _target is not None:
                    self._pending_reply_nudged.add(name)
                    _mins = self.config.communication.peer_reply_timeout_minutes
                    log.warning("peer-reply timeout: %s waited >%dm for %s → nudge", name, _mins, _target)
                    self._pending_reply.pop(name, None)
                    await get_event_log().record(
                        name, EventType.HANG,
                        detail=f"peer-reply timeout waiting {_target} (>{_mins}m)",
                    )
                    _nudge = (
                        f"⏱️ 你約 {_mins} 分鐘前請 {_target} 處理的請求仍無回覆，"
                        f"對方可能已重啟或未回應。請重新評估：重試、改派其他 agent，或回報上級。"
                    )
                    try:
                        await self.send_message(name, _nudge, source="system")
                    except Exception as _pe:  # noqa: BLE001
                        log.debug("peer-reply nudge failed for %s: %s", name, _pe)

                # ── [2026-07-31] Idle eviction for non-persistent agents ──────
                # persistent=False + idle > idle_timeout_minutes → auto stop
                ic_evict = self.config.instances.get(name)
                if (
                    ic_evict
                    and not ic_evict.persistent
                    and ic_evict.idle_timeout_minutes > 0
                    and state.status in (InstanceStatus.RUNNING, InstanceStatus.AWAITING_REPLY,
                                         InstanceStatus.IDLE)
                    and state.last_activity
                ):
                    idle_secs = time.time() - state.last_activity
                    if idle_secs > ic_evict.idle_timeout_minutes * 60:
                        log.info(
                            "Idle eviction: stopping %s (idle %.0fs, timeout=%dm)",
                            name, idle_secs, ic_evict.idle_timeout_minutes,
                        )
                        try:
                            await self.stop_instance(name)
                        except Exception as ev_err:
                            log.warning("Idle eviction stop failed for %s: %s", name, ev_err)

                # ── [team-agent 2026-07-30] Decision loop watchdog rules ──────
                # Rules run only when decision_mgr is available (W1 must be live)
                if self.decision_mgr is not None:
                    await self._check_decision_rules(name, state)

    def _record_pending_reply(self, sender: str, target: str) -> None:
        """[1.1.13] 記錄 sender 正在等 target 的回覆（peer→peer）。

        只追 team instance 之間（user/web 來源不記 → 天然區分「等 peer」與「等使用者」）；
        `peer_reply_timeout_minutes<=0` 則停用。只保留最近一筆（已知限制）。
        """
        timeout_min = self.config.communication.peer_reply_timeout_minutes
        if timeout_min <= 0:
            return
        insts = self.config.instances
        if sender not in insts or target not in insts:
            return
        self._pending_reply[sender] = (target, time.time() + timeout_min * 60)
        self._pending_reply_nudged.discard(sender)

    def _mcp_for(self, ic: InstanceConfig) -> dict:
        """[1.2.13 P1] 依 team.yaml 組出該 instance 的 MCP 掛載參數。

        掛載集合 = `(defaults.mcp ∪ instance.mcp) − mcp_exclude`
        —— union 已在 `config._merge_instance` 算完（ADR-006），此處只做過濾與轉換。

        `enabled: False` 的 server 進 `mcp_disabled`（含內建 `fetch`），
        **不記 degraded** —— 刻意停用不是降級（ADR-007）。

        `mcp_prune` 只在 team.yaml 真的有宣告時開啟，否則會把使用者手寫的條目全搬走。

        Author: ark-agent（1.2.13）
        """
        declared = getattr(self.config, "mcp_servers", {}) or {}
        disabled = {n for n, sc in declared.items() if not sc.enabled}
        # mcp_exclude 也算刻意停用（讓 fetch 可被排除）
        disabled |= set(getattr(ic, "mcp_exclude", []) or [])

        servers: dict[str, dict] = {}
        for sname in getattr(ic, "mcp", []) or []:
            sc = declared.get(sname)
            if sc is None or not sc.enabled:
                continue
            servers[sname] = sc.to_entry()

        if servers:
            log.info("MCP 掛載 %s ← %s", ic.name, ", ".join(sorted(servers)))
        return {
            "mcp_servers": servers,
            "mcp_disabled": disabled,
            "mcp_prune": bool(declared),
        }

    @staticmethod
    def classify_exit(rc: int | None, *, intentional: bool = False) -> str:
        """[1.2.11] 由退出碼判斷死因（最便宜的鑑別器）。

        asyncio subprocess 被信號殺時 returncode 是**負數**（-9），非 shell 的 128+N（137）。
        `intentional=True`（我們自己 stop/restart）時不得判成 OOM —— 否則每次 systemctl
        restart 都產生假訊號（2026-08-11 已因類似誤判繞過一次）。

        SIGKILL 只代表「被強制殺」，**不等於 OOM** —— 故僅標「疑似」並提示查 dmesg，不斷言。

        Author: ark-agent
        """
        if rc is None:
            return "unknown(no returncode)"
        if intentional:
            return f"stopped-by-us(rc={rc})"
        if rc == 0:
            return "exited-cleanly(agent 自行結束)"
        if rc > 0:
            return f"self-exit(rc={rc}，程式自行退出，多為上游/API 錯誤)"
        sig = -rc
        named = {9: "SIGKILL", 15: "SIGTERM", 11: "SIGSEGV", 6: "SIGABRT", 2: "SIGINT"}.get(sig, f"SIG{sig}")
        if sig == 9:
            return "killed(SIGKILL，疑似 OOM —— 請查 dmesg / journalctl -k | grep -i oom)"
        if sig == 11:
            return "killed(SIGSEGV，記憶體錯誤)"
        if sig == 15:
            return "killed(SIGTERM，被外部要求終止)"
        return f"killed({named})"

    def _record_dispatch(self, source: str, target: str, summary: str) -> None:
        """[1.2.2 N4] 記錄 source 的最近派工（source→target）。

        只追 team instance 之間；`dispatch_context_ttl_minutes<=0` 停用。只保留最近一筆。
        """
        ttl = self.config.communication.dispatch_context_ttl_minutes
        if ttl <= 0:
            return
        insts = self.config.instances
        if source not in insts or target not in insts:
            return
        self._last_dispatch[source] = (target, (summary or "").strip()[:80], time.time() + ttl * 60)

    def _dispatch_context(self, name: str, now: float) -> str | None:
        """[1.2.2 N4] 若 name 有未逾時的最近派工 → 回一行脈絡並清除（注入一次），否則 None。"""
        rec = self._last_dispatch.get(name)
        if not rec:
            return None
        target, summary, deadline = rec
        if now > deadline:
            self._last_dispatch.pop(name, None)
            return None
        self._last_dispatch.pop(name, None)  # 注入一次即消耗
        return f"（脈絡：你上一步請 {target} 處理「{summary}」）"

    def _peer_reply_due(self, name: str, now: float) -> str | None:
        """[1.1.13] name 等待的 peer 回覆是否已逾時且未戳過 → 回 target，否則 None。純判斷。"""
        pending = self._pending_reply.get(name)
        if not pending or name in self._pending_reply_nudged:
            return None
        target, deadline = pending
        return target if now > deadline else None

    def _awaiting_safety_net_due(self, state, now: float) -> bool:
        """[1.1.11 Bug2] AWAITING_REPLY 是否已超過安全網門檻（2× escalation）。

        用於解除「等待方永久卡在 awaiting_reply」（例如所等待的 peer 已崩潰重啟、
        原任務遺失，回覆永不到來）。純判斷、無副作用，便於單元測試。
        """
        hd = self.config.hang_detector
        if not (hd.enabled and state.status == InstanceStatus.AWAITING_REPLY and state.last_activity):
            return False
        safety_net_secs = hd.escalation_minutes * 60 * 2
        return (now - state.last_activity) > safety_net_secs

    async def _check_decision_rules(self, name: str, state) -> None:
        """Four watchdog rules for the decision loop (design doc §5.2).

        Rule 1 — legacy-question-convert:
          AWAITING_REPLY > 30m + last message contains a question mark
          → LLM-translate to decision-request (source=watchdog)

        Rule 2 — decision-remind:
          Open decision request > 30m with no verdict
          → re-send card to owner

        Rule 3 — decision-escalate:
          Open decision request > 60m with no verdict (replaces old 60min hang notify)
          → escalate to Paddy

        Rule 4 — decider-stuck:
          任一決策者（矩陣推導）in AWAITING_REPLY > 30m
          → direct escalate to owner (prevent second-order deadlock)
        """
        from .decision_manager import _parse_window
        import time as _time

        remind_after = _parse_window(
            self.config.hang_detector.__dict__.get("remind_after", "30m")
            if hasattr(self.config.hang_detector, "__dict__") else "30m"
        )
        escalate_after = _parse_window(
            self.config.hang_detector.__dict__.get("escalate_after", "60m")
            if hasattr(self.config.hang_detector, "__dict__") else "60m"
        )
        decider_stuck = _parse_window("30m")

        from datetime import timedelta
        remind_secs = remind_after.total_seconds()
        escalate_secs = escalate_after.total_seconds()
        decider_stuck_secs = decider_stuck.total_seconds()

        from .daemon import InstanceStatus
        idle_seconds = (_time.time() - state.last_activity) if state.last_activity else 0

        # ── Rule 4: decider-stuck ──────────────────────────────────────
        # Must check first — if the decision-maker itself is stuck, escalate immediately.
        # [ark-agent 2026-08-07] v1.1.3：決策者由矩陣推導，不再寫死 ceo/cto
        # （否則其他團隊的決策者永遠不會被 decider-stuck 偵測）
        if (name in self.decision_mgr._deciders()
                and state.status == InstanceStatus.AWAITING_REPLY
                and idle_seconds > decider_stuck_secs
                and name not in self._legacy_question_flagged):
            self._legacy_question_flagged.add(name)
            log.warning("Decision rule 4 (decider-stuck): %s idle %.0fs → escalate Paddy", name, idle_seconds)
            try:
                # Get last output for context
                last_output = ""
                if state.process:
                    last_output = state.process.capture(lines=5)
                self.decision_mgr.daemon.notify_paddy(
                    f"⚠️ 決策者卡住｜{name} 已 awaiting_reply {int(idle_seconds//60)} 分鐘\n"
                    f"可能在等待某個回覆或自己遇到問題，請查看 Topic。\n"
                    f"末尾輸出：{last_output[-200:] if last_output else '(無)'}",
                    buttons=["查看", f"hang:restart:{name}"],
                )
            except Exception as e:
                log.debug("decider-stuck escalation failed: %s", e)
            return  # don't run other rules for this instance this cycle

        # ── Rule 1: legacy-question-convert ──────────────────────────────
        # Old-habit agents drop questions in Topic without using decision-request.
        if (state.status == InstanceStatus.AWAITING_REPLY
                and idle_seconds > remind_secs
                and name not in self._legacy_question_flagged):
            # Check if last output contains a question mark (heuristic)
            last_output = ""
            if state.process:
                last_output = state.process.capture(lines=10)
            if "?" in last_output or "？" in last_output:
                self._legacy_question_flagged.add(name)
                log.info("Decision rule 1 (legacy-question-convert): %s → attempting translation", name)
                try:
                    feedback = self.decision_mgr.handle_request_message(
                        f"[watchdog 自動轉譯]\n以下是 {name} 在 Topic 發出的問題，"
                        f"請轉為拍板請求：\n\n{last_output[-500:]}",
                        sender=f"{name}:watchdog",
                    )
                    log.info("legacy-question-convert result for %s: %s", name, feedback[:80])
                except Exception as e:
                    log.debug("legacy-question-convert failed for %s: %s", name, e)

        # ── Rule 2 & 3: decision-remind / decision-escalate ──────────────
        # Scan open requests assigned to this instance's domain
        if self.decision_mgr is not None:
            try:
                from datetime import timedelta as _td
                open_reqs = self.decision_mgr.store.open_requests()
                for req in open_reqs:
                    # Only process requests assigned to this instance
                    if req["assigned_to"] != name:
                        continue
                    req_id = req["req_id"]
                    # Parse age of request
                    from datetime import datetime, timezone as _tz
                    created = datetime.fromisoformat(req["created_at"])
                    age_secs = (_time.time()
                                - created.replace(tzinfo=_tz.utc).timestamp()
                                  if created.tzinfo else
                                  _time.time() - created.timestamp())

                    # Rule 3: decision-escalate (> 60m)
                    # First check if domain has ark fallback; if so, escalate to ark
                    # instead of going directly to Paddy.
                    if age_secs > escalate_secs and req_id not in self._hang_escalated:
                        self._hang_escalated.add(req_id)
                        # Check for fallback in authority-matrix
                        fallback = None
                        try:
                            l2 = self.decision_mgr.matrix.get("levels", {}).get("L2", {})
                            domain_cfg = l2.get(req["domain"], {})
                            fallback = domain_cfg.get("fallback")
                        except Exception:
                            pass

                        if fallback:
                            log.warning("Decision rule 3 (decision-escalate): %s age=%.0fs → ark fallback", req_id, age_secs)
                            try:
                                self.decision_mgr.escalate_to_ark(req_id)
                            except Exception as e:
                                log.debug("escalate_to_ark failed: %s", e)
                        else:
                            log.warning("Decision rule 3 (decision-escalate): %s age=%.0fs → Paddy (no fallback)", req_id, age_secs)
                            try:
                                self.decision_mgr.daemon.notify_paddy(
                                    f"⚠️ 拍板請求逾時｜{req_id}\n"
                                    f"來自：{req['requester']}\n"
                                    f"問題：{req['question']}\n"
                                    f"已送 {name} 超過 {int(age_secs//60)} 分鐘未拍板。",
                                    buttons=["查看", "批准A", "批准B"],
                                )
                            except Exception as e:
                                log.debug("decision-escalate notify failed: %s", e)
                    # Rule 2: decision-remind (> 30m, not yet escalated)
                    elif age_secs > remind_secs and req_id not in self._decision_reminded:
                        self._decision_reminded.add(req_id)
                        log.info("Decision rule 2 (decision-remind): %s age=%.0fs → re-send card", req_id, age_secs)
                        try:
                            from .decision_manager import _render_request_card, DecisionRequest
                            import json
                            req_obj = DecisionRequest(
                                req_id=req["req_id"],
                                requester=req["requester"],
                                domain=req["domain"],
                                question=req["question"],
                                options=json.loads(req["options_json"]),
                                blocking=json.loads(req["blocking_json"]),
                                source=req["source"],
                            )
                            card = (f"⏰ 提醒：尚有未拍板請求 {req_id}（已等 {int(age_secs//60)} 分鐘）\n\n"
                                    + _render_request_card(req_obj))
                            self.decision_mgr.daemon.send_message(name, card)
                        except Exception as e:
                            log.debug("decision-remind failed: %s", e)
            except Exception as e:
                log.debug("_check_decision_rules open_requests scan failed: %s", e)

    # ── Helper methods ──────────────────────────────────────────

    # [team-agent 2026-05-15] 抽出 active hours 判斷，消除 hang/escalation 重複
    def _is_active_hour(self) -> bool:
        """Check if current hour is within hang_detector active window."""
        now_hour = _dt.now().hour
        start = self.config.hang_detector.active_start_hour
        end = self.config.hang_detector.active_end_hour
        if start < end:
            return start <= now_hour < end
        # Wrap-around (e.g. 22:00 ~ 06:00)
        return now_hour >= start or now_hour < end

    # [team-agent 2026-05-15] 抽出 manager 通知邏輯
    def _notify_managers_override(self, leader_name: str, idle_seconds: float) -> None:
        """Notify managers when leader is hung (指揮鏈斷裂防護)."""
        manager_names = [
            n for n, c in self.entity_instances().items()
            if c.role == "manager" and not c.private_chat
        ]
        for mgr in manager_names:
            override_msg = (
                f"⚠️ 緊急通知：{leader_name} 已無回應 {idle_seconds/60:.0f} 分鐘。\n"
                f"指揮鏈斷裂防護啟動 — 你現在可以直接使用 delegate_task / send_to_instance 對 worker 下達指令。\n"
                f"待 {leader_name} 恢復後，權限自動收回（回歸正常指揮鏈）。"
            )
            asyncio.create_task(self.send_message(mgr, override_msg, source="system"))
            log.warning("Emergency override granted to %s (leader %s hung)", mgr, leader_name)

    # ── Team operations ────────────────────────────────────────

    def _should_skip_resume(self, name: str, inst_dir: Path) -> bool:
        """Detect if MCP config changed since last run → force clean session.

        Kiro CLI only loads tools/list on new session start, not on --resume.
        If we added/removed MCP tools, the old session won't see them.

        Strategy: compare current mcp.json hash with a stored hash from last run.
        """
        import hashlib
        mcp_path = Path(self.config.instances[name].working_directory) / ".kiro" / "settings" / "mcp.json"
        hash_file = inst_dir / ".mcp_hash"
        # Ensure inst_dir exists before writing hash file
        hash_file.parent.mkdir(parents=True, exist_ok=True)

        if not mcp_path.exists():
            return False

        try:
            current_hash = hashlib.md5(mcp_path.read_bytes()).hexdigest()
        except OSError:
            return False

        if hash_file.exists():
            stored_hash = hash_file.read_text().strip()
            if current_hash != stored_hash:
                log.info("MCP config changed for %s (hash %s → %s), forcing clean session",
                         name, stored_hash[:8], current_hash[:8])
                hash_file.write_text(current_hash)
                return True
            return False
        else:
            # First run — store hash, don't force skip
            hash_file.write_text(current_hash)
            return False

    async def start_all(self) -> dict[str, bool]:
        # [team-agent 2026-05-18] Clean up stale .lock files from previous run
        self._cleanup_stale_locks()

        results: dict[str, bool] = {}
        sem = asyncio.Semaphore(self.config.startup.concurrency)
        stagger = self.config.startup.stagger_delay_ms / 1000

        # Skip instances with auto_start=False (e.g. cto-agent = this workspace itself)
        startable = [n for n, ic in self.config.instances.items() if ic.auto_start]

        async def _start(name: str, idx: int) -> None:
            if idx > 0:
                await asyncio.sleep(stagger * (idx // self.config.startup.concurrency))
            async with sem:
                try:
                    await self.start_instance(name)
                    results[name] = True
                except Exception as e:
                    log.error("Failed to start %s: %s", name, e)
                    results[name] = False

        tasks = [_start(n, i) for i, n in enumerate(startable)]
        await asyncio.gather(*tasks)
        return results

    async def stop_all(self) -> None:
        await asyncio.gather(*(self.stop_instance(n) for n in list(self.instances)))

    def get_status(self) -> list[dict]:
        return [
            {
                "name": name,
                "status": state.status.value,
                "pid": state.process.pid if state.process else None,
                "crash_count": state.crash_count,
                # [1.2.11] 崩潰鑑識：維運不必翻 log 就能看到上次死因
                "last_exit_code": state.last_exit_code,
                "last_exit_cause": state.last_exit_cause,
                # [1.2.14 P3] 迴圈觀測 —— crash_count 會被活動偵測歸零，這三個不會
                "lifetime_crashes": state.lifetime_crashes,
                "crashes_in_window": len(state.crash_times),
                "cooldown_count": state.cooldown_count,
                "halted": state.halted,
                # [1.2.14 P4] 啟動觀測：耗時 + Kiro 實際載入的 MCP server 數
                "last_startup_seconds": state.last_startup_seconds,
                "mcp_loaded": state.mcp_loaded,
                "mcp_declared": len(state._mcp_declared),
                "last_activity": state.last_activity,
                # [1.4.7] 分開暴露 —— 只有這個能回答「它到底多久沒產出東西了」。
                # `last_activity` 會被 inbound 刷新，看它會誤以為 agent 還活躍。
                "last_output": state.last_output,
                "working_directory": state.config.working_directory,
                "model": state.config.model,
            }
            for name, state in self.instances.items()
        ]

    def get_instances_detail(self) -> dict[str, dict]:
        """Detailed instance info combining config and runtime state."""
        result: dict[str, dict] = {}
        for name, state in self.instances.items():
            ic = state.config
            result[name] = {
                "name": name,
                "status": state.status.value,
                "pid": state.process.pid if state.process else None,
                "crash_count": state.crash_count,
                "last_activity": state.last_activity,
                # [1.4.7] 分開暴露 —— 只有這個能回答「它到底多久沒產出東西了」。
                # `last_activity` 會被 inbound 刷新，看它會誤以為 agent 還活躍。
                "last_output": state.last_output,
                "working_directory": ic.working_directory,
                "model": ic.model,
                "description": ic.description,
                "display_name": ic.display_name,
                "role": ic.role,
                "topic_id": ic.topic_id,
                "general_topic": ic.general_topic,
                "private_chat": bool(ic.private_chat),
                "tags": ic.tags,
                "restart_policy": {
                    "max_retries": ic.restart_policy.max_retries,
                    "backoff": ic.restart_policy.backoff,
                    "health_check_interval_ms": ic.restart_policy.health_check_interval_ms,
                },
            }
        return result

    def get_config_summary(self) -> dict:
        """Team config summary without secrets (tokens, user IDs)."""
        return {
            "health_port": self.config.health_port,
            "startup": {
                "concurrency": self.config.startup.concurrency,
                "stagger_delay_ms": self.config.startup.stagger_delay_ms,
            },
            "cost_guard": {
                "daily_limit_usd": self.config.cost_guard.daily_limit_usd,
                "warn_at_percentage": self.config.cost_guard.warn_at_percentage,
                "timezone": self.config.cost_guard.timezone,
            },
            "hang_detector": {
                "enabled": self.config.hang_detector.enabled,
                "timeout_minutes": self.config.hang_detector.timeout_minutes,
            },
            "channel": {
                "general_topic_id": self.config.channel.general_topic_id,
                # Intentionally omit group_id, bot_token_env
            },
            "access": {
                "mode": self.config.access.mode,
                "allowed_user_count": len(self.config.access.allowed_users),
                # Intentionally omit actual user IDs
            },
            "instance_count": len(self.config.instances),
            "instance_names": list(self.config.instances.keys()),
        }
