"""Allow running as: python -m ark_team_agent"""
from .cli import main

main()
