"""Central constants — single source of truth for defaults that appear in
multiple places (api, team_mcp, backend, templates, docker).

When you need to change a default port, bump a version, or adjust a timeout
that cuts across modules, edit it here first. Keep module-local tweaks
(like a test-specific value) inline, not here.
"""
from __future__ import annotations

# ── Service ports ─────────────────────────────────────────────
# Naming convention:
#   1xxxx = internal daemon (core team-agent API, only consumed by team_mcp
#           processes and the webbot observer)
#   3xxx  = user-facing web endpoints (webbot SPA + REST)
#
# Changing these changes defaults only. team.yaml / webbot.yaml / env vars
# can still override at runtime.

DEFAULT_TEAM_AGENT_PORT: int = 13030
"""team-agent FastAPI Daemon API port (consumed by team_mcp + webbot)."""

DEFAULT_WEBBOT_PORT: int = 3030
"""webbot unified service port (REST + WebSocket + embedded SPA)."""
