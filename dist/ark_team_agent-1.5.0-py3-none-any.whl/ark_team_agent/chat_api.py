"""Chat API endpoints — /api/chat/* namespace (Web Chat SSE interface)."""
from __future__ import annotations

import asyncio
import uuid
from typing import Any

from fastapi import APIRouter, Request
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

router = APIRouter(prefix="/api/chat", tags=["chat"])

_daemon = None
_api = None  # DaemonAPI reference for _web_source_map access


def init(daemon, api) -> None:
    global _daemon, _api
    _daemon = daemon
    _api = api


class ChatSendRequest(BaseModel):
    instance: str = "pm-agent"
    message: str


@router.post("/send")
async def chat_send(req: ChatSendRequest) -> dict[str, Any]:
    """Send message to agent with web session tracking. Returns session_id for SSE."""
    session_id = uuid.uuid4().hex[:8]
    source = f"web:{session_id}"

    # Use daemon's send_message + register web source
    ok = await _daemon.send_message(req.instance, req.message)
    if ok:
        _api._web_source_map[req.instance] = session_id

    return {"ok": ok, "session_id": session_id, "instance": req.instance}


@router.get("/stream")
async def chat_stream(request: Request, session_id: str) -> StreamingResponse:
    """SSE stream — pushes agent replies as they arrive in the web reply queue."""
    from ark_team_agent.api import _web_reply_queues, _web_queue

    async def event_generator():
        timeout = 120  # max wait 2 min
        elapsed = 0.0
        interval = 0.3

        # Ensure queue exists
        _web_queue(session_id)

        while elapsed < timeout:
            if await request.is_disconnected():
                break

            queue = _web_reply_queues.get(session_id)
            if queue:
                while queue:
                    item = queue.popleft()
                    text = item.get("text", "") if isinstance(item, dict) else str(item)
                    kind = item.get("kind", "primary") if isinstance(item, dict) else "primary"
                    import json
                    payload = json.dumps({"text": text, "kind": kind})
                    yield f"data: {payload}\n\n"
                # After delivering, signal done
                yield "data: [DONE]\n\n"
                return

            await asyncio.sleep(interval)
            elapsed += interval

        # Timeout
        yield "data: [DONE]\n\n"

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )
