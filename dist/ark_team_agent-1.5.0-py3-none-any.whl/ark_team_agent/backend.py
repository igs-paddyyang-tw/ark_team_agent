"""Kiro CLI backend — build commands, write MCP config, detect ready state."""
from __future__ import annotations

import filecmp
import json
import logging
import os
import re
import shlex
import shutil
import stat
import sys
import tempfile
import time
from dataclasses import dataclass, field
from pathlib import Path

from .session_key import SessionKey

log = logging.getLogger(__name__)

# [1.2.25] 移除 `ctrl-c to start chatting now` 與 `start chatting` 兩個 pattern。
#
# 它們不是就緒訊號，而是 Kiro **MCP 初始化進度行**的尾巴：
#
#     ⠋ 0 of 1 mcp servers initialized. ctrl-c to start chatting now
#
# 這行在 2026-08-17 實測（復現 daemon 的 pipe spawn，非 pty）於 **2.4 秒**就印出，
# 而當下 `k=0` —— **一個 MCP server 都還沒起來**。舊 pattern 兩個都吃中它，
# 於是 daemon 在 MCP 完全未初始化時就判定就緒，把 status 設成 RUNNING、啟動訊息佇列。
# 多數 agent 帳面上的「2.0s 就緒」其實是「MCP 剛開始初始化」。
#
# 實測的真就緒訊號是 `All tools are now trusted`（2.8–2.9s，`--resume` 與否都會印，
# 且在 logo／`Model: auto` 之後）。它已在下列 pattern 中，所以移除進度行不會讓
# 判定失去依據 —— 代價只是多等一輪輪詢（2s）。
#
# ⚠️ 不改成「等 k == m」：實測 Kiro **不等 MCP 完成就進 chat**
# （印 `⚠ 0 of 1 … Servers still loading: - fetch` 後直接進入交談），
# 所以 `k == m` 的進度行可能**永遠不出現**，那種寫法會等到 timeout。
READY_PATTERN = re.compile(
    r"All tools are now trusted|Trust All Tools active|Credits:.*Time:|ask a question or describe a task",
    re.MULTILINE,
)

ERROR_PATTERNS: list[tuple[re.Pattern, str, str]] = [
    # [1.1.12] 收緊為「描述性字樣」，移除裸數字（401/429/500/503）—— 裸數字常出現在 agent 產出的
    # 程式碼/文件（如 [400,401,403]、if code==500），會誤判。真實執行器錯誤都帶描述字。
    (re.compile(r"rate.?limit|too many requests|throttl", re.I), "rate_limit", "Rate limit reached"),
    # [1.1.11] 生成失敗（上游/暫時性）— 置於 auth 之前，避免同 buffer 含 auth 字樣時誤判 auth_error。
    # [1.1.12] 補「failed to receive the next message」（kiro 真實生成失敗訊息的一部分）。
    (re.compile(r"failed to generate|trouble responding|generation failed|unable to generate|"
                r"failed to receive the next message", re.I),
     "generation_failed", "Generation failed (upstream, transient)"),
    (re.compile(r"auth\w*\s*error|unauthorized|authentication failed|invalid credential|expired token",
                re.I), "auth_error", "Authentication error"),
    (re.compile(r"usage limit|insufficient.?credit|credit.*exhaust", re.I), "quota", "Usage limit reached"),
    (re.compile(r"network.?error|ECONNREFUSED|ETIMEDOUT|fetch failed", re.I), "network_error", "Network error"),
    (re.compile(r"internal.?server.?error|service unavailable|bad gateway", re.I), "server_error", "Server error"),
    (re.compile(r"context.?length|token.?limit|too.?long", re.I), "context_overflow", "Context length exceeded"),
]

# [1.2.14 P4] Kiro CLI 自己會印 MCP 初始化進度與失敗，這是**唯一**能看到
# 「Kiro 實際載入幾個 server」的地方 —— 它會合併全域設定
# （`~/.kiro/settings/mcp.json`），數量常大於套件寫進 workspace 的那些。
#   ⠸ 3 of 7 mcp servers initialized. ctrl-c to start chatting now
#   Error: One or more MCP servers failed to start (--require-mcp-startup enabled)
MCP_PROGRESS = re.compile(r"(\d+)\s+of\s+(\d+)\s+mcp servers initialized", re.I)
MCP_STARTUP_FAILED = re.compile(r"One or more MCP servers failed to start", re.I)

STARTUP_DIALOG = re.compile(r"No,?\s*exit", re.MULTILINE)
RUNTIME_DIALOG = re.compile(r"Do you trust the files|Yes,?\s*I accept", re.MULTILINE)

_ANSI_RE = re.compile(r"\x1b\[[0-9;?]*[A-Za-z]|\x1b[=>]?\S*")


def _resolve_binary() -> str:
    # 0. Explicit override via KIRO_CLI_PATH env var (CI / systemd / custom install)
    explicit = os.environ.get("KIRO_CLI_PATH", "")
    if explicit:
        p = Path(explicit)
        if p.exists():
            return str(p)
        log.warning("KIRO_CLI_PATH=%s specified but not found, continuing search", explicit)
    # 1. Check PATH for kiro-cli (NOT "kiro" — that's the IDE)
    path = shutil.which("kiro-cli")
    if path:
        return path
    # 2. Check common install locations
    import platform
    if platform.system() == "Windows":
        candidates = []
        # 優先使用 LOCALAPPDATA 環境變數（可能指向非 C 槽）
        local_app = os.environ.get("LOCALAPPDATA", "")
        if local_app:
            candidates.append(Path(local_app) / "kiro-cli" / "kiro-cli.exe")
        # 檢查 Home 下的標準路徑
        candidates.append(Path.home() / "AppData" / "Local" / "kiro-cli" / "kiro-cli.exe")
        # 檢查 D 槽鏡像路徑（使用者目錄可能在 D 槽）
        home_drive = os.environ.get("HOMEDRIVE", "C:")
        username = os.environ.get("USERNAME", "")
        if username:
            for drive in ("D:", "E:", home_drive):
                candidates.append(Path(f"{drive}\\Users\\{username}\\AppData\\Local\\kiro-cli\\kiro-cli.exe"))
        for candidate in candidates:
            if candidate.exists():
                return str(candidate)
    else:
        for loc in (Path.home() / ".local" / "bin" / "kiro-cli", Path("/usr/local/bin/kiro-cli")):
            if loc.exists():
                return str(loc)
    raise RuntimeError(
        "kiro-cli not found. Install from https://kiro.dev/downloads/ "
        "or add to PATH: %LOCALAPPDATA%\\kiro-cli (Windows)"
    )

@dataclass
class KiroBackendConfig:
    working_directory: str
    instance_name: str
    instance_dir: str
    mcp_servers: dict[str, dict] = field(default_factory=dict)
    # [1.2.13 P1 / ADR-007] 刻意停用的 server 名（含內建 fetch）；停用**不記 degraded**
    mcp_disabled: set[str] = field(default_factory=set)
    # [1.2.13 P2 / ADR-003] True = 未宣告的 server 移至 _disabled（宣告即真相）。
    # 只有 team.yaml 有 mcp_servers 宣告時才啟用 —— 否則會把使用者手寫的全部搬走。
    mcp_prune: bool = False
    skip_permissions: bool = True
    skip_resume: bool = False
    model: str | None = None
    instructions: str | None = None
    # [1.2.19] team.yaml 的 description —— 代號與職責在這裡（instructions 是
    # system_prompt，實測多半為 None）。根目錄 AGENTS.md 的標題與「我是誰」用它。
    description: str = ""
    template: str | None = None  # [v1.1.3 P2-8] 明示 SOUL/BRAIN 範本；None=依 role
    team_doc: dict = field(default_factory=dict)  # [v1.1.3 P1-4] TEAM.md 指揮鏈/協作流程可選文案
    team_api_port: int = field(default_factory=lambda: _default_api_port())
    team_home: str = ""
    role: str = "worker"
    allowed_targets: list[str] = field(default_factory=list)
    kiro_files_policy: "KiroFilesPolicy | None" = None


def _default_api_port() -> int:
    from .constants import DEFAULT_TEAM_AGENT_PORT
    return DEFAULT_TEAM_AGENT_PORT


def _team_md_policy_note(tc_policy: str) -> list[str]:
    """TEAM.md 末尾那段「這個檔會不會自動更新」的說明，依**實際** policy 產出。

    [1.2.22] 原本三個 role 分支各自寫死「由系統每次啟動自動產生（policy=always）」，
    但 `team_md` 的預設是 `once`。對 `once` 的部署來說那句話是反的 ——
    它不但不會每次重啟產生，而且**永遠不會再產生**。

    實測代價：slot 從 fish fork 後，14 份 TEAM.md 全部凍在 fork 當天，
    內容含 team.yaml 從未宣告過的 `cto-agent`（v1.0.5 硬塞時代的遺物）。
    升級套件到 1.2.21 也修不好 —— 而檔案上那句「自動產生」讓人往產生器去查。

    Author: ark-agent（1.2.22）
    """
    if tc_policy == "once":
        return [
            "**注意：** 本檔的 policy 是 `once` —— **只在檔案不存在時寫入，"
            "重啟不會更新**。改了 `team.yaml` 的成員後這裡不會同步，",
            "要它重新產生請先刪除本檔再重啟，或把 "
            "`kiro_files.steering.team_md` 設為 `always`。",
        ]
    if tc_policy == "symlink":
        return [
            "**注意：** 本檔是指向團隊根目錄的 symlink，內容由系統維護。"
            "成員變更一律改 `team.yaml`。",
        ]
    return [
        "**注意：** TEAM.md 由系統每次啟動自動產生（policy=`always`），",
        "手動修改會在下次重啟時被覆寫。成員變更一律改 `team.yaml`。",
    ]


class KiroBackend:
    binary_name = "kiro-cli"

    def __init__(self, instance_dir: str) -> None:
        self.instance_dir = Path(instance_dir)
        self.binary_path = _resolve_binary()

    def build_command(self, cfg: KiroBackendConfig) -> str:
        cmd = f"{self.binary_path} chat --trust-all-tools --legacy-ui --require-mcp-startup"
        if not cfg.skip_resume:
            cmd += " --resume"
        if cfg.model:
            if not re.match(r"^[A-Za-z0-9._:/-]+$", cfg.model):
                raise ValueError(f"Invalid model name: {cfg.model}")
            cmd += f" --model {cfg.model}"
        return cmd

    def write_config(self, cfg: KiroBackendConfig) -> list[str]:
        """寫入 agent 的 .kiro 設定，回傳 degraded 註記清單。

        [1.2.13] 回傳型別由 None 改為 list[str] —— MCP 預檢剔除的項目需要一條
        回報通道，由 `daemon.start_instance` 併入 `self.degraded`（沿用既有
        「不重複 append + 成功後自癒移除」慣例，不新增機制）。

        Author: ark-agent（1.2.13）
        """
        notes = self._write_mcp_config(cfg)
        self._write_steering(cfg)
        return notes

    # ── MCP 預檢工具（1.2.13）────────────────────────────────────────────
    @staticmethod
    def _atomic_write_json(path: Path, obj: dict) -> None:
        """原子寫入 JSON —— 同目錄 tmp 檔 + os.replace。

        非原子寫入被中斷會留下半截 JSON，Kiro 解析失敗即所有 MCP server 啟動失敗，
        搭配 `--require-mcp-startup` 就是 exit 3（agent 完全起不來）。
        tmp 必須建在**同目錄**，跨檔案系統的 rename 不是原子操作。

        Author: ark-agent（1.2.13）
        """
        path.parent.mkdir(parents=True, exist_ok=True)
        fd, tmp = tempfile.mkstemp(dir=str(path.parent), prefix=f"{path.name}.", suffix=".tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump(obj, f, indent=2, ensure_ascii=False)
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp, path)
        except BaseException:
            Path(tmp).unlink(missing_ok=True)
            raise

    @staticmethod
    def _resolve_command(cmd: str) -> str | None:
        """把 command 解析為絕對路徑；解析不到回 None（**不猜**）。

        順序：已是絕對路徑 → 驗證；否則 venv/bin → `shutil.which`（ADR-002）。
        systemd unit 的 PATH 不含 venv/bin，故 venv 內的 console script 必須絕對路徑。
        回 None 而非原值 —— fallback 只會把問題延後成難歸因的 exit 3
        （比照 `paths.find_project_root` 找不到就拋錯、不回猜測值的精神）。

        Author: ark-agent（1.2.13）
        """
        if not cmd:
            return None
        p = Path(cmd)
        if p.is_absolute():
            return str(p) if p.is_file() and os.access(p, os.X_OK) else None
        venv_bin = Path(sys.executable).parent
        for cand in (venv_bin / cmd, venv_bin / f"{cmd}.exe"):
            if cand.is_file() and os.access(cand, os.X_OK):
                return str(cand)
        return shutil.which(cmd)

    _VAR_RE = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)\}")

    @classmethod
    def _expand_env_value(cls, value: str) -> tuple[str | None, str | None]:
        """展開 `${VAR}`，回 `(展開後值, 缺少的變數名)`。

        **不用 `os.path.expandvars`** —— 它對缺值會靜默留下原字串 `${VAR}`，
        那個字串會被當成 token 實值傳給 MCP server（ADR-004 要求明確失敗）。
        缺值時回 `(None, VAR)`，呼叫端據此**不部署**該 server ——
        空 token 會讓 server 啟動成功但所有呼叫失敗，是最難查的靜默失敗。

        Author: ark-agent（1.2.13）
        """
        missing: list[str] = []

        def _sub(m: re.Match) -> str:
            var = m.group(1)
            got = os.environ.get(var)
            if got is None or got == "":
                missing.append(var)
                return ""
            return got

        out = cls._VAR_RE.sub(_sub, value)
        return (None, missing[0]) if missing else (out, None)

    @classmethod
    def _preflight_server(
        cls, instance: str, name: str, entry: dict
    ) -> tuple[dict | None, str | None]:
        """驗證單一 MCP server 條目，回 `(可用條目, degraded 註記)`。

        - `command` 解析為絕對路徑，解析不到即剔除（ADR-002）
        - `args` 中**以 `/` 開頭**者視為檔案路徑並檢查存在（ADR-008）

        **不驗套件名**（如 `npx -y @scope/pkg`）—— 那需查 registry（網路 I/O），
        會讓 agent 啟動依賴外部服務可用性，為預防一種錯誤而引入一整類新的失敗模式。
        該類錯誤在執行期表現為 exit 3，靠 1.2.11 的輸出尾巴已可診斷。

        Author: ark-agent（1.2.13）
        """
        cmd = str(entry.get("command") or "")
        resolved = cls._resolve_command(cmd)
        if not resolved:
            return None, f"mcp_command_not_found:{instance}:{name}:{cmd or '(empty)'}"
        for a in entry.get("args") or []:
            if isinstance(a, str) and a.startswith("/") and not Path(a).exists():
                return None, f"mcp_arg_path_missing:{instance}:{name}:{a}"
        out = dict(entry)
        out["command"] = resolved
        return out, None

    def _write_mcp_config(self, cfg: KiroBackendConfig) -> list[str]:
        """Write .kiro/settings/mcp.json with wrapper scripts (env workaround).

        回傳 degraded 註記清單（見 write_config 的說明）。

        [1.2.13] 加入啟動前預檢：`--require-mcp-startup` 的語意是「任一 server 啟動
        失敗即 exit 3」，故單一壞條目會讓整個 agent 起不來。改為**先剔除通不過預檢者**、
        剩下的才交給 Kiro（ADR-001）。被剔除者搬到 `_disabled` 而非刪除（ADR-003 精神：
        那是使用者設定的最後副本），並記入 degraded。
        """
        notes: list[str] = []
        policy = cfg.kiro_files_policy
        if policy and policy.mcp_json == "skip":
            return notes

        mcp_dir = Path(cfg.working_directory) / ".kiro" / "settings"
        mcp_dir.mkdir(parents=True, exist_ok=True)
        mcp_path = mcp_dir / "mcp.json"

        # once: only write if not exists
        if policy and policy.mcp_json == "once" and mcp_path.exists():
            return notes

        mcp_config: dict = {}
        if mcp_path.exists():
            try:
                mcp_config = json.loads(mcp_path.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError) as exc:
                # [1.2.13] 壞檔先備份再重建 —— 原本靜默忽略，壞檔內容（可能含手工設定）
                # 會在下一行 write 時被覆蓋掉，事後無從查證。
                backup = mcp_path.with_name(f"{mcp_path.name}.corrupt-{int(time.time())}")
                try:
                    shutil.copy2(str(mcp_path), str(backup))
                    log.warning("MCP config 損壞（%s），已備份為 %s", exc, backup.name)
                except OSError:
                    log.warning("MCP config 損壞（%s），備份失敗", exc)
                notes.append(f"mcp_config_corrupt:{cfg.instance_name}")
                mcp_config = {}

        servers: dict = mcp_config.get("mcpServers", {})
        disabled: dict = mcp_config.get("_disabled", {}) or {}

        # ── 宣告式 MCP server（1.2.13 P1）——————————————————————————————
        # cfg.mcp_servers 自 1.2.13 起由 daemon 依 team.yaml 組出（在此之前永遠是空 dict，
        # 整段 wrapper 產生器等於死程式碼 —— 這是「env 傳不進去」查不出原因的根因）。
        declared_keys: set[str] = set()
        for name, entry in cfg.mcp_servers.items():
            instance_key = f"{name}-{cfg.instance_name}"

            # ① env 展開（缺值就不部署，ADR-004）
            raw_env = {**(entry.get("env") or {})}
            all_env: dict[str, str] = {}
            missing_var: str | None = None
            for k, v in raw_env.items():
                expanded, miss = self._expand_env_value(str(v))
                if miss:
                    missing_var = miss
                    break
                all_env[k] = expanded or ""
            if missing_var:
                note = f"mcp_unresolved_env:{cfg.instance_name}:{name}:{missing_var}"
                notes.append(note)
                log.warning(
                    "MCP server %r 的 env 變數 %s 無值 → 不部署（空 token 會造成"
                    "「啟動成功但所有呼叫失敗」的靜默失敗）。%s 仍會啟動。",
                    name, missing_var, cfg.instance_name,
                )
                continue
            all_env["ARK_INSTANCE_NAME"] = cfg.instance_name

            # ②a [1.2.21] env 值若是絕對路徑卻不存在 → 不部署。
            #
            # 原本預檢只看 command 與 args 內的路徑，漏掉「憑證檔路徑寫在 env」的情況。
            # 實測 bigquery 的 GOOGLE_APPLICATION_CREDENTIALS 指向不存在的檔案 ——
            # server 進程起得來、Kiro 也回報成功，但**所有呼叫都會失敗**，
            # 正是 ADR-004 要消滅的靜默失敗（只是當時只防空 token，沒防壞路徑）。
            _bad_path = next(
                (f"{k}={v}" for k, v in all_env.items()
                 if v.startswith("/") and "/" in v[1:] and not Path(v).exists()),
                None,
            )
            if _bad_path:
                note = f"mcp_env_path_missing:{cfg.instance_name}:{name}:{_bad_path}"
                notes.append(note)
                log.warning("MCP server %r 的 env 路徑不存在（%s）→ 不部署。"
                            "server 會起得來但所有呼叫失敗。", name, _bad_path)
                continue

            # ② 預檢（command 絕對路徑 + args 內絕對路徑存在）
            ok_entry, note = self._preflight_server(cfg.instance_name, name, entry)
            if ok_entry is None:
                notes.append(note or f"mcp_command_not_found:{cfg.instance_name}:{name}:?")
                log.warning("MCP server %r 預檢未通過（%s）→ 不部署，%s 仍會啟動。",
                            name, note, cfg.instance_name)
                continue

            # ③ Generate wrapper script (Kiro CLI ignores env in mcp.json)
            wrapper_path = self.instance_dir / f"mcp-wrapper-{name}.sh"
            env_exports = "\n".join(
                f"export {k}='{str(v).replace(chr(39), chr(39) + chr(92) + chr(39) + chr(39))}'"
                for k, v in all_env.items()
            )
            # [1.2.13] 改用 shlex.quote —— 原本 command 完全未引用（含空格的路徑會壞），
            # args 用 json.dumps 只是「看起來像」shell 引用，遇單引號等字元語意不同。
            entry_cmd = shlex.quote(str(ok_entry["command"]))
            entry_args = " ".join(shlex.quote(str(a)) for a in ok_entry.get("args", []))
            wrapper_content = (
                f"#!/bin/bash\n{env_exports}\n"
                f"exec {entry_cmd} {entry_args}\n"
            )
            wrapper_path.write_text(wrapper_content, encoding="utf-8")
            wrapper_path.chmod(stat.S_IRWXU)

            # Preserve existing autoApprove
            existing_entry = servers.get(instance_key, {})
            new_entry = {"command": str(wrapper_path), "args": []}
            if existing_entry.get("autoApprove"):
                new_entry["autoApprove"] = existing_entry["autoApprove"]
            servers[instance_key] = new_entry
            declared_keys.add(instance_key)

        servers.pop("fleet", None)  # Remove stale entry from old kiro_agent

        # Inject team MCP server (cross-agent communication)
        py_path = sys.executable  # Use same Python that runs the daemon (venv-aware)
        # Preserve existing autoApprove if present
        existing_team = servers.get("team", {})
        auto_approve = existing_team.get("autoApprove", [])
        mcp_args = ["-m", "ark_team_agent.team_mcp",
                    "--port", str(cfg.team_api_port or _default_api_port()),
                    "--instance", cfg.instance_name,
                    "--role", cfg.role]
        if cfg.allowed_targets:
            mcp_args.extend(["--allowed-targets", ",".join(cfg.allowed_targets)])
        if cfg.team_home:
            mcp_args.extend(["--home", cfg.team_home])
        servers["team"] = {
            "command": py_path,
            "args": mcp_args,
        }
        if auto_approve:
            servers["team"]["autoApprove"] = auto_approve

        # [2026-07-28] llm-tool MCP 已移除 — Kiro CLI 本身即 LLM，不需額外 LLM tool server
        # 省 10 個進程 + ~300MB RAM + 消除 GEMINI_API_KEY 依賴
        servers.pop("llm-tool", None)

        # Inject fetch MCP server (網頁擷取，僅 AI Team worker/leader)
        # [1.2.13 P1 / ADR-007] `mcp_servers.fetch.enabled: false` 可停用。
        # role 條件本身仍硬編（技術債，spec Q5 記為 P5）—— 本版只加停用鉤子，
        # 不改預設，避免 27 個 instance 需補宣告的破壞性變更。
        if "fetch" in cfg.mcp_disabled:
            servers.pop("fetch", None)
        elif "fetch" in cfg.mcp_servers or f"fetch-{cfg.instance_name}" in servers:
            # 舊檔可能留著硬編那份（`servers` 是從既有檔案讀進來的）——
            # 不移除就會**兩份並存**：實測 11 個 agent 跑出 22 個 fetch 進程，
            # 其中 11 個是壞的那份，還會繼續觸發 rc=3。
            servers.pop("fetch", None)
            # [1.2.21] team.yaml 宣告的 fetch **勝過**下面的硬編預設。
            #
            # ⚠️ 宣告的 server 是寫成 **per-instance key**（`fetch-<instance>`，
            # 因為 wrapper script 是逐 instance 產生的），所以不能只判斷 `"fetch"` ——
            # 那樣永遠是 False，硬編分支照跑，結果是**兩份 fetch 並存**
            # （一份宣告的、一份硬編的），而硬編那份目前是壞的。
            #
            # 原本這個 elif 鏈會無條件覆蓋 servers["fetch"]，導致
            # `mcp_servers.fetch` 的宣告被**靜默忽略** —— 設定寫了沒用，
            # 且沒有任何警示。這是 1.2.13 宣告機制的漏洞。
            #
            # 實際需求：uvx 的 `mcp-server-fetch` 目前壞掉
            # （上游把 `McpError` 改名 `MCPError`，快取版本歪斜），
            # 必須用 `--with 'mcp<1.15'` 釘住舊 SDK 才起得來。
            # 沒有這個覆蓋就無法從設定修，只能改套件程式碼。
            pass
        elif cfg.role in ("worker", "leader", "admin"):
            # 優先用 venv 內的 mcp-server-fetch（相容性佳），fallback 到 uvx
            import sys as _sys
            _venv_bin = Path(_sys.executable).parent
            # Windows: Scripts\mcp-server-fetch.exe / Linux: bin/mcp-server-fetch
            venv_fetch = _venv_bin / ("mcp-server-fetch.exe" if _venv_bin.name == "Scripts" else "mcp-server-fetch")
            if venv_fetch.exists():
                servers["fetch"] = {
                    "command": str(venv_fetch),
                    "args": [],
                }
            else:
                uvx_path = shutil.which("uvx")
                if uvx_path:
                    servers["fetch"] = {
                        "command": uvx_path,
                        "args": ["mcp-server-fetch"],
                    }

        # ── [1.2.13] 啟動前預檢：剔除起不來的 server，保住 agent 可用性（ADR-001）──
        # `team` 不參與剔除 —— 它由 sys.executable 推導（必然有效），且沒有它
        # 等於整個跨 agent 通訊消失，剔除的代價遠大於保留。
        for name in [k for k in servers if k != "team"]:
            ok_entry, note = self._preflight_server(cfg.instance_name, name, servers[name])
            if ok_entry is None:
                bad = dict(servers.pop(name))
                bad["_reason"] = note
                disabled[name] = bad
                notes.append(note or f"mcp_command_not_found:{cfg.instance_name}:{name}:?")
                log.warning(
                    "MCP server %r 預檢未通過（%s）→ 已移至 _disabled，%s 仍會啟動。"
                    " 修正後補回 team.yaml 或 mcp.json 即回歸。",
                    name, note, cfg.instance_name,
                )
            else:
                servers[name] = ok_entry

        # ── [1.2.13 P2 / ADR-003] 宣告即真相：未宣告者移至 _disabled ──────────
        # 只在 team.yaml 有宣告時啟用（mcp_prune），否則會把使用者手寫的全部搬走。
        # 搬移而非刪除 —— Kiro 只讀 mcpServers，_disabled 不影響啟動卻保留可回溯。
        # [1.2.22] 宣告式條目的 key 是 `{server}-{instance}`（wrapper script 逐 instance
        # 產生）。這種 key **必然是本套件寫的**，使用者手寫的一律是裸名 `{server}`。
        _suffix = f"-{cfg.instance_name}"

        def _is_generated(_k: str) -> bool:
            """key 形如 `{server}-{instance}` → 本套件產生的宣告式條目，非使用者手寫。

            Author: ark-agent
            """
            return _k.endswith(_suffix) and len(_k) > len(_suffix)

        if cfg.mcp_prune:
            _keep = declared_keys | {"team", "fetch"}
            for name in [k for k in servers if k not in _keep]:
                moved = dict(servers.pop(name))
                # [1.2.14] 區分「真的沒宣告」與「已由宣告取代」。宣告式條目的 key 是
                # `{server}-{instance}`，升級前手寫的是 `{server}` —— 兩者指同一個 server。
                # 原本一律標「未宣告」且計入常駐提醒，會讓維運以為漏了設定
                # （1.2.13 升級 aiops 後 4 個 agent 各出現一筆假警報）。
                if name in cfg.mcp_servers:
                    moved["_reason"] = f"已由 team.yaml 宣告取代（{name}-{cfg.instance_name}）"
                    log.info("MCP server %r 已由宣告取代 → 舊條目移至 _disabled（%s）",
                             name, cfg.instance_name)
                elif _is_generated(name):
                    # [1.2.22] 第三種情況：**宣告曾存在、後來被移除**。
                    # 1.2.14 只修了「舊手寫 + 新宣告並存」，漏了這個 ——
                    # 判斷式 `name in cfg.mcp_servers` 拿 `bigquery-data-agent`
                    # 去比對宣告名 `bigquery`，永遠是 False，於是套件自己產生的
                    # 殘骸被歸類成「使用者手寫但忘了宣告」，永久計入 degraded。
                    # 報它等於叫維運去補一個他剛刻意移除的宣告。
                    moved["_reason"] = (
                        f"team.yaml 已移除 {name[: -len(_suffix)]} 宣告"
                        "（本套件產生的殘留，可安全刪除）"
                    )
                    log.info("MCP server %r 的宣告已移除 → 殘留條目移至 _disabled（%s）",
                             name, cfg.instance_name)
                else:
                    moved["_reason"] = "未在 team.yaml 的 mcp_servers 宣告"
                    log.info("MCP server %r 未宣告 → 移至 _disabled（%s）", name, cfg.instance_name)
                disabled[name] = moved

        mcp_config["mcpServers"] = servers
        if disabled:
            mcp_config["_disabled"] = disabled
            # [1.2.13 / ADR-005] 常駐提醒，不做 TTL 刪除 —— _disabled 是使用者設定的
            # 最後副本。附行動指引，否則常駐條目會被習慣性忽略。
            # [1.2.14] 只計「真的沒宣告」的 —— 已由宣告取代者不是缺口，報它就是假警報。
            # 掃**整個** _disabled 而非只看本次搬移：條目一旦進了 _disabled 就不會再被搬，
            # 只算本次的話，前一版留下的舊條目會永遠被誤報（1.2.14 首版就是這樣漏的）。
            # 順手把舊條目的 _reason 補正，讓檔案自己也說得清楚。
            for _k, _v in disabled.items():
                if _k in cfg.mcp_servers and "取代" not in str(_v.get("_reason", "")):
                    _v["_reason"] = f"已由 team.yaml 宣告取代（{_k}-{cfg.instance_name}）"
                elif _is_generated(_k) and "殘留" not in str(_v.get("_reason", "")):
                    # [1.2.22] 同上：補正前幾版留下的錯誤 _reason，讓檔案自己說得清楚。
                    _v["_reason"] = (
                        f"team.yaml 已移除 {_k[: -len(_suffix)]} 宣告"
                        "（本套件產生的殘留，可安全刪除）"
                    )
            # [1.2.22] 只計「使用者手寫但沒宣告」的裸名條目。套件自己產生的殘骸
            # （`{server}-{instance}`）不是設定缺口 —— 報它就是永久假警報。
            _undeclared = sorted(
                _k for _k in disabled if _k not in cfg.mcp_servers and not _is_generated(_k)
            )
            if _undeclared:
                notes.append(f"mcp_undeclared_moved:{cfg.instance_name}:{len(_undeclared)}")
                log.info(
                    "%s 有 %d 個 MCP server 未宣告而在 _disabled（%s）—— 補進 team.yaml 的"
                    " mcp_servers 即回歸；本套件不會自動刪除它們。",
                    cfg.instance_name, len(_undeclared), ", ".join(_undeclared),
                )
        else:
            mcp_config.pop("_disabled", None)
        self._atomic_write_json(mcp_path, mcp_config)
        log.debug("Wrote MCP config: %s (%d servers)", mcp_path, len(servers))
        return notes

    def _template_role(self, cfg: KiroBackendConfig) -> str:
        """[v1.1.3 P2-8] 解析 SOUL/BRAIN 範本角色：cfg.template 明示優先，否則依 role 預設。

        不再一律把 worker 套成 coder（researcher/analyst 等可用 team.yaml `template` 指定）。

        Author: ark-agent
        """
        if getattr(cfg, "template", None):
            return cfg.template
        role = getattr(cfg, "role", "worker") or "worker"
        # 🔴 [1.4.5] `leader` 原本映到 **`tech-lead`，而那個範本目錄不存在** ——
        # 而 `leader/` 就躺在旁邊沒人用。
        #
        # 為什麼一直沒被發現：挑選邏輯會**先試 instance 名**
        # （`_instance_key = instance_name.replace("-agent","")`），
        # 所以叫 `leader-agent` 的碰巧命中 `leader/`，映射表根本沒被用到。
        # 但 leader 若叫別的名字（`pm-agent`、`tech-agent`…）→ `pm/` 不存在
        # → 退回 `tech-lead/` 也不存在 → **`soul_content` 是空的，SOUL.md 不會被寫出來**。
        # 沒有錯誤訊息，只是那個 agent 沒有人格檔。
        role_map = {"admin": "admin", "leader": "leader", "worker": "coder", "manager": "admin"}
        return role_map.get(role, "coder")

    def _write_steering(self, cfg: KiroBackendConfig) -> None:
        """Write steering files: symlink agents.md from root, write role file from system_prompt."""
        policy = cfg.kiro_files_policy
        steering_dir = Path(cfg.working_directory) / ".kiro" / "steering"
        steering_dir.mkdir(parents=True, exist_ok=True)

        # agents.md — SKIP: no longer symlink to root (each agent manages its own context)
        # Previously symlinked to root .kiro/steering/agents.md, now handled by TEAM.md

        # SOUL.md from system_prompt (role identity)
        soul_md_policy = policy.soul_md if policy else "once"
        if soul_md_policy != "skip":
            soul_file = steering_dir / "SOUL.md"
            # Determine content: instructions → role template fallback
            soul_content = cfg.instructions
            if not soul_content:
                # Fallback: use bundled template for this role（P2-8：template 明示優先）
                _tpl_role = self._template_role(cfg)
                _tpl_base = Path(__file__).parent / "templates" / "agents"
                _instance_key = cfg.instance_name.replace("-agent", "")
                # Try instance-specific first, then role fallback
                _tpl_soul = _tpl_base / _instance_key / "SOUL.md"
                if not _tpl_soul.exists():
                    _tpl_soul = _tpl_base / _tpl_role / "SOUL.md"
                if _tpl_soul.exists():
                    soul_content = _tpl_soul.read_text(encoding="utf-8")
                    log.info("Using SOUL.md template for %s: %s", cfg.instance_name, _tpl_soul)

            if soul_content:
                if soul_md_policy == "always":
                    soul_file.write_text(soul_content, encoding="utf-8")
                    log.info("Wrote SOUL.md (always): %s", soul_file)
                elif soul_md_policy == "template":
                    self._write_template_file(cfg, soul_file, soul_content, "steering/SOUL.md")
                else:
                    # once (default)
                    if not soul_file.exists():
                        soul_file.write_text(soul_content, encoding="utf-8")
                        log.info("Wrote SOUL.md: %s", soul_file)

        # memory.md (only if not exists)
        memory_md_policy = policy.memory_md if policy else "once"
        if memory_md_policy != "skip":
            memory_file = steering_dir / "MEMORY.md"
            if not memory_file.exists():
                memory_file.write_text(
                    f"# 🧠 {cfg.instance_name} Memory\n\n"
                    "> Agent 工作記憶\n\n---\n\n",
                    encoding="utf-8",
                )

        # BRAIN.md — per-role knowledge template (policy=once)
        brain_file = steering_dir / "BRAIN.md"
        if not brain_file.exists():
            _tpl_role = self._template_role(cfg)  # P2-8：template 明示優先
            # Try instance-specific template first, then role fallback
            _tpl_base = Path(__file__).parent / "templates" / "agents"
            _instance_key = cfg.instance_name.replace("-agent", "")  # e.g. "coder-agent" → "coder"
            _tpl_brain = _tpl_base / _instance_key / "BRAIN.md"
            if not _tpl_brain.exists():
                _tpl_brain = _tpl_base / _tpl_role / "BRAIN.md"
            if _tpl_brain.exists():
                import shutil as _shutil
                _shutil.copy2(_tpl_brain, brain_file)
                log.info("Wrote BRAIN.md from template (%s): %s", _instance_key, brain_file)

        # CODE.md — shared coding standards (policy=once)
        code_file = steering_dir / "CODE.md"
        if not code_file.exists():
            _tpl_code = Path(__file__).parent / "templates" / "steering" / "CODE.md"
            if _tpl_code.exists():
                import shutil as _shutil
                _shutil.copy2(_tpl_code, code_file)
                log.info("Wrote CODE.md from template: %s", code_file)

        # USER.md (shared across all agents, only if not exists)
        user_file = steering_dir / "USER.md"
        if not user_file.exists():
            # Try to copy from team_home root steering
            if cfg.team_home:
                user_source = Path(cfg.team_home) / ".kiro" / "steering" / "USER.md"
                if user_source.exists():
                    import shutil as _shutil
                    _shutil.copy2(user_source, user_file)
                    log.info("Copied USER.md: %s", user_file)
                else:
                    # Try templates bundled with package
                    tpl_user = Path(__file__).parent / "templates" / "steering" / "USER.md"
                    if tpl_user.exists():
                        import shutil as _shutil
                        _shutil.copy2(tpl_user, user_file)
                        log.info("Wrote USER.md from template: %s", user_file)

        # KIRO.md — SKIP deployment to agent directories.
        # Kiro IDE auto-generates this file (幽靈檔), and agents inherit it
        # from the root workspace via symlink/agents.md. Deploying copies causes
        # git noise. If needed, agents get it via fileMatch from root .kiro/steering/.

    def write_team_context(self, cfg: KiroBackendConfig, instances: dict) -> None:
        """Write TEAM.md — filtered by role permissions."""
        policy = cfg.kiro_files_policy
        tc_policy = policy.team_md if policy else "always"
        if tc_policy == "skip":
            return

        steering_dir = Path(cfg.working_directory) / ".kiro" / "steering"
        steering_dir.mkdir(parents=True, exist_ok=True)
        ctx_file = steering_dir / "TEAM.md"

        # once: only write if not exists
        if tc_policy == "once" and ctx_file.exists() and not ctx_file.is_symlink():
            return

        # symlink mode: write shared file to team_home, symlink from agent
        if tc_policy == "symlink" and cfg.team_home:
            wd_resolved = Path(cfg.working_directory).resolve()
            home_resolved = Path(cfg.team_home).resolve()
            if wd_resolved != home_resolved:
                root_ctx = Path(cfg.team_home) / ".kiro" / "steering" / "TEAM.md"
                if root_ctx.exists():
                    # Remove existing file/symlink and create symlink
                    if ctx_file.exists() or ctx_file.is_symlink():
                        ctx_file.unlink()
                    try:
                        ctx_file.symlink_to(root_ctx.resolve())
                        log.info("Symlinked team-context: %s → %s", ctx_file, root_ctx)
                        return
                    except OSError:
                        pass  # Fall through to write directly

        # Remove stale symlink
        if ctx_file.is_symlink():
            ctx_file.unlink()

        # All roles see all instances (全員可見，指揮鏈透明)
        visible = dict(instances)

        lines = ["# 團隊運作規範\n"]
        # [1.2.22] 原本無條件寫死「policy=always」，但 team_md 的**預設是 `once`**
        # （config.py）。這行字讓檔案自己說謊 —— 實測 slot 的 14 份 TEAM.md 全部
        # 凍在 fork 當天，內容含一個 team.yaml 從未宣告過的 cto-agent（v1.0.5
        # 硬塞時代的遺物，隨 fork 帶過來），而診斷者看到「自動產生」四個字，
        # 自然往「產生器壞了」查，不會想到「它根本沒再產生過」。
        # tc_policy 就在手上 —— 印實際值，並在 once 模式下明說它不會更新。
        lines.append(f"> 本文件由系統依 `team.yaml` 產生（`kiro_files.steering.team_md` = `{tc_policy}`）。\n")
        if tc_policy == "once":
            lines.append(
                "> ⚠️ **`once` 模式：本檔只在不存在時寫入，重啟不會更新。**"
                " 改了 `team.yaml` 的成員後這裡**不會**同步 ——"
                " 要它重新產生，先刪除本檔再重啟，或把 policy 設為 `always`。\n"
            )

        # ── Team members table ──
        lines.append("## 團隊成員\n")
        lines.append("| Instance | 角色 | 職責 |")
        lines.append("|----------|------|------|")
        # [ark-agent 2026-08-06] v1.2.0 P0-3 (ADR-001)：移除硬塞 cto-agent。
        # 本體/非啟動 agent 一律由 team.yaml 宣告（auto_start: false），TEAM.md 只忠實反映 config.instances。
        for name, ic in visible.items():
            role_label = getattr(ic, "role", "worker") if hasattr(ic, "role") else "worker"
            desc = ic.description if hasattr(ic, "description") else str(ic)
            lines.append(f"| {name} | {role_label} | {desc or '-'} |")

        # ── Command chain ──
        # [v1.1.3 P1-4] 指揮鏈：team.yaml team_doc.command_chain 提供才寫，否則省略（寧可不寫，不要寫錯）
        _cmd_chain = (cfg.team_doc or {}).get("command_chain")
        if _cmd_chain:
            lines.append("\n## 指揮鏈\n")
            lines.append("```")
            lines.append(str(_cmd_chain))
            lines.append("```\n")
            # [1.3.1] `command_chain` 是**自由文字**，產生器原本完全不驗證它與
            # `instances` 的實際編制是否一致 —— 圖上可以寫一個根本不存在的角色，
            # 或漏掉實際存在的角色，而沒有任何訊號。
            #
            # 實例：nana 的指揮鏈寫「使用者 → admin → manager → leader → worker」，
            # 看起來像單一 admin，實際有**兩個**（ark-agent 與 cto-agent）。
            # 那不是錯誤（同 role 多 instance 是常態），但讀圖的人會誤判。
            #
            # 所以做兩件事：① 圖下方附註實際 role 分佈（agent 讀 TEAM.md 就看到）
            # ② 真正的不一致才發 warning（圖上有的 role 不存在 / 實際有的 role 沒上圖）
            _roles: dict[str, list[str]] = {}
            for _n, _ic in visible.items():
                _roles.setdefault(getattr(_ic, "role", "worker") or "worker", []).append(_n)
            if _roles:
                _dist = "、".join(f"{_r}×{len(_a)}" for _r, _a in sorted(_roles.items()))
                lines.append(f"> 實際編制：{_dist}。"
                             "上圖是角色層級的簡化 —— 同一角色可能有多個 instance，"
                             "完整成員見上方表格。\n")
            _chain_text = str(_cmd_chain)
            _ghost = [_r for _r in ("admin", "manager", "leader", "worker")
                      if _r in _chain_text and _r not in _roles]
            _unlisted = [_r for _r in _roles if _r not in _chain_text]
            if _ghost:
                log.warning(
                    "team_doc.command_chain 提到的角色 %s 在 team.yaml 的 instances 中"
                    "**不存在**（%s）—— 指揮鏈圖與實際編制不符，讀圖的 agent 會誤判。",
                    _ghost, cfg.instance_name,
                )
            if _unlisted:
                log.warning(
                    "team.yaml 有角色 %s 但 team_doc.command_chain 沒提到（%s）—— "
                    "那些 agent 在指揮鏈圖上是隱形的。",
                    _unlisted, cfg.instance_name,
                )

        # ── Communication rules (dynamic, based on actual system permissions) ──
        lines.append("## 跨 Agent 通訊規則\n")
        if cfg.role == "admin":
            lines.append("你是 admin，可以發訊息給所有人，無限制。\n")
        elif cfg.role == "leader":
            lines.append("你是 leader，可以派工給所有 worker，重大議題升級 manager。\n")
        elif cfg.role == "manager":
            lines.append("你是 manager，對 leader 下達方針，不直接指揮 worker。\n")
        else:
            lines.append("你是 worker，可以發訊息給 leader 和其他 worker（不可直接發給 admin）。\n")
            lines.append("**建議**：重要協調走 leader，避免資訊碎片化。\n")

        lines.append("| 角色 | 可發給 | 可用工具 |")
        lines.append("|------|--------|---------|")
        lines.append("| admin | 所有人 | send_to_instance / delegate_task / broadcast_all |")
        lines.append("| leader | 所有人（除 admin） | send_to_instance / delegate_task / broadcast_all |")
        lines.append("| manager | 所有 group 成員 | send_to_instance（無 create_task） |")
        lines.append("| worker | leader + 其他 worker | send_to_instance（無 delegate_task / broadcast_all） |")

        # ── MCP tools table (reflects actual _get_tools logic) ──
        lines.append("\n## MCP 工具（你可直接呼叫）\n")
        lines.append("| 工具 | 用途 |")
        lines.append("|------|------|")
        lines.append("| `reply(text, kind)` | 回覆使用者（Telegram），唯一出口 |")
        lines.append("| `query_team_status()` | 查詢團隊狀態 |")
        lines.append("| `log_to_leader(text)` | 私下回報上級（錯誤/過程） |")
        lines.append("| `list_tasks(status)` | 列出任務板 |")
        lines.append("| `update_task(task_id, status, note)` | 更新任務狀態 |")
        lines.append("| `record_spend(amount_usd, note)` | 記錄成本消費 |")
        lines.append("| `send_to_instance(instance, msg)` | 發訊息給指定 agent |")
        if cfg.role in ("leader", "admin"):
            lines.append("| `delegate_task(instance, task)` | 委派任務（加格式前綴） |")
            lines.append("| `create_task(title, assignee, ...)` | 建立任務到 board.json |")
        if cfg.role in ("leader", "admin", "manager"):
            lines.append("| `broadcast_all(message)` | 廣播訊息給所有 agent |")
        lines.append("| `wiki_query(query, scope)` | 搜尋知識庫 |")
        if cfg.role in ("leader", "admin"):
            lines.append("| `wiki_ingest(source_path, scope)` | 匯入知識 |")

        # [v1.1.3 P1-4] 協作流程：team.yaml team_doc.workflow 提供才寫，否則省略
        _workflow = (cfg.team_doc or {}).get("workflow")
        if _workflow:
            lines.append("\n## 協作流程\n")
            lines.append("```")
            lines.append(str(_workflow))
            lines.append("```\n")

        # ── Team membership management ──
        lines.append("\n## 成員管理規範\n")
        if cfg.role in ("manager", "admin"):
            lines.append("你有權調整團隊成員組成。變更流程：\n")
            lines.append("1. 修改 `team.yaml` 的 `instances` 區塊（新增/移除/改 role）")
            lines.append("2. 重啟服務（寫 restart.flag）讓 TEAM.md 重新產生")
            lines.append("3. 所有 agent 下次啟動時會拿到更新後的成員表\n")
            lines.extend(_team_md_policy_note(tc_policy))
        elif cfg.role == "leader":
            lines.append("你有權建議調整團隊成員。變更流程：\n")
            lines.append("1. 修改 `team.yaml` 的 `instances` 區塊（新增/移除/改 role）")
            lines.append("2. 重啟服務讓 TEAM.md 重新產生")
            lines.append("3. 所有 agent 下次啟動時會拿到更新後的成員表\n")
            lines.extend(_team_md_policy_note(tc_policy))
        else:
            lines.extend(_team_md_policy_note(tc_policy))
            lines.append("如需調整成員，請向 leader 提出。")

        ctx_file.write_text("\n".join(lines), encoding="utf-8")

        # ── AGENTS.md — REMOVED: no longer synced, replaced by TEAM.md ──

    @staticmethod
    def _default_agents_md(name: str) -> str:
        return (
            f"# Agent: {name}\n\n"
            "## 核心職責\n\n"
            "<!-- 在此定義此 Agent 的專精領域與職責範圍 -->\n\n"
            "## 關鍵原則\n\n"
            "1. 安全優先\n2. 效能導向\n3. 可靠性\n4. 可觀測性\n\n"
            "## Memory 規範\n\n"
            "每完成一個開發段落，必須將以下資訊記錄到 `memory.md`：\n\n"
            "```markdown\n"
            "## [日期] — [功能名稱]\n"
            "- ✅ 完成：做了什麼\n"
            "- 💡 決策：為什麼這樣做\n"
            "- 📋 待辦：下一步\n"
            "- ⚠️ 已知問題：待解決的問題\n"
            "```\n"
        )

    # ── Template mode (.meta.json tracking) ───────────────────────

    def _get_meta_path(self, cfg: KiroBackendConfig) -> Path:
        return Path(cfg.working_directory) / ".kiro" / ".meta.json"

    def _load_meta(self, cfg: KiroBackendConfig) -> dict:
        meta_path = self._get_meta_path(cfg)
        if meta_path.exists():
            try:
                return json.loads(meta_path.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                pass
        return {"version": "1.0", "files": {}}

    def _save_meta(self, cfg: KiroBackendConfig, meta: dict) -> None:
        meta_path = self._get_meta_path(cfg)
        meta_path.parent.mkdir(parents=True, exist_ok=True)
        meta_path.write_text(json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8")

    @staticmethod
    def _hash_content(content: str) -> str:
        import hashlib
        return "sha256:" + hashlib.sha256(content.encode("utf-8")).hexdigest()[:16]

    def _write_template_file(self, cfg: KiroBackendConfig, target: Path, content: str, rel_key: str) -> None:
        """Write file using template mode: track hash, warn on update if user modified."""
        import datetime
        meta = self._load_meta(cfg)
        files = meta.setdefault("files", {})
        entry = files.get(rel_key, {})
        content_hash = self._hash_content(content)

        if not target.exists():
            # First time: write + record
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(content, encoding="utf-8")
            files[rel_key] = {
                "template_hash": content_hash,
                "written_at": datetime.datetime.now().isoformat(),
                "user_modified": False,
            }
            self._save_meta(cfg, meta)
            log.info("Wrote template file: %s", target)
        else:
            # File exists — check if user modified
            current_hash = self._hash_content(target.read_text(encoding="utf-8"))
            old_template_hash = entry.get("template_hash", "")

            if current_hash != old_template_hash:
                entry["user_modified"] = True

            if content_hash != old_template_hash:
                # Template has been updated
                if entry.get("user_modified"):
                    log.warning(
                        "⚠️ %s 有新版模板可用，用 `ark-team-agent team kiro sync` 同步",
                        rel_key,
                    )
                else:
                    # User hasn't modified — safe to overwrite
                    target.write_text(content, encoding="utf-8")
                    entry["template_hash"] = content_hash
                    entry["written_at"] = datetime.datetime.now().isoformat()
                    entry["user_modified"] = False
                    log.info("Updated template file: %s", target)
            files[rel_key] = entry
            self._save_meta(cfg, meta)

    # ── Agent files (agents.json + prompts + skills) ────────────

    def write_agent_files(self, cfg: KiroBackendConfig) -> None:
        """Write agent identity files and prompts based on kiro_files policy."""
        policy = cfg.kiro_files_policy
        if not policy:
            return

        self._write_agent_json(cfg, policy)
        self._write_prompts(cfg, policy)
        self._write_skills(cfg, policy)
        self._ensure_workspace_dirs(cfg)
        self._write_root_agents_md(cfg, policy)

    # ── 工作區根目錄（1.2.19）────────────────────────────────────────────
    #: 每個 agent 工作區都該有的目錄與用途（順序即導覽檔的呈現順序）
    _WORKSPACE_DIRS: tuple[tuple[str, str], ...] = (
        (".kiro", "Kiro 設定：steering（規範）/ skills / prompts / settings / agents"),
        ("knowledge", "知識庫：wiki（唯讀，ingest 產出）/ raw（只新增）/ index / log"),
        ("memory", "工作記憶：memory.md（長期）/ daily/（每日）/ journal.md"),
        ("docs", "文件：specs / designs / plans / reports"),
        ("scripts", "可重用腳本、工具、POC"),
        ("artifacts", "交付物：charts / reports / exports"),
        ("output", "臨時產物，可清理（不入 git）"),
    )

    def _ensure_workspace_dirs(self, cfg: KiroBackendConfig) -> None:
        """[1.2.19] 補齊工作區目錄 —— 導覽檔說有的目錄就該存在。

        實測 10 個 agent 裡有 4 個缺 `artifacts/` 與 `scripts/`（結構不一致）。
        只建目錄與 `.gitkeep`，**不動既有內容**。

        Author: ark-agent（1.2.19）
        """
        root = Path(cfg.working_directory)
        # [1.2.20] 衍生 session 不建立 knowledge/ —— 跨 session 共用一律走
        # MCP wiki_query，不靠檔案。建了空目錄反而會誘導 agent 往裡面寫。
        _is_session = SessionKey.is_session(cfg.instance_name)
        for name, _desc in self._WORKSPACE_DIRS:
            if name == ".kiro":
                continue          # .kiro 由各 write_* 自行建立
            if _is_session and name == "knowledge":
                continue
            d = root / name
            if not d.exists():
                try:
                    d.mkdir(parents=True, exist_ok=True)
                    (d / ".gitkeep").touch()
                    log.info("建立工作區目錄 %s/%s", cfg.instance_name, name)
                except OSError as e:
                    log.warning("無法建立 %s: %s", d, e)

    def _write_root_agents_md(self, cfg: KiroBackendConfig, policy) -> None:
        """[1.2.19] 在 **working_directory 根目錄**寫 AGENTS.md（給非 Kiro agent 看）。

        Kiro 自動載入 `.kiro/steering/*.md`，其他工具不會 —— 它們進到目錄後
        沒有任何入口。這份檔案就是那個入口：東西在哪、規範是什麼、什麼不能做。

        **本檔是規範主文件**（Paddy 2026-08-14 定調），其他工具的專屬檔應直接參考它。
        預設 policy `once` —— agent 可自行補充工作區筆記而不被覆寫。

        Author: ark-agent（1.2.19）
        """
        if getattr(policy, "agents_md", "once") == "skip":
            return
        target = Path(cfg.working_directory) / "AGENTS.md"
        if policy.agents_md == "once" and target.exists():
            return

        tpl = Path(__file__).parent / "templates" / "AGENTS-root.md"
        if not tpl.exists():
            log.warning("AGENTS-root.md 範本不存在，跳過")
            return

        # 目錄樹只列**實際存在**的 —— 導覽檔不該指向不存在的路徑
        root = Path(cfg.working_directory)
        lines = ["```"]
        for name, desc in self._WORKSPACE_DIRS:
            if (root / name).exists():
                lines.append(f"{name + '/':14} {desc}")
        lines.append("```")

        # 代號取自 description 的前綴（如「🏴‍☠️ 魯夫（技術長） — …」→「🏴‍☠️ 魯夫」）——
        # backend 拿不到 telegram 的 _CODENAMES，而 description 本來就帶代號
        # description 優先 —— 代號在那裡；instructions（system_prompt）多半是 None
        _src_text = (getattr(cfg, "description", "") or cfg.instructions or "")
        _desc_line = (_src_text.strip().splitlines() or [""])[0]
        _codename = cfg.instance_name
        if _desc_line:
            _head = _desc_line.split("（")[0].split(" — ")[0].split(" - ")[0].strip()
            if _head and len(_head) <= 20:
                _codename = _head

        body = tpl.read_text(encoding="utf-8")
        for key, val in (
            ("{codename}", _codename),
            ("{instance_name}", cfg.instance_name),
            ("{description}", _desc_line or "（team.yaml 未設 description）"),
            ("{role}", cfg.role),
            ("{working_directory}", cfg.working_directory),
            ("{directory_tree}", "\n".join(lines)),
        ):
            body = body.replace(key, val)
        # 範本中的 `{{...}}` 是刻意保留給使用者看的佔位符（如回報格式），還原為單層
        body = body.replace("{{", "{").replace("}}", "}")
        try:
            target.write_text(body, encoding="utf-8")
            log.info("寫入 %s", target)
        except OSError as e:
            log.warning("無法寫入 %s: %s", target, e)

    def _write_agent_json(self, cfg: KiroBackendConfig, policy) -> None:
        """Write .kiro/agents/{name}.json based on policy."""
        if policy.agent_json == "skip":
            return

        agents_dir = Path(cfg.working_directory) / ".kiro" / "agents"
        agents_dir.mkdir(parents=True, exist_ok=True)
        agent_file = agents_dir / f"{cfg.instance_name}.json"

        # Look for source in team_home
        source_file: Path | None = None
        if cfg.team_home:
            # Check {team_home}/{instance}/.kiro/agents/{name}.json
            candidate = Path(cfg.team_home) / cfg.instance_name / ".kiro" / "agents" / f"{cfg.instance_name}.json"
            if candidate.exists():
                source_file = candidate
            else:
                # Check {team_home}/.kiro/agents-json/{name}.json (legacy)
                role = cfg.instance_name.replace("-agent", "")
                candidate2 = Path(cfg.team_home) / ".kiro" / "agents-json" / f"{role}.json"
                if candidate2.exists():
                    source_file = candidate2

        # Fallback: bundled templates/agents/{role}/agent.json
        if not source_file:
            role = cfg.instance_name.replace("-agent", "")
            # Map common role names to template directories
            # [claude-code 2026-08-05] 去重：leader/tester 目錄化；移除 leader→tech-lead，
            # get(role, role) 使 leader 自動 fallback 到 templates/agents/leader/
            role_map = {"dev": "coder", "qa": "tester"}
            tpl_name = role_map.get(role, role)
            candidate3 = Path(__file__).parent / "templates" / "agents" / tpl_name / "agent.json"
            if candidate3.exists():
                source_file = candidate3

        if source_file:
            content = source_file.read_text(encoding="utf-8")
        else:
            # [ark-agent 2026-08-06] v1.1.1 P2-9：範本缺 agent.json → 用 InstanceConfig 動態生成
            # （KiroBackendConfig 無 description 欄位，以 instructions fallback）
            content = json.dumps({
                "name": cfg.instance_name,
                "description": cfg.instructions or cfg.instance_name,
                "prompt": "file://../../.kiro/steering/SOUL.md",
                "model": cfg.model or "auto",
                "tools": ["*"],
                "allowedTools": ["*"],
                "resources": [
                    "file://../../.kiro/steering/**/*.md",
                    "skill://.kiro/skills/**/SKILL.md",
                ],
            }, ensure_ascii=False, indent=2)
            log.info("Generated agent JSON dynamically for %s (no template source)", cfg.instance_name)

        if policy.agent_json == "always":
            agent_file.write_text(content, encoding="utf-8")
            log.info("Wrote agent JSON (always): %s", agent_file)
        elif policy.agent_json == "template":
            self._write_template_file(cfg, agent_file, content, f"agents/{cfg.instance_name}.json")
        else:
            # once (default)
            if not agent_file.exists():
                agent_file.write_text(content, encoding="utf-8")
                log.info("Wrote agent JSON: %s", agent_file)

    def _write_prompts(self, cfg: KiroBackendConfig, policy) -> None:
        """Write .kiro/prompts/*.md based on policy."""
        if policy.prompts_policy == "skip":
            return

        # Determine source directory
        source_dir: Path | None = None
        if policy.prompts_source:
            source_dir = Path(policy.prompts_source)
            if not source_dir.is_absolute() and cfg.team_home:
                source_dir = Path(cfg.team_home) / source_dir
        elif cfg.team_home:
            source_dir = Path(cfg.team_home) / "prompts"

        if not source_dir or not source_dir.exists():
            return

        prompts_dir = Path(cfg.working_directory) / ".kiro" / "prompts"
        prompts_dir.mkdir(parents=True, exist_ok=True)

        for src_file in source_dir.glob("*.md"):
            dst_file = prompts_dir / src_file.name
            content = src_file.read_text(encoding="utf-8")

            if policy.prompts_policy == "always":
                dst_file.write_text(content, encoding="utf-8")
            elif policy.prompts_policy == "template":
                self._write_template_file(cfg, dst_file, content, f"prompts/{src_file.name}")
            else:
                # once (default)
                if not dst_file.exists():
                    dst_file.write_text(content, encoding="utf-8")

    @staticmethod
    def _sync_skill_dir(src: Path, dst: Path) -> int:
        """逐檔比對並覆寫有差異的檔案，回傳更新檔數。

        只「新增或覆寫」，**不刪除** dst 多出的檔案 —— agent 可能在 skill 目錄下
        放自己的產出（evals、references），沿用 rsync --delete 語意會誤刪。

        Author: ark-agent（1.2.12）
        """
        updated = 0
        for f in src.rglob("*"):
            if f.is_dir():
                continue
            target = dst / f.relative_to(src)
            # shallow=False：比內容而非 stat，避免 copytree 保留 mtime 後看似相同
            if target.exists() and filecmp.cmp(str(f), str(target), shallow=False):
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(str(f), str(target))
            updated += 1
        return updated

    def _write_skills(self, cfg: KiroBackendConfig, policy) -> None:
        """Write .kiro/skills/ based on policy. All agents get bundled skills.

        policy.skills_policy：
          - ``skip`` 不部署
          - ``once``（預設）只在 skill 目錄不存在時複製 —— 內容更新不會下發
          - ``sync`` 逐檔比對內容，有差異才覆寫（不刪除 agent 自行新增的檔案）
        """
        if policy.skills_policy == "skip":
            return
        # 打錯字（如 snyc）不能靜默退化成 once —— 那會讓人以為同步生效了卻沒有
        if policy.skills_policy not in ("once", "sync"):
            log.warning(
                "Unknown skills policy %r for %s — falling back to 'once' "
                "(valid: once | sync | skip)",
                policy.skills_policy, cfg.instance_name,
            )
        sync = policy.skills_policy == "sync"

        skills_dir = Path(cfg.working_directory) / ".kiro" / "skills"
        skills_dir.mkdir(parents=True, exist_ok=True)

        # Source 1: bundled templates/skills/ (all agents get these)
        bundled_skills = Path(__file__).parent / "templates" / "skills"
        if bundled_skills.exists():
            for skill_src in bundled_skills.iterdir():
                # 只認目錄 —— templates/skills/README.md 是套件說明，不是 skill
                if not skill_src.is_dir():
                    continue
                skill_dst = skills_dir / skill_src.name
                if not skill_dst.exists():
                    shutil.copytree(str(skill_src), str(skill_dst))
                    log.info("Deployed skill: %s → %s", skill_src.name, skill_dst)
                elif sync and (n := self._sync_skill_dir(skill_src, skill_dst)):
                    log.info("Synced skill: %s (%d file(s) updated)", skill_src.name, n)

        # Source 2: custom skills from team_home (if specified)
        source_dir: Path | None = None
        if policy.skills_source:
            source_dir = Path(policy.skills_source)
            if not source_dir.is_absolute() and cfg.team_home:
                source_dir = Path(cfg.team_home) / source_dir
        elif cfg.team_home:
            source_dir = Path(cfg.team_home) / cfg.instance_name / ".kiro" / "skills"

        if source_dir and source_dir.exists():
            for skill_src in source_dir.iterdir():
                if not skill_src.is_dir():
                    continue
                skill_dst = skills_dir / skill_src.name
                if not skill_dst.exists():
                    shutil.copytree(str(skill_src), str(skill_dst))
                    log.info("Copied custom skill: %s", skill_dst)
                elif sync and (n := self._sync_skill_dir(skill_src, skill_dst)):
                    log.info("Synced custom skill: %s (%d file(s) updated)", skill_src.name, n)

    def _mount_shared_knowledge(self, cfg: KiroBackendConfig) -> None:
        """Mount shared knowledge — DISABLED (knowledge/shared/ deprecated since v0.12).

        Shared knowledge now lives only at {team_home}/knowledge/shared/ and is
        accessed via wiki_query MCP tool. No per-agent symlink/copy needed.
        """
        # [team-agent 2026-05-18] Disabled to prevent 幽靈目錄 復活
        return

    def cleanup(self, cfg: KiroBackendConfig) -> None:
        """Cleanup on stop. No longer clears mcp.json — write_config() overwrites on next start."""
        # [2026-06-15] 不再清空 mcp.json，保留上次有效設定
        # 原因：cleanup 清空後 IDE 看到空檔、手動測試失敗、git noise
        # write_config (policy=always) 下次啟動時會用最新值覆寫
        pass

    @staticmethod
    def _strip(output: str) -> str:
        return _ANSI_RE.sub("", output)

    @staticmethod
    def is_ready(output: str) -> bool:
        return bool(READY_PATTERN.search(KiroBackend._strip(output)))

    @staticmethod
    def mcp_progress(output: str) -> tuple[int, int] | None:
        """[1.2.14 P4] 解析 Kiro 的「k of m mcp servers initialized」，回 `(k, m)`。

        取**最後一筆**（進度會一行一行遞增）。`m` 是 Kiro 實際載入的 server 總數 ——
        它會合併全域 `~/.kiro/settings/mcp.json`，所以常大於套件寫進 workspace 的數量。
        這是唯一能從外部看到那個差距的訊號。

        Author: ark-agent（1.2.14）
        """
        hits = MCP_PROGRESS.findall(KiroBackend._strip(output))
        if not hits:
            return None
        k, m = hits[-1]
        return int(k), int(m)

    @staticmethod
    def has_mcp_startup_failure(output: str) -> bool:
        """[1.2.14 P4] 輸出是否含 Kiro 的 MCP 啟動失敗訊息（對應 exit code 3）。"""
        return bool(MCP_STARTUP_FAILED.search(KiroBackend._strip(output)))

    @staticmethod
    def _strip_code_regions(text: str) -> str:
        """[1.1.12] 移除 agent 產出的程式碼/差異/工具區塊，避免其內含的錯誤字樣被
        ERROR_PATTERNS 誤判為執行器錯誤（報告 A）。只留敘述性文字供錯誤偵測掃描。"""
        t = re.sub(r"```.*?```", " ", text, flags=re.DOTALL)      # fenced code
        t = re.sub(r"(?m)^\s*[+\-]\s.*$", " ", t)                  # diff 行（+/- 開頭）
        t = re.sub(r"(?m)^\s*[+\-]?\s*\d+:\s.*$", " ", t)          # 行號輸出「60: code」
        t = re.sub(r"(?m)^\s*⋮.*$", " ", t)                        # 工具參數/輸出區塊
        t = re.sub(r"`[^`\n]+`", " ", t)                           # inline code
        return t

    @staticmethod
    def detect_error(output: str) -> tuple[str, str] | None:
        clean = KiroBackend._strip(output)
        # [1.1.12] 先剝除程式碼區塊再比對，避免 agent 寫的 code 觸發誤判（報告 A）
        scan = KiroBackend._strip_code_regions(clean)
        for pattern, err_type, msg in ERROR_PATTERNS:
            if pattern.search(scan):
                return err_type, msg
        return None

    @staticmethod
    def has_startup_dialog(output: str) -> bool:
        return bool(STARTUP_DIALOG.search(KiroBackend._strip(output)))

    @staticmethod
    def has_runtime_dialog(output: str) -> bool:
        return bool(RUNTIME_DIALOG.search(KiroBackend._strip(output)))

    @staticmethod
    def dismiss_dialog_keys() -> list[str]:
        return ["Down", "Enter"]

    @staticmethod
    def quit_command() -> str:
        return "/quit"
