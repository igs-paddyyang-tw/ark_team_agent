"""Dashboard API endpoints — /api/dashboard/* namespace."""
from __future__ import annotations

from datetime import datetime
from typing import Any

from fastapi import APIRouter, Body, HTTPException
from pydantic import BaseModel

router = APIRouter(prefix="/api/dashboard", tags=["dashboard"])

# Will be set by DaemonAPI at startup
_daemon = None
_task_board = None


def init(daemon, task_board) -> None:
    """Inject daemon and task_board references."""
    global _daemon, _task_board
    _daemon = daemon
    _task_board = task_board


# ── Models ────────────────────────────────────────────────────────


class CreateTaskRequest(BaseModel):
    title: str
    assignee: str
    priority: str = "medium"
    description: str = ""


class PatchTaskRequest(BaseModel):
    status: str | None = None
    assignee: str | None = None
    note: str = ""


# ── GET /api/dashboard/stats ──────────────────────────────────────


@router.get("/stats")
async def get_stats() -> dict[str, Any]:
    """KPI stats: running count, today cost, task summary."""
    instances = _daemon.get_status()
    running = sum(1 for i in instances if i["status"] == "running")

    cost_today = 0.0
    cg = getattr(_daemon, "cost_guard", None)
    if cg:
        cost_today = round(cg.spent_today(), 2)

    tasks = _task_board.list_tasks() if _task_board else []
    task_stats = {"total": len(tasks), "pending": 0, "in_progress": 0, "completed": 0, "blocked": 0, "failed": 0}
    for t in tasks:
        if t.status in task_stats:
            task_stats[t.status] += 1

    return {
        "ok": True,
        "running_agents": running,
        "total_agents": len(instances),
        "cost_today_usd": cost_today,
        "tasks": task_stats,
    }


# ── GET /api/dashboard/agents ─────────────────────────────────────


@router.get("/agents")
async def list_agents() -> dict[str, Any]:
    """All agents with name/role/status/last_activity."""
    detail = _daemon.get_instances_detail()
    agents = [
        {
            "name": v["name"],
            "role": v.get("role", ""),
            "display_name": v.get("display_name", ""),
            "status": v["status"],
            "last_activity": v.get("last_activity"),
        }
        for v in detail.values()
    ]
    return {"ok": True, "agents": agents}


# ── GET /api/dashboard/agents/{name} ─────────────────────────────


@router.get("/agents/{name}")
async def get_agent(name: str) -> dict[str, Any]:
    """Single agent detail."""
    detail = _daemon.get_instances_detail()
    agent = detail.get(name)
    if not agent:
        raise HTTPException(status_code=404, detail=f"Agent '{name}' not found")
    return {"ok": True, "agent": agent}


# ── GET /api/dashboard/board ──────────────────────────────────────


@router.get("/board")
async def list_board() -> dict[str, Any]:
    """All tasks from board.json."""
    tasks = _task_board.list_tasks() if _task_board else []
    return {
        "ok": True,
        "tasks": [
            {
                "id": t.id,
                "title": t.title,
                "assignee": t.assignee,
                "status": t.status,
                "priority": t.priority,
                "created_at": t.created_at,
                "completed_at": t.completed_at,
            }
            for t in tasks
        ],
    }


# ── POST /api/dashboard/board ─────────────────────────────────────


@router.post("/board", status_code=201)
async def create_task(req: CreateTaskRequest) -> dict[str, Any]:
    """Create a new task."""
    if not _task_board:
        raise HTTPException(status_code=503, detail="Task board not available")
    task = _task_board.create_task(
        title=req.title,
        assignee=req.assignee,
        priority=req.priority,
        description=req.description,
    )
    return {"ok": True, "task": {"id": task.id, "title": task.title, "status": task.status}}


# ── PATCH /api/dashboard/board/{task_id} ──────────────────────────


@router.patch("/board/{task_id}")
async def patch_task(task_id: str, req: PatchTaskRequest) -> dict[str, Any]:
    """Update task status or assignee."""
    if not _task_board:
        raise HTTPException(status_code=503, detail="Task board not available")

    task = _task_board.get_task(task_id)
    if not task:
        raise HTTPException(status_code=404, detail=f"Task '{task_id}' not found")

    if req.status:
        updated = _task_board.update_status(task_id, req.status, note=req.note)
    elif req.assignee:
        # Reassign via raw update
        updated = _task_board.update_status(task_id, task.status, note=f"reassigned to {req.assignee}")
    else:
        raise HTTPException(status_code=400, detail="Provide status or assignee")

    if not updated:
        raise HTTPException(status_code=500, detail="Update failed")

    return {
        "ok": True,
        "task": {"id": updated.id, "title": updated.title, "status": updated.status, "assignee": updated.assignee},
    }


# ── DELETE /api/dashboard/board/{task_id} ─────────────────────────
# [1.2.9] design 早有定義（team-web-dashboard-design.md:116）但未實作 → drift 補齊
@router.delete("/board/{task_id}")
async def delete_task(task_id: str) -> dict[str, Any]:
    """Delete a task from the board."""
    if not _task_board:
        raise HTTPException(status_code=503, detail="Task board not available")
    if not _task_board.get_task(task_id):
        raise HTTPException(status_code=404, detail=f"Task '{task_id}' not found")
    if not _task_board.delete_task(task_id):
        raise HTTPException(status_code=500, detail="Delete failed")
    return {"ok": True, "deleted": task_id}


# ── GET /api/dashboard/costs/trend ────────────────────────────────
# [1.2.9] 成本趨勢（依日期彙總，資料源 CostGuard.get_range）
@router.get("/costs/trend")
async def get_costs_trend(days: int = 7) -> dict[str, Any]:
    """Daily spend trend for the last N days (per-day total + per-instance breakdown)."""
    cg = getattr(_daemon, "cost_guard", None) if _daemon else None
    if not cg:
        return {"ok": True, "days": days, "trend": [], "note": "cost_guard 未啟用（daily_limit_usd=0）"}
    rows = cg.get_range(since_days=days)
    by_date: dict[str, dict[str, Any]] = {}
    for r in rows:
        d = by_date.setdefault(r.date, {"date": r.date, "total_usd": 0.0, "by_instance": {}})
        d["total_usd"] = round(d["total_usd"] + r.amount_usd, 6)
        d["by_instance"][r.instance] = round(
            d["by_instance"].get(r.instance, 0.0) + r.amount_usd, 6)
    trend = sorted(by_date.values(), key=lambda x: x["date"])[-days:]
    return {"ok": True, "days": days, "trend": trend}


# ── GET /api/dashboard/timeline ───────────────────────────────────
# [1.2.9] 事件時間軸（資料源 event_log.query）
@router.get("/timeline")
async def get_timeline(limit: int = 50, instance: str | None = None,
                       event_type: str | None = None) -> dict[str, Any]:
    """Recent events as a timeline (newest first)."""
    from .event_log import get_event_log
    events = get_event_log().query(instance=instance, event_type=event_type, limit=limit)
    return {
        "ok": True,
        "count": len(events),
        "events": [
            {"timestamp": e.timestamp, "instance": e.instance,
             "type": e.type, "detail": e.detail, "source": e.source}
            for e in events
        ],
    }


# ── GET /api/dashboard/autopilots ─────────────────────────────────


@router.get("/autopilots")
async def list_autopilots() -> dict[str, Any]:
    """List scheduler jobs from scheduler.yaml."""
    import yaml
    from .config import get_home

    yaml_path = get_home() / "scheduler.yaml"
    if not yaml_path.exists():
        return {"ok": True, "jobs": []}

    data = yaml.safe_load(yaml_path.read_text(encoding="utf-8"))
    jobs = data.get("jobs", []) if data else []
    return {"ok": True, "jobs": jobs}


# ── PATCH /api/dashboard/autopilots/{name} ────────────────────────


@router.patch("/autopilots/{name}")
async def patch_autopilot(name: str, req: dict[str, Any] = Body(...)) -> dict[str, Any]:
    """Toggle enabled/disabled for a scheduler job."""
    import yaml
    from .config import get_home

    yaml_path = get_home() / "scheduler.yaml"
    if not yaml_path.exists():
        raise HTTPException(status_code=404, detail="scheduler.yaml not found")

    data = yaml.safe_load(yaml_path.read_text(encoding="utf-8"))
    jobs = data.get("jobs", [])
    found = False
    for job in jobs:
        if job.get("name") == name:
            if "enabled" in req:
                job["enabled"] = req["enabled"]
            found = True
            break

    if not found:
        raise HTTPException(status_code=404, detail=f"Job '{name}' not found")

    yaml_path.write_text(yaml.dump(data, allow_unicode=True, default_flow_style=False), encoding="utf-8")
    return {"ok": True, "job": name, "enabled": req.get("enabled")}


# ── POST /api/dashboard/autopilots/{name}/trigger ─────────────────


@router.post("/autopilots/{name}/trigger")
async def trigger_autopilot(name: str) -> dict[str, Any]:
    """Manually trigger a scheduler job (send prompt to target)."""
    import yaml
    from .config import get_home

    yaml_path = get_home() / "scheduler.yaml"
    if not yaml_path.exists():
        raise HTTPException(status_code=404, detail="scheduler.yaml not found")

    data = yaml.safe_load(yaml_path.read_text(encoding="utf-8"))
    jobs = data.get("jobs", [])
    job = next((j for j in jobs if j.get("name") == name), None)
    if not job:
        raise HTTPException(status_code=404, detail=f"Job '{name}' not found")

    target = job.get("target", "")
    prompt = job.get("prompt", "")
    if not target or not prompt:
        raise HTTPException(status_code=400, detail="Job has no target or prompt")

    ok = await _daemon.send_message(target, prompt)
    return {"ok": ok, "target": target}
