"""Docs API endpoints — /api/docs/* + /api/mcp-tools namespace."""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from fastapi import APIRouter, HTTPException

router = APIRouter(tags=["docs"])

_docs_dir: Path | None = None


def init(docs_dir: Path) -> None:
    global _docs_dir
    _docs_dir = docs_dir


@router.get("/api/docs/list")
async def list_docs() -> dict[str, Any]:
    """List all .md files under docs/."""
    if not _docs_dir or not _docs_dir.exists():
        return {"ok": True, "files": []}

    files: list[str] = []
    for md in sorted(_docs_dir.rglob("*.md")):
        rel = md.relative_to(_docs_dir).as_posix()
        # Skip archive
        if "archive/" in rel:
            continue
        files.append(rel)

    return {"ok": True, "files": files}


@router.get("/api/docs/changelog")
async def get_changelog() -> dict[str, Any]:
    """Return parsed CHANGELOG.md entries."""
    if not _docs_dir:
        return {"ok": True, "entries": []}

    # Look for CHANGELOG.md in docs/ or project root
    changelog_path = _docs_dir / "CHANGELOG.md"
    if not changelog_path.exists():
        changelog_path = _docs_dir.parent / "CHANGELOG.md"
    if not changelog_path.exists():
        return {"ok": True, "entries": []}

    content = changelog_path.read_text(encoding="utf-8", errors="ignore")
    entries: list[dict[str, str]] = []
    current_version = ""
    current_body: list[str] = []

    for line in content.splitlines():
        m = re.match(r"^##\s+\[?(\d+\.\d+\.\d+[^\]]*)\]?", line)
        if m:
            if current_version:
                entries.append({"version": current_version, "body": "\n".join(current_body).strip()})
            current_version = m.group(1)
            current_body = []
        elif current_version:
            current_body.append(line)

    if current_version:
        entries.append({"version": current_version, "body": "\n".join(current_body).strip()})

    return {"ok": True, "entries": entries}


@router.get("/api/docs/{path:path}")
async def get_doc(path: str) -> dict[str, Any]:
    """Read a doc file."""
    if not _docs_dir:
        raise HTTPException(status_code=503, detail="Docs dir not configured")

    file = _docs_dir / path
    if not file.exists() or file.suffix != ".md":
        raise HTTPException(status_code=404, detail=f"Doc not found: {path}")

    # Prevent path traversal
    try:
        file.resolve().relative_to(_docs_dir.resolve())
    except ValueError:
        raise HTTPException(status_code=403, detail="Access denied")

    content = file.read_text(encoding="utf-8", errors="ignore")
    return {"ok": True, "path": path, "content": content}


@router.get("/api/mcp-tools")
async def list_mcp_tools() -> dict[str, Any]:
    """Return all MCP tool definitions (name + description + inputSchema)."""
    from .team_mcp import _ALL_TOOLS  # noqa: WPS436

    tools = [
        {
            "name": t["name"],
            "description": t.get("description", ""),
            "inputSchema": t.get("inputSchema", {}),
        }
        for t in _ALL_TOOLS
    ]
    return {"ok": True, "tools": tools}
