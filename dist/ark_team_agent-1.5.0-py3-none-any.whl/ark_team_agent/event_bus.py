"""EventBus — asyncio pub/sub 事件匯流排 + WebSocket push。

架構：
  EventBus.emit(event) → 佇列 → 分發給 subscribers + WebSocket clients
  subscriber = async (event) -> None
"""
from __future__ import annotations

import asyncio
import json
import logging
import time
from collections import defaultdict
from typing import Callable, Awaitable

from .event_log import EventType, Event, get_event_log

log = logging.getLogger(__name__)

# Handler type: async function that receives an Event
EventHandler = Callable[["BusEvent"], Awaitable[None]]


class BusEvent:
    """EventBus 事件（比 Event 更輕量，不含 DB id）。"""

    __slots__ = ("type", "instance", "detail", "source", "timestamp", "data")

    def __init__(
        self,
        type: str | EventType,
        instance: str = "",
        detail: str = "",
        source: str = "",
        data: dict | None = None,
    ) -> None:
        self.type = type.value if isinstance(type, EventType) else type
        self.instance = instance
        self.detail = detail
        self.source = source
        self.timestamp = time.time()
        self.data = data or {}

    def to_json(self) -> str:
        """序列化為 JSON（供 WebSocket / SSE 推送）。"""
        return json.dumps({
            "type": self.type,
            "instance": self.instance,
            "detail": self.detail,
            "source": self.source,
            "timestamp": self.timestamp,
            "data": self.data,
        }, ensure_ascii=False)


class EventBus:
    """asyncio pub/sub 事件匯流排。

    用法：
        bus = EventBus()
        bus.subscribe("crash", my_handler)
        bus.subscribe_all(audit_handler)
        await bus.start()
        await bus.emit(BusEvent(type="crash", instance="coder-agent"))
    """

    def __init__(self, maxsize: int = 5000, persist: bool = True) -> None:
        self._subscribers: dict[str, list[EventHandler]] = defaultdict(list)
        self._global_subscribers: list[EventHandler] = []
        self._queue: asyncio.Queue[BusEvent] = asyncio.Queue(maxsize=maxsize)
        self._task: asyncio.Task | None = None
        self._ws_queues: list[asyncio.Queue] = []
        self._persist = persist  # 是否同時寫入 EventLog（SQLite）
        self._running = False

    def subscribe(self, event_type: str | EventType, handler: EventHandler) -> None:
        """訂閱特定事件類型。"""
        key = event_type.value if isinstance(event_type, EventType) else event_type
        self._subscribers[key].append(handler)

    def subscribe_all(self, handler: EventHandler) -> None:
        """訂閱所有事件。"""
        self._global_subscribers.append(handler)

    async def emit(self, event: BusEvent) -> None:
        """發射事件（非阻塞，佇列滿時丟棄最舊的）。"""
        try:
            self._queue.put_nowait(event)
        except asyncio.QueueFull:
            # 丟棄最舊的
            try:
                self._queue.get_nowait()
                self._queue.put_nowait(event)
            except asyncio.QueueEmpty:
                pass
            log.warning("EventBus queue full, dropped oldest event")

    def add_ws_client(self, q: asyncio.Queue) -> None:
        """新增 WebSocket 客戶端佇列。"""
        self._ws_queues.append(q)

    def remove_ws_client(self, q: asyncio.Queue) -> None:
        """移除 WebSocket 客戶端佇列。"""
        self._ws_queues = [c for c in self._ws_queues if c is not q]

    @property
    def ws_client_count(self) -> int:
        return len(self._ws_queues)

    async def start(self) -> None:
        """啟動事件分發 loop。"""
        if self._running:
            return
        self._running = True
        self._task = asyncio.create_task(self._dispatch_loop())
        log.info("EventBus started")

    async def stop(self) -> None:
        """停止事件分發。"""
        self._running = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        log.info("EventBus stopped")

    async def _dispatch_loop(self) -> None:
        """主迴圈：從佇列取事件 → 分發給 subscribers + WS + persist。"""
        while self._running:
            try:
                event = await asyncio.wait_for(self._queue.get(), timeout=1.0)
            except asyncio.TimeoutError:
                continue
            except asyncio.CancelledError:
                return

            # 1. 分發給 type-specific subscribers
            for handler in self._subscribers.get(event.type, []):
                try:
                    await handler(event)
                except Exception as e:
                    log.error("EventBus handler error (%s): %s", event.type, e)

            # 2. 分發給 global subscribers
            for handler in self._global_subscribers:
                try:
                    await handler(event)
                except Exception as e:
                    log.error("EventBus global handler error: %s", e)

            # 3. Push to WebSocket clients
            json_data = event.to_json()
            for ws_q in self._ws_queues:
                try:
                    ws_q.put_nowait(json_data)
                except asyncio.QueueFull:
                    pass

            # 4. Persist to EventLog（如果啟用）
            if self._persist:
                try:
                    event_log = get_event_log()
                    await event_log.record(
                        event.instance, event.type, event.detail, event.source
                    )
                except Exception as e:
                    log.debug("EventBus persist failed: %s", e)

    @property
    def pending_count(self) -> int:
        return self._queue.qsize()


# ── Module-level singleton ────────────────────────────────────────

_bus: EventBus | None = None


def get_event_bus() -> EventBus:
    """Get or create the singleton EventBus."""
    global _bus
    if _bus is None:
        _bus = EventBus()
    return _bus


def reset_bus_singleton() -> None:
    """Test helper。"""
    global _bus
    _bus = None
