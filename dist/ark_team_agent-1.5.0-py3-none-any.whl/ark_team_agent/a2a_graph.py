"""A2A TaskGraph — DAG 任務依賴圖。"""
from __future__ import annotations

import logging

from .a2a_protocol import TaskHandoff

log = logging.getLogger(__name__)


class CycleError(Exception):
    """新增任務會產生循環依賴。"""


class TaskGraph:
    """DAG 依賴管理：新增任務、檢查 ready、標記完成/失敗、解鎖下游。"""

    def __init__(self) -> None:
        self._tasks: dict[str, TaskHandoff] = {}
        self._status: dict[str, str] = {}  # pending / running / completed / failed
        self._outputs: dict[str, str] = {}

    def add_task(self, task: TaskHandoff) -> None:
        """新增任務到 DAG，自動檢測循環。"""
        if task.task_id in self._tasks:
            return
        if self._has_cycle(task.task_id, task.depends_on):
            raise CycleError(f"Adding {task.task_id} would create a cycle")
        self._tasks[task.task_id] = task
        self._status[task.task_id] = "pending"

    def is_ready(self, task_id: str) -> bool:
        """檢查任務是否所有依賴已完成。"""
        task = self._tasks.get(task_id)
        if not task:
            return False
        return all(
            self._status.get(dep) == "completed" for dep in task.depends_on
        )

    def get_ready_tasks(self) -> list[TaskHandoff]:
        """取得所有 ready（依賴已滿足）的 pending 任務。"""
        return [
            t
            for tid, t in self._tasks.items()
            if self._status[tid] == "pending" and self.is_ready(tid)
        ]

    def mark_running(self, task_id: str) -> None:
        """標記為執行中。"""
        self._status[task_id] = "running"

    def mark_complete(self, task_id: str, output: str = "") -> list[TaskHandoff]:
        """標記完成，回傳被解鎖的下游任務。"""
        self._status[task_id] = "completed"
        self._outputs[task_id] = output
        return self._get_unlocked()

    def mark_failed(self, task_id: str, reason: str = "") -> None:
        """標記失敗。"""
        self._status[task_id] = "failed"
        self._outputs[task_id] = reason

    def get_task(self, task_id: str) -> TaskHandoff | None:
        """取得任務。"""
        return self._tasks.get(task_id)

    def get_output(self, task_id: str) -> str:
        """取得任務產出。"""
        return self._outputs.get(task_id, "")

    def get_status(self, task_id: str) -> str:
        """取得任務狀態。"""
        return self._status.get(task_id, "unknown")

    @property
    def pending_count(self) -> int:
        return sum(1 for s in self._status.values() if s == "pending")

    @property
    def running_count(self) -> int:
        return sum(1 for s in self._status.values() if s == "running")

    def _get_unlocked(self) -> list[TaskHandoff]:
        """找出新解鎖的 pending 任務。"""
        return [
            t
            for tid, t in self._tasks.items()
            if self._status[tid] == "pending" and self.is_ready(tid)
        ]

    def _has_cycle(self, new_id: str, deps: list[str]) -> bool:
        """DFS 檢測加入 new_id 後是否有循環。"""
        visited: set[str] = set()

        def dfs(tid: str) -> bool:
            if tid == new_id:
                return True
            if tid in visited:
                return False
            visited.add(tid)
            t = self._tasks.get(tid)
            if t:
                return any(dfs(d) for d in t.depends_on)
            return False

        return any(dfs(d) for d in deps)
