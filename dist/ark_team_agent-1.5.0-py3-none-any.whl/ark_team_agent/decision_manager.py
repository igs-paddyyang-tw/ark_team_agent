"""DecisionManager — 拍板迴路核心模組

職責：
  1. 接收 worker 的 decision-request（schema 驗證 → 入庫 → 路由給決策者）
  2. reply() hook：偵測並解析回覆中的 ```decision 塊 → 入庫 → 解鎖 → 通知
  3. 供 watchdog / ark 日報查詢的 store 介面

設計約束：
  - 純程式邏輯，不呼叫 LLM（LLM 判讀只存在於 watchdog 的兜底轉譯，不在此）
  - 冪等：同一 req_id / decision_id 重複進入不產生副作用
  - 對非決策訊息零侵入：inspect() 找不到機器塊時回 None 原樣放行
"""
from __future__ import annotations

import json
import re
import sqlite3
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Optional

import yaml

log_name = __name__
import logging
log = logging.getLogger(log_name)

# ─────────────────────────────────────────────────────────────
# 常數與設定
# ─────────────────────────────────────────────────────────────

# 🔴 **這裡刻意沒有模組層路徑常數。**
#
# v1.4.9 前有 `DB_PATH = Path("state/decisions.db")` 與
# `MATRIX_PATH = Path("config/authority-matrix.yml")`，兩個都是 cwd 相對路徑，
# 用途是下面兩個 resolver 的 `except` fallback（註解寫「fallback for unit tests」）。
#
# 移除的三個理由：
#   ① **那個 fallback 到不了** —— `get_home()` 不會拋例外（env → 往上找 team.yaml
#      → DEFAULT_HOME，三條路都有回傳值）。實測沒有任何測試依賴它。
#   ② **就算到得了也是錯的** —— 它會讓 DB 靜默寫到「當下 cwd 底下的 state/」。
#      daemon 從專案根啟動所以看不出來，但 agent 各自有 working_directory，
#      從別處啟動就會寫到別的地方，而且**不拋例外不寫 log**。
#   ③ **死碼且路徑也錯，留著只會被人照抄** —— 與 0.7.2 移除
#      `wiki_distill._RAW_DIR` 同一個理由。
#
# 路徑一律走 `config` 的正規存取器，不在這裡手組。


def _get_db_path() -> Path:
    """決策 DB 的位置 —— 一律以 team home 為基準，永不依賴 cwd。

    用 `get_state_dir()` 而不是自己組 `get_home() / "state"` ——
    全套件其他地方（`daemon` / `event_log` / `team`）都走這個出口，
    手組會在「state 目錄改位置」時漂掉一個。
    """
    from .config import get_state_dir
    return get_state_dir() / "decisions.db"


def _get_matrix_path() -> Path:
    """`authority-matrix.yml` 的位置 —— 以 team home 為基準。"""
    from .config import get_home
    return get_home() / "config" / "authority-matrix.yml"

# fenced 機器塊：```decision-request … ``` / ```decision … ```
_BLOCK_RE = re.compile(
    r"```(?P<kind>decision-request|decision)\s*\n(?P<body>.*?)```",
    re.DOTALL,
)

REQUIRED_REQUEST_FIELDS = {"req_id", "requester", "domain", "question", "options"}
REQUIRED_RECORD_FIELDS = {
    "decision_id", "req_id", "verdict", "rationale", "confidence",
}
# [ark-agent 2026-08-06] v1.2.0 P0-1/P0-2：域與決策者不再寫死，改由 authority-matrix.yml 推導
# （見 DecisionManager._valid_domains / _deciders）。防互鎖：決策者不得對彼此發 L2。


# ─────────────────────────────────────────────────────────────
# 資料類
# ─────────────────────────────────────────────────────────────

@dataclass
class DecisionRequest:
    req_id: str
    requester: str
    domain: str
    question: str
    options: list[dict]
    blocking: list[str] = field(default_factory=list)
    source: str = "push"            # push | watchdog


@dataclass
class DecisionRecord:
    decision_id: str
    req_id: str
    decided_by: str
    verdict: str
    rationale: str
    confidence: str                 # high | medium | low
    reversibility: str = ""
    precedents: list[str] = field(default_factory=list)
    blocking_released: list[str] = field(default_factory=list)


# ─────────────────────────────────────────────────────────────
# DecisionStore（SQLite）
# ─────────────────────────────────────────────────────────────

class DecisionStore:
    """SQLite-backed persistence for decision requests, records, and events."""

    def __init__(self, db_path: Path | None = None) -> None:
        if db_path is None:
            db_path = _get_db_path()
        db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(db_path), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._init_schema()

    def _init_schema(self) -> None:
        self._conn.executescript("""
        CREATE TABLE IF NOT EXISTS decision_requests (
          req_id        TEXT PRIMARY KEY,
          created_at    TEXT NOT NULL,
          requester     TEXT NOT NULL,
          domain        TEXT NOT NULL,
          question      TEXT NOT NULL,
          options_json  TEXT NOT NULL,
          blocking_json TEXT NOT NULL,
          state         TEXT NOT NULL DEFAULT 'open',
          assigned_to   TEXT NOT NULL,
          source        TEXT NOT NULL DEFAULT 'push'
        );
        CREATE TABLE IF NOT EXISTS decision_records (
          decision_id       TEXT PRIMARY KEY,
          req_id            TEXT NOT NULL REFERENCES decision_requests(req_id),
          decided_at        TEXT NOT NULL,
          decided_by        TEXT NOT NULL,
          verdict           TEXT NOT NULL,
          rationale         TEXT NOT NULL,
          confidence        TEXT NOT NULL,
          reversibility     TEXT NOT NULL DEFAULT '',
          precedents_json   TEXT NOT NULL DEFAULT '[]',
          overturn_deadline TEXT NOT NULL,
          status            TEXT NOT NULL DEFAULT 'effective',
          overturn_reason   TEXT
        );
        CREATE TABLE IF NOT EXISTS decision_events (
          ts           TEXT NOT NULL,
          req_id       TEXT NOT NULL,
          event        TEXT NOT NULL,
          payload_json TEXT NOT NULL
        );
        """)
        self._conn.commit()

    # ── requests ──────────────────────────────────────────────

    def insert_request(self, r: DecisionRequest, assigned_to: str) -> bool:
        """Insert a new request. Returns False if req_id already exists (idempotent)."""
        try:
            self._conn.execute(
                "INSERT INTO decision_requests VALUES (?,?,?,?,?,?,?,?,?,?)",
                (r.req_id, _now(), r.requester, r.domain, r.question,
                 _j(r.options), _j(r.blocking), "open", assigned_to, r.source),
            )
            self._log(r.req_id, "request_created", {"assigned_to": assigned_to})
            self._conn.commit()
            return True
        except sqlite3.IntegrityError:
            return False

    def open_requests(self, older_than: Optional[timedelta] = None) -> list[sqlite3.Row]:
        """Return open requests. Optionally filter by age (for watchdog)."""
        rows = self._conn.execute(
            "SELECT * FROM decision_requests WHERE state='open'"
        ).fetchall()
        if older_than is None:
            return rows
        cutoff = datetime.now(timezone.utc) - older_than
        return [r for r in rows
                if datetime.fromisoformat(r["created_at"]) < cutoff]

    def mark_request(self, req_id: str, state: str) -> None:
        self._conn.execute(
            "UPDATE decision_requests SET state=? WHERE req_id=?", (state, req_id))
        self._log(req_id, f"request_{state}", {})
        self._conn.commit()

    def get_request(self, req_id: str) -> Optional[sqlite3.Row]:
        return self._conn.execute(
            "SELECT * FROM decision_requests WHERE req_id=?", (req_id,)
        ).fetchone()

    # ── records ───────────────────────────────────────────────

    def insert_record(self, rec: DecisionRecord, overturn_window: timedelta) -> bool:
        """Insert a decision record. Returns False if decision_id already exists."""
        deadline = (datetime.now(timezone.utc) + overturn_window).isoformat()
        try:
            self._conn.execute(
                "INSERT INTO decision_records VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                (rec.decision_id, rec.req_id, _now(), rec.decided_by,
                 rec.verdict, rec.rationale, rec.confidence, rec.reversibility,
                 _j(rec.precedents), deadline, "effective", None),
            )
            self._log(rec.req_id, "decision_made",
                      {"decision_id": rec.decision_id, "verdict": rec.verdict})
            self._conn.commit()
            return True
        except sqlite3.IntegrityError:
            return False

    def records_between(self, start_iso: str, end_iso: str) -> list[sqlite3.Row]:
        """Query records by decided_at range. Used by ark daily digest."""
        return self._conn.execute(
            "SELECT * FROM decision_records "
            "WHERE decided_at >= ? AND decided_at < ? ORDER BY decided_at",
            (start_iso, end_iso),
        ).fetchall()

    def overturn(self, decision_id: str, reason: str) -> None:
        """Mark a decision as overturned. reason is mandatory (training signal)."""
        assert reason and reason.strip(), \
            "翻案原因必填 — 這是最高價值的訓練訊號，請說明 Paddy 希望的方向"
        self._conn.execute(
            "UPDATE decision_records SET status='overturned', overturn_reason=? "
            "WHERE decision_id=?",
            (reason.strip(), decision_id),
        )
        self._log("-", "decision_overturned",
                  {"decision_id": decision_id, "reason": reason})
        self._conn.commit()

    def expire_confirmed(self, decision_id: str) -> None:
        """Mark as expired_confirmed (24h window passed, Paddy took no action)."""
        self._conn.execute(
            "UPDATE decision_records SET status='expired_confirmed' WHERE decision_id=?",
            (decision_id,),
        )
        self._log("-", "decision_expired_confirmed", {"decision_id": decision_id})
        self._conn.commit()

    def get_overdue_for_expiry(self) -> list[sqlite3.Row]:
        """Return effective records whose overturn_deadline has passed."""
        now = _now()
        return self._conn.execute(
            "SELECT * FROM decision_records "
            "WHERE status='effective' AND overturn_deadline < ?",
            (now,),
        ).fetchall()

    # ── events（append-only，可回放）─────────────────────────

    def events_for(self, req_id: str) -> list[sqlite3.Row]:
        """Return all events for a given req_id in chronological order."""
        return self._conn.execute(
            "SELECT * FROM decision_events WHERE req_id=? ORDER BY ts",
            (req_id,),
        ).fetchall()

    def _log(self, req_id: str, event: str, payload: dict) -> None:
        self._conn.execute(
            "INSERT INTO decision_events VALUES (?,?,?,?)",
            (_now(), req_id, event, _j(payload)),
        )


# ─────────────────────────────────────────────────────────────
# DecisionManager
# ─────────────────────────────────────────────────────────────

class DecisionManager:
    """Routing hub for the decision loop.

    Requires a daemon_api object that provides:
      - send_message(instance: str, text: str) -> None
      - notify_paddy(text: str, buttons: list[str] | None = None) -> None
      - unlock_task(task_id: str) -> None   (no-op until aibi TaskStore)
    """

    def __init__(self, daemon_api: Any, store: Optional[DecisionStore] = None,
                 matrix_path: Path | None = None) -> None:
        self.daemon = daemon_api
        self.store = store or DecisionStore()
        self.matrix = self._load_matrix(matrix_path or _get_matrix_path())
        # parse failure counter: sender → consecutive failures
        self._parse_failures: dict[str, int] = {}

    @staticmethod
    def _load_matrix(path: Path) -> dict:
        # ⚠️ `path` 刻意沒有預設值。v1.4.9 前預設是 `MATRIX_PATH`
        # （cwd 相對），唯一呼叫點永遠傳值所以那個預設是死的 ——
        # 但它讓「裸呼叫 `_load_matrix()`」看起來合法，而結果會依 cwd 而變。
        if not path.exists():
            raise FileNotFoundError(f"authority-matrix.yml not found at {path}")
        with open(path, encoding="utf-8") as f:
            data = yaml.safe_load(f)
        # Validate required top-level keys
        for key in ("version", "levels", "escalation", "overturn_window"):
            if key not in data:
                raise ValueError(f"authority-matrix.yml 缺少必要欄位: {key}")
        levels = data["levels"]
        for level in ("L1", "L2", "L3"):
            if level not in levels:
                raise ValueError(f"authority-matrix.yml levels 缺少: {level}")
        # [ark-agent 2026-08-06] v1.2.0 P0-1：不再要求固定三域，改「至少一域且每域有 owner 或 first+final」
        l2 = levels["L2"]
        domains = {k: v for k, v in l2.items() if isinstance(v, dict)}
        if not domains:
            raise ValueError("authority-matrix.yml L2 至少需定義一個 domain")
        for name, cfg in domains.items():
            if "owner" not in cfg and not ({"first", "final"} <= set(cfg.keys())):
                raise ValueError(
                    f"authority-matrix.yml L2.{name} 需有 owner 或 first+final"
                )
        return data

    # ── 入口 1：worker 發來 decision-request ──────────────────

    def handle_request_message(self, text: str, sender: str) -> str:
        """Called by daemon when a message is sent to 'decision-manager'.
        Returns feedback string to send back to the requester."""
        block = _extract_block(text, "decision-request")
        if block is None:
            return "❌ 未找到 ```decision-request 塊，請依格式重出。"

        try:
            req = self._parse_request(block, sender)
        except ValueError as e:
            log.warning("DecisionManager: invalid request from %s: %s", sender, e)
            return f"❌ 請求格式錯誤：{e}"

        owner = self._resolve_owner(req.domain)
        if not self.store.insert_request(req, owner):
            return f"⚠️ {req.req_id} 已存在，忽略（冪等）。"

        # 通知決策者（卡片貼到 owner Topic）
        card = _render_request_card(req)
        self.daemon.send_message(owner, card)
        log.info("DecisionManager: routed %s (domain=%s) → %s", req.req_id, req.domain, owner)

        # TODO（aibi-loop TaskStore 接入後）：for t in req.blocking: taskstore.block(t, req.req_id)
        return (f"✅ {req.req_id} 已送 {owner} 拍板；"
                f"你可先處理其他不相依的工作，收到「✅ 已拍板」通知後再繼續。")

    # ── 入口 2：reply() hook ───────────────────────────────────

    def inspect(self, text: str, sender: str) -> Optional[str]:
        """Called by DaemonAPI.reply() before routing.

        Returns:
          None  — no decision block found; caller should proceed normally (zero intrusion)
          str   — error message to send back to the decider; caller sends it but STILL
                  routes the original message (decision留痕)
        On success: stores DR, unlocks tasks, notifies requester. Returns None.
        """
        block = _extract_block(text, "decision")
        if block is None:
            return None  # 零侵入放行

        try:
            rec = self._parse_record(block, sender)
        except ValueError as e:
            return self._handle_parse_failure(sender, str(e))

        # 安全閥：confidence=low → 自動升級 Paddy，不入庫 effective
        if rec.confidence.strip().lower() == "low":
            self.daemon.notify_paddy(
                f"⚠️ {rec.decided_by} 對 {rec.req_id} 信心不足（confidence=low），"
                f"需要你拍板：\n問題見 Topic，DR-id: {rec.decision_id}",
                buttons=["批准", "改判"],
            )
            self.store.mark_request(rec.req_id, "escalated")
            log.info("DecisionManager: %s escalated to Paddy (confidence=low)", rec.req_id)
            return None  # 訊息照常送 Topic 留痕

        window = _parse_window(self.matrix.get("overturn_window", "24h"))
        if not self.store.insert_record(rec, overturn_window=window):
            log.debug("DecisionManager: duplicate decision_id %s, ignored", rec.decision_id)
            return None  # 冪等忽略

        self.store.mark_request(rec.req_id, "decided")

        # 解鎖受阻任務
        for task_id in rec.blocking_released:
            try:
                self.daemon.unlock_task(task_id)
            except Exception as exc:
                log.warning("DecisionManager: unlock_task(%s) failed: %s", task_id, exc)

        # 通知 requester 續行
        requester = self._requester_of(rec.req_id)
        if requester:
            self.daemon.send_message(
                requester,
                f"✅ 已拍板 {rec.decision_id}\n"
                f"決定：{rec.verdict}\n"
                f"理由：{rec.rationale}\n"
                f"請依此繼續執行（24h 內 Paddy 可翻案）。",
            )

        # 重置 parse failure counter（成功了）
        self._parse_failures.pop(sender, None)
        log.info("DecisionManager: DR %s effective (req=%s, verdict=%s)",
                 rec.decision_id, rec.req_id, rec.verdict)
        return None  # 訊息照常送 Topic 留痕

    # ── 解析與驗證 ─────────────────────────────────────────────

    def _parse_request(self, body: str, sender: str) -> DecisionRequest:
        try:
            data = yaml.safe_load(body)
        except yaml.YAMLError as e:
            raise ValueError(f"YAML 解析失敗：{e}") from e

        if not isinstance(data, dict):
            raise ValueError("decision-request 塊必須是 YAML mapping")

        missing = REQUIRED_REQUEST_FIELDS - set(data)
        if missing:
            raise ValueError(f"缺少必要欄位：{sorted(missing)}")

        domain = data.get("domain", "")
        # [ark-agent 2026-08-06] v1.2.0 P0-1：域由矩陣推導，不再寫死三種
        valid = self._valid_domains()
        if domain not in valid:
            raise ValueError(f"domain 必須是 {sorted(valid)}，收到：{domain!r}")

        # 防互鎖：決策者不得對決策者發 L2
        # [ark-agent 2026-08-06] v1.2.0 P0-2：決策者集合由矩陣推導
        owner = self._resolve_owner(domain)
        deciders = self._deciders()
        if sender in deciders and owner in deciders and sender != owner:
            raise ValueError(
                f"決策者（{sender}）不得對另一決策者（{owner}）發 L2 請求，"
                f"防止互鎖。mixed 域走固定單向流（cto→ceo）。"
            )

        options = data.get("options", [])
        if not isinstance(options, list) or len(options) < 2:
            raise ValueError("options 必須是含至少 2 個選項的 list")

        # 自動補 req_id（若 worker 未填）
        req_id = data.get("req_id") or f"DRQ-{_stamp()}-{uuid.uuid4().hex[:4].upper()}"

        return DecisionRequest(
            req_id=req_id,
            requester=data.get("requester") or sender,
            domain=domain,
            question=str(data["question"]),
            options=options,
            blocking=data.get("blocking") or [],
            source="push",
        )

    def _parse_record(self, body: str, sender: str) -> DecisionRecord:
        try:
            data = yaml.safe_load(body)
        except yaml.YAMLError as e:
            raise ValueError(f"YAML 解析失敗：{e}") from e

        if not isinstance(data, dict):
            raise ValueError("decision 塊必須是 YAML mapping")

        missing = REQUIRED_RECORD_FIELDS - set(data)
        if missing:
            raise ValueError(f"缺少必要欄位：{sorted(missing)}")

        return DecisionRecord(
            decision_id=str(data["decision_id"]),
            req_id=str(data["req_id"]),
            decided_by=sender,
            verdict=str(data["verdict"]),
            rationale=str(data["rationale"]),
            confidence=str(data["confidence"]).strip().lower(),
            reversibility=str(data.get("reversibility") or ""),
            precedents=list(data.get("precedents") or []),
            blocking_released=list(data.get("blocking_released") or []),
        )

    def _resolve_owner(self, domain: str) -> str:
        cfg = self.matrix["levels"]["L2"][domain]
        # [ark-agent 2026-08-06] v1.2.0 P0-1：first/final 流程（如 mixed）→ first 先出；否則 owner
        return cfg.get("first") or cfg["owner"]

    def _l2_domains(self) -> dict:
        """L2 中所有 domain 設定（排除 desc 等非 dict 值）。"""
        return {k: v for k, v in self.matrix["levels"]["L2"].items() if isinstance(v, dict)}

    def _valid_domains(self) -> set[str]:
        """合法決策域 = 矩陣 L2 自定義的域（v1.2.0 P0-1，不再寫死三種）。"""
        return set(self._l2_domains())

    def _deciders(self) -> set[str]:
        """決策者集合 = 矩陣 L2 各域的 owner/first/final（v1.2.0 P0-2，不再寫死 ceo/cto）。"""
        out: set[str] = set()
        for cfg in self._l2_domains().values():
            for key in ("owner", "first", "final"):
                v = cfg.get(key)
                if v:
                    out.add(v)
        return out

    def _requester_of(self, req_id: str) -> Optional[str]:
        row = self.store.get_request(req_id)
        return row["requester"] if row else None

    def _handle_parse_failure(self, sender: str, err: str) -> str:
        """Track parse failures. On 2nd consecutive failure, escalate to Paddy."""
        count = self._parse_failures.get(sender, 0) + 1
        self._parse_failures[sender] = count
        log.warning("DecisionManager: parse failure #%d from %s: %s", count, sender, err)

        if count >= 2:
            self.daemon.notify_paddy(
                f"⚠️ {sender} decision 塊連續 2 次格式錯誤，升級給你確認：\n錯誤：{err}"
            )
            self._parse_failures.pop(sender, None)
            return f"❌ decision 塊格式連續錯誤，已升級 Paddy。錯誤：{err}"

        return (f"❌ decision 塊格式錯誤，請重出一次（第 {count} 次）：{err}\n\n"
                f"必填欄位：decision_id, req_id, verdict, rationale, confidence")

    # ── ark fallback 拍板路由（W2.5）─────────────────────────────

    def escalate_to_ark(self, req_id: str) -> None:
        """Escalate an unanswered L2 request to ark-agent for fallback decision.

        ark-agent will:
          1. recall knowledge/raw/decisions + BRAIN.md ARK:AGENT-NOTES
          2. self-decide if confidence>=medium, else send Paddy card
          3. write knowledge feedback to original owner after any decision
        """
        row = self.store.get_request(req_id)
        if not row:
            log.warning("escalate_to_ark: req_id %s not found", req_id)
            return

        # Look up fallback agent from matrix
        l2 = self.matrix.get("levels", {}).get("L2", {})
        domain_cfg = l2.get(row["domain"], {})
        # [1.2.26] 原本預設 `"ark-agent"` —— nana 的入口名。其他部署沒這個 instance，
        # 矩陣沒定義 fallback 時就會把升級發給一個**不存在的對象**（訊息靜默丟失）。
        # 改為依 role 推導：矩陣未指定 → 第一個 admin → 退回原 owner（至少送得到人）。
        fallback = domain_cfg.get("fallback") or self._fallback_owner(row["assigned_to"])
        original_owner = row["assigned_to"]

        import json
        options_json = json.loads(row["options_json"])
        opts_text = "\n".join(
            f"  {o.get('id', i+1)}. {o.get('desc', o)}"
            for i, o in enumerate(options_json)
        )

        card = (
            f"📋 Fallback 拍板請求 {req_id}（原送 {original_owner}，已逾時）\n"
            f"問題：{row['question']}\n"
            f"選項：\n{opts_text}\n\n"
            f"[fallback-decision-request]\n"
            f"req_id: {req_id}\n"
            f"original_owner: {original_owner}\n"
            f"domain: {row['domain']}\n"
            f"請依 fallback-decision.md steering 處理：\n"
            f"1. recall 前例方針\n"
            f"2. confidence>=medium → 自拍（輸出 decision 塊）\n"
            f"3. confidence=low → 呼叫 notify_paddy 送三鈕給 Paddy\n"
            f"4. 拍板完成後呼叫 write_knowledge_feedback"
        )

        self.store._log(req_id, "escalated_to_ark", {"fallback": fallback})
        self.store._conn.commit()
        self.daemon.send_message(fallback, card)
        log.info("DecisionManager: escalated %s to %s (original: %s)", req_id, fallback, original_owner)

    def _fallback_owner(self, original_owner: str) -> str:
        """L2 升級的預設接手人 —— **依 role 推導，不寫死 instance 名**。

        順序：第一個 `role == "admin"` → 第一個 `role == "manager"` → 原 owner。
        退回原 owner 而非空字串：升級失敗至少要讓原本的人知道，
        發給不存在的 instance 只會靜默丟失。

        Author: ark-agent（1.2.26）
        """
        cfg = getattr(self.daemon, "config", None)
        insts = getattr(cfg, "instances", None) if cfg is not None else None
        if insts:
            for want in ("admin", "manager"):
                for name, ic in insts.items():
                    if getattr(ic, "role", "") == want:
                        return name
        return original_owner

    def _knowledge_raw_dir(self, base: Path, owner: str) -> Path:
        """回傳該 agent 的 `knowledge/raw/` 目錄，依 `working_directory` 推導。

        判準是「wd 是否就是專案根」，不是比對 instance 名稱：

        - wd == 專案根 → `base/knowledge/{owner}/raw/`
          （不能用 `base/knowledge/raw/` —— 那層是共用圖書館，會污染其他櫃子）
        - wd == 別處   → `base/{wd}/knowledge/raw/`
        - 查不到設定   → 退回 `base/agents/{owner}/knowledge/raw/`（1.2.23 前的 else 分支）

        Author: ark-agent（1.2.23）
        """
        wd: str | None = None
        cfg = getattr(self.daemon, "config", None)
        inst = getattr(cfg, "instances", None) if cfg is not None else None
        if inst and owner in inst:
            wd = getattr(inst[owner], "working_directory", None)

        if wd is None:
            return base / "agents" / owner / "knowledge" / "raw"

        try:
            is_root = (base / wd).resolve() == base.resolve()
        except OSError:  # 路徑無法解析（如 symlink 迴圈）→ 當成非根目錄處理
            is_root = False

        if is_root:
            return base / "knowledge" / owner / "raw"
        return base / wd / "knowledge" / "raw"

    def write_knowledge_feedback(
        self,
        decision_id: str,
        req_id: str,
        original_owner: str,
        verdict: str,
        rationale: str,
        decided_by: str,
    ) -> None:
        """Write decision knowledge back to the original owner's knowledge & BRAIN.md.

        Called by ark-agent after any fallback decision (self or Paddy).
        Paths:
          agents/{original_owner}/knowledge/raw/decisions/DR-{id}.md
          agents/{original_owner}/.kiro/steering/BRAIN.md  (ARK:AGENT-NOTES section)
        """
        from .config import get_home
        base = get_home()

        # 1. Write to knowledge/raw/decisions/
        #
        # [1.2.23] 原本寫死 `if original_owner == "ark-agent"` —— 那是 nana 的
        # instance 名，其他部署永遠走 else，是死分支。真正的判準不是「叫什麼名字」，
        # 而是「working_directory 是否就是專案根」：
        #   wd == 專案根 → 不能用 base/knowledge/（那是共用的圖書館），
        #                  要用自己的櫃子 base/knowledge/{owner}/
        #   wd == 別處   → 用該 agent 自己的 {wd}/knowledge/
        # 這樣任何部署的「wd=專案根」agent 都正確，不只 ark-agent。
        decisions_dir = self._knowledge_raw_dir(base, original_owner) / "decisions"
        decisions_dir.mkdir(parents=True, exist_ok=True)
        dr_file = decisions_dir / f"{decision_id}.md"
        content = (
            f"# {decision_id}\n\n"
            f"- **req_id**: {req_id}\n"
            f"- **decided_by**: {decided_by}\n"
            f"- **verdict**: {verdict}\n"
            f"- **rationale**: {rationale}\n"
            f"- **date**: {_stamp()}\n"
        )
        try:
            dr_file.write_text(content, encoding="utf-8")
            log.info("Knowledge feedback written: %s", dr_file)
        except Exception as e:
            log.warning("write_knowledge_feedback: failed to write DR file: %s", e)

        # 2. Append to BRAIN.md ARK:AGENT-NOTES
        brain_path = base / "agents" / original_owner / ".kiro" / "steering" / "BRAIN.md"
        if brain_path.exists():
            try:
                brain = brain_path.read_text(encoding="utf-8")
                note = (
                    f"\n### ARK:AGENT-NOTES [{_stamp()}]\n"
                    f"- {decision_id}：{rationale}（由 {decided_by} 拍板，verdict={verdict}）\n"
                )
                if "ARK:AGENT-NOTES" not in brain:
                    brain += f"\n## ARK:AGENT-NOTES\n{note}"
                else:
                    # Append after the last ARK:AGENT-NOTES entry
                    brain += note
                brain_path.write_text(brain, encoding="utf-8")
                log.info("BRAIN.md ARK:AGENT-NOTES updated for %s", original_owner)
            except Exception as e:
                log.warning("write_knowledge_feedback: failed to update BRAIN.md: %s", e)
        else:
            log.debug("write_knowledge_feedback: BRAIN.md not found at %s", brain_path)


# ─────────────────────────────────────────────────────────────
# 工具函式
# ─────────────────────────────────────────────────────────────

def _extract_block(text: str, kind: str) -> Optional[str]:
    """Extract the body of a fenced block of the given kind, or None."""
    for m in _BLOCK_RE.finditer(text):
        if m.group("kind") == kind:
            return m.group("body")
    return None


def _render_request_card(r: DecisionRequest) -> str:
    opts = "\n".join(
        f"  {o.get('id', i+1)}. {o.get('desc', o)}"
        for i, o in enumerate(r.options)
    )
    blocking_note = (
        f"\n⛔ 受阻任務：{', '.join(r.blocking)}" if r.blocking else ""
    )
    return (
        f"🔔 拍板請求 {r.req_id} | 來自 {r.requester}\n"
        f"問題：{r.question}\n"
        f"選項：\n{opts}"
        f"{blocking_note}\n\n"
        f"請依 decision-making steering 回覆（人話結論 + ```decision 塊）。"
    )


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _stamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%d")


def _parse_window(s: str) -> timedelta:
    """Parse duration string like '24h', '30m', '7d' to timedelta."""
    unit = s[-1].lower()
    try:
        n = int(s[:-1])
    except ValueError as e:
        raise ValueError(f"無效的時間格式：{s!r}") from e
    mapping = {"h": timedelta(hours=n), "m": timedelta(minutes=n), "d": timedelta(days=n)}
    if unit not in mapping:
        raise ValueError(f"不支援的時間單位：{unit!r}（支援 h/m/d）")
    return mapping[unit]


def _j(obj: Any) -> str:
    return json.dumps(obj, ensure_ascii=False)
