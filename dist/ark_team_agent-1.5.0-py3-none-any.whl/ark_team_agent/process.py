"""Process-based session management for Kiro CLI instances (Windows-native, no tmux).

[2026-06-15] 穩定性優化（從 game-team-agent 反向同步）：
- subprocess_exec 取代 subprocess_shell（消除 shell 中間層 pipe 問題）
- deque 取代手動 list 裁剪（消除 GC 壓力）
- send_input 加 BrokenPipeError 保護（pipe 斷裂不崩潰）
"""
from __future__ import annotations

import asyncio
import logging
import os
import sys
from collections import deque
from dataclasses import dataclass, field
from pathlib import Path

log = logging.getLogger(__name__)


@dataclass
class ManagedProcess:
    """Wraps an asyncio subprocess with stdin/stdout access and output capture."""

    name: str
    proc: asyncio.subprocess.Process | None = None
    _output_lines: deque[str] = field(default_factory=lambda: deque(maxlen=500))
    _reader_task: asyncio.Task | None = None
    _max_capture: int = 500  # ring buffer size
    _pipe_broken: bool = False  # [2026-06-15] 追蹤 pipe 狀態
    _output_count: int = 0  # 累計輸出行數（只增不減，用於活動偵測）

    @property
    def pid(self) -> int | None:
        return self.proc.pid if self.proc else None

    @property
    def output_count(self) -> int:
        """累計輸出行數（只增不減，用於活動偵測比較）。"""
        return self._output_count

    def is_alive(self) -> bool:
        """Process 是否存活。

        [P2] pipe_broken 不再直接判定 dead — process 可能還活著只是 stdin 斷了。
        health_loop 會透過 returncode 最終確認。
        """
        return self.proc is not None and self.proc.returncode is None

    async def start(self, cmd: str, cwd: str, *, env: dict[str, str] | None = None) -> None:
        """啟動子程序。

        [2026-06-15] 改用 subprocess_exec 取代 subprocess_shell。
        cmd 參數仍接收完整命令字串（由 backend.build_command 產生），
        內部分割為 list 傳給 exec。
        """
        # 強制子程序使用 UTF-8，避免 Windows CP950 亂碼
        full_env = {**os.environ, "PYTHONUTF8": "1", "PYTHONIOENCODING": "utf-8", **(env or {})}
        self._pipe_broken = False

        # 將命令字串分割為 list
        import shlex
        if sys.platform == "win32":
            cmd_parts = self._parse_windows_cmd(cmd)
        else:
            cmd_parts = shlex.split(cmd)

        kwargs: dict = {
            "stdin": asyncio.subprocess.PIPE,
            "stdout": asyncio.subprocess.PIPE,
            "stderr": asyncio.subprocess.STDOUT,
            "cwd": cwd,
            "env": full_env,
        }
        if sys.platform == "win32":
            kwargs["creationflags"] = 0x00000200  # CREATE_NEW_PROCESS_GROUP

        self._output_lines.clear()
        self.proc = await asyncio.create_subprocess_exec(*cmd_parts, **kwargs)
        self._reader_task = asyncio.create_task(self._read_output())
        log.info("Process started: %s (pid=%s, cwd=%s)", self.name, self.pid, cwd)

    @staticmethod
    def _parse_windows_cmd(cmd: str) -> list[str]:
        """Parse Windows command string to list, handling quoted paths."""
        parts: list[str] = []
        current = ""
        in_quote = False
        quote_char = ""
        for ch in cmd:
            if ch in ('"', "'") and not in_quote:
                in_quote = True
                quote_char = ch
            elif ch == quote_char and in_quote:
                in_quote = False
                quote_char = ""
            elif ch == " " and not in_quote:
                if current:
                    parts.append(current)
                    current = ""
            else:
                current += ch
        if current:
            parts.append(current)
        return parts

    async def _read_output(self) -> None:
        assert self.proc and self.proc.stdout
        try:
            while True:
                line = await self.proc.stdout.readline()
                if not line:
                    break
                decoded = line.decode("utf-8", errors="replace").rstrip("\n")
                # 處理 \r 覆寫：取最後一個片段（Kiro CLI 用 \r 更新同一行）
                if "\r" in decoded:
                    decoded = decoded.split("\r")[-1]
                decoded = decoded.rstrip("\r")
                if not decoded:
                    continue
                self._output_lines.append(decoded)
                self._output_count += 1
        except (asyncio.CancelledError, OSError):
            pass

    async def send_input(self, text: str) -> None:
        """發送文字到 stdin。

        [2026-06-15] pipe 保護 + drain timeout 防止 hang。
        """
        if not self.proc or not self.proc.stdin:
            raise RuntimeError(f"Process {self.name} has no stdin")
        if self._pipe_broken:
            raise RuntimeError(f"Process {self.name} pipe is broken")
        text = text.replace("\n", " ").replace("\r", " ")
        data = (text + "\n").encode("utf-8", errors="replace")
        try:
            self.proc.stdin.write(data)
            await asyncio.wait_for(self.proc.stdin.drain(), timeout=10.0)
        except asyncio.TimeoutError:
            log.warning("Process %s stdin drain timeout (10s)", self.name)
            self._pipe_broken = True
            raise RuntimeError(f"Process {self.name} stdin drain timeout") from None
        except (BrokenPipeError, ConnectionResetError, OSError) as e:
            log.warning("Process %s pipe broken during send: %s", self.name, e)
            self._pipe_broken = True
            raise RuntimeError(f"Process {self.name} pipe broken: {e}") from e

    def capture(self, lines: int = 200) -> str:
        recent = list(self._output_lines)[-lines:]
        return "\n".join(recent)

    async def drain_stdout(self, timeout: float = 5.0) -> int:
        """Drain remaining stdout with timeout. Returns lines drained."""
        if not self._reader_task:
            return 0
        count_before = self._output_count
        try:
            await asyncio.wait_for(self._reader_task, timeout=timeout)
        except (asyncio.TimeoutError, asyncio.CancelledError):
            pass
        return self._output_count - count_before

    async def kill(self) -> None:
        # Drain stdout first to capture last diagnostic output
        if self._reader_task and not self._reader_task.done():
            try:
                await asyncio.wait_for(self._reader_task, timeout=3.0)
            except (asyncio.TimeoutError, asyncio.CancelledError):
                self._reader_task.cancel()
                try:
                    await self._reader_task
                except asyncio.CancelledError:
                    pass
        elif self._reader_task:
            self._reader_task.cancel()
            try:
                await self._reader_task
            except asyncio.CancelledError:
                pass
        self._reader_task = None

        if self.proc and self.proc.returncode is None:
            try:
                self.proc.terminate()
                try:
                    await asyncio.wait_for(self.proc.wait(), timeout=5)
                except asyncio.TimeoutError:
                    self.proc.kill()
                    await self.proc.wait()
            except OSError:
                pass
            log.info("Process killed: %s (pid=%s)", self.name, self.pid)

        # [team-agent 2026-05-18] Close subprocess transport to prevent Windows GC ResourceWarning
        if self.proc:
            # Close pipe streams first
            for stream in (self.proc.stdin, self.proc.stdout, self.proc.stderr):
                if stream:
                    try:
                        stream.close()
                    except Exception:
                        pass
            # Close the underlying SubprocessTransport — prevents
            # "unclosed transport" ResourceWarning on Windows GC
            transport = getattr(self.proc, "_transport", None)
            if transport and not transport.is_closing():
                try:
                    transport.close()
                except Exception:
                    pass

        self.proc = None
        self._pipe_broken = False


# ── Registry for listing active processes ───────────────────

_active: dict[str, ManagedProcess] = {}


def register(mp: ManagedProcess) -> None:
    _active[mp.name] = mp


def unregister(name: str) -> None:
    _active.pop(name, None)


def list_active() -> list[str]:
    return [name for name, mp in _active.items() if mp.is_alive()]


def get(name: str) -> ManagedProcess | None:
    return _active.get(name)
