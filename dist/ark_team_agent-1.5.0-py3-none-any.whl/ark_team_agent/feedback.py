"""ECHO-inspired terminal feedback — 結構化錯誤分類與關鍵信號提取。

將 agent 執行 shell command 的 raw output 轉為結構化回饋，
供 Telegram 通知、失敗模式追蹤、跨 instance 報告使用。
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import datetime


@dataclass
class TerminalFeedback:
    """結構化終端回饋。"""

    command: str
    exit_code: int
    error_type: str | None = None  # syntax | runtime | permission | not_found | timeout
    key_signal: str = ""
    duration_ms: int = 0
    timestamp: datetime = field(default_factory=datetime.now)

    @property
    def success(self) -> bool:
        return self.exit_code == 0

    def summary(self) -> str:
        """一行摘要，適合 Telegram 通知或 log。"""
        if self.success:
            return f"✅ `{self.command}` (exit 0)"
        tag = self.error_type or "unknown"
        return f"❌ [{tag}] `{self.command}` — {self.key_signal}"


# ── 錯誤分類 patterns ──────────────────────────────────────────

_SYNTAX_RE = re.compile(
    r"SyntaxError|ParseError|unexpected token|unexpected EOF", re.I
)
_PERMISSION_RE = re.compile(
    r"Permission denied|EACCES|Operation not permitted", re.I
)
_NOT_FOUND_RE = re.compile(
    r"No such file|command not found|ModuleNotFoundError|ImportError|not recognized", re.I
)
_TIMEOUT_RE = re.compile(r"timed?\s*out|TimeoutError|deadline exceeded", re.I)


class FeedbackEnricher:
    """將 raw shell output 轉為 TerminalFeedback。"""

    @staticmethod
    def classify_error(stderr: str, exit_code: int) -> str | None:
        """分類錯誤類型，exit_code=0 回傳 None。"""
        if exit_code == 0:
            return None
        if _SYNTAX_RE.search(stderr):
            return "syntax"
        if _PERMISSION_RE.search(stderr):
            return "permission"
        if _NOT_FOUND_RE.search(stderr):
            return "not_found"
        if _TIMEOUT_RE.search(stderr):
            return "timeout"
        # 有 Traceback / Error 但不屬於上述 → runtime
        if re.search(r"Traceback|Error|Exception", stderr):
            return "runtime"
        return "runtime"  # 非零 exit code 預設 runtime

    @staticmethod
    def extract_key_signal(stderr: str) -> str:
        """從 stderr 提取一句話關鍵錯誤訊息。"""
        if not stderr.strip():
            return "non-zero exit code (no stderr)"
        lines = stderr.strip().splitlines()
        # 從後往前找第一個含 Error / Exception 的行
        for line in reversed(lines):
            stripped = line.strip()
            if re.search(r"Error|Exception|FAILED|fatal", stripped, re.I):
                return stripped[:200]
        # fallback: 最後一行非空
        for line in reversed(lines):
            if line.strip():
                return line.strip()[:200]
        return lines[-1].strip()[:200]

    @classmethod
    def enrich(
        cls,
        command: str,
        stdout: str,
        stderr: str,
        exit_code: int,
        duration_ms: int = 0,
    ) -> TerminalFeedback:
        """主入口：raw output → TerminalFeedback。"""
        # 合併 stdout+stderr 做分類（有些工具把錯誤寫到 stdout）
        combined = f"{stderr}\n{stdout}" if stderr else stdout
        error_type = cls.classify_error(combined, exit_code)
        key_signal = cls.extract_key_signal(combined) if exit_code != 0 else "success"

        return TerminalFeedback(
            command=command,
            exit_code=exit_code,
            error_type=error_type,
            key_signal=key_signal,
            duration_ms=duration_ms,
        )
