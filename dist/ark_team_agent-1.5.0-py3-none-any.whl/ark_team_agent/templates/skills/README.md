# templates/skills — 套件預設 Skill（自動同步，勿手改）

> ⚠️ **此目錄由 `scripts/sync_default_skills.py` 從 `ark-agent-skills` repo 自動拉取覆寫。**
> **不要手動編輯**任何 skill —— 改動請進上游單一真相來源：
> `https://github.com/igs-paddyyang-tw/ark-agent-skills`

## 單一真相來源（Single Source of Truth）

```
ark-agent-skills repo（canonical）
        │  build 前 scripts/sync_default_skills.py 拉取
        ▼
src/ark_team_agent/templates/skills/  ← 本目錄（勿手改）
        │  部署新團隊時複製
        ▼
各專案 .kiro/skills/
```

## 預設 skill 子集（6）

部署新團隊帶出去的最小「SDD 自進化」工具組：

| Skill | 角色 |
|-------|------|
| ark-grill-me | ① 拷問設計 |
| ark-superpowers | ② 產 spec/design/plan |
| ark-spec-executor | ③ 執行計畫 |
| ark-code-spec-validator | ④ 驗收 drift |
| ark-wiki-engine | 知識庫引擎 |
| ark-skill-creator | 元技能（自我擴充） |

## 手動同步

```bash
# 用遠端（需 GITHUB_TOKEN）
python scripts/sync_default_skills.py

# 用本地 clone
ARK_AGENT_SKILLS_DIR=/path/to/ark-agent-skills python scripts/sync_default_skills.py
```

build_release.py 會在打包前自動執行（`--skip-sync` 可略過）。
