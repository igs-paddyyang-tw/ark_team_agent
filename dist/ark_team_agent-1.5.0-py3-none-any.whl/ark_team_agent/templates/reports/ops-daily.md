---
title: "維運日報 {date}"
type: data
date: "{date}"
verdict: "{verdict}"
confidence: high
tags: [ops-daily, monitoring]
findings_count: { P0: 0, P1: 0, P2: 0, P3: 0 }
sources: [query_team_status, cost_guard]
created: "{date}"
updated: "{date}"
---

# 維運日報 {date}

## Verdict

**{verdict}** — {verdict_summary}

## 服務狀態

| Instance | 角色 | 狀態 |
|----------|------|------|
| {instance} | {role} | {status} |

**{running}/{total} running**

## 重啟紀錄

無重啟。

## 異常事件

無異常事件。

## 成本

| 項目 | 值 |
|------|-----|
| 已花費 | $0.00 |
| 每日上限 | $10.00 |
| 使用率 | 0% |

---
📚 參考：query_team_status(), cost_guard
