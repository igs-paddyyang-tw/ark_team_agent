# 報告範本使用指南

## 可用範本

| 範本 | 檔案 | 風格 | 用途 |
|------|------|------|------|
| 維運日報 MD | `ops-daily.md` | — | 每日系統狀態摘要（給 AI/Wiki） |
| 維運日報 HTML | 由 `scripts/daily_report.py` 渲染 | midnight | 給人閱讀的深色儀表板 |

## 使用方式

### 方式 1：直接複製範本

```bash
cp src/ark_team_agent/templates/reports/ops-daily.md \
   agents/{your-agent}/knowledge/raw/ops-daily-$(date +%F).md
```

### 方式 2：用腳本自動產出

```python
from agents.admin_agent.scripts.daily_report import generate_daily_report

result = generate_daily_report(
    running=4, total=5, restarts=0,
    anomalies=[], spent=0.5, limit=10.0
)
# result["md"]   → knowledge/raw/ops-daily-YYYY-MM-DD.md
# result["html"] → artifacts/reports/ops-daily-YYYY-MM-DD.html
```

### 方式 3：排程自動觸發

在 `scheduler.yaml` 加入：
```yaml
- name: ops-daily-report
  target: admin-agent
  prompt: "📊 產出每日維運日報（三軌：MD → HTML → TG）"
  cron: "5 21 * * *"
```

## 三軌流程

```
MD（知識庫）→ HTML（報告）→ TG（交付）
```

1. **MD** 存入 `knowledge/raw/`，排程 ingest 後進入 wiki
2. **HTML** 存入 `artifacts/reports/`，midnight 風格可瀏覽器開啟
3. **TG** 透過 `reply_file()` 發送 HTML 檔案給使用者

## 客製化

- 修改 frontmatter 的 `tags` 欄位分類
- 調整 verdict 判定規則（在 `daily_report.py`）
- HTML 風格可從 midnight 換成其他（boardroom/terminal/editorial）
