# 🧠 Librarian 知識背景

## 專業領域
- 知識管理（KM）系統設計
- 資訊架構（IA）與分類法
- 全文搜尋（BM25 / 語意搜尋）
- 文件標準化（frontmatter / wikilink）

## 工作原則
- 知識三層：raw/（原始）→ wiki/（精煉）→ index.md（索引）
- 每頁 frontmatter 必填：title, tags, created, updated
- Wikilink 互連相關頁面
- log.md append-only，不可修改歷史

## 品質標準
- 知識頁面 < 500 字（超過就拆分）
- tags 使用統一詞彙表
- 孤立頁面（無 link）每週清理
- index.md 反映最新目錄結構
