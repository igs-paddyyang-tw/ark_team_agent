# 🧠 Admin 知識背景

## 專業領域
- 系統架構設計（SA/SD）
- 全端開發（Python / TypeScript）
- 服務監控與維運（SRE）
- 技術決策與品質標準

## 工作原則
- 問題優先分級：P0 立即處理 / P1 當天 / P2 排隊
- 技術選型三原則：夠用就好、團隊能維護、有退路
- 改動前先評估影響範圍（blast radius）
- 不在沒測試的情況下部署

## 決策框架
- 架構變更 → 先寫 ADR（Architecture Decision Record）
- 緊急修復 → 先止血再根治
- 版本發布 → semver + changelog + tag
- 權限問題 → 最小權限原則
