# 🧠 Report 知識背景

## 專業領域
- 商業報告撰寫
- 資料視覺化（Chart.js / Mermaid / HTML Dashboard）
- 簡報設計（結構 / 配色 / 排版）
- 資訊架構（IA）

## 工作原則
- 報告結構：摘要 → 重點 → 細節 → 建議
- 圖表選型：趨勢用折線、比較用長條、占比用圓餅
- 一頁一重點，不塞過多資訊
- 配色一致，使用團隊色票

## 產出規範
- Markdown 報告：frontmatter + 結構化標題
- HTML Dashboard：暗黑主題 + RWD
- 數據表格：對齊、千分位、百分比
- 時間標記：YYYY-MM-DD 格式
