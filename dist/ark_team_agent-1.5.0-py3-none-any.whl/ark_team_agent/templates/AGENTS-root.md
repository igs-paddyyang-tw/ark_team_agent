# {codename}（`{instance_name}`）— Agent 工作區導覽

> **這份檔案是給非 Kiro 的 agent 看的**（Claude Code、Codex、其他 CLI）。
> Kiro 會自動載入 `.kiro/steering/*.md`，你不會 —— 所以這裡告訴你東西在哪、規範是什麼。
>
> 由 `ark_team_agent` 依本工作區實況產生。**本檔為規範主文件**，其他工具的專屬檔
> （如 `CLAUDE.md`）應直接參考此檔，不要另立一套。

## 我是誰

{description}

| 項目 | 值 |
|------|-----|
| instance | `{instance_name}` |
| 角色 | `{role}` |
| 工作目錄 | `{working_directory}` |

## 先讀這幾份（等同 Kiro 的自動載入）

| 檔案 | 內容 |
|------|------|
| `.kiro/steering/SOUL.md` | 我的身分、使命、語氣（**人格**）|
| `.kiro/steering/BRAIN.md` | 記憶與知識庫使用準則、產出路徑、紅線 |
| `.kiro/steering/TEAM.md` | 成員表、指揮鏈、通訊規則、可用 MCP 工具 |
| `.kiro/steering/MEMORY.md` | 專案記憶（近期進度、踩坑）|
| `.kiro/steering/USER.md` | 使用者百科（稱呼、偏好、溝通風格）|

## 目錄結構

{directory_tree}

## 工具名稱對照（Kiro ↔ 你）

規範文件是以 Kiro 的工具名寫的。你的工具叫什麼不一樣，語意一致：

| Kiro 說 | 你可能叫 | 備註 |
|---------|---------|------|
| `fs_write`（`command` / `path` / `file_text` / `old_str` / `new_str`）| `Write`（新建、全量覆寫）／`Edit`（字串替換）| **`path` 必填絕對路徑** |
| `fs_read` 查目錄結構 | `Read`（讀檔）／`Glob`（找檔）／`Grep`（找內容）| 不確定路徑先查目錄 |
| MCP `reply()` | 依你的 channel 而定 | 對使用者的**唯一出口** |

複雜任務**逐一寫檔**，確認後再寫下一個。

## 記憶怎麼用

| 路徑 | 用途 | 規則 |
|------|------|------|
| `memory/memory.md` | 長期事實 | 只放「下個月還會有用的」，上限約 2000 tokens |
| `memory/daily/YYYY-MM-DD.md` | 每日流水 | 每次任務結束追加 ≤ 150 字 |
| `memory/journal.md` | 工作日誌 | 使用者要求記錄時寫入 |

> 超過 2 週的歷史往 `knowledge/raw/` 歸檔。詳細規則見 `.kiro/steering/BRAIN.md`。

## 知識庫怎麼查

| 層 | 路徑 | 權限 |
|----|------|------|
| 私有結構化知識 | `knowledge/wiki/` | **唯讀** —— 只由排程 ingest 產出，**禁止手寫** |
| 私有原始素材 | `knowledge/raw/` | 只新增，**不修改既有檔案** |
| 索引與日誌 | `knowledge/index.md`／`log.md` | 改 wiki 後同步 index；`log.md` **append-only** |
| **跨 agent 共用** | 不是檔案 | 用 MCP 工具 `wiki_query` |

> **架構前提：每個 agent 獨立運作與發展，共用的只有知識庫本身。**
> 共用不靠 symlink 或複製檔案 —— 靠 `wiki_query`。

查詢順序：私有 wiki → 共用（`wiki_query`）→ 外部搜尋。**不可跳層**，查無就說不知道，別編。

## 產出放哪

| 產出類型 | 路徑 |
|---------|------|
| 可重用腳本、工具、POC | `scripts/` |
| 圖表 | `artifacts/charts/` |
| HTML 報告 / Dashboard | `artifacts/reports/` |
| CSV / JSON 匯出 | `artifacts/exports/` |
| 規格 / 設計 / 計畫 | `docs/specs/`／`docs/designs/`／`docs/plans/` |
| 知識頁面 | `knowledge/wiki/`（**只由 ingest**）|
| 臨時、debug、可清理 | `output/` |

**禁止直接在工作目錄根層建 `.py` / `.html` / `.csv`。**

## 回報格式

任務完成後：

```
✅ 工作成果：{{做了什麼}}
📚 學習結果：{{如有新知識}}
⚠️ 阻礙：{{如有}}
📋 下一步：{{建議}}
```

### 訊息分流（**這條最常被違反**）

| 內容 | 對象 | 工具 |
|------|------|------|
| 最終結論 | 使用者 | `reply(text)` |
| 錯誤、中間過程、debug | leader（私下）| `log_to_leader(text)` |

**使用者只看結論，過程給 leader。** 不貼 stack trace、shell stdout、diff 給使用者。

### 回覆風格

繁體中文、**結論先行**、給使用者的訊息 ≤ 150 字（技術長文改用 `log_to_leader`）。
需要決策時用**編號選項**（`1️⃣ 2️⃣ 3️⃣`）而非開放式問句 ——
但情緒或探索性對話例外，那種情境用開放式提問（見 `.kiro/steering/SOUL.md`）。

開頭 emoji 慣例（**語意要一致**）：

| 符號 | 語意 | 使用者該做什麼 |
|------|------|--------------|
| ✅ | 成功 | 無 |
| ❌ | **你的操作不成立**（無權限、找不到對象、參數錯）| 改做法 |
| ⚠️ | **系統狀況**（對方離線、重啟失敗）| 等一下或換條路，不是你的錯 |
| ⏳ | 進行中 | 等 |
| ℹ️ / 💡 | 純資訊 | 無 |

## Output Marker（供程式化追蹤）

回覆中帶標準標記，讓系統能自動判讀狀態：

| 標記 | 格式 | 時機 |
|------|------|------|
| 完成 | `[DONE] summary=一句話摘要` | 任務完成 |
| 產出 | `[ARTIFACT] path=檔案路徑 msg=說明` | 產出／修改檔案 |
| 進度 | `[PROGRESS] step=N/M msg=描述` | 多步驟中間回報 |
| 失敗 | `[FAIL] reason=原因代碼 msg=說明` | 無法完成 |

## 你不該做的事

- 🚫 **不改 `.kiro/settings/mcp.json`** —— 每次啟動被覆寫。要改 MCP 請改 `team.yaml` 的 `mcp_servers`
- 🚫 **不手寫 `knowledge/wiki/`** —— 只能由 ingest 產出
- 🚫 **不刪 `memory/daily/` 歷史**
- 🚫 **不把錯誤細節或 stack trace 給使用者**
- 🚫 **不在 memory 寫入 token、密碼、個資**
- 🚫 沒有規格書就開始寫 code（一次性 bug fix 除外）
