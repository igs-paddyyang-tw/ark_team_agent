# {project-name}

> 由 [ark-team-agent](https://github.com/igs-paddyyang-tw/team-agent) 管理的多 Agent 團隊。

## 團隊成員

| Agent | 角色 | 職責 |
|-------|------|------|
| pm-agent | leader | 架構規劃、任務拆解、品質把關 |
| dev-agent | worker | 編寫程式碼、實現功能、重構 |
| qa-agent | worker | 測試策略、自動化測試、Code Review |

## 快速開始

```bash
# 1. 安裝
pip install ark-team-agent

# 2. 編輯配置（選填：啟用 Telegram）
# vim team.yaml

# 3. 啟動
ark-team-agent team start

# 4. 查看狀態
ark-team-agent team status
```

## 目錄結構

```
.
├── team.yaml           # 團隊配置
├── scheduler.yaml      # 排程設定
├── .kiro/steering/     # 全域 steering（共用規範）
├── prompts/            # 提詞模板
├── tasks/              # 任務板
├── knowledge/          # 全域知識庫
├── docs/               # 全域文件
├── pm-agent/       # Leader 工作目錄
├── dev-agent/          # Developer 工作目錄
└── qa-agent/           # QA 工作目錄
```

## 常用指令

| 指令 | 說明 |
|------|------|
| `ark-team-agent team start` | 啟動所有 agent |
| `ark-team-agent team stop` | 停止所有 agent |
| `ark-team-agent team status` | 查看狀態 |
| `ark-team-agent send <name> <msg>` | 發送訊息給指定 agent |
| `ark-team-agent kiro status` | 查看 .kiro/ 檔案狀態 |

## 擴充

- 加人：在 `team.yaml` 的 instances 下新增 agent
- 加 Telegram：取消 channel + access 註解
- 加排程：編輯 `scheduler.yaml`
- 加知識庫：跑 `/ark-wiki-engine`
- 自訂 .kiro：跑 `/ark-kiro-init`
