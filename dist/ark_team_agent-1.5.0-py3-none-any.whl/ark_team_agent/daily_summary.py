"""Daily summary — aggregate events + costs and post to General Topic."""
from __future__ import annotations

import asyncio
import logging
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Awaitable, Callable

try:
    from zoneinfo import ZoneInfo
except ImportError:  # pragma: no cover
    ZoneInfo = None  # type: ignore

from .cost_guard import CostGuard
from .event_log import EventLog, EventType

log = logging.getLogger(__name__)


SendCallback = Callable[[str], Awaitable[None]]


def build_summary(
    event_log: EventLog,
    cost_guard: CostGuard | None,
    *,
    since_seconds: float = 86400,
    codenames: dict[str, str] | None = None,
) -> str:
    """Build a human-readable daily summary from event log + cost guard."""
    now = time.time()
    since = now - since_seconds

    # Aggregate events per instance
    stats: dict[str, dict] = {}
    for event in event_log.query(since=since, limit=10000):
        s = stats.setdefault(event.instance, {
            "restarts": 0,
            "crashes": 0,
            "hangs": 0,
            "errors": 0,
            "messages": 0,
        })
        if event.type == EventType.RESTART.value:
            s["restarts"] += 1
        elif event.type == EventType.CRASH.value:
            s["crashes"] += 1
        elif event.type == EventType.HANG.value:
            s["hangs"] += 1
        elif event.type == EventType.ERROR.value:
            s["errors"] += 1
        elif event.type == EventType.MESSAGE.value:
            s["messages"] += 1

    # Cost data (if available)
    today_costs: dict[str, float] = {}
    total_cost = 0.0
    cost_limit = 0.0
    if cost_guard:
        today_costs = cost_guard.get_today_all()
        total_cost = sum(today_costs.values())
        cost_limit = cost_guard.daily_limit_usd

    # Build date label in configured timezone
    if cost_guard:
        today_dt = datetime.now(cost_guard._tz)
    else:
        today_dt = datetime.now()
    today = today_dt.strftime("%Y-%m-%d")
    weekday = ["一", "二", "三", "四", "五", "六", "日"][today_dt.weekday()]

    # Codenames for display (dynamic from caller, or fallback to name)
    _codenames = codenames or {}

    def _display(name: str) -> str:
        return _codenames.get(name, f"🤖 {name}")

    # Render
    lines = [f"📊 <b>每日報告 — {today}（週{weekday}）</b>", ""]

    # ━━ 💰 成本 ━━
    lines.append("━━ 💰 成本 ━━")
    if cost_limit > 0:
        pct = int(total_cost / cost_limit * 100) if cost_limit else 0
        lines.append(f"今日：<b>${total_cost:.2f}</b> / ${cost_limit:.2f}（{pct}%）")
    elif total_cost > 0:
        lines.append(f"今日：<b>${total_cost:.2f}</b>")
    else:
        lines.append("今日：$0.00")

    # Top 3 spenders
    if today_costs:
        sorted_costs = sorted(today_costs.items(), key=lambda x: x[1], reverse=True)[:3]
        top_parts = [f"{_display(n).split(' ', 1)[-1]} ${c:.2f}" for n, c in sorted_costs if c > 0]
        if top_parts:
            lines.append(f"Top: {' | '.join(top_parts)}")
    lines.append("")

    # ━━ ⚠️ 異常 ━━ (only crashes, errors, restarts — NOT hangs)
    anomalies: list[str] = []
    total_hangs = 0
    all_instances = sorted(set(stats.keys()) | set(today_costs.keys()))
    for name in all_instances:
        s = stats.get(name, {})
        total_hangs += s.get("hangs", 0)
        issues: list[str] = []
        if s.get("crashes", 0):
            issues.append(f"{s['crashes']} 次崩潰")
        if s.get("errors", 0):
            issues.append(f"{s['errors']} 次錯誤")
        if s.get("restarts", 0):
            issues.append(f"{s['restarts']} 次重啟")
        if issues:
            icon = "🔴" if (s.get("crashes", 0) or s.get("errors", 0)) else "🟡"
            anomalies.append(f"• {icon} {_display(name)}：{', '.join(issues)}")

    if anomalies:
        lines.append("━━ ⚠️ 異常 ━━")
        lines.extend(anomalies)
        lines.append("💡 查詳情：GET /api/events?instance=&lt;name&gt;")
    else:
        lines.append("━━ ✅ 狀態 ━━")
        lines.append("全員正常運作")
    lines.append("")

    # ━━ 📈 活動量 ━━
    lines.append("━━ 📈 活動 ━━")
    total_messages = sum(s.get("messages", 0) for s in stats.values())
    total_events = sum(sum(s.values()) for s in stats.values())
    activity_parts = [f"訊息：{total_messages}", f"事件：{total_events}"]
    if total_hangs:
        activity_parts.append(f"閒置提醒：{total_hangs} 次")
    lines.append(" | ".join(activity_parts))

    return "\n".join(lines)


async def run_daily_summary_loop(
    event_log: EventLog,
    cost_guard: CostGuard | None,
    send_callback: SendCallback,
    *,
    hour: int = 21,
    minute: int = 0,
    tz_name: str = "Asia/Taipei",
    task_board=None,
    task_export_path: Path | None = None,
) -> None:
    """Background task — sleep until next HH:MM (in tz), send summary, repeat."""
    tz = None
    if ZoneInfo is not None:
        try:
            tz = ZoneInfo(tz_name)
        except Exception:
            log.warning("Unknown timezone %s, using local time", tz_name)

    while True:
        try:
            wait = _seconds_until(hour, minute, tz)
            log.info("Daily summary scheduled in %.0fs (next %02d:%02d)", wait, hour, minute)
            await asyncio.sleep(wait)

            try:
                summary = build_summary(event_log, cost_guard)
                await send_callback(summary)
            except Exception as e:
                log.warning("Failed to send daily summary: %s", e)

            # Export task board markdown
            if task_board and task_export_path:
                try:
                    task_board.export_markdown(task_export_path)
                except Exception as e:
                    log.warning("Failed to export task markdown: %s", e)

            # Sleep 60s so we don't re-fire in the same minute
            await asyncio.sleep(60)
        except asyncio.CancelledError:
            return


def _seconds_until(hour: int, minute: int, tz) -> float:
    now = datetime.now(tz) if tz else datetime.now()
    target = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
    if target <= now:
        target = target + timedelta(days=1)
    return (target - now).total_seconds()
