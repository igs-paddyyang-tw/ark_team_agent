"""File lock — prevent concurrent modification of task items."""
from __future__ import annotations

import json
import logging
import time
from pathlib import Path

log = logging.getLogger(__name__)

STALE_TIMEOUT = 1800  # 30 minutes


class FileLock:
    """Simple file-based locking for task items.

    Lock file format: {path}.lock containing JSON {"agent": "...", "acquired_at": "..."}
    """

    def acquire(self, path: str | Path, agent: str) -> bool:
        """Acquire lock on a file. Returns True if successful."""
        lock_path = Path(f"{path}.lock")
        if lock_path.exists():
            # Check if stale
            try:
                data = json.loads(lock_path.read_text(encoding="utf-8"))
                acquired = data.get("acquired_at", 0)
                if time.time() - acquired > STALE_TIMEOUT:
                    log.info("Releasing stale lock: %s (held by %s)", lock_path, data.get("agent"))
                    lock_path.unlink()
                else:
                    log.warning("Lock held by %s on %s", data.get("agent"), path)
                    return False
            except (json.JSONDecodeError, OSError):
                lock_path.unlink(missing_ok=True)

        lock_data = {"agent": agent, "acquired_at": time.time()}
        lock_path.parent.mkdir(parents=True, exist_ok=True)  # ensure parent dir exists
        lock_path.write_text(json.dumps(lock_data), encoding="utf-8")
        log.debug("Lock acquired: %s by %s", path, agent)
        return True

    def release(self, path: str | Path, agent: str) -> bool:
        """Release lock. Only the holder can release."""
        lock_path = Path(f"{path}.lock")
        if not lock_path.exists():
            return True
        try:
            data = json.loads(lock_path.read_text(encoding="utf-8"))
            if data.get("agent") == agent:
                lock_path.unlink()
                log.debug("Lock released: %s by %s", path, agent)
                return True
            log.warning("Cannot release lock on %s: held by %s, not %s", path, data.get("agent"), agent)
            return False
        except (json.JSONDecodeError, OSError):
            lock_path.unlink(missing_ok=True)
            return True

    def is_locked(self, path: str | Path) -> tuple[bool, str | None]:
        """Check if a file is locked. Returns (is_locked, holder_agent)."""
        lock_path = Path(f"{path}.lock")
        if not lock_path.exists():
            return False, None
        try:
            data = json.loads(lock_path.read_text(encoding="utf-8"))
            acquired = data.get("acquired_at", 0)
            if time.time() - acquired > STALE_TIMEOUT:
                lock_path.unlink()
                return False, None
            return True, data.get("agent")
        except (json.JSONDecodeError, OSError):
            return False, None

    def cleanup_stale(self, directory: Path, max_age_seconds: int = STALE_TIMEOUT) -> int:
        """Remove all stale .lock files in directory. Returns count removed."""
        removed = 0
        for lock_file in directory.rglob("*.lock"):
            try:
                data = json.loads(lock_file.read_text(encoding="utf-8"))
                if time.time() - data.get("acquired_at", 0) > max_age_seconds:
                    lock_file.unlink()
                    removed += 1
            except (json.JSONDecodeError, OSError):
                lock_file.unlink(missing_ok=True)
                removed += 1
        if removed:
            log.info("Cleaned up %d stale locks in %s", removed, directory)
        return removed
