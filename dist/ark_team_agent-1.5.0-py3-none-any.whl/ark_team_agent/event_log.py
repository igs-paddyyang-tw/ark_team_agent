"""Event log — persistent record of instance lifecycle, messages, and errors."""
from __future__ import annotations

import asyncio
import logging
import sqlite3
import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Iterator

log = logging.getLogger(__name__)


class EventType(str, Enum):
    START = "start"
    STOP = "stop"
    CRASH = "crash"
    RESTART = "restart"
    MESSAGE = "message"
    REPLY = "reply"
    HANG = "hang"
    COST_WARN = "cost_warn"
    ERROR = "error"
    # [1.2.7] chat trace：記錄「誰的訊息 → 路由到哪個 agent → 用什麼依據」（取經 hoyeah #11）
    ROUTE = "route"


@dataclass
class Event:
    timestamp: float
    instance: str
    type: str          # one of EventType values
    detail: str = ""
    source: str = ""   # optional origin (user / agent name / system)
    id: int | None = None


# Retention window: events older than this are purged on each cleanup pass.
_RETENTION_SECONDS = 30 * 24 * 3600  # 30 days


class EventLog:
    """SQLite-backed event recorder. Thread-safe via serialized asyncio writes."""

    _SCHEMA = """
    CREATE TABLE IF NOT EXISTS events (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp REAL NOT NULL,
        instance TEXT NOT NULL,
        type TEXT NOT NULL,
        detail TEXT NOT NULL DEFAULT '',
        source TEXT NOT NULL DEFAULT ''
    );
    CREATE INDEX IF NOT EXISTS idx_events_ts ON events(timestamp);
    CREATE INDEX IF NOT EXISTS idx_events_instance ON events(instance);
    CREATE INDEX IF NOT EXISTS idx_events_type ON events(type);
    """

    def __init__(self, db_path: Path) -> None:
        self._path = db_path
        self._write_lock = asyncio.Lock()
        self._init_db()

    def _init_db(self) -> None:
        self._path.parent.mkdir(parents=True, exist_ok=True)
        with self._connect() as conn:
            conn.executescript(self._SCHEMA)
            # WAL mode for better concurrency
            conn.execute("PRAGMA journal_mode=WAL")

    @contextmanager
    def _connect(self) -> Iterator[sqlite3.Connection]:
        conn = sqlite3.connect(self._path, timeout=5.0)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
            conn.commit()
        finally:
            conn.close()

    # ── Record ────────────────────────────────────────────────────

    async def record(
        self,
        instance: str,
        event_type: str | EventType,
        detail: str = "",
        source: str = "",
    ) -> None:
        """Write an event. Never raises — logs and swallows DB errors."""
        et = event_type.value if isinstance(event_type, EventType) else event_type
        ts = time.time()
        async with self._write_lock:
            try:
                await asyncio.to_thread(self._insert, ts, instance, et, detail, source)
            except Exception as e:
                log.warning("Failed to record event %s/%s: %s", instance, et, e)

    def _insert(self, ts: float, instance: str, et: str, detail: str, source: str) -> None:
        with self._connect() as conn:
            conn.execute(
                "INSERT INTO events (timestamp, instance, type, detail, source) VALUES (?, ?, ?, ?, ?)",
                (ts, instance, et, detail, source),
            )

    # Synchronous variant for non-async callers (e.g. signal handlers).
    def record_sync(
        self,
        instance: str,
        event_type: str | EventType,
        detail: str = "",
        source: str = "",
    ) -> None:
        et = event_type.value if isinstance(event_type, EventType) else event_type
        try:
            self._insert(time.time(), instance, et, detail, source)
        except Exception as e:
            log.warning("Failed to record event %s/%s: %s", instance, et, e)

    # ── Query ─────────────────────────────────────────────────────

    def query(
        self,
        instance: str | None = None,
        event_type: str | None = None,
        since: float | None = None,
        until: float | None = None,
        limit: int = 100,
    ) -> list[Event]:
        clauses: list[str] = []
        params: list = []
        if instance:
            clauses.append("instance = ?")
            params.append(instance)
        if event_type:
            clauses.append("type = ?")
            params.append(event_type)
        if since is not None:
            clauses.append("timestamp >= ?")
            params.append(since)
        if until is not None:
            clauses.append("timestamp <= ?")
            params.append(until)

        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        sql = f"SELECT * FROM events {where} ORDER BY timestamp DESC LIMIT ?"
        params.append(limit)

        with self._connect() as conn:
            rows = conn.execute(sql, params).fetchall()

        return [
            Event(
                id=r["id"],
                timestamp=r["timestamp"],
                instance=r["instance"],
                type=r["type"],
                detail=r["detail"],
                source=r["source"],
            )
            for r in rows
        ]

    def count(self, since: float | None = None) -> int:
        sql = "SELECT COUNT(*) FROM events"
        params: tuple = ()
        if since is not None:
            sql += " WHERE timestamp >= ?"
            params = (since,)
        with self._connect() as conn:
            return conn.execute(sql, params).fetchone()[0]

    # ── Cleanup ───────────────────────────────────────────────────

    def purge_older_than(self, seconds: int = _RETENTION_SECONDS) -> int:
        """Delete events older than `seconds`. Returns number of rows deleted."""
        cutoff = time.time() - seconds
        with self._connect() as conn:
            cursor = conn.execute("DELETE FROM events WHERE timestamp < ?", (cutoff,))
            return cursor.rowcount

    async def cleanup_loop(self, interval_hours: int = 6) -> None:
        """Background task: purge old events every N hours."""
        while True:
            try:
                await asyncio.sleep(interval_hours * 3600)
                deleted = await asyncio.to_thread(self.purge_older_than)
                if deleted:
                    log.info("Purged %d old events (> 30 days)", deleted)
            except asyncio.CancelledError:
                return
            except Exception as e:
                log.warning("Event cleanup failed: %s", e)


# ── Module-level singleton (lazy init) ────────────────────────────

_instance: EventLog | None = None


def get_event_log(db_path: Path | None = None) -> EventLog:
    """Get or create the singleton EventLog. Defaults to {home}/state/events.db."""
    global _instance
    if _instance is None:
        if db_path is None:
            from .config import get_state_dir
            db_path = get_state_dir() / "events.db"
        _instance = EventLog(db_path)
    return _instance


def reset_singleton() -> None:
    """Test helper — reset the singleton so tests can use isolated DBs."""
    global _instance
    _instance = None
