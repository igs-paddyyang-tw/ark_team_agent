"""服務重啟的單一入口 —— 判斷「誰會把我拉起來」，並據此決定要不要寫 flag。

## 為什麼需要這個模組（2026-08-18）

重啟這件事原本有**三套機制**散在程式碼裡，而每種環境只用其中一套：

| 環境 | 實際靠什麼重啟 | `restart.flag` 的角色 |
|------|--------------|---------------------|
| Linux + systemd | **SIGTERM → `Restart=always` 拉起** | 沒人讀，寫了只是垃圾 |
| `start-team.sh` / `.bat` | wrapper 的 while loop 讀 flag | **必要** |
| Windows（前景執行） | `team.py` 的輪詢迴圈讀 flag | **必要** |
| 沒有 supervisor | ❌ **沒有東西會拉起** —— SIGTERM 等於關機 | 沒人讀 |

**問題不是哪一套壞了，是看不出哪一套在生效。** 實測有人回報
「TG 重啟功能壞了 —— 會寫 `restart.flag` 但沒人讀它」：
結論錯的（Linux 上靠 SIGTERM，重啟是好的），但**推論過程完全合理** ——
程式碼裡看得到 flag 的讀取者（`watchdog.py`、win32 分支），
而那些讀取者在現行部署裡都沒在跑。加上磁碟上真的躺著 08-14 的殘留 flag，
任何人看到都會得出同樣的錯誤結論。

> 🔴 **殘留的檔案本身就是誤導的來源。** 治本不是「補一個讀取者」，
> 是讓「flag 存在」重新變成有意義的訊號，並且**把生效的機制講出來**。

## 這個模組做三件事

1. **`detect_supervisor()`** —— 判斷退出後誰會拉起我（可觀測、會寫 log）
2. **`request_restart()`** —— 唯一的重啟入口。只在 flag **真的會被消費**時才寫它
3. **`clear_stale_flag()`** —— 啟動與收尾時清掉殘留，讓 flag 不再累積

## 最重要的行為改變

**沒有 supervisor 時不再假裝重啟。** 原本 `/restart` 一律回「重啟中」，
但在前景執行的環境下 SIGTERM 只會讓服務**關掉不再起來** —— 使用者以為重啟了，
實際上服務死了。現在會明確回報這件事。
"""
from __future__ import annotations

import asyncio
import logging
import os
import signal
import sys
from pathlib import Path

log = logging.getLogger(__name__)

FLAG_NAME = "restart.flag"

#: `start-team.sh` / `.bat` 會設這個 —— 代表有 wrapper 的 while loop 在等
WRAPPER_ENV = "ARK_TEAM_AGENT_WRAPPER"


def _home() -> Path:
    from .config import get_home
    return Path(os.environ.get("ARK_TEAM_AGENT_HOME", str(get_home())))


def flag_path() -> Path:
    return _home() / FLAG_NAME


def detect_supervisor() -> tuple[str, str, bool]:
    """判斷「進程退出後誰會把我拉起來」。

    回傳 `(mechanism, 人看得懂的說明, flag 是否會被消費)`。

    偵測依據（**都是外部環境給的事實，不是猜的**）：

    - `ARK_TEAM_AGENT_WRAPPER` —— `start-team.sh` / `.bat` 自己設的
    - `INVOCATION_ID` —— **systemd 對每個 unit 都會設**，是判斷「被 systemd 管著」
      最可靠的訊號（比找 `systemctl` 執行檔可靠 —— 那只證明工具在，不證明我被它管）
    - `sys.platform == "win32"` —— win32 分支有自己的輪詢迴圈
    """
    if os.environ.get(WRAPPER_ENV):
        return ("wrapper", "start-team.sh 的 while loop 會讀 restart.flag 後重啟", True)
    if os.environ.get("INVOCATION_ID"):
        return ("systemd", "systemd 會依 Restart= 設定拉起（本專案範本是 always）", False)
    if sys.platform == "win32":
        return ("poll", "win32 輪詢迴圈會讀 restart.flag 後結束，由外層腳本重啟", True)
    return ("none", "找不到 supervisor —— 進程退出後不會自動起來", False)


def describe_supervisor() -> str:
    """給 log 與 TG 回覆用的一行說明。"""
    mech, why, _ = detect_supervisor()
    return f"{mech}（{why}）"


def clear_stale_flag(*, reason: str = "startup") -> bool:
    """清掉殘留的 `restart.flag`。回傳是否真的刪了東西。

    在**啟動**與**收尾**各叫一次：
    - 啟動時清 → 上一輪留下的殘留不會影響這一輪（wrapper 環境尤其重要，
      殘留會讓它多重啟一次）
    - 收尾時清 → 「我已經因為它而結束」，flag 的使命就到這裡

    ⚠️ **wrapper 環境的收尾不可以清** —— 那份 flag 正是要給 wrapper 讀的。
    呼叫端要自己判斷（`request_restart` 回傳的 `consumed` 就是這個用途）。
    """
    f = flag_path()
    try:
        if f.exists():
            f.unlink()
            log.info("清除殘留的 %s（%s）", FLAG_NAME, reason)
            return True
    except OSError as e:
        log.warning("無法清除 %s：%s", FLAG_NAME, e)
    return False


def request_restart(*, delay: float = 1.0, source: str = "") -> dict[str, object]:
    """請求整個服務重啟 —— **唯一入口**（TG `/restart` 與 `/api/restart-service` 共用）。

    原本這段邏輯在 `telegram.py` 與 `api.py` **各有一份**，而且不一致
    （延遲 1.0s vs 0.5s）。兩份實作必然漂移，所以收斂成一個。

    行為：
    1. 判斷 supervisor
    2. **只在 flag 會被消費時才寫它** —— systemd 環境不寫，才不會累積殘留
    3. 排程 SIGTERM（graceful shutdown → 由 supervisor 拉起）

    回傳 dict 供呼叫端據實回報，**含 `will_restart`** ——
    沒有 supervisor 時它是 `False`，呼叫端必須據此改變說法，
    不可以再說「重啟中」（那會讓使用者以為服務會回來，而它不會）。
    """
    mech, why, consumed = detect_supervisor()

    wrote_flag = False
    if consumed:
        try:
            flag_path().write_text("", encoding="utf-8")
            wrote_flag = True
        except OSError as e:
            log.warning("無法寫入 %s：%s", FLAG_NAME, e)
    else:
        # 不寫。寫了沒人讀，只會變成下一個人的誤導來源。
        clear_stale_flag(reason="restart requested（本環境不使用 flag）")

    will_restart = mech != "none"
    log.info(
        "重啟請求%s：supervisor=%s / flag=%s / 預期會被拉起=%s",
        f"（來源 {source}）" if source else "", mech,
        "已寫入" if wrote_flag else "不使用", will_restart,
    )
    if not will_restart:
        log.warning(
            "⚠️ 找不到 supervisor —— 這次退出後服務**不會自動起來**。"
            "若這不是你要的，請用 systemd／start-team.sh 啟動。"
        )

    async def _terminate() -> None:
        await asyncio.sleep(delay)
        os.kill(os.getpid(), signal.SIGTERM)

    try:
        asyncio.get_running_loop().create_task(_terminate())
    except RuntimeError:
        # 沒有 running loop（同步呼叫端）→ 直接送訊號
        os.kill(os.getpid(), signal.SIGTERM)

    return {
        "ok": True, "mechanism": mech, "why": why,
        "flag_written": wrote_flag, "will_restart": will_restart,
    }
