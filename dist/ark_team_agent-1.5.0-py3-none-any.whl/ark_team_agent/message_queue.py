"""Per-topic message queue with exponential backoff and flood control."""
from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from enum import Enum

log = logging.getLogger(__name__)

MAX_MESSAGE_LENGTH = 4096
WORKER_IDLE_WAIT = 0.2        # seconds between idle checks
WORKER_BETWEEN = 0.05         # seconds between successful sends
INITIAL_BACKOFF = 1.0         # seconds
MAX_BACKOFF = 30.0            # seconds cap
FLOOD_THRESHOLD = 10.0        # seconds — drop status_update above this backoff


class MessageType(str, Enum):
    CONTENT = "content"
    STATUS_UPDATE = "status_update"
    STATUS_CLEAR = "status_clear"


@dataclass
class QueuedMessage:
    type: MessageType = MessageType.CONTENT
    text: str = ""
    edit_message_id: int | None = None
    parse_mode: str | None = None
    reply_markup: object | None = None


@dataclass
class _QueueState:
    """Per chat+thread queue state."""
    chat_id: int
    thread_id: int | None
    items: list[QueuedMessage] = field(default_factory=list)
    backoff: float = INITIAL_BACKOFF
    backoff_until: float = 0.0
    worker: asyncio.Task | None = None


class MessageQueue:
    """Manages per-topic message queues with 429 handling and flood control.

    Usage:
        queue = MessageQueue(bot)
        queue.start()
        queue.enqueue(chat_id, thread_id, QueuedMessage(text="hello"))
        ...
        queue.stop()
    """

    def __init__(self, bot) -> None:
        self._bot = bot
        self._queues: dict[str, _QueueState] = {}
        self._stopped = True

    def _key(self, chat_id: int, thread_id: int | None) -> str:
        return f"{chat_id}:{thread_id or ''}"

    def _get_or_create(self, chat_id: int, thread_id: int | None) -> _QueueState:
        key = self._key(chat_id, thread_id)
        if key not in self._queues:
            self._queues[key] = _QueueState(chat_id=chat_id, thread_id=thread_id)
        return self._queues[key]

    def enqueue(self, chat_id: int, thread_id: int | None, msg: QueuedMessage) -> None:
        """Add a message to the queue. Starts worker if needed."""
        state = self._get_or_create(chat_id, thread_id)
        state.items.append(msg)
        if not self._stopped and (state.worker is None or state.worker.done()):
            state.worker = asyncio.create_task(self._run_worker(state))

    def start(self) -> None:
        self._stopped = False
        for state in self._queues.values():
            if state.items and (state.worker is None or state.worker.done()):
                state.worker = asyncio.create_task(self._run_worker(state))
        log.info("MessageQueue started")

    def stop(self) -> None:
        self._stopped = True
        for state in self._queues.values():
            state.items.clear()
            if state.worker and not state.worker.done():
                state.worker.cancel()
        log.info("MessageQueue stopped")

    async def _run_worker(self, state: _QueueState) -> None:
        """Worker loop for a single chat+thread queue."""
        while not self._stopped:
            try:
                # Apply backoff
                now = time.time()
                if state.backoff_until > now:
                    await asyncio.sleep(min(state.backoff_until - now, 0.5))
                    continue

                # Flood control: drop status_update when backoff is high
                if state.backoff > FLOOD_THRESHOLD:
                    before = len(state.items)
                    state.items = [m for m in state.items if m.type != MessageType.STATUS_UPDATE]
                    dropped = before - len(state.items)
                    if dropped:
                        state.backoff = INITIAL_BACKOFF
                        state.backoff_until = 0
                        log.warning("Flood control: dropped %d status_update for %s:%s",
                                    dropped, state.chat_id, state.thread_id)

                if not state.items:
                    await asyncio.sleep(WORKER_IDLE_WAIT)
                    # Exit worker if still empty
                    if not state.items:
                        return
                    continue

                # Take next item(s)
                msg = state.items.pop(0)

                # Merge adjacent content messages (same parse_mode, no edit)
                if msg.type == MessageType.CONTENT and msg.text and not msg.edit_message_id:
                    while (state.items
                           and state.items[0].type == MessageType.CONTENT
                           and state.items[0].text
                           and not state.items[0].edit_message_id
                           and state.items[0].parse_mode == msg.parse_mode
                           and len(msg.text) + len(state.items[0].text) + 1 < MAX_MESSAGE_LENGTH):
                        msg.text += "\n" + state.items.pop(0).text

                await self._send(state, msg)

                # Success — reset backoff
                state.backoff = INITIAL_BACKOFF
                state.backoff_until = 0
                await asyncio.sleep(WORKER_BETWEEN)

            except asyncio.CancelledError:
                return
            except _RateLimitError as e:
                # Re-insert at front
                state.items.insert(0, msg)
                state.backoff_until = time.time() + state.backoff
                log.warning("429 for %s:%s — backoff %.1fs (retry_after=%s)",
                            state.chat_id, state.thread_id, state.backoff, e.retry_after)
                if e.retry_after:
                    state.backoff = max(state.backoff, float(e.retry_after) + 0.5)
                state.backoff = min(state.backoff * 2, MAX_BACKOFF)
            except Exception as e:
                # Non-retryable — drop and continue
                log.warning("Message dropped for %s:%s: %s", state.chat_id, state.thread_id, e)
                state.backoff = INITIAL_BACKOFF
                state.backoff_until = 0
                await asyncio.sleep(WORKER_BETWEEN)

    async def _send(self, state: _QueueState, msg: QueuedMessage) -> None:
        """Execute the actual Telegram API call."""
        try:
            if msg.type == MessageType.STATUS_CLEAR:
                return  # no-op, just clears tracker state

            if msg.edit_message_id:
                kwargs: dict = {"chat_id": state.chat_id, "message_id": msg.edit_message_id, "text": msg.text}
                if msg.parse_mode:
                    kwargs["parse_mode"] = msg.parse_mode
                await self._bot.edit_message_text(**kwargs)
            else:
                kwargs = {"chat_id": state.chat_id, "text": msg.text}
                if state.thread_id:
                    kwargs["message_thread_id"] = state.thread_id
                if msg.parse_mode:
                    kwargs["parse_mode"] = msg.parse_mode
                if msg.reply_markup:
                    kwargs["reply_markup"] = msg.reply_markup
                # Split if too long
                text = kwargs.pop("text")
                chunks = [text[i:i + MAX_MESSAGE_LENGTH] for i in range(0, len(text), MAX_MESSAGE_LENGTH)]
                for chunk in chunks:
                    await self._bot.send_message(text=chunk, **kwargs)

        except Exception as e:
            retry_after = getattr(e, "retry_after", None)
            if retry_after is not None:
                raise _RateLimitError(retry_after) from e
            # Check for 429 in message
            if "429" in str(e) or "too many requests" in str(e).lower():
                raise _RateLimitError(None) from e
            raise


class _RateLimitError(Exception):
    """Internal: signals a 429 for the worker to handle."""
    def __init__(self, retry_after: float | None) -> None:
        self.retry_after = retry_after
        super().__init__(f"Rate limited (retry_after={retry_after})")
