"""steering/MEMORY.md 的日期分節歸檔（確定式，無 LLM）。

## 為什麼需要這個

`.kiro/steering/MEMORY.md` 是 **always-on 載入**的檔案 —— 每次對話都吃 context。
它自己的開頭寫著「歸檔規則：> 2 週的段落移到 knowledge/ 目錄」，
但**沒有任何機制執行**。實測 ark-agent 636 行、pm-agent 626 行。

既有的 `_builtin:memory-consolidate`（1.2.4）只處理 `memory/daily/*.md` 與
`memory/memory.md` —— 後者實測只有 45 行，根本不是問題所在。

## 為什麼用確定式而非 LLM 蒸餾

N5 的 one-pager 建議「先 prompt job（靠 agent 自律）後內建確定式」。
但這裡的工作是**搬移**不是**摘要** —— 分節有 `## YYYY-MM-DD` 結構，
日期比對是機械的。用 LLM 會引入「摘要漏掉重要事實」的風險，
而搬移只要「歸檔檔案寫成功才動原檔」就零資訊損失。

## 安全設計（這個模組會改動 always-on 的規範檔，謹慎）

1. **只動日期分節** —— `## 專案快照`、`## 待辦`、`## 基礎設施` 這類
   非日期標題絕不碰（它們是當前狀態，不是歷史）
2. **先寫歸檔、再改原檔** —— 歸檔寫失敗就整個放棄，不動原檔
3. **原處留指標行** —— 讀 MEMORY.md 的人知道歷史去哪了，不會以為被刪了
4. **append 不覆寫** —— 同月多次歸檔會累加，不會互相蓋掉
"""
from __future__ import annotations

import logging
import re
from datetime import date
from pathlib import Path

log = logging.getLogger(__name__)

#: 日期分節標題：`## 2026-08-14 — 標題`、`## 2026-08-07~10 — 標題`、
#: `## 2026-08-14（下午）— 標題` 都要能認。只取開頭的 `YYYY-MM-DD`。
_DATE_HEADING = re.compile(r"^##\s+(\d{4})-(\d{2})-(\d{2})")

#: 分節邊界：任何 `## ` 開頭（`###` 不算，那是分節內的子標題）
_SECTION_START = re.compile(r"^##\s+(?!#)")


def _split_sections(text: str) -> tuple[str, list[tuple[str, str]]]:
    """把文件切成「前言」與「`## ` 分節清單」。

    回傳 `(preamble, [(heading_line, body_including_heading), ...])`。
    前言是第一個 `## ` 之前的內容（含 `# 標題` 與說明），**永不歸檔**。
    """
    lines = text.splitlines(keepends=True)
    starts = [i for i, ln in enumerate(lines) if _SECTION_START.match(ln)]
    if not starts:
        return text, []
    preamble = "".join(lines[: starts[0]])
    sections: list[tuple[str, str]] = []
    for idx, s in enumerate(starts):
        end = starts[idx + 1] if idx + 1 < len(starts) else len(lines)
        sections.append((lines[s].rstrip("\n"), "".join(lines[s:end])))
    return preamble, sections


def _section_date(heading: str) -> date | None:
    m = _DATE_HEADING.match(heading)
    if not m:
        return None
    try:
        return date(int(m[1]), int(m[2]), int(m[3]))
    except ValueError:
        return None


def archive_memory_sections(
    memory_path: Path,
    archive_dir: Path,
    *,
    today: date,
    keep_days: int = 14,
    min_bytes: int = 8000,
    dry_run: bool = False,
) -> tuple[int, list[str]]:
    """把 `memory_path` 中日期早於 `keep_days` 的分節搬到 `archive_dir`。

    Args:
        memory_path: 通常是 `<wd>/.kiro/steering/MEMORY.md`
        archive_dir: 通常是 `<wd>/knowledge/raw/memory-archive/`
        today: 基準日（由呼叫端傳入，方便測試且不在此模組取系統時間）
        keep_days: 保留天數，預設 14（對應 MEMORY.md 自己寫的「> 2 週」）
        min_bytes: 檔案小於此值就不處理，預設 8000（~2000 tokens）。
            **這個門檻是刻意的** —— 目的是降低 always-on 的 context 佔用，
            小檔案本來就沒有這個問題，硬歸檔只會在 9 行的檔案裡塞一段指標，
            淨效果是變吵。實測 10 個 agent 裡只有 2 個真的超標。
        dry_run: 只回報不寫檔

    Returns:
        `(歸檔分節數, 被歸檔的標題清單)`。找不到檔案或無可歸檔時回 `(0, [])`。

    非日期分節（`## 專案快照`、`## 待辦` 等）**一律保留** ——
    它們描述當前狀態，不是歷史。
    """
    if not memory_path.is_file():
        return 0, []
    try:
        if memory_path.stat().st_size < min_bytes:
            return 0, []
    except OSError:
        return 0, []
    try:
        text = memory_path.read_text(encoding="utf-8")
    except OSError as exc:
        log.warning("memory-archive: 讀取失敗 %s: %s", memory_path, exc)
        return 0, []

    preamble, sections = _split_sections(text)
    if not sections:
        return 0, []

    keep: list[str] = []
    # 依「歸檔到哪個月檔」分組，讓同月的段落集中在一份
    by_month: dict[str, list[str]] = {}
    titles: list[str] = []
    for heading, body in sections:
        d = _section_date(heading)
        if d is None or (today - d).days <= keep_days:
            keep.append(body)
            continue
        by_month.setdefault(f"{d.year:04d}-{d.month:02d}", []).append(body)
        titles.append(heading.lstrip("# ").strip())

    if not titles:
        return 0, []
    if dry_run:
        return len(titles), titles

    # ① 先寫歸檔 —— 全部成功才動原檔（失敗就整個放棄，零資訊損失）
    try:
        archive_dir.mkdir(parents=True, exist_ok=True)
        for month, bodies in sorted(by_month.items()):
            target = archive_dir / f"{month}.md"
            head = "" if target.exists() else (
                f"# 記憶歸檔 {month}\n\n"
                f"> 由 `_builtin:memory-consolidate` 自動從 `.kiro/steering/MEMORY.md` 搬移。\n"
                f"> **append-only** —— 不要編輯既有段落。\n\n"
            )
            with target.open("a", encoding="utf-8") as fh:
                fh.write(head + "".join(bodies))
    except OSError as exc:
        log.warning("memory-archive: 寫入歸檔失敗，原檔不動 (%s)", exc)
        return 0, []

    # ② 原處留指標 —— 讓讀的人知道歷史去哪了，不會以為被刪
    months = "、".join(f"`{m}.md`" for m in sorted(by_month))
    pointer = (
        f"\n## 📦 已歸檔的歷史\n\n"
        f"{len(titles)} 個段落已搬到 `knowledge/raw/memory-archive/`（{months}）——\n"
        f"依本檔開頭的「> 2 週歸檔」規則自動處理，內容未刪除。\n\n"
    )
    try:
        memory_path.write_text(preamble + "".join(keep) + pointer, encoding="utf-8")
    except OSError as exc:
        log.warning("memory-archive: 原檔寫入失敗（歸檔已完成，可能重複）: %s", exc)
        return 0, []

    log.info("memory-archive: %s 歸檔 %d 個段落 → %s",
             memory_path.name, len(titles), archive_dir)
    return len(titles), titles
