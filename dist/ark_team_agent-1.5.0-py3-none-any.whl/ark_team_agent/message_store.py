"""SQLite-backed persistent message queue for Telegram sends.

Features:
- SQLite WAL mode: 重啟後未送出訊息自動恢復
- 全域 retry_after: 一個 429 暫停所有發送
- 過期清理: 超過 expire_hours 的訊息自動刪除
- 毒訊息保護: max_retries 後標記 failed（不再重試）
- 長訊息自動分段: 4096 char limit
"""
from __future__ import annotations

import asyncio
import logging
import re
import sqlite3
import time
from dataclasses import dataclass, field
from pathlib import Path

log = logging.getLogger(__name__)

MAX_MESSAGE_LENGTH = 4096
MAX_RETRIES = 3
EXPIRE_HOURS = 24


@dataclass
class PendingMessage:
    """A message waiting to be sent."""

    chat_id: int
    text: str
    topic_id: int | None = None
    parse_mode: str = "HTML"
    created_at: float = field(default_factory=time.time)
    retries: int = 0
    rowid: int | None = None


class MessageStore:
    """SQLite-backed message queue with rate limiting and 429 retry.

    Usage:
        store = MessageStore(send_fn, db_path="state/message_queue.db")
        store.enqueue(chat_id, text, topic_id)
        await store.start()  # begins drain loop
        ...
        store.stop()
    """

    def __init__(
        self,
        send_fn,
        *,
        db_path: str = "state/message_queue.db",
        max_per_second: int = 25,
        expire_hours: int = EXPIRE_HOURS,
    ) -> None:
        self._send = send_fn
        self._semaphore = asyncio.Semaphore(max_per_second)
        self._retry_after: float = 0  # global pause timestamp
        self._task: asyncio.Task | None = None
        self._expire_hours = expire_hours
        self._stopped = False

        # Init SQLite
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(db_path, timeout=5.0)
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("""
            CREATE TABLE IF NOT EXISTS outbox (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                chat_id INTEGER NOT NULL,
                text TEXT NOT NULL,
                topic_id INTEGER,
                parse_mode TEXT DEFAULT 'HTML',
                created_at REAL NOT NULL,
                retries INTEGER DEFAULT 0,
                status TEXT DEFAULT 'pending'
            )
        """)
        self._conn.execute("CREATE INDEX IF NOT EXISTS idx_outbox_status ON outbox(status)")
        self._conn.commit()

        # Log pending count on init
        count = self._conn.execute("SELECT COUNT(*) FROM outbox WHERE status='pending'").fetchone()[0]
        if count > 0:
            log.info("MessageStore: %d pending messages recovered from disk", count)

    def enqueue(self, chat_id: int, text: str, topic_id: int | None = None,
                parse_mode: str = "HTML") -> None:
        """Add message to persistent queue. Auto-splits if too long."""
        chunks = self._split(text)
        now = time.time()
        for i, chunk in enumerate(chunks):
            if len(chunks) > 1:
                chunk = f"[{i + 1}/{len(chunks)}]\n{chunk}"
            self._conn.execute(
                "INSERT INTO outbox (chat_id, text, topic_id, parse_mode, created_at) VALUES (?, ?, ?, ?, ?)",
                (chat_id, chunk, topic_id, parse_mode, now),
            )
        self._conn.commit()

    @property
    def pending_count(self) -> int:
        return self._conn.execute("SELECT COUNT(*) FROM outbox WHERE status='pending'").fetchone()[0]

    async def start(self) -> None:
        """Start the drain loop."""
        self._stopped = False
        if self._task and not self._task.done():
            return
        self._task = asyncio.create_task(self._drain_loop())
        log.info("MessageStore drain loop started")

    def stop(self) -> None:
        """Stop the drain loop."""
        self._stopped = True
        if self._task and not self._task.done():
            self._task.cancel()
        log.info("MessageStore stopped")

    async def _drain_loop(self) -> None:
        """Continuously drain pending messages from SQLite."""
        try:
            while not self._stopped:
                # Global rate limit pause
                if self._retry_after > time.time():
                    await asyncio.sleep(self._retry_after - time.time())
                    continue

                # Fetch pending messages (oldest first, batch of 5)
                rows = self._conn.execute(
                    "SELECT id, chat_id, text, topic_id, parse_mode, created_at, retries "
                    "FROM outbox WHERE status='pending' ORDER BY id LIMIT 5"
                ).fetchall()

                if not rows:
                    self._cleanup_expired()
                    await asyncio.sleep(0.5)
                    continue

                for row in rows:
                    if self._stopped:
                        return
                    msg = PendingMessage(
                        chat_id=row[1], text=row[2], topic_id=row[3],
                        parse_mode=row[4], created_at=row[5], retries=row[6], rowid=row[0],
                    )
                    async with self._semaphore:
                        success = await self._try_send(msg)
                        if success:
                            self._conn.execute("DELETE FROM outbox WHERE id=?", (msg.rowid,))
                            self._conn.commit()
                        else:
                            # 429 — break batch, wait for retry_after
                            break
                    # Inter-message delay
                    await asyncio.sleep(0.1)

        except asyncio.CancelledError:
            pass
        except Exception as e:
            log.error("MessageStore drain loop crashed: %s", e)

    async def _try_send(self, msg: PendingMessage) -> bool:
        """Attempt to send. Returns True on success, False on 429."""
        try:
            kwargs: dict = {"chat_id": msg.chat_id, "text": msg.text}
            if msg.topic_id:
                kwargs["message_thread_id"] = msg.topic_id
            if msg.parse_mode:
                kwargs["parse_mode"] = msg.parse_mode
            await self._send(**kwargs)
            return True
        except Exception as e:
            err_str = str(e)
            # 429 rate limit
            if "429" in err_str or "Retry" in err_str or "too many requests" in err_str.lower():
                m = re.search(r"[Rr]etry[- ]?[Aa]fter\D*(\d+)", err_str)
                wait = int(m.group(1)) if m else 30
                self._retry_after = time.time() + wait
                log.warning("429 rate limited, global pause %ds", wait)
                return False
            # 400 Bad Request — try without parse_mode
            if "400" in err_str or "Bad Request" in err_str:
                try:
                    kwargs_plain: dict = {"chat_id": msg.chat_id, "text": msg.text}
                    if msg.topic_id:
                        kwargs_plain["message_thread_id"] = msg.topic_id
                    await self._send(**kwargs_plain)
                    return True
                except Exception:
                    pass
            # Other error — increment retries
            new_retries = msg.retries + 1
            if new_retries >= MAX_RETRIES:
                log.warning("Message %d failed %d times, marking failed", msg.rowid, new_retries)
                self._conn.execute("UPDATE outbox SET status='failed', retries=? WHERE id=?",
                                   (new_retries, msg.rowid))
            else:
                self._conn.execute("UPDATE outbox SET retries=? WHERE id=?",
                                   (new_retries, msg.rowid))
            self._conn.commit()
            return True  # Don't block other messages

    def _cleanup_expired(self) -> None:
        """Remove messages older than expire_hours."""
        cutoff = time.time() - (self._expire_hours * 3600)
        deleted = self._conn.execute("DELETE FROM outbox WHERE created_at < ?", (cutoff,)).rowcount
        if deleted:
            self._conn.commit()
            log.info("MessageStore: cleaned %d expired messages", deleted)

    @staticmethod
    def _split(text: str) -> list[str]:
        """Split text into chunks respecting newlines."""
        if len(text) <= MAX_MESSAGE_LENGTH:
            return [text]
        chunks: list[str] = []
        while text:
            if len(text) <= MAX_MESSAGE_LENGTH:
                chunks.append(text)
                break
            # Find last newline before limit
            cut = text.rfind("\n", 0, MAX_MESSAGE_LENGTH)
            if cut <= 0:
                cut = MAX_MESSAGE_LENGTH
            chunks.append(text[:cut])
            text = text[cut:].lstrip("\n")
        return chunks
