"""A2A Router — 核心協調器（整合 Graph + Discovery + FeedbackLoop）。"""
from __future__ import annotations

import logging
import uuid
from typing import Callable, Awaitable

from .a2a_protocol import TaskHandoff
from .a2a_graph import TaskGraph, CycleError
from .a2a_discovery import AgentDiscovery
from .a2a_feedback import FeedbackLoop, MaxIterationsExceeded
from .config import TeamConfig

log = logging.getLogger(__name__)


class A2ARouter:
    """接收 TaskHandoff → 依賴管理 → 能力匹配 → 執行 → 自動修復。"""

    def __init__(
        self,
        config: TeamConfig,
        spawn_fn: Callable[[str, str], Awaitable[str | None]],
    ) -> None:
        self.graph = TaskGraph()
        self.discovery = AgentDiscovery(config)
        self.spawn_fn = spawn_fn

    async def dispatch(self, handoff: TaskHandoff) -> str:
        """接收 handoff → 檢查依賴 → 匹配 agent → spawn。

        回傳：任務處理結果或狀態訊息。
        """
        # 自動生成 task_id（如果沒有）
        if not handoff.task_id:
            handoff.task_id = f"task-{uuid.uuid4().hex[:8]}"

        # 加入依賴圖
        try:
            self.graph.add_task(handoff)
        except CycleError as e:
            return f"❌ 循環依賴：{e}"

        # 檢查是否 ready
        if not self.graph.is_ready(handoff.task_id):
            log.info(
                "Task %s queued (waiting for %s)",
                handoff.task_id, handoff.depends_on,
            )
            return f"⏳ 已排入佇列，等待依賴完成：{handoff.depends_on}"

        return await self._execute(handoff)

    async def _execute(self, task: TaskHandoff) -> str:
        """執行單一任務。"""
        # 能力匹配
        target = task.to_agent
        if target == "auto":
            target = self.discovery.match(task)
            task.to_agent = target

        # 組裝 context（注入依賴的 output）
        context_parts = [task.title]
        if task.context:
            context_parts.append(task.context)
        for dep_id in task.depends_on:
            dep_output = self.graph.get_output(dep_id)
            if dep_output:
                context_parts.append(
                    f"[依賴 {dep_id} 的產出]:\n{dep_output[:500]}"
                )
        if task.acceptance_criteria:
            context_parts.append(f"驗收條件：{task.acceptance_criteria}")

        message = "\n\n".join(context_parts)

        # Mark running
        self.graph.mark_running(task.task_id)
        log.info("Executing %s → %s", task.task_id, target)

        # Spawn
        output = await self.spawn_fn(target, message)

        if output:
            # 有 feedback loop？
            if task.loop_back:
                # 先讓 reviewer 驗收
                review_msg = (
                    f"驗證任務：{task.title}\n\n"
                    f"產出：{output[:1000]}\n\n"
                    f"驗收條件：{task.acceptance_criteria}\n\n"
                    f"請回覆 PASS 或說明失敗原因。"
                )
                review_result = await self.spawn_fn(task.loop_back, review_msg)
                if review_result and not _is_pass(review_result):
                    # 進入 feedback loop
                    return await self._feedback(task, review_result)

            # 標記完成 + 解鎖下游
            return await self._on_complete(task.task_id, output)
        else:
            return await self._on_failed(task.task_id, "agent returned empty")

    async def _feedback(self, task: TaskHandoff, failure_reason: str) -> str:
        """進入 FeedbackLoop 自動修復。"""
        log.info(
            "Task %s entering feedback loop (loop_back=%s)",
            task.task_id, task.loop_back,
        )
        try:
            output = await FeedbackLoop(self.spawn_fn).run(task, failure_reason)
            return await self._on_complete(task.task_id, output)
        except MaxIterationsExceeded as e:
            return await self._on_failed(task.task_id, str(e))

    async def _on_complete(self, task_id: str, output: str) -> str:
        """任務完成 → 更新圖 → 執行解鎖的下游。"""
        unlocked = self.graph.mark_complete(task_id, output)
        log.info("Task %s completed, unlocked %d downstream", task_id, len(unlocked))

        # 自動執行解鎖的下游任務
        downstream_results: list[str] = []
        for next_task in unlocked:
            result = await self._execute(next_task)
            downstream_results.append(f"{next_task.task_id}: {result[:100]}")

        if downstream_results:
            return f"✅ {task_id} 完成，已觸發 {len(downstream_results)} 個下游任務"
        return f"✅ {task_id} 完成"

    async def _on_failed(self, task_id: str, reason: str) -> str:
        """任務失敗。"""
        self.graph.mark_failed(task_id, reason)
        log.warning("Task %s failed: %s", task_id, reason[:100])
        return f"❌ {task_id} 失敗：{reason[:200]}"

    @property
    def status_summary(self) -> str:
        """簡短狀態摘要。"""
        return (
            f"pending={self.graph.pending_count} "
            f"running={self.graph.running_count}"
        )


def _is_pass(text: str) -> bool:
    """判斷 review 結果是否為通過。"""
    upper = text.upper()
    return any(kw in upper for kw in ["PASS", "通過", "[DONE]", "✅", "LGTM"])
