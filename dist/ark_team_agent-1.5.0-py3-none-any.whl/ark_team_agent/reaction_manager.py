"""ReactionManager — 統一管理 Telegram 訊息 Reaction 生命週期。

使用 Telegram 合法 emoji：👀→🔥→👍/💔
"""
from __future__ import annotations

import logging

log = logging.getLogger(__name__)

# Telegram 合法 Reaction emoji
REACTION_RECEIVED = "👀"
REACTION_PROCESSING = "🔥"
REACTION_DELEGATING = "⚡"
REACTION_SUCCESS = "👍"
REACTION_FAILURE = "💔"


class ReactionManager:
    """Manages message reaction lifecycle per instance (instance-centric)."""

    def __init__(self, bot=None):
        self._bot = bot
        self._targets: dict[str, tuple[int, int]] = {}  # instance → (chat_id, msg_id)

    def set_bot(self, bot) -> None:
        """延遲設定 bot（啟動後才有）。"""
        self._bot = bot

    async def mark_received(self, instance: str, chat_id: int, message_id: int) -> None:
        """收到訊息 → 👀。"""
        self._targets[instance] = (chat_id, message_id)
        await self._set(chat_id, message_id, REACTION_RECEIVED)

    async def mark_processing(self, instance: str) -> None:
        """開始處理 → 🔥。"""
        target = self._targets.get(instance)
        if target:
            await self._set(*target, REACTION_PROCESSING)

    async def mark_delegating(self, instance: str) -> None:
        """派工給子 Agent → ⚡。"""
        target = self._targets.get(instance)
        if target:
            await self._set(*target, REACTION_DELEGATING)

    async def mark_done(self, instance: str, success: bool = True) -> None:
        """完成 → 👍 或 💔。"""
        target = self._targets.pop(instance, None)
        if target:
            emoji = REACTION_SUCCESS if success else REACTION_FAILURE
            await self._set(*target, emoji)

    def stop_all(self) -> None:
        """清除所有追蹤（shutdown 時呼叫）。"""
        self._targets.clear()

    async def _set(self, chat_id: int, message_id: int, emoji: str) -> None:
        """底層 set_message_reaction，失敗靜默。"""
        if not self._bot:
            return
        try:
            from telegram import ReactionTypeEmoji
            await self._bot.set_message_reaction(
                chat_id=chat_id,
                message_id=message_id,
                reaction=[ReactionTypeEmoji(emoji=emoji)],
                is_big=False,
            )
        except Exception as e:
            log.debug("set_reaction failed (chat=%d, msg=%d): %s", chat_id, message_id, e)
