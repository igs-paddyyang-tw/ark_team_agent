"""Telegram Bot adapter — route messages to instances, relay output back."""
from __future__ import annotations

import asyncio
import logging
import os
import re
from dataclasses import dataclass, field
from datetime import datetime as _dt

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, constants
from telegram.ext import Application, MessageHandler, CommandHandler, CallbackQueryHandler, ContextTypes, filters

from .session import SessionManager
from .planner import ConversationPlanner, Action
from .event_log import EventType, get_event_log
from .chat_router import ChatRouter, RouteResult, _MENTION_PATTERN
from .daemon import InstanceStatus

log = logging.getLogger(__name__)

# Telegram 單則訊息硬上限 4096 字；留安全邊界給 HTML 標籤
TG_MSG_LIMIT = 4000

# [1.2.3] ANSI / 控制字元清洗：所有送往 TG 的文字在最終出口過一次，
# 避免終端顏色碼（如 \x1b[0m、\x1b[38;5;8m）殘留成可見的「[0m」「[38;5;8m」外洩。
_ANSI_CSI = re.compile(r"\x1b\[[0-9;?]*[A-Za-z]")
_ANSI_OSC = re.compile(r"\x1b\][^\x07\x1b]*(?:\x07|\x1b\\)")
_ANSI_OTHER = re.compile(r"\x1b[^[\]A-Za-z]?[A-Za-z]?")
_CTRL_CHARS = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")


def _strip_ansi(text: str) -> str:
    """移除 ANSI escape / 控制字元（送 TG 前的最終清洗，永不拋例外）。"""
    if not text:
        return text
    try:
        text = _ANSI_CSI.sub("", text)
        text = _ANSI_OSC.sub("", text)
        text = _ANSI_OTHER.sub("", text)
        text = _CTRL_CHARS.sub("", text)
        return text
    except Exception:  # noqa: BLE001
        return text


def _chunk_text(text: str, limit: int = TG_MSG_LIMIT) -> list[str]:
    """[v1.1.5 FR-1] 把超過 TG 上限的長文依「行邊界」切成多段，避免靜默截斷。

    - 盡量不切在行中間；單行本身超長才硬切（罕見，如超長 code）。
    - 回傳至少一段；<=limit 時原樣回傳單段。

    Author: ark-agent
    """
    if len(text) <= limit:
        return [text]
    chunks: list[str] = []
    cur = ""
    for line in text.split("\n"):
        if len(line) > limit:
            if cur:
                chunks.append(cur.rstrip("\n"))
                cur = ""
            for i in range(0, len(line), limit):
                chunks.append(line[i:i + limit])
            continue
        if len(cur) + len(line) + 1 > limit:
            chunks.append(cur.rstrip("\n"))
            cur = line + "\n"
        else:
            cur += line + "\n"
    if cur.strip():
        chunks.append(cur.rstrip("\n"))
    return chunks


def keyword_routes_for(routing_cfg: object, bound_instance: str) -> dict[str, list[str]]:
    """依 `private_chat_routing.mode` 決定私訊是否走 keyword 路由。

    回傳可用的 `keyword_routes`；**空 dict 代表不使用 keyword**（一律送 bound_instance）。

    為什麼要分流 —— `keyword_routes` 在 1.2.23 之前從未生效（`TeamConfig` 沒有
    `private_chat_routing` 欄位，`getattr` 永遠回 `{}`）。接上之後若無條件套用，
    設 `mode: <入口 agent>` 的部署會突然改變行為：nana 的入口 agent 有完整的
    7 種意圖分類提詞，而 keyword 會在它之前把「技術」「bug」直接攔去別的 agent
    —— 那是把一個沉睡的備援變成會改變既有行為的攔截器。

    - `mode: keyword` → 用 `keyword_routes`（空的話發警告，因為那等於沒設定）
    - 其他 / 未設      → 回 `{}`，套件不介入，交給入口 agent 自己判斷

    `fallback` 與 `confidence_threshold` **不在此處理** —— confidence 是 agent 的
    LLM 判斷結果，不會回傳給套件，套件無從得知該不該降級。那兩個值由 agent 的
    steering（如 `intent-classify.md`）自行遵循。

    Author: ark-agent（1.2.23）
    """
    if not isinstance(routing_cfg, dict):
        return {}
    if str(routing_cfg.get("mode") or "").strip().lower() != "keyword":
        return {}
    routes = routing_cfg.get("keyword_routes")
    if not isinstance(routes, dict) or not routes:
        log.warning(
            "private_chat_routing.mode=keyword 但沒有可用的 keyword_routes"
            " → 一律送 %s。要嘛補 keyword_routes，要嘛把 mode 改成入口 agent。",
            bound_instance,
        )
        return {}
    return routes


@dataclass
class TelegramConfig:
    bot_token_env: str = "TELEGRAM_BOT_TOKEN"
    group_id: int = 0
    general_topic_id: int = 1
    allowed_users: list[int] = field(default_factory=list)
    mode: str = "locked"                 # locked | group | open（存取模式）
    poll_interval: float = 3.0
    max_message_length: int = 4000


class TelegramAdapter:
    """Bridges Telegram forum topics ↔ ark-team-agent instances."""

    # Global rate limiting constraints (tuned for Telegram Bot API limits):
    # - 30 messages/second to different chats (we stay well below)
    # - 1 message/second per chat
    _MAX_CONCURRENT = 5
    _RATE_LIMIT_DELAY = 0.1  # base delay between sends (10/s upper bound)

    def __init__(self, config: TelegramConfig, daemon) -> None:
        self.config = config
        self.daemon = daemon
        self._app: Application | None = None
        self._poll_tasks: dict[str, asyncio.Task] = {}
        # topic_id → instance name
        self._topic_map: dict[int, str] = {}
        # [claude-code 2026-08-06] FR-3：instance → 最近來源 (chat_id, topic_id)，供回覆定址跟隨來源
        self._last_source: dict[str, tuple[int, int]] = {}
        # instance name → private chat_id
        self._private_chat_map: dict[str, int] = {}
        # SQLite message store (set by team.py after init)
        self._message_store = None
        # instance name → last seen output length
        self._output_cursors: dict[str, int] = {}
        # Persist sessions to {home}/state/sessions.db
        from .config import get_state_dir
        from .conversation_log import ConversationLog

        self._conv_log = ConversationLog(db_path=get_state_dir() / "conversations.db")

        def _on_session_expire(session):
            """Session 過期時自動摘要到 conversation_log。"""
            if session.instance and session.turns:
                summary = ConversationLog.summarize_session(session)
                self._conv_log.record(
                    instance=session.instance,
                    user_id=session.user_id,
                    summary=summary,
                    turn_count=len(session.turns),
                )

        self._sessions = SessionManager(
            db_path=get_state_dir() / "sessions.db",
            on_expire=_on_session_expire,
        )
        self._planner: ConversationPlanner | None = None
        # Rate limiting: semaphore controls concurrent Telegram API calls.
        self._send_semaphore = asyncio.Semaphore(self._MAX_CONCURRENT)
        # Message queue for output flush (non-interactive sends)
        self._queue = None  # initialized in start() after bot is ready
        # Skill growth detector: tracks tool calls per instance
        from .skill_growth import SkillGrowthDetector
        self._skill_growth = SkillGrowthDetector()
        # Build codenames/titles dynamically from instance config
        dyn_codenames, dyn_titles = self._build_codenames(
            getattr(daemon, "config", None)
        )
        self._CODENAMES = dyn_codenames
        self._TITLES = dyn_titles
        # Hang detection daily counter: "instance:YYYY-MM-DD" → count
        self._hang_daily_count: dict[str, int] = {}
        # ToolTracker per instance (for reply edit support)
        self._output_trackers: dict[str, "ToolTracker"] = {}  # noqa: F821
        # Typing indicator tasks: instance → asyncio.Task
        self._typing_tasks: dict[str, asyncio.Task] = {}
        # Reaction manager (統一管理 message reaction 生命週期)
        from .reaction_manager import ReactionManager
        self._reactions = ReactionManager()

    @staticmethod
    def _build_codenames(team_config) -> tuple[dict[str, str], dict[str, str]]:
        """Parse codename and title from instance description.

        Expected description format: "{emoji} {代號} — {職稱描述}"
        e.g. "🧠 專案經理 — 需求分析、規格書、派工、驗收"

        Returns (codenames, titles) dicts keyed by instance name.
        Falls back gracefully if description is missing or malformed.
        """
        if not team_config or not hasattr(team_config, "instances"):
            return {}, {}
        codenames: dict[str, str] = {}
        titles: dict[str, str] = {}
        for name, ic in team_config.instances.items():
            desc = (ic.description or "").strip()
            if not desc:
                continue
            if "—" in desc:
                short, rest = desc.split("—", 1)
                codenames[name] = short.strip()
                titles[name] = rest.strip()
            else:
                # No separator — use full description as codename
                codenames[name] = desc
        return codenames, titles

    def _start_typing(self, instance: str, chat_id: int, thread_id: int | None = None, action: str = "typing") -> None:
        """Start sending chat action every 4s for an instance. Cancel previous if any."""
        self._stop_typing(instance)
        self._typing_tasks[instance] = asyncio.create_task(
            self._typing_loop(instance, chat_id, thread_id, action)
        )

    def _stop_typing(self, instance: str) -> None:
        """Stop typing indicator for an instance."""
        task = self._typing_tasks.pop(instance, None)
        if task and not task.done():
            task.cancel()

    async def _typing_loop(self, instance: str, chat_id: int, thread_id: int | None, action: str = "typing") -> None:
        """Send chat action every 4 seconds until cancelled."""
        try:
            while True:
                try:
                    await self._app.bot.send_chat_action(
                        chat_id=chat_id,
                        action=action,
                        message_thread_id=thread_id,
                    )
                except Exception:
                    pass
                await asyncio.sleep(4)
        except asyncio.CancelledError:
            return

    async def _set_reaction(self, chat_id: int, message_id: int, emoji: str) -> None:
        """Set a message reaction. Delegates to ReactionManager."""
        await self._reactions._set(chat_id, message_id, emoji)

    def _store_reaction_target(self, instance: str, chat_id: int, message_id: int) -> None:
        """Remember the message to react to when instance finishes."""
        self._reactions._targets[instance] = (chat_id, message_id)

    async def _finish_reaction(self, instance: str, success: bool = True) -> None:
        """Set ✅ or ❌ reaction on the original user message."""
        await self._reactions.mark_done(instance, success)

    def bind_topic(self, topic_id: int, instance_name: str, general: bool = False) -> None:
        self._topic_map[topic_id] = instance_name
        if general:
            self._general_instance = instance_name

    async def create_topic_for_instance(self, instance_name: str, display_name: str) -> int | None:
        """動態建立 Forum Topic 並綁定到 instance。回傳 topic_id 或 None。"""
        if not self._app or not self.config.group_id:
            return None
        try:
            result = await self._app.bot.create_forum_topic(
                chat_id=self.config.group_id,
                name=display_name,
            )
            topic_id = result.message_thread_id
            self.bind_topic(topic_id, instance_name)
            log.info("Created forum topic %d for %s (%s)", topic_id, instance_name, display_name)
            return topic_id
        except Exception as e:
            log.warning("Failed to create forum topic for %s: %s", instance_name, e)
            # [v1.1.3 P1-6] 記入降級清單 → health 端點可見（避免靜默降級）
            dg = getattr(self.daemon, "degraded", None)
            if isinstance(dg, list):
                msg = f"topic_creation_failed: {instance_name}"
                if msg not in dg:
                    dg.append(msg)
            return None

    def bind_private_chat(self, instance_name: str, chat_id: int) -> None:
        self._private_chat_map[instance_name] = chat_id

    def _user_display(self, user_id: int) -> str:
        """Convert user ID to display name for logs."""
        # Currently single-user system; extend via team.yaml user_names if needed
        if user_id in self.config.allowed_users or user_id == list(self._private_chat_map.values())[0] if self._private_chat_map else False:
            return "Paddy"
        return f"user:{user_id}"

    def _instance_display(self, instance: str | None) -> str:
        """Convert instance name to codename for logs."""
        if not instance:
            return "?"
        return self._CODENAMES.get(instance, instance)

    def _resolve_instance(self, topic_id: int | None) -> str | None:
        if topic_id is not None and topic_id in self._topic_map:
            return self._topic_map[topic_id]
        # Fallback to general_topic instance (leader)
        return getattr(self, "_general_instance", None)

    def _check_access(self, user_id: int, chat_id: int | None = None) -> bool:
        """檢查存取權限，依 access.mode 決定策略。

        - open   : 全放行
        - group  : 來自本群組（chat_id == group_id）的訊息全放行，不看 user_id
                   （群組管理員匿名發言 GroupAnonymousBot 也因此自動通過）
        - locked : （預設）allowed_users 為空則全開，否則僅名單內 user 可對話
        """
        mode = getattr(self.config, "mode", "locked")
        if mode == "open":
            return True
        if mode == "group" and chat_id is not None and chat_id == self.config.group_id:
            return True
        if not self.config.allowed_users:
            return True
        return user_id in self.config.allowed_users

    def _check_admin(self, user_id: int) -> bool:
        """管理指令（/allow /deny）專用：嚴格白名單，不受 mode 影響。"""
        return bool(self.config.allowed_users) and user_id in self.config.allowed_users

    def _find_multi_user_entry(self) -> str | None:
        """回傳第一個 multi_user 入口 instance（優先 admin/manager），供未綁定私聊預設路由。

        Author: claude-code
        """
        candidates: list[tuple[str, str]] = []
        for n, ic in self.daemon.entity_instances().items():
            if getattr(ic, "multi_user", False):
                candidates.append((ic.role or "worker", n))
        if not candidates:
            return None
        priority = {"admin": 0, "manager": 1, "leader": 2, "worker": 3}
        candidates.sort(key=lambda x: priority.get(x[0], 9))
        return candidates[0][1]

    async def _send_to_topic(self, topic_id: int, text: str, **kwargs) -> "telegram.Message":
        """Send message to topic. General Topic (id=1) doesn't use thread_id. Rate-limited + 429-aware."""
        base = {"chat_id": self.config.group_id}
        if topic_id != self.config.general_topic_id:
            base["message_thread_id"] = topic_id
        text = _strip_ansi(text)  # [1.2.3] 最終出口清 ANSI/控制字元
        # [v1.1.5 FR-1] 超長分段送（reply_markup 只掛最後一段）
        chunks = _chunk_text(text)
        result = None
        for i, chunk in enumerate(chunks):
            p = {**base, "text": (chunk if i == 0 else f"↪️ {chunk}"), **kwargs}
            if i < len(chunks) - 1:
                p.pop("reply_markup", None)
            result = await self._rate_limited_send(p)
        return result

    async def _send_to_private(self, chat_id: int, text: str, **kwargs) -> "telegram.Message":
        """Send message to a private chat. Uses persistent store if available."""
        text = _strip_ansi(text)  # [1.2.3] 最終出口清 ANSI/控制字元
        # [v1.1.5 FR-1] 超長分段
        chunks = _chunk_text(text)
        # 使用 SQLite 持久化 queue（重啟不丟訊息）— 不支援 reply_markup 等複雜參數
        if self._message_store and "reply_markup" not in kwargs:
            for i, chunk in enumerate(chunks):
                self._message_store.enqueue(
                    chat_id, (chunk if i == 0 else f"↪️ {chunk}"),
                    parse_mode=kwargs.get("parse_mode", "HTML"),
                )
            return None  # type: ignore — drain loop 會非同步送出
        result = None
        for i, chunk in enumerate(chunks):
            p = {"chat_id": chat_id, "text": (chunk if i == 0 else f"↪️ {chunk}"), **kwargs}
            if i < len(chunks) - 1:
                p.pop("reply_markup", None)
            result = await self._rate_limited_send(p)
        return result

    async def _send_photo_to_private(self, chat_id: int, photo_path: str, caption: str = "") -> "telegram.Message":
        """Send photo to a private chat. Rate-limited."""
        async with self._send_semaphore:
            with open(photo_path, "rb") as f:
                result = await self._app.bot.send_photo(
                    chat_id=chat_id, photo=f, caption=caption or None,
                )
            await asyncio.sleep(self._RATE_LIMIT_DELAY)
            return result

    async def _send_photo_to_topic(self, topic_id: int, photo_path: str, caption: str = "") -> "telegram.Message":
        """Send photo to a topic. Rate-limited."""
        async with self._send_semaphore:
            kwargs: dict = {"chat_id": self.config.group_id}
            if topic_id != self.config.general_topic_id:
                kwargs["message_thread_id"] = topic_id
            with open(photo_path, "rb") as f:
                result = await self._app.bot.send_photo(photo=f, caption=caption or None, **kwargs)
            await asyncio.sleep(self._RATE_LIMIT_DELAY)
            return result

    # 資安白名單：TG 只允許傳送整理過的報告格式
    ALLOWED_FILE_TYPES: set[str] = {".html", ".md"}

    async def _send_document_to_private(self, chat_id: int, file_path: str, caption: str = "") -> "telegram.Message":
        """Send document/file to a private chat. Rate-limited. 資安限制：只允許 .html/.md。"""
        from pathlib import Path
        p = Path(file_path)
        if p.suffix.lower() not in self.ALLOWED_FILE_TYPES:
            log.warning("⛔ 拒絕傳送非白名單檔案到 TG：%s（允許：%s）", p.name, self.ALLOWED_FILE_TYPES)
            raise ValueError(f"檔案類型 '{p.suffix}' 不允許傳送到 TG")
        async with self._send_semaphore:
            with open(file_path, "rb") as f:
                result = await self._app.bot.send_document(
                    chat_id=chat_id, document=f, caption=caption or None,
                )
            await asyncio.sleep(self._RATE_LIMIT_DELAY)
            return result

    async def _send_document_to_topic(self, topic_id: int, file_path: str, caption: str = "") -> "telegram.Message":
        """Send document/file to a topic. Rate-limited. 資安限制：只允許 .html/.md。"""
        from pathlib import Path
        p = Path(file_path)
        if p.suffix.lower() not in self.ALLOWED_FILE_TYPES:
            log.warning("⛔ 拒絕傳送非白名單檔案到 TG：%s（允許：%s）", p.name, self.ALLOWED_FILE_TYPES)
            raise ValueError(f"檔案類型 '{p.suffix}' 不允許傳送到 TG")
        async with self._send_semaphore:
            kwargs: dict = {"chat_id": self.config.group_id}
            if topic_id != self.config.general_topic_id:
                kwargs["message_thread_id"] = topic_id
            with open(file_path, "rb") as f:
                result = await self._app.bot.send_document(document=f, caption=caption or None, **kwargs)
            await asyncio.sleep(self._RATE_LIMIT_DELAY)
            return result

    async def _rate_limited_send(self, params: dict, *, max_retries: int = 4) -> "telegram.Message":
        """Send via bot.send_message with semaphore throttling, 429 Retry-After, and timeout retry."""
        from telegram.error import TimedOut, NetworkError, BadRequest

        async with self._send_semaphore:
            for attempt in range(max_retries + 1):
                try:
                    result = await self._app.bot.send_message(**params)
                    await asyncio.sleep(self._RATE_LIMIT_DELAY)
                    return result
                except BadRequest as e:
                    # [team-agent 2026-05-18] BadRequest (4xx) is not retryable.
                    # Common cause: invalid HTML entities from agent output.
                    # Fallback: strip HTML and resend as plain text.
                    if "parse_mode" in params:
                        log.warning("Telegram BadRequest (%s) → fallback to plain text", e.message)
                        plain_params = {**params}
                        plain_params.pop("parse_mode", None)
                        plain_params["text"] = _strip_html(params["text"])
                        try:
                            result = await self._app.bot.send_message(**plain_params)
                            await asyncio.sleep(self._RATE_LIMIT_DELAY)
                            return result
                        except Exception:
                            pass
                    raise
                except TimedOut:
                    if attempt < max_retries:
                        wait = 2.0 * (attempt + 1)
                        log.warning("Telegram TimedOut → retry in %.1fs (attempt %d/%d)",
                                    wait, attempt + 1, max_retries)
                        await asyncio.sleep(wait)
                        continue
                    raise
                except NetworkError as e:
                    # Covers ReadTimeout from httpx/httpcore wrapped by python-telegram-bot
                    if attempt < max_retries:
                        wait = 2.0 * (attempt + 1)
                        log.warning("Telegram NetworkError (%s) → retry in %.1fs (attempt %d/%d)",
                                    type(e).__name__, wait, attempt + 1, max_retries)
                        await asyncio.sleep(wait)
                        continue
                    raise
                except Exception as e:
                    # python-telegram-bot raises RetryAfter with retry_after attribute
                    retry_after = getattr(e, "retry_after", None)
                    if retry_after is not None and attempt < max_retries:
                        wait = float(retry_after) + 0.5
                        log.warning("Telegram 429 → waiting %.1fs (attempt %d/%d)",
                                    wait, attempt + 1, max_retries)
                        await asyncio.sleep(wait)
                        continue
                    # Not a retryable error or out of retries — propagate
                    raise

    async def preflight_check(self) -> list[str]:
        """[v1.1.3 P1-6] 啟動前檢查 bot 群組權限，回傳降級警告清單（不拋錯）。

        缺 can_manage_topics 時 forum topic 全建失敗、訊息 fallback 私訊，
        但 health 仍可能顯示 ok —— 此檢查讓「靜默降級」在啟動時就浮上來。

        Author: ark-agent
        """
        warns: list[str] = []
        if not self.config.group_id:
            return warns  # 純私聊模式，無群組 topic 需求
        try:
            me = await self._app.bot.get_me()
            member = await self._app.bot.get_chat_member(self.config.group_id, me.id)
            status = getattr(member, "status", "")
            if status != "administrator":
                warns.append(
                    f"topic_unavailable: Bot 非群組管理員（status={status}），無法建立/管理 forum topic"
                )
            elif not getattr(member, "can_manage_topics", False):
                warns.append("topic_unavailable: Bot 缺 can_manage_topics 權限，無法建立 forum topic")
        except Exception as e:  # noqa: BLE001
            warns.append(f"preflight_failed: 無法查詢 bot 群組權限：{e}")
        return warns

    async def start(self) -> None:
        token = os.environ.get(self.config.bot_token_env, "")
        if not token:
            raise RuntimeError(
                f"❌ 缺少 Telegram Bot Token\n"
                f"  環境變數 {self.config.bot_token_env} 未設定\n"
                f"  解決方法：\n"
                f"  1. 在 .env 加入：{self.config.bot_token_env}=your-token\n"
                f"  2. 或設定環境變數：export {self.config.bot_token_env}=your-token\n"
                f"  取得 Token：https://t.me/BotFather"
            )

        from telegram.request import HTTPXRequest
        request = HTTPXRequest(
            read_timeout=30.0,
            write_timeout=30.0,
            connect_timeout=15.0,
            pool_timeout=15.0,
        )
        self._app = Application.builder().token(token).request(request).build()
        self._app.add_handler(CommandHandler("start", self._cmd_start))
        self._app.add_handler(CommandHandler("status", self._cmd_status))
        self._app.add_handler(CommandHandler("tasks", self._cmd_tasks))
        self._app.add_handler(CommandHandler("restart", self._cmd_restart))
        self._app.add_handler(CommandHandler("help", self._cmd_help))
        self._app.add_handler(CommandHandler("allow", self._cmd_allow))
        self._app.add_handler(CommandHandler("deny", self._cmd_deny))
        self._load_allowed()  # 合併 state/allowed_users.json（動態授權持久化）
        # Accept text messages but exclude Telegram service events (topic created/renamed,
        # member join/leave, pin, etc.) — these waste agent context window.
        self._app.add_handler(MessageHandler(filters.TEXT & ~filters.StatusUpdate.ALL, self._on_message))
        self._app.add_handler(CallbackQueryHandler(self._on_callback))
        self._app.add_error_handler(self._on_error)

        self._planner = ConversationPlanner(self._topic_map, self.daemon.instances, daemon=self.daemon)
        self._reactions.set_bot(self._app.bot)

        await self._app.initialize()
        await self._app.start()
        await self._app.updater.start_polling(drop_pending_updates=True, allowed_updates=["message", "callback_query"])

        # 設定 Bot Menu 命令
        await self._set_menu_commands()

        # Initialize message queue now that bot is ready
        from .message_queue import MessageQueue
        self._queue = MessageQueue(self._app.bot)
        self._queue.start()

        log.info("Telegram bot started, topic bindings: %s", self._topic_map)

    async def stop(self) -> None:
        if self._queue:
            self._queue.stop()
        for task in self._poll_tasks.values():
            task.cancel()
        self._poll_tasks.clear()
        if self._app:
            await self._app.updater.stop()
            await self._app.stop()
            await self._app.shutdown()
            log.info("Telegram bot stopped")

    async def _set_menu_commands(self) -> None:
        """設定 Bot Menu 預設命令選項 + 強制覆蓋 MenuButton 為命令列表模式。"""
        from telegram import BotCommand, MenuButtonCommands
        commands = [
            BotCommand("start", "系統介紹 · 你的 ID · 如何對話"),
            BotCommand("status", "agent + 主程式狀態"),
            BotCommand("tasks", "任務派工狀況"),
            BotCommand("restart", "重啟服務（需確認）"),
            BotCommand("help", "細部介紹與操作"),
        ]
        try:
            await self._app.bot.set_my_commands(commands)
            await self._app.bot.set_chat_menu_button(menu_button=MenuButtonCommands())
            log.info("Bot menu commands set: %d commands", len(commands))
        except Exception as e:
            log.warning("Failed to set menu commands: %s", e)

    def start_output_polling(self) -> None:
        all_instances = set(self._topic_map.values()) | set(self._private_chat_map.keys())
        for name in all_instances:
            if name not in self._poll_tasks:
                # Skip existing output (startup messages)
                state = self.daemon.instances.get(name)
                if state and state.process:
                    self._output_cursors[name] = len(state.process.capture(lines=500))
                else:
                    self._output_cursors[name] = 0
                self._poll_tasks[name] = asyncio.create_task(self._poll_output(name))

    async def _on_message(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
        msg = update.effective_message
        if not msg or not msg.text:
            return

        user = update.effective_user
        chat = update.effective_chat
        topic_id = msg.message_thread_id
        text = msg.text.strip()

        # [team-agent 2026-07-30] Decision Loop — pending overturn reason interception
        # If user has a pending overturn decision, treat this message as the reason
        if user and hasattr(self, "_pending_overturn") and user.id in self._pending_overturn:
            decision_id = self._pending_overturn.pop(user.id)
            reason = text
            if not reason:
                await msg.reply_text("❌ 翻案原因不可空白，請重新點 [翻案] 按鈕重試。")
                return
            await self._execute_overturn(decision_id, reason, msg)
            return

        # Inject reply_to quoted text so the agent has context about what the user is replying to.
        # Skip if the referenced message is a progress message from the bot itself.
        delivered_text = text
        if msg.reply_to_message and msg.reply_to_message.text:
            quoted = msg.reply_to_message.text.strip()
            # Skip progress/status messages to avoid noise
            if quoted and not quoted.startswith(("🚀 ", "✅ 團隊就緒", "⚠️ ")):
                # Limit quoted text length to avoid context bloat
                if len(quoted) > 500:
                    quoted = quoted[:500] + "..."
                delivered_text = f"> 引用：{quoted}\n\n{text}"

        log.info("📨 %s → %s「%s」",
                 self._user_display(user.id if user else 0),
                 self._instance_display(self._resolve_instance(topic_id) or "?"),
                 text[:60])

        if user and not self._check_access(user.id, update.effective_chat.id if update.effective_chat else None):
            log.warning("Access denied for user %s", user.id)
            return

        # --- Private chat → route via @mention or fallback to bound instance ---
        if chat and chat.type == "private":
            bound_instance = None
            for name, cid in self._private_chat_map.items():
                # [claude-code 2026-08-06] 只認實體綁定，跳過 session key（name#uid）
                if cid == user.id and "#" not in name:
                    bound_instance = name
                    break

            # [claude-code 2026-08-06] 未綁定私聊 → 若有 multi_user 入口（admin/manager）預設 route 到它
            if not bound_instance:
                bound_instance = self._find_multi_user_entry()
            if not bound_instance:
                await msg.reply_text("❌ 此私聊未綁定任何 agent")
                return

            # Determine fallback target:
            # - Always fallback to bound_instance (admin, e.g. ceo-agent)
            # - @mention overrides fallback
            fallback_target = bound_instance

            # Parse @mention for multi-agent routing
            if not hasattr(self, "_chat_router"):
                self._chat_router = ChatRouter(
                    codename_map=self._CODENAMES,
                    instances=list(self.daemon.instances.keys()),
                )
            result = self._chat_router.route(delivered_text, fallback=fallback_target)

            # No @mention → 依 private_chat_routing.mode 決定要不要用 keyword 路由
            if not _MENTION_PATTERN.findall(delivered_text):
                # [1.2.23] `private_chat_routing` 現在真的讀得到了 ——
                # 在此之前 TeamConfig 沒有這個欄位，`getattr` 永遠回 `{}`，
                # keyword_routes 從未生效過一次。
                #
                # ⚠️ 接上之後**必須依 mode 分流**，不能一律套用 keyword：
                # nana 設 `mode: ark-agent`，語意是「全部交給入口 agent 用 LLM 判斷意圖」
                # （它的 SOUL.md 有完整的 7 種意圖分類規則）。若套件先用 keyword 攔截，
                # 「技術」「bug」等字會被直接送去 cto-agent，**繞過入口 agent 的判斷** ——
                # 那是把一個從未生效的備援，變成會改變既有行為的攔截器。
                _kw_routes = keyword_routes_for(
                    self.daemon.config.private_chat_routing, bound_instance)
                # `or bound_instance`：route_by_keyword 現在可能回 None（1.2.23 起
                # 不再有寫死的預設目標）。我們傳了 fallback 所以理論上不會，但
                # 靠「理論上」撐著的地方，就是下一個靜默故障的位置。
                keyword_target = self._chat_router.route_by_keyword(
                    delivered_text,
                    fallback=bound_instance,
                    keyword_routes=_kw_routes or None,
                ) or bound_instance
                result = RouteResult(targets=[keyword_target], text=delivered_text)

            # Send to all resolved targets
            sent_count = 0
            # 👀 reaction on the user message (immediate feedback)
            await self._set_reaction(msg.chat_id, msg.message_id, "👀")

            # 判斷是否為 @mention（決定 reply channel）
            has_mention = bool(_MENTION_PATTERN.findall(delivered_text))

            for target in result.targets:
                # [claude-code 2026-08-06] 多使用者隔離：multi_user 的 target 轉成 per-user session
                send_target = target
                _t_ic0 = self.daemon.config.instances.get(target)
                if _t_ic0 and getattr(_t_ic0, "multi_user", False):
                    send_target = await self.daemon.resolve_session(target, user.id)
                    self.bind_private_chat(send_target, msg.chat_id)  # 定址回本 user
                    self.start_output_polling()                        # 補建 session poll task

                # 設定 reply channel（判斷用實體 target，key 存 send_target）
                #
                # [1.4.2] 啟用 reply_to_origin 時：**私訊問就回同一個私訊視窗**，
                # 包含 `@mention` 別人、以及該次發問派工出去的下游。
                #
                # 原本 `@mention` 別人會設成 "topic" → 你在私訊問，答案跑到群組的
                # 某個 topic。那是同一類體驗問題（回覆去「agent 的家」而不是
                # 「你問的地方」），只是場景從 General 換成私訊。
                #
                # ⚠️ 記的是 `msg.chat_id`（你這個視窗），不是 agent 自己設定的
                # `private_chat` —— 被派工的 worker 通常沒有那個設定。
                if self._daemon_api._origin_routing_on():
                    self._daemon_api._origin_topic[send_target] = ("private", msg.chat_id)
                    self._daemon_api._reply_channel[send_target] = "origin"
                elif has_mention and target != bound_instance:
                    self._daemon_api._reply_channel[send_target] = "topic"
                elif not has_mention and target == bound_instance:
                    self._daemon_api._reply_channel[send_target] = "private"
                else:
                    self._daemon_api._reply_channel[send_target] = "topic"

                # [2026-07-31] Lazy spawn 啟動中提示
                _tgt_state = self.daemon.instances.get(send_target)
                _tgt_ic = self.daemon.config.instances.get(send_target)
                if (
                    _tgt_state
                    and _tgt_ic
                    and not _tgt_ic.persistent
                    and _tgt_state.status == InstanceStatus.STOPPED
                ):
                    _codename = self._instance_display(target).split("（")[0].strip()
                    await self._send_to_private(
                        msg.chat_id,
                        f"⏳ {_codename} 目前離線，正在啟動中，請稍候...",
                    )
                ok = await self.daemon.send_message(send_target, result.text)
                if ok:
                    sent_count += 1
                    log.info("📨 私聊 @mention → %s「%s」", send_target, result.text[:40])
                    # Store reaction target for completion callback（對應 session 進程）
                    self._store_reaction_target(send_target, msg.chat_id, msg.message_id)
                    # ⏳ reaction: agent confirmed processing
                    await self._reactions.mark_processing(send_target)
                    # Start typing indicator (replaces 「處理中」text message)
                    self._start_typing(send_target, msg.chat_id)
                    # 私訊轉發確認：只要轉給其他 agent（@mention 或 keyword routing）都送私訊確認
                    #
                    # [1.4.4] 但 `reply_to_origin` 開啟時**不發** —— 它原本的用途是
                    # 「去別的地方看答案」（被派工者的回覆會落在它自己的 topic）。
                    # origin 模式下答案回到**同一個視窗**，這句話沒有路可指了，
                    # 只是在答案前面多一行狀態播報。
                    #
                    # 實測使用者看到的是：
                    #   ⏳ 喬巴 目前離線，正在啟動中…   ← 有資訊（解釋等待）
                    #   ✅ 已轉給👃 喬巴                 ← 沒資訊（答案就要來了）
                    # 保留前者、移除後者。
                    if target != bound_instance and not (
                        self._daemon_api and self._daemon_api._origin_routing_on()
                    ):
                        display = self._instance_display(target)
                        # 取 emoji + 代號（去掉職稱括號部分），例如「📋 羅賓」
                        display = display.split("（")[0].strip()
                        await self._send_to_private(msg.chat_id, f"✅ 已轉給{display}")
                    await get_event_log().record(
                        target, EventType.MESSAGE,
                        detail=result.text[:200],
                        source=f"user:{user.id}",
                    )
                else:
                    await self._finish_reaction(send_target, success=False)
                    # [1.2.16] 統一「沒在線上」文案：這不是使用者操作錯誤 → 用 ⚠️ 不用 ❌，
                    # 並補一句「能做什麼」（原本只丟狀態，使用者不知道下一步）
                    await msg.reply_text(
                        f"⚠️ {self._instance_display(target)} 現在沒在線上，訊息還沒送出。\n"
                        "稍等一下再試，或用 /status 看看狀況。")

            if sent_count == 0:
                if not result.targets:
                    # No @mention in private-only mode → show usage
                    instances_list = []
                    admin_line = None
                    for inst_name, state in self.daemon.instances.items():
                        ic = self.daemon.config.instances.get(inst_name)
                        if not ic:
                            continue
                        if ic.role == "admin":
                            admin_line = f"  @{inst_name.replace('-agent', '')} — {ic.description or inst_name}"
                        else:
                            instances_list.append(f"  @{inst_name.replace('-agent', '')} — {ic.description or inst_name}")
                    usage = "📋 用 @mention 指定對象：\n\n" + "\n".join(instances_list)
                    if admin_line:
                        usage += f"\n\n👑 管理層：\n{admin_line}"
                    usage += "\n\n💡 範例：\n"
                    usage += "  @pm 幫我建一個 chatbot spec\n"
                    usage += "  @coder fix 登入頁的 bug\n"
                    usage += "  @qa 跑一次測試\n"
                    usage += f"\n直接打字（不加 @）= 跟{self._entry_codename()}對話"
                    await msg.reply_text(usage)
                else:
                    # Had @mention but target not running
                    suggestions = self._chat_router.suggest(text.split("@")[1].split()[0] if "@" in text else "")
                    if suggestions:
                        await msg.reply_text(f"❌ 找不到目標。你是指：\n" + "\n".join(suggestions))
                    else:
                        await msg.reply_text(
                            "⚠️ 對方現在沒在線上，訊息還沒送出。\n"
                            "稍等一下再試，或用 /status 看看團隊狀況。")
            return

        if user and not self._check_access(user.id, update.effective_chat.id if update.effective_chat else None):
            log.warning("Access denied for user %s", user.id)
            return

        # --- Commands ---
        if text == "/status":
            await self._cmd_status(update, ctx)
            return
        if text == "/memory":
            from . import memory as mem
            content = mem.read(user.id) or "（尚無記憶）"
            await msg.reply_text(content[:4000])
            return
        if text == "/memory clear":
            from . import memory as mem
            mem.clear(user.id)
            await msg.reply_text("✅ 記憶已清除")
            return
        if text == "/reset":
            self._sessions.reset(user.id)
            await msg.reply_text("好的，重新開始。有什麼可以幫你的嗎？")
            return

        # --- Session + Planner ---
        instance = self._resolve_instance(topic_id)
        # [claude-code 2026-08-06] FR-3：記錄來源 topic，供回覆定址跟隨來源
        if instance and topic_id is not None:
            self._last_source[instance] = (msg.chat_id, topic_id)
        session = self._sessions.get_or_create(
            user.id, msg.chat_id, topic_id=topic_id, instance=instance,
        )
        session.add_turn("user", text)

        from . import memory as mem
        memory_ctx = mem.read(user.id)

        # [1.4.3] 群組也解析 `@mention` —— 與私訊路徑一致。
        #
        # 🔴 在此之前 **只有私訊路徑**會解析（`ChatRouter.route()`）；群組路徑走
        # `planner.plan()`，而 planner **完全不看 @**（`session.instance` 已綁 topic
        # 的主人）。後果是：在 General 打「@qa 你是誰」，訊息其實送給了入口 agent，
        # 靠**它的 LLM 去讀懂那個 @**，然後它再 `send_to_instance` 派給 qa。
        #
        # 那條路徑有四個代價：
        #   1. 順序倒置 —— agent 的 ack 在 `send_to_instance` **之後**才產生，
        #      而被派工者可能秒答（「你是誰」不用做事）→ 答案先到、ack 後到
        #   2. 多一次 LLM 呼叫（入口 agent 的意圖分類）
        #   3. 可能判錯人 —— 而 `@qa` 本來是使用者**已經做完的決定**
        #   4. 多喚醒一個 agent 的成本
        #
        # `@mention` 是明確指令，不該再交給 LLM 猜一次。
        _mentions = _MENTION_PATTERN.findall(text)
        _mention_target = None
        if _mentions and self._planner is not None:
            if not hasattr(self, "_chat_router"):
                self._chat_router = ChatRouter(
                    codename_map=self._CODENAMES,
                    instances=list(self.daemon.instances.keys()),
                )
            _r = self._chat_router.route(text, fallback=None)
            # 只在**解析出單一明確目標**時接手；`@all` 廣播與解析失敗都交回 planner
            # （廣播語意由 planner／既有流程處理，這裡不重新實作一份）
            if len(_r.targets) == 1 and not _r.is_broadcast and _r.targets[0] in self.daemon.instances:
                _mention_target = _r.targets[0]
                # 🔴 [1.4.4] **`delivered_text` 也要更新** —— 群組分支實際送出的是它
                # （`ctx_text = delivered_text`），不是 `text`。1.4.3 只改了 `text`，
                # 於是 log 出現 `Sent to qa-agent: @qa 你是誰` —— `@qa` 沒被清掉，
                # 而私訊路徑是乾淨的 `你是誰`。**同一件事兩條路徑結果不同就是漏改的訊號。**
                # 後果：agent 收到帶 `@qa` 的字串，可能誤判成「要轉給別人」。
                text = _r.text or text
                delivered_text = _r.text or delivered_text
                session.instance = _mention_target
                log.info("📨 群組 @mention → %s（不經入口 agent）", _mention_target)

        if _mention_target:
            action = Action("execute", instance=_mention_target)
        else:
            action = self._planner.plan(session, text, memory_ctx)

        # [1.2.7] chat trace：記下路由決策（動作型別 + 目標 agent + 訊息摘要），
        # 供事後追查「這句話為什麼跑到那個 agent」。永不影響主流程。
        try:
            # ⚠️ 不要在此處 import get_event_log —— 模組層（本檔第 16 行）已 import；
            # 函式內再 import 會使該名稱成為「整個函式的區域變數」，導致本函式**更早**
            # 使用它的第 707 行拋 UnboundLocalError（v1.2.7 引入、v1.2.9 修正）。
            await get_event_log().record(
                action.instance or "-", EventType.ROUTE,
                detail=f"action={action.type} text={text[:60]}",
                source=f"user:{user.id}",
            )
        except Exception as _te:  # noqa: BLE001
            log.debug("chat trace record failed: %s", _te)

        if action.type == "reset":
            self._sessions.reset(user.id)
            await msg.reply_text(action.message)

        elif action.type == "answer":
            session.add_turn("assistant", action.message)
            await msg.reply_text(action.message)

        elif action.type == "clarify":
            keyboard = InlineKeyboardMarkup(
                [[InlineKeyboardButton(b["text"], callback_data=b["callback_data"]) for b in row]
                 for row in action.keyboard]
            ) if action.keyboard else None
            session.add_turn("assistant", action.message)
            await msg.reply_text(action.message, reply_markup=keyboard)

        elif action.type == "execute":
            # 注入精簡上下文（摘要式，≤100 字/輪）
            ctx_text = delivered_text
            if len(session.turns) > 1:
                prev_turns = session.turns[-(min(3, len(session.turns))):-1]
                summary_parts = []
                for t in prev_turns:
                    content = t.content[:100] + "..." if len(t.content) > 100 else t.content
                    label = "用戶" if t.role == "user" else "回覆"
                    summary_parts.append(f"{label}「{content}」")
                if summary_parts:
                    ctx_text = f"[上文] {' → '.join(summary_parts)}\n[當前] {delivered_text}"

            # [1.4.0] 設定 reply channel → "origin"：回到使用者發問的那個 topic。
            #
            # 原本一律是 "topic"（＝agent 的歸屬 topic）。實際後果：使用者習慣在
            # General 跟入口 agent 講話，而回覆跑到被指定 agent 自己的 topic ——
            # 使用者留在 General，看不到答案，得自己切 topic 找。
            #
            # `topic_id` 這裡本來就在 scope 內（下方 typing indicator 也用它），
            # 只是從來沒被當成「回哪裡」的依據。
            if hasattr(self, "_daemon_api") and self._daemon_api:
                # [1.4.1] 依 communication.reply_to_origin 決定（預設關 → 維持既有行為）
                if self._daemon_api._origin_routing_on():
                    _origin = topic_id or self.config.general_topic_id or 1
                    self._daemon_api._origin_topic[action.instance] = ("topic", _origin)
                    self._daemon_api._reply_channel[action.instance] = "origin"
                else:
                    self._daemon_api._reply_channel[action.instance] = "topic"

            ok = await self.daemon.send_message(action.instance, ctx_text)
            if ok:
                log.info("Sent to %s: %s", action.instance, delivered_text[:50])
                # 👀 reaction: immediate feedback that message was received
                await self._set_reaction(msg.chat_id, msg.message_id, "👀")
                self._store_reaction_target(action.instance, msg.chat_id, msg.message_id)
                # ⏳ reaction: agent confirmed processing
                await self._reactions.mark_processing(action.instance)
                # Start typing indicator for group topic
                thread_id = topic_id if topic_id and topic_id != self.config.general_topic_id else None
                self._start_typing(action.instance, self.config.group_id, thread_id)
                await get_event_log().record(
                    action.instance, EventType.MESSAGE,
                    detail=delivered_text[:200],
                    source=f"user:{user.id}",
                )
            else:
                await self._finish_reaction(action.instance, success=False)
                await msg.reply_text(
                    f"⚠️ {self._instance_display(action.instance)} 現在沒在線上，訊息還沒送出。\n"
                    "稍等一下再試，或用 /status 看看狀況。")

    async def _on_callback(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
        query = update.callback_query
        await query.answer()
        data = query.data or ""

        if data.startswith("route:"):
            instance = data.split(":", 1)[1]
            user = query.from_user
            session = self._sessions.get_or_create(user.id, query.message.chat_id)
            session.instance = instance

            # [1.2.16] 用代號而非 raw instance 名 —— 同一動作在 @mention 路徑已用代號，
            # 兩處不一致會讓使用者以為是不同對象
            await query.edit_message_text(f"✅ 已轉給 {self._instance_display(instance)}")

            # Replay last user message to the selected instance
            last_user_msg = None
            for t in reversed(session.turns):
                if t.role == "user":
                    last_user_msg = t.content
                    break
            if last_user_msg:
                ok = await self.daemon.send_message(instance, last_user_msg)
                if not ok:
                    tid = query.message.message_thread_id or self.config.general_topic_id
                    await self._send_to_topic(
                        tid,
                        f"⚠️ {self._instance_display(instance)} 現在沒在線上，訊息還沒送出。")
            return

        # [1.2.5] /restart 確認
        if data.startswith("restart:"):
            action = data.split(":", 1)[1]
            if not self._check_access(query.from_user.id):
                await query.edit_message_text("❌ 無權限")
                return
            if action == "confirm":
                log.info("Restart confirmed via callback by user %s", query.from_user.id)
                # [1.3.3] 先問清楚「誰會拉起我」，再據實回報。
                # 原本一律回「watchdog 將在數秒內拉起服務」—— 但本機根本沒有
                # watchdog 進程在跑（Linux 靠 systemd、wrapper 靠 while loop），
                # 而在沒有 supervisor 的環境那句話是**謊話**：服務會停掉不再起來。
                r = self._do_restart()
                await query.edit_message_text(
                    f"🔄 重啟中… 約 30–60 秒無回應（{r['mechanism']}）"
                    if r.get("will_restart") else
                    f"⚠️ <b>服務即將停止，且不會自動起來</b>\n{r.get('why', '')}\n\n"
                    "要自動重啟請改用 systemd 或 <code>start-team.sh</code> 啟動。",
                    parse_mode="HTML",
                )
            else:
                await query.edit_message_text("已取消，未重啟。")
            return

        # Startup begin action
        if data == "startup:begin":
            await query.edit_message_reply_markup(reply_markup=None)
            instance = getattr(self, "_general_instance", None)
            if instance:
                await self.daemon.send_message(instance, "開始工作，請查詢團隊狀態並發派今日任務。完成後更新 memory.md 記錄今日進度。")
            return

        # Hang detection actions
        if data.startswith("hang:report:"):
            instance = data.split(":", 2)[2]
            await query.edit_message_reply_markup(reply_markup=None)
            msg = self._HANG_REPORT_PROMPT
            await self.daemon.send_message(instance, msg)
            return

        if data.startswith("hang:plan:"):
            instance = data.split(":", 2)[2]
            await query.edit_message_reply_markup(reply_markup=None)
            # 個性化注入 role + description
            desc = self._get_instance_description(instance)
            msg = (
                f"【執行計劃】{desc}\n"
                "1. 用 list_tasks 查詢分配給你的 pending/in_progress 任務\n"
                "2. 有任務 → 立即執行最高優先的，完成後 update_task(status=completed) + reply\n"
                "3. 無任務 → 向 pm-agent 請求派工（send_to_instance）\n"
                "4. 完成後更新 memory.md\n"
                "⚠️ 此為系統指令，優先級高於等待規則。"
            )
            await self.daemon.send_message(instance, msg)
            await query.edit_message_text(f"▶️ 已發送執行計劃給 {instance}")
            return

        if data.startswith("hang:analyze:"):
            # Deprecated — no longer used (removed in favor of auto-report)
            return

        if data.startswith("hang:assign:"):
            instance = data.split(":", 2)[2]
            await query.edit_message_reply_markup(reply_markup=None)
            # Find leader dynamically from config
            leader_name = "leader"
            if hasattr(self.daemon, "config"):
                for n, ic in self.daemon.entity_instances().items():
                    if ic.role == "leader":
                        leader_name = n
                        break
            msg = (
                "【派工請求】你目前無進行中任務。\n"
                f"請向 {leader_name} 報到並請求下一個任務：\n"
                f'send_to_instance("{leader_name}", "Hi, 我目前空閒，請派工。")\n'
                "收到任務後立即執行並 reply 回報。"
            )
            await self.daemon.send_message(instance, msg)
            await query.edit_message_text(f"📋 已要求 {instance} 向 leader 請求派工")
            return

        if data.startswith("hang:restart:"):
            instance = data.split(":", 2)[2]
            # 二次確認，避免誤按
            await query.edit_message_reply_markup(
                reply_markup=InlineKeyboardMarkup([
                    [
                        InlineKeyboardButton(
                            f"✅ 確認重啟 {instance}",
                            callback_data=f"hang:restart_confirm:{instance}",
                        ),
                        InlineKeyboardButton("取消", callback_data=f"hang:skip:{instance}"),
                    ]
                ])
            )
            return

        if data.startswith("hang:restart_confirm:"):
            instance = data.split(":", 2)[2]
            await query.edit_message_text(f"🔄 正在重啟 {instance}...")
            try:
                await self.daemon.restart_instance(instance)
                await query.edit_message_text(f"✅ {instance} 已重啟")
            except Exception as e:
                # [1.2.16] 不把例外文字丟給使用者（SOUL 明訂禁止）—— 細節進 log
                    log.error("Restart %s failed: %s", instance, e)
                    await query.edit_message_text(
                        f"⚠️ {self._instance_display(instance)} 重啟沒成功。\n"
                        "已記錄原因，可以再試一次，或用 /status 看目前狀況。")
            return

        if data.startswith("hang:wait:"):
            instance = data.split(":", 2)[2]
            self.daemon._hang_notified.discard(instance)
            await query.edit_message_text(f"▶️ {instance} 繼續執行計劃")
            return

        # [team-agent 2026-07-30] Decision loop L3 escalation callbacks
        if data.startswith("l3:approve:"):
            req_id = data.split(":", 2)[2]
            await query.edit_message_text(f"✅ 已批准 {req_id}，通知相關 agent 繼續。")
            # Notify the requester to proceed
            if hasattr(self.daemon, "decision_mgr") and self.daemon.decision_mgr:
                try:
                    requester = self.daemon.decision_mgr._requester_of(req_id)
                    if requester:
                        await self.daemon.send_message(
                            requester,
                            f"✅ Paddy 已批准 L3 請求 {req_id}，請繼續執行。"
                        )
                    self.daemon.decision_mgr.store.mark_request(req_id, "decided")
                except Exception as e:
                    log.warning("L3 approve callback error: %s", e)
            return

        if data.startswith("l3:reject:"):
            req_id = data.split(":", 2)[2]
            await query.edit_message_text(f"❌ 已否決 {req_id}，通知相關 agent 停止。")
            if hasattr(self.daemon, "decision_mgr") and self.daemon.decision_mgr:
                try:
                    requester = self.daemon.decision_mgr._requester_of(req_id)
                    if requester:
                        await self.daemon.send_message(
                            requester,
                            f"❌ Paddy 否決了 L3 請求 {req_id}，請停止相關操作並等待指示。"
                        )
                    self.daemon.decision_mgr.store.mark_request(req_id, "escalated")
                except Exception as e:
                    log.warning("L3 reject callback error: %s", e)
            return

        if data.startswith("l3:delegate:"):
            # Delegate L3 to L2 (e.g. authorise CTO to decide)
            parts = data.split(":", 3)
            req_id = parts[2] if len(parts) > 2 else ""
            delegate_to = parts[3] if len(parts) > 3 else self._default_decider()  # [v1.1.3] 改用 _default_decider（不再寫死決策者）
            await query.edit_message_text(
                f"🔄 已將 {req_id} 降為 L2，授權 {delegate_to} 拍板。"
            )
            if hasattr(self.daemon, "decision_mgr") and self.daemon.decision_mgr:
                try:
                    await self.daemon.send_message(
                        delegate_to,
                        f"📋 Paddy 授權你拍板 L3→L2 請求 {req_id}，"
                        f"請依 decision-making steering 回覆 decision 塊。"
                    )
                except Exception as e:
                    log.warning("L3 delegate callback error: %s", e)
            return

        if data.startswith("paddy_action:"):
            action = data.split(":", 1)[1]
            await query.edit_message_text(f"✅ 已收到：{action}")
            return

        # [team-agent 2026-07-30] Decision Loop — overturn callback
        if data.startswith("overturn:"):
            decision_id = data.split(":", 1)[1]
            user = query.from_user
            # Ask for reason — send a follow-up message prompting input
            # We store the pending overturn in a simple dict keyed by user_id
            if not hasattr(self, "_pending_overturn"):
                self._pending_overturn: dict[int, str] = {}
            self._pending_overturn[user.id] = decision_id
            await query.edit_message_text(
                f"⚠️ 翻案 {decision_id}\n\n"
                f"請回覆翻案原因（必填）。\n"
                f"格式：直接輸入原因文字，系統會識別為翻案確認。\n"
                f"例：「範圍應收窄，NL2SQL 不列入 MVP」"
            )
            return

        # Overturn reason confirmation — triggered by user reply after overturn: prompt
        if data.startswith("overturn_confirm:"):
            parts = data.split(":", 2)
            decision_id = parts[1] if len(parts) > 1 else ""
            reason = parts[2] if len(parts) > 2 else ""
            if not reason.strip():
                await query.edit_message_text("❌ 翻案原因不可空白，請重新輸入。")
                return
            await self._execute_overturn(decision_id, reason, query)
            return

    # 代號與職稱對照 — 僅作為 fallback（動態版由 _build_codenames 產出）
    _CODENAMES: dict[str, str] = {}
    _TITLES: dict[str, str] = {}

    def _get_instance_description(self, instance: str) -> str:
        """取得 instance 的角色描述，用於個性化提詞。"""
        try:
            ic = self.daemon.config.instances.get(instance)
            if ic and getattr(ic, "description", None):
                return f"你是 {ic.description}。"
        except (AttributeError, TypeError):
            pass
        title = self._TITLES.get(instance, "")
        if title:
            return f"你是{title}。"
        return ""

    def _entry_codename(self) -> str:
        """[v1.1.5 FR-5] 私訊入口 agent 的代號（general_topic 實例）。

        取代硬編碼「小娜」——由 team.yaml 的 general_topic/manager 推導，其他團隊自動正確。

        Author: ark-agent
        """
        cfg = getattr(self.daemon, "config", None)
        cn = getattr(self, "_CODENAMES", {})
        if cfg:
            for name, ic in cfg.instances.items():
                if getattr(ic, "general_topic", False):
                    return cn.get(name, name)
            for name, ic in cfg.instances.items():
                if (getattr(ic, "role", "") or "") == "manager":
                    return cn.get(name, name)
        return "管家"

    def _hang_keyboard(self, instance: str) -> InlineKeyboardMarkup:
        """Post-report buttons: user decides next action after auto-report.

        [v1.1.5 FR-3] 命名統一（喚醒/已知悉）、順序一致（喚醒>重啟>暫停>已知悉）、
        暫停帶代號、拆兩列避免手機擠壓。
        """
        codename = getattr(self, "_CODENAMES", {}).get(instance, instance)
        return InlineKeyboardMarkup([
            [
                InlineKeyboardButton("🔔 喚醒", callback_data=f"hang:plan:{instance}"),
                InlineKeyboardButton("🔁 重啟", callback_data=f"hang:restart:{instance}"),
            ],
            [
                InlineKeyboardButton(f"⏸ 暫停 {codename} 今日", callback_data=f"hang:assign:{instance}"),
                InlineKeyboardButton("✅ 已知悉", callback_data=f"hang:skip:{instance}"),
            ],
        ])

    def _owner_chat_id(self) -> int | None:
        """私訊通知的目標 chat_id —— **依 role 推導，不寫死 instance 名**。

        [1.2.26] 原本寫死 `_private_chat_map.get("ark-agent")`（nana 的入口名）。
        實測 aiops 的入口是 `admin-agent`、director 是 `tech-agent` ——
        兩者一律拿不到值，**L3 拍板卡從來沒送出過**。

        與 `api.DaemonAPI.owner_chat_id()` 同一套判準：
        優先 `role == "admin"`，找不到就取任何已綁定 private_chat 的 instance。

        Author: ark-agent（1.2.26）
        """
        insts = getattr(self.daemon, "config", None)
        insts = getattr(insts, "instances", {}) if insts is not None else {}
        for name, cid in self._private_chat_map.items():
            cfg = insts.get(name)
            if cfg and getattr(cfg, "role", "") == "admin":
                return cid
        return next(iter(self._private_chat_map.values()), None)

    def _default_decider(self) -> str:
        """L3→L2 授權的預設對象（v1.1.3）：矩陣第一個決策者 → 退回第一個 admin → 空字串。

        取代原本寫死的固定決策者名。

        Author: ark-agent
        """
        dm = getattr(self.daemon, "decision_mgr", None)
        if dm is not None:
            try:
                ds = sorted(dm._deciders())
                if ds:
                    return ds[0]
            except Exception:  # noqa: BLE001
                pass
        cfg = getattr(self.daemon, "config", None)
        if cfg:
            for n, ic in cfg.instances.items():
                if (getattr(ic, "role", "") or "") == "admin":
                    return n
        return ""

    async def send_l3_escalation_card(
        self,
        req_id: str,
        question: str,
        requester: str,
        context_note: str = "",
        delegate_to: str = "",
    ) -> None:
        """Send an L3 escalation card to Paddy's private chat with three action buttons.

        Buttons:
          [批准]   — approve the L3 request, notify requester to proceed
          [否決]   — reject, notify requester to stop
          [改為 L2 授權] — downgrade to L2, delegate to specified agent
        """
        paddy_chat_id: int | None = self._owner_chat_id()
        if not paddy_chat_id:
            log.warning(
                "send_l3_escalation_card: 沒有任何 instance 綁定 private_chat"
                " → L3 拍板卡無處可送。請在 team.yaml 為入口 instance 設 private_chat。"
            )
            return

        delegate_to = delegate_to or self._default_decider()  # [v1.1.3] 改用 _default_decider（不再寫死決策者）
        context = f"\n備註：{context_note}" if context_note else ""
        text = (
            f"⚠️ <b>需要你拍板｜L3 請求 {req_id}</b>\n"
            f"來自：{requester}\n"
            f"問題：{question}"
            f"{context}"
        )
        # [v1.1.5 FR-3 / B4] 批准/否決同列，降級獨立一列（避免手機三顆擠壓/截斷）
        keyboard = InlineKeyboardMarkup([
            [
                InlineKeyboardButton("✅ 批准", callback_data=f"l3:approve:{req_id}"),
                InlineKeyboardButton("❌ 否決", callback_data=f"l3:reject:{req_id}"),
            ],
            [
                InlineKeyboardButton(
                    f"🔄 降為 L2（{delegate_to.replace('-agent', '')}）",
                    callback_data=f"l3:delegate:{req_id}:{delegate_to}",
                ),
            ],
        ])
        try:
            await self._send_to_private(paddy_chat_id, text, parse_mode="HTML", reply_markup=keyboard)
            log.info("L3 escalation card sent to Paddy: %s", req_id)
        except Exception as e:
            log.warning("send_l3_escalation_card failed: %s", e)

    async def _execute_overturn(self, decision_id: str, reason: str, responder) -> None:
        """Execute the overturn: update DB, notify parties, write knowledge feedback.

        responder: telegram Message or CallbackQuery — has reply_text / edit_message_text
        """
        async def _reply(text: str) -> None:
            try:
                if hasattr(responder, "edit_message_text"):
                    await responder.edit_message_text(text)
                else:
                    await responder.reply_text(text)
            except Exception:
                pass

        if not reason.strip():
            await _reply("❌ 翻案原因不可空白。")
            return

        # Use DecisionManager to overturn
        if hasattr(self.daemon, "decision_mgr") and self.daemon.decision_mgr:
            dm = self.daemon.decision_mgr
            try:
                # Fetch record for context
                import sqlite3 as _sq
                rec = dm.store._conn.execute(
                    "SELECT * FROM decision_records WHERE decision_id=?", (decision_id,)
                ).fetchone()
                if not rec:
                    await _reply(f"❌ 找不到 {decision_id}。")
                    return
                if rec["status"] != "effective":
                    await _reply(f"⚠️ {decision_id} 狀態為 {rec['status']}，無法翻案。")
                    return

                # Overturn in store
                dm.store.overturn(decision_id, reason)

                # Get requester
                req_row = dm.store.get_request(rec["req_id"])
                requester = req_row["requester"] if req_row else None
                decided_by = rec["decided_by"]

                # Notify parties
                if requester:
                    await self.daemon.send_message(
                        requester,
                        f"⚠️ Paddy 翻案了 {decision_id}\n"
                        f"原決定：{rec['verdict']} — {rec['rationale'][:60]}\n"
                        f"翻案原因：{reason}\n"
                        f"請停止依原 verdict 執行，等待進一步指示。",
                    )
                if decided_by and decided_by != requester:
                    await self.daemon.send_message(
                        decided_by,
                        f"⚠️ Paddy 翻案了你的決定 {decision_id}\n"
                        f"原決定：{rec['verdict']} — {rec['rationale'][:60]}\n"
                        f"翻案原因：{reason}\n"
                        f"請更新 BRAIN.md 記錄此方針修正。",
                    )

                # Write knowledge feedback
                dm.write_knowledge_feedback(
                    decision_id=decision_id,
                    req_id=rec["req_id"],
                    original_owner=decided_by,
                    verdict=f"{rec['verdict']}（已翻案：{reason}）",
                    rationale=f"Paddy 翻案 — {reason}",
                    decided_by="Paddy",
                )

                await _reply(
                    f"✅ 已翻案 {decision_id}\n"
                    f"原因：{reason}\n"
                    f"已通知：{decided_by}"
                    + (f"、{requester}" if requester and requester != decided_by else "")
                )
                log.info("Overturn executed: %s reason=%s", decision_id, reason[:50])
            except AssertionError as e:
                await _reply(f"❌ {e}")
            except Exception as e:
                log.warning("_execute_overturn error: %s", e)
                # [1.2.16] 同上：原因寫 log，不丟給使用者
                await _reply("⚠️ 翻案沒有成功，原因已記錄。要不要再試一次？")
        else:
            await _reply("❌ DecisionManager 未就緒，無法翻案。")

    _HANG_REPORT_PROMPT = (
        "【系統掛起偵測】你已閒置，請立即行動：\n"
        "1. 用 list_tasks 查詢分配給你的 pending 任務\n"
        "2. 有任務 → 選最高優先的立即執行，完成後 update_task + reply 回報\n"
        "3. 無任務 → 讀 memory.md 找待辦，執行後 reply 回報\n"
        "4. 都沒有 → 向 leader 請求派工\n"
        "⚠️ 不要只寫報告，要產出實際成果。"
    )

    _HANG_SILENT_PROMPT = (
        "【系統掛起偵測】你已閒置超過 60 分鐘。\n"
        "請用 list_tasks 查詢你的 pending 任務並立即執行。\n"
        "無任務則讀 memory.md 找待辦。完成後 reply 回報。"
    )

    async def notify_hang(self, instance: str, idle_seconds: float) -> None:
        """閒置通報，按 role 分流：

        - admin/manager → 送提詞 + 通知 Paddy（帶按鈕）
        - leader → 送提詞（靜默，不通知 Paddy）
        - worker → 送提詞（靜默，不通知 Paddy，等 escalation 才通知 leader）

        Special signals:
        - idle_seconds == -1: cooldown (max retries exceeded)
        - idle_seconds == -2: memory warning
        - idle_seconds == -3: rate limit cooldown
        """
        # Rate limit cooldown: 輕量通知，不暫停 agent
        if idle_seconds == -3:
            codename = self._CODENAMES.get(instance, f"🤖 {instance}").split("（")[0].strip()
            text = (
                f"⚡ <b>{codename}</b> 觸發速率限制\n\n"
                f"原因：短時間內 API 請求過多\n"
                f"冷卻時間：<b>90 秒</b>（自動恢復，無需操作）\n"
                f"冷卻結束後會繼續處理中的任務\n\n"
                f"<i>若頻繁觸發，考慮在 team.yaml 調整 model 為較輕量的選項</i>"
            )
            # [v1.1.5 FR-3] Rate limit 是 per-instance 事件 → 只通知 admin/manager，不再全私聊廣播
            for name, cid in self._private_chat_map.items():
                _st = self.daemon.instances.get(name)
                _role = getattr(_st.config, "role", "worker") if _st else "worker"
                if _role not in ("admin", "manager"):
                    continue
                try:
                    await self._send_to_private(cid, text, parse_mode="HTML")
                except Exception:
                    pass
            return

        state = self.daemon.instances.get(instance)
        role = getattr(state.config, "role", "worker") if state else "worker"

        # 安全護欄：已被 cost_guard 暫停的 agent 不觸發
        cg = getattr(self.daemon, "cost_guard", None)
        if cg and cg.is_paused(instance):
            log.info("Hang detected for %s but cost-paused — skipping", instance)
            return

        # 安全護欄：每日觸發上限 3 次
        today = _dt.now().strftime("%Y-%m-%d")
        counter_key = f"{instance}:{today}"
        count = self._hang_daily_count.get(counter_key, 0)
        if count >= 3:
            log.info("Hang detected for %s but daily limit reached (%d/3) — skipping", instance, count)
            return
        self._hang_daily_count[counter_key] = count + 1

        # Worker / Leader: 靜默送提詞，不通知 Paddy
        if role in ("worker", "leader"):
            # P2: 無 pending task → 不送提詞（agent 本來就該閒著）
            try:
                from .task_board import TaskBoard
                from .config import get_home
                tasks_dir = get_home() / "tasks"
                board = TaskBoard(tasks_dir)
                if not board.has_pending(instance):
                    log.info("Hang: %s has no pending tasks, skip prompt (role=%s)", instance, role)
                    return
            except Exception as e:
                log.debug("Hang: TaskBoard check failed for %s: %s (fallback to prompt)", instance, e)

            try:
                await self.daemon.send_message(instance, self._HANG_SILENT_PROMPT)
                log.info("Sent silent hang prompt to %s (role=%s)", instance, role)
            except Exception as e:
                log.warning("Failed to send hang prompt to %s: %s", instance, e)
            return

        # Admin / Manager: 送提詞 + 通知 Paddy
        minutes = int(idle_seconds / 60)
        codename = self._CODENAMES.get(instance, f"🤖 {instance}")
        title = self._TITLES.get(instance, "")
        display = f"{codename}（{title}）" if title else codename

        # Step 1: 發提詞給 agent 本身
        try:
            await self.daemon.send_message(instance, self._HANG_REPORT_PROMPT)
            log.info("Sent hang report prompt to %s", instance)
        except Exception as e:
            log.warning("Failed to send hang prompt to %s: %s", instance, e)

        # Step 2: 通知 Paddy
        import datetime as _dt2
        last_active = ""
        if state and state.last_activity:
            try:
                from zoneinfo import ZoneInfo
                tz = ZoneInfo(self.daemon.config.cost_guard.timezone)
            except Exception:
                tz = None
            last_dt = _dt2.datetime.fromtimestamp(state.last_activity, tz=tz)
            now_dt = _dt2.datetime.now(tz=tz)
            last_active = f"\n上次活動：<code>{last_dt.strftime('%H:%M')}</code>　現在：<code>{now_dt.strftime('%H:%M')}</code>"

        # 分鐘換算成人類友善格式
        if minutes >= 60:
            hours = minutes // 60
            mins = minutes % 60
            idle_display = f"{hours} 小時" + (f" {mins} 分鐘" if mins else "")
        else:
            idle_display = f"{minutes} 分鐘"

        text = (
            f"ℹ️ <b>{display}</b> 閒置超過 {idle_display}"
            f"{last_active}\n\n"
            f"已自動喚醒，等待回覆中。\n"
            f"如需手動介入，請選擇："
        )
        keyboard = self._hang_keyboard(instance)

        private_chat_id = self._private_chat_map.get(instance)
        if private_chat_id:
            try:
                await self._send_to_private(private_chat_id, text, parse_mode="HTML", reply_markup=keyboard)
            except Exception as e:
                log.warning("Failed to send hang notification to private chat for %s: %s", instance, e)
            return

        topic_id = None
        for tid, n in self._topic_map.items():
            if n == instance:
                topic_id = tid
                break
        if topic_id:
            try:
                await self._send_to_topic(topic_id, text, parse_mode="HTML", reply_markup=keyboard)
            except Exception as e:
                log.warning("Failed to send hang notification for %s: %s", instance, e)

    async def notify_hang_escalation(self, instance: str, idle_seconds: float) -> None:
        """二次閾值升級通報：

        - leader 還卡著 → 通知 Paddy
        - worker 還卡著 → 通知 pm-agent（一句話）
        """
        state = self.daemon.instances.get(instance)
        role = getattr(state.config, "role", "worker") if state else "worker"
        minutes = int(idle_seconds / 60)
        codename = self._CODENAMES.get(instance, f"🤖 {instance}")
        title = self._TITLES.get(instance, "")
        display = f"{codename}（{title}）" if title else codename

        if role == "worker":
            # 通知 pm-agent（用 send_message，幾乎零成本）
            leader_name = None
            for name, ic in self.daemon.entity_instances().items():
                if getattr(ic, "role", "") == "leader":
                    leader_name = name
                    break
            if leader_name:
                msg = f"ℹ️ {display} 已閒置 {minutes} 分鐘，可能需要派工或協助。"
                try:
                    await self.daemon.send_message(leader_name, msg)
                    log.info("Hang escalation: notified %s about %s", leader_name, instance)
                except Exception as e:
                    log.warning("Hang escalation to leader failed for %s: %s", instance, e)
            return

        # Leader / admin / manager 升級 → 通知 Paddy
        # 分鐘換算成人類友善格式
        if minutes >= 60:
            hours = minutes // 60
            mins = minutes % 60
            idle_display = f"{hours} 小時" + (f" {mins} 分鐘" if mins else "")
        else:
            idle_display = f"{minutes} 分鐘"

        # 上次活動時間
        last_active = ""
        state2 = self.daemon.instances.get(instance)
        if state2 and state2.last_activity:
            try:
                import datetime as _dt3
                from zoneinfo import ZoneInfo
                tz = ZoneInfo(self.daemon.config.cost_guard.timezone)
                last_dt = _dt3.datetime.fromtimestamp(state2.last_activity, tz=tz)
                last_active = f"\n上次活動：<code>{last_dt.strftime('%H:%M')}</code>"
            except Exception:
                pass

        text = (
            f"⚠️ <b>{display} 長時間無回應</b>\n\n"
            f"閒置：<b>{idle_display}</b>\n"
            f"狀態：自動喚醒 ×2 均無效"
            f"{last_active}\n\n"
            # [1.2.16] 原本列三個工程師視角的「可能原因」，但使用者一個都不能行動 ——
            # 真正能做的是下面三個按鈕。改為一句人話 + 明確建議（含代價）。
            f"喚醒兩次都沒反應，多半是卡在某個請求裡出不來。\n"
            f"最有效的是直接重啟，他會從頭開始（進行中的對話會消失）。"
        )
        # [v1.1.5 FR-3] 與 _hang_keyboard 命名/順序一致（喚醒>重啟>暫停）
        _codename = getattr(self, "_CODENAMES", {}).get(instance, instance)
        escalation_keyboard = InlineKeyboardMarkup([
            [
                InlineKeyboardButton("🔔 喚醒", callback_data=f"hang:plan:{instance}"),
                InlineKeyboardButton("🔁 重啟", callback_data=f"hang:restart:{instance}"),
            ],
            [
                InlineKeyboardButton(f"⏸ 暫停 {_codename} 今日", callback_data=f"hang:assign:{instance}"),
            ],
        ])

        # 找 admin/manager 的私聊（Paddy）
        target_chat = None
        for name, cid in self._private_chat_map.items():
            target_state = self.daemon.instances.get(name)
            if target_state and getattr(target_state.config, "role", "") in ("admin", "manager"):
                target_chat = cid
                break

        if target_chat:
            try:
                await self._send_to_private(target_chat, text, parse_mode="HTML", reply_markup=escalation_keyboard)
            except Exception as e:
                log.warning("Failed to send hang escalation for %s: %s", instance, e)

    async def _notify_to_instance_channel(self, instance: str, text: str, **kwargs) -> None:
        """Internal: send a formatted notification to an instance's topic or private chat."""
        private_chat_id = self._private_chat_map.get(instance)
        if private_chat_id:
            try:
                await self._send_to_private(private_chat_id, text, **kwargs)
            except Exception as e:
                log.warning("Failed to notify private chat for %s: %s", instance, e)
            return

        topic_id = None
        for tid, n in self._topic_map.items():
            if n == instance:
                topic_id = tid
                break
        if topic_id:
            try:
                await self._send_to_topic(topic_id, text, **kwargs)
            except Exception as e:
                log.warning("Failed to notify topic for %s: %s", instance, e)

    async def notify_cost_warn(self, instance: str, spent: float, limit: float) -> None:
        """Warn that an instance is approaching its daily cost limit."""
        pct = (spent / limit * 100) if limit > 0 else 0
        remaining = limit - spent
        # ASCII 進度條（10格）
        filled = int(pct / 10)
        bar = "█" * filled + "░" * (10 - filled)
        codename = self._CODENAMES.get(instance, f"🤖 {instance}").split("（")[0].strip()
        text = (
            f"💰 <b>成本警告</b> — {codename}\n\n"
            f"今日消費：<b>${spent:.2f}</b> / ${limit:.2f}（{pct:.0f}%）\n"
            f"<code>{bar}</code>\n\n"
            f"剩餘額度：<b>${remaining:.2f}</b>\n\n"
            f"<i>達上限後自動暫停，明日 00:00 恢復</i>"
        )
        await self._notify_to_instance_channel(instance, text, parse_mode="HTML")

    async def notify_cost_pause(self, instance: str, spent: float) -> None:
        """Notify that an instance was paused due to reaching the daily cost limit."""
        codename = self._CODENAMES.get(instance, f"🤖 {instance}").split("（")[0].strip()
        text = (
            f"⏸ <b>{codename} 已暫停</b>\n\n"
            f"今日消費 <b>${spent:.2f}</b>，達每日上限。\n\n"
            f"影響：{codename} 無法接收新任務\n"
            f"其他 agent 不受影響 ✅\n"
            f"恢復時間：明日 <code>00:00</code>（Asia/Taipei）\n\n"
            f"<i>如需繼續，請在 team.yaml 提高 daily_limit_usd</i>"
        )
        await self._notify_to_instance_channel(instance, text, parse_mode="HTML")

    async def notify_cost_resume(self, instance: str) -> None:
        """Notify that an instance was resumed after midnight rollover."""
        codename = self._CODENAMES.get(instance, f"🤖 {instance}").split("（")[0].strip()
        # 取預算上限
        limit = 0.0
        cg = getattr(self.daemon, "cost_guard", None)
        if cg:
            limit = cg.daily_limit_usd
        limit_str = f"，預算重置為 <b>${limit:.2f}</b>" if limit > 0 else ""
        text = (
            f"▶️ <b>{codename} 已恢復</b>\n\n"
            f"新的一天開始{limit_str}\n"
            f"{codename} 可以正常接收任務了 🟢"
        )
        await self._notify_to_instance_channel(instance, text, parse_mode="HTML")

    async def notify_recovery(self, instance: str) -> None:
        """Notify that an instance was restarted and recovered by health loop."""
        codename = self._CODENAMES.get(instance, f"🤖 {instance}").split("（")[0].strip()
        text = f"✅ <b>{codename} 已恢復</b>  重啟成功，恢復工作中 🟢"
        general_tid = self.config.general_topic_id or 1
        if self.config.group_id:
            try:
                await self._send_to_topic(general_tid, text, parse_mode="HTML")
            except Exception as e:
                log.warning("notify_recovery failed for %s: %s", instance, e)

    @staticmethod
    async def _on_error(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
        log.error("Telegram error: %s", context.error)

    async def _cmd_start(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle /start — 系統介紹 + 使用者自己的 ID + 如何對話（精簡）。

        [1.2.5] 不 gate：未授權者也能看到自己的 ID 去申請授權（onboarding 入口）。
        狀態歸 /status、完整成員與操作歸 /help。
        """
        user = update.effective_user
        uid = user.id if user else 0
        total = len(self.daemon.config.instances)
        ec = self._entry_codename()
        authed = self._check_access(uid) if uid else False

        lines = [
            "🚀 <b>Paddy 的 AI Team</b>",
            f"{total} 個 AI agent 組成的團隊，用 Telegram 指揮。",
            "",
            f"🆔 你的 ID：<code>{uid}</code>",
        ]
        if authed:
            lines += [
                "　授權狀態：✅ 已授權",
                "",
                "<b>💬 怎麼對話</b>",
                f"　· 私訊我（{ec}）→ 我判斷後幫你分流",
                "　· 群組 <code>@某人 需求</code> → 直接派工，例 <code>@pm 幫我寫規格</code>",
                "",
                "ℹ️ <code>/status</code> 系統狀態　<code>/help</code> 完整成員與操作",
            ]
        else:
            lines += [
                "　授權狀態：⛔ 未授權",
                "",
                "請把上面的 ID 給管理員，用 <code>/allow &lt;ID&gt;</code> 授權後即可使用。",
            ]
        await update.effective_message.reply_text("\n".join(lines), parse_mode="HTML")

    async def _cmd_help(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle /help — [1.2.5] 細部介紹：指令清單 + 完整成員（職責導向）+ @mention 語法。"""
        if not self._check_access(update.effective_user.id):
            return
        insts = self.daemon.config.instances

        def _job(ic, short: str) -> str:
            d = (getattr(ic, "description", "") or "").strip()
            job = d.split("—", 1)[1].strip() if "—" in d else d
            return job or short

        lead, work = [], []
        for name, ic in insts.items():
            short = name.replace("-agent", "")
            entry = f"<code>@{short}</code> {_job(ic, short)}"
            if (getattr(ic, "role", "worker") or "worker") in ("admin", "manager", "leader"):
                lead.append(entry)
            else:
                work.append(entry)

        lines = [
            "🛠 <b>指令</b>",
            "<code>/start</code> 系統介紹 + 你的 ID",
            "<code>/status</code> agent + 主程式狀態",
            "<code>/tasks</code> 任務派工狀況",
            "<code>/restart</code> 重啟服務（需確認，限私聊）",
            "<code>/allow</code> <code>/deny</code> 授權管理（admin）",
            "",
            "👥 <b>完整成員（找誰做什麼）</b>",
        ]
        if lead:
            lines.append("指揮層　" + " · ".join(lead))
        if work:
            lines.append("執行層　" + " · ".join(work))
        lines += [
            "",
            "💬 <b>@mention 派工</b>：<code>@{agent} 你的需求</code> → 直接發給該 agent",
        ]
        await update.effective_message.reply_text("\n".join(lines), parse_mode="HTML")

    async def _cmd_status(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
        if not self._check_access(update.effective_user.id):
            return
        statuses = self.daemon.get_status()
        if not statuses:
            await update.message.reply_text("沒有已定義的 instance")
            return

        # [ark-agent 2026-07-29] 重構：分組顯示 + HTML + 中文狀態
        STATUS_ICON: dict[str, tuple[str, str]] = {
            "running":        ("🟢", "待機"),
            "awaiting_reply": ("⏳", "處理中"),
            "idle":           ("🟢", "待機"),   # [1.2.16] 做完了、沒待辦
            "starting":       ("🔄", "啟動中"),
            "crashed":        ("🔴", "崩潰"),
            "stopped":        ("⚪", "已停止"),
            "paused":         ("⏸", "已暫停"),
        }

        # 按 role 分組
        groups: dict[str, list] = {"admin": [], "manager": [], "leader": [], "worker": []}
        for s in statuses:
            ic = self.daemon.config.instances.get(s["name"])
            role = getattr(ic, "role", "worker") if ic else "worker"
            groups.setdefault(role, []).append(s)

        # [1.2.5] 標題含就緒數 + 主程式健康行（版本 / alive / degraded）
        _run = sum(1 for s in statuses if s["status"] == "running")
        _alive = sum(1 for s in statuses if s["status"] in ("running", "awaiting_reply", "idle"))
        _tot = len(statuses)
        _ver = __import__("ark_team_agent").__version__
        _deg = getattr(self.daemon, "degraded", None) or []
        _deg_txt = f"⚠️ {len(_deg)} 項" if _deg else "無"
        lines = [
            f"📊 <b>AI Team 狀態</b> ｜ {_alive}/{_tot} 存活",
            f"🖥 主程式 v{_ver} · 運行 {_run} · degraded {_deg_txt}\n",
        ]

        # 指揮層（admin + manager 合併）
        mgmt = groups.get("admin", []) + groups.get("manager", [])
        if mgmt:
            lines.append("👑 <b>指揮層</b>")
            for s in mgmt:
                icon, zh = STATUS_ICON.get(s["status"], ("❓", s["status"]))
                cn = self._instance_display(s["name"]).split("（")[0].strip()
                crash_note = f"  <i>⚠️ 崩潰 {s['crash_count']} 次</i>" if s.get("crash_count", 0) > 0 else ""
                lines.append(f"  {icon} {cn}  <i>{zh}</i>{crash_note}")

        # 專案層（leader）
        if groups.get("leader"):
            lines.append("\n📋 <b>專案層</b>")
            for s in groups["leader"]:
                icon, zh = STATUS_ICON.get(s["status"], ("❓", s["status"]))
                cn = self._instance_display(s["name"]).split("（")[0].strip()
                crash_note = f"  <i>⚠️ 崩潰 {s['crash_count']} 次</i>" if s.get("crash_count", 0) > 0 else ""
                lines.append(f"  {icon} {cn}  <i>{zh}</i>{crash_note}")

        # 執行層（workers，每行 3 個緊湊顯示）
        workers = groups.get("worker", [])
        if workers:
            lines.append(f"\n⚙️ <b>執行層</b> ({len(workers)})")
            parts = []
            for s in workers:
                icon, _ = STATUS_ICON.get(s["status"], ("❓", ""))
                cn = self._instance_display(s["name"]).split("（")[0].strip()
                crash_note = " ⚠️" if s.get("crash_count", 0) > 0 else ""
                parts.append(f"{icon} {cn}{crash_note}")
            for i in range(0, len(parts), 3):
                lines.append("  " + "  ".join(parts[i:i + 3]))

        # 統計摘要
        n_running = sum(1 for s in statuses if s["status"] == "running")
        n_waiting = sum(1 for s in statuses if s["status"] == "awaiting_reply")
        n_crashed = sum(1 for s in statuses if s["status"] == "crashed")
        lines.append("\n──────────────")
        summary = f"✅ {n_running} 待機"
        if n_waiting:
            summary += f" · ⏳ {n_waiting} 處理中"
        if n_crashed:
            summary += f" · 🔴 {n_crashed} 崩潰"
        lines.append(summary)

        await update.message.reply_text("\n".join(lines), parse_mode="HTML")

    async def _cmd_restart(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle /restart — [1.2.5] 先跳確認鍵，按「確定重啟」才執行（避免誤觸）。"""
        if not self._check_access(update.effective_user.id):
            return
        # 只允許在私聊執行，避免群組 Topic 誤觸發
        if update.effective_chat.type != "private":
            await update.message.reply_text(
                "⚠️ `/restart` 僅能在私聊中執行，請私訊 Bot 後再輸入。",
                parse_mode="Markdown",
            )
            return
        from telegram import InlineKeyboardButton, InlineKeyboardMarkup
        kb = InlineKeyboardMarkup([[
            InlineKeyboardButton("✅ 確定重啟", callback_data="restart:confirm"),
            InlineKeyboardButton("❌ 取消", callback_data="restart:cancel"),
        ]])
        await update.message.reply_text(
            "⚠️ <b>確定要重啟整個 AI Team？</b>\n重啟期間約 30–60 秒無回應。",
            parse_mode="HTML", reply_markup=kb,
        )

    def _do_restart(self) -> dict:
        """[1.2.5] 實際觸發重啟，供 /restart 確認 callback 呼叫。

        [1.3.3] 改走 `restart.request_restart()` —— 原本這裡與 `api.py` 各有一份
        「寫 flag + SIGTERM」，而且延遲不一致（1.0s vs 0.5s）。兩份必然漂移。
        回傳 dict 含 `will_restart`，呼叫端要據實回報（沒有 supervisor 時
        SIGTERM 等於關機，不可以說「重啟中」）。
        """
        from .restart import request_restart
        return request_restart(delay=1.0, source="telegram:/restart")

    async def _cmd_allow(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle /allow <user_id> — 動態加入授權名單（admin only，免重啟）。"""
        user = update.effective_user
        if not user or not self._check_admin(user.id):
            await update.effective_message.reply_text("❌ 僅授權管理員可執行")
            return
        if not ctx.args:
            await update.effective_message.reply_text("用法：/allow <user_id>")
            return
        try:
            uid = int(ctx.args[0])
        except ValueError:
            await update.effective_message.reply_text("❌ user_id 必須為數字")
            return
        if uid in self.config.allowed_users:
            await update.effective_message.reply_text(f"ℹ️ {uid} 已在名單內")
            return
        self.config.allowed_users.append(uid)
        self._persist_allowed()
        await update.effective_message.reply_text(f"✅ 已授權 {uid}（即時生效）")
        log.info("User %s allowed by %s", uid, user.id)

    async def _cmd_deny(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle /deny <user_id> — 移除授權（admin only，免重啟）。"""
        user = update.effective_user
        if not user or not self._check_admin(user.id):
            await update.effective_message.reply_text("❌ 僅授權管理員可執行")
            return
        if not ctx.args:
            await update.effective_message.reply_text("用法：/deny <user_id>")
            return
        try:
            uid = int(ctx.args[0])
        except ValueError:
            await update.effective_message.reply_text("❌ user_id 必須為數字")
            return
        if uid not in self.config.allowed_users:
            await update.effective_message.reply_text(f"ℹ️ {uid} 不在名單內")
            return
        self.config.allowed_users.remove(uid)
        self._persist_allowed()
        await update.effective_message.reply_text(f"✅ 已移除 {uid}（即時生效）")
        log.info("User %s denied by %s", uid, user.id)

    def _persist_allowed(self) -> None:
        """將目前 allowed_users 寫入 state/allowed_users.json（重啟保留）。"""
        import json
        from .config import get_state_dir
        path = get_state_dir() / "allowed_users.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(self.config.allowed_users), encoding="utf-8")

    def _load_allowed(self) -> None:
        """啟動時合併 state/allowed_users.json 的動態授權（與 team.yaml 取聯集）。"""
        import json
        from .config import get_state_dir
        path = get_state_dir() / "allowed_users.json"
        if not path.exists():
            return
        try:
            extra = json.loads(path.read_text(encoding="utf-8"))
        except (ValueError, OSError) as e:
            log.warning("讀取 allowed_users.json 失敗：%s", e)
            return
        for uid in extra:
            if isinstance(uid, int) and uid not in self.config.allowed_users:
                self.config.allowed_users.append(uid)
        log.info("動態授權已載入，目前 allowed_users=%s", self.config.allowed_users)

    async def _cmd_tasks(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle /tasks — show task board summary."""
        if not self._check_access(update.effective_user.id):
            return
        from pathlib import Path
        from .config import get_home
        from .task_board import TaskBoard
        board = TaskBoard(get_home() / "tasks")
        summary = board.summary(codenames=self._CODENAMES)
        await update.message.reply_text(summary)

    async def _poll_output(self, name: str) -> None:
        """輪詢 agent 輸出，即時進度 + 穩定後發送完整回覆。"""
        from .progress import ProgressReporter

        # Determine output destination: topic or private chat
        topic_id = None
        private_chat_id = self._private_chat_map.get(name)
        # [claude-code 2026-08-06] FR-3：回覆優先跟隨最近來源 topic（_last_source），取代易選錯的反查
        if not private_chat_id and name in self._last_source:
            topic_id = self._last_source[name][1]
        if not private_chat_id and topic_id is None:
            for tid, n in self._topic_map.items():
                if n == name:
                    topic_id = tid
                    break
            if topic_id is None:
                # Fallback: 用 admin 的 private_chat 作為預設出口
                # （純私聊模式下，所有 agent 的 stdout 回覆都送到 admin chat）
                for fallback_name, fallback_cid in self._private_chat_map.items():
                    private_chat_id = fallback_cid
                    break
                if not private_chat_id:
                    return

        async def _send(text: str, **kwargs):
            if private_chat_id:
                return await self._send_to_private(private_chat_id, text, **kwargs)
            return await self._send_to_topic(topic_id, text, **kwargs)

        async def _edit(message_id: int, text: str, **kwargs):
            chat_id = private_chat_id or self.config.group_id
            return await self._app.bot.edit_message_text(
                chat_id=chat_id, message_id=message_id, text=text, **kwargs)

        # Wait for startup output to stabilize, then reset cursor
        await asyncio.sleep(5)
        state = self.daemon.instances.get(name)
        if state and state.process:
            self._output_cursors[name] = len(state.process.capture(lines=500))

        # Determine output mode based on role:
        # - admin: full (stdout flush to TG — Paddy needs visibility to debug)
        # - leader/manager/worker: reply_only (only reply() MCP reaches TG)
        instance_role = "worker"
        if state and hasattr(state, "config") and state.config:
            instance_role = getattr(state.config, "role", "worker")
        reply_only = instance_role in ("worker", "manager", "leader", "admin")

        idle_threshold = 2.0
        buffer = ""
        buffer_since: float = 0
        reporter: ProgressReporter | None = None
        progress_msg_id: int | None = None
        progress_msg_since: float = 0
        progress_timeout = 30 * 60  # 30 minutes

        # ToolTracker: real-time tool call display (only in group topic mode)
        from .tool_tracker import ToolTracker, _TOOL_START_PATTERNS as tool_tracker_patterns
        is_private = name in self._private_chat_map

        # delete_fn: 刪除 topic 訊息（工具狀態訊息在 reply 送出後清除）
        _topic_id_for_tracker = topic_id  # capture for closure
        async def _delete_tracker_msg(message_id: int) -> None:
            try:
                chat_id = self.config.group_id
                if chat_id:
                    await self._app.bot.delete_message(chat_id=chat_id, message_id=message_id)
            except Exception as e:
                log.debug("ToolTracker delete_fn failed: %s", e)

        _comm = getattr(getattr(self.daemon, "config", None), "communication", None)
        tool_tracker = ToolTracker(
            send_fn=_send,
            edit_fn=_edit,
            delete_fn=_delete_tracker_msg,
            enabled=not is_private,
            detail=bool(getattr(_comm, "tool_detail", False)),  # [1.1.9 E]
        )
        codename = self._CODENAMES.get(name, f"🤖 {name}")
        tool_tracker.set_context(codename)
        # 註冊到 _output_trackers 供 reply edit 使用
        self._output_trackers[name] = tool_tracker

        while True:
            try:
                await asyncio.sleep(self.config.poll_interval)
                state = self.daemon.instances.get(name)
                if not state or not state.process:
                    continue

                full = state.process.capture(lines=500)
                cursor = self._output_cursors.get(name, 0)
                has_new = len(full) > cursor

                if has_new:
                    new_text = full[cursor:]
                    self._output_cursors[name] = len(full)
                    if not buffer:
                        buffer_since = asyncio.get_event_loop().time()
                        reporter = ProgressReporter()
                        # Finalize previous tracker if still active (reply_only: reply already sent)
                        if tool_tracker.has_activity:
                            await tool_tracker.finalize()
                            tool_tracker.soft_reset()  # 保留 message_id，下一段繼續 edit 同一條
                        # Update ToolTracker task context from last message sent
                        task_summary = state.last_task if state else ""
                        tool_tracker.set_context(codename, task_summary)
                    buffer += new_text

                    # Feed tool tracker (real-time tool call display)
                    tool_tracker.feed(new_text)
                    await tool_tracker.flush()

                    # Feed skill growth detector from tool tracker detections
                    for line in new_text.splitlines():
                        stripped = line.strip()
                        if not stripped:
                            continue
                        for pattern in tool_tracker_patterns:
                            m = pattern.search(stripped)
                            if m:
                                self._skill_growth.on_tool_call(name, m.group(1))
                                break

                    # Feed progress reporter and update progress message
                    reporter.feed(new_text)
                    progress_text = reporter.render()
                    if progress_text and not reply_only:
                        if not progress_msg_id:
                            m = await _send(
                                f"🚀 {name} 執行中...\n\n{progress_text}",
                            )
                            progress_msg_id = m.message_id
                            progress_msg_since = asyncio.get_event_loop().time()
                        else:
                            try:
                                await _edit(
                                    progress_msg_id,
                                    f"🚀 {name} 執行中...\n\n{progress_text}",
                                )
                            except Exception:
                                pass
                    continue

                # 沒有新輸出 — 檢查進度訊息是否超時
                if progress_msg_id and progress_msg_since:
                    age = asyncio.get_event_loop().time() - progress_msg_since
                    if age > progress_timeout:
                        # Mark as possibly hung + ❌ reaction
                        try:
                            await _edit(
                                progress_msg_id,
                                f"⚠️ {name} 超過 30 分鐘未完成，可能已掛起。",
                            )
                        except Exception:
                            pass
                        await self._finish_reaction(name, success=False)
                        buffer = ""
                        buffer_since = 0
                        reporter = None
                        progress_msg_id = None
                        progress_msg_since = 0
                        tool_tracker.reset()
                        continue

                # 沒有新輸出 — 檢查是否該 flush
                if not buffer:
                    continue

                now = asyncio.get_event_loop().time()
                age = now - buffer_since if buffer_since else 0
                if age < idle_threshold:
                    continue

                # reply_only mode (worker): don't flush stdout text to Telegram.
                # Only ToolTracker progress is shown; final reply comes via reply() MCP.
                if reply_only:
                    # Skill growth: check if we should suggest saving as Skill
                    if self._skill_growth.should_suggest(name):
                        suggestion = self._skill_growth.get_suggestion(name)
                        self._skill_growth.mark_suggested(name)
                        await self.daemon.send_message(name, suggestion)
                        log.info("🌱 Skill growth suggestion sent to %s", name)

                    buffer = ""
                    buffer_since = 0
                    reporter = None
                    if progress_msg_id:
                        try:
                            chat_id = private_chat_id or self.config.group_id
                            await self._app.bot.delete_message(chat_id=chat_id, message_id=progress_msg_id)
                        except Exception:
                            pass
                    progress_msg_id = None
                    progress_msg_since = 0
                    # Keep tool_tracker alive (it resets on next task)
                    continue

                # 更新進度訊息為完成狀態，然後 edit 成最終回覆
                cleaned = self._clean_output(buffer)
                cleaned = self._extract_final_reply(cleaned)
                if cleaned.strip():
                    log.info("📤 %s → TG (%d字)", self._CODENAMES.get(name, name), len(cleaned))
                    formatted = self._format_telegram(cleaned)
                    final_text = formatted[:self.config.max_message_length]

                    plain_text = _strip_html(final_text)

                    # 任務完成有 reply：刪除工具狀態訊息，Topic 只留最終回覆
                    await tool_tracker.delete()

                    if progress_msg_id:
                        # Edit existing progress message into final reply
                        try:
                            await _edit(progress_msg_id, final_text, parse_mode="HTML")
                        except Exception:
                            try:
                                await _edit(progress_msg_id, plain_text)
                            except Exception:
                                pass
                    else:
                        # No progress message yet, send new
                        try:
                            await _send(final_text, parse_mode="HTML")
                        except Exception:
                            await _send(plain_text)
                elif progress_msg_id:
                    # Agent 沒有正式回覆（無 `> ` 段落）— 刪掉進度訊息，不留殘影
                    try:
                        chat_id = private_chat_id or self.config.group_id
                        await self._app.bot.delete_message(chat_id=chat_id, message_id=progress_msg_id)
                    except Exception:
                        pass
                    # Finalize tool tracker (無正式回覆時也清除工具狀態訊息)
                    await tool_tracker.delete()

                buffer = ""
                buffer_since = 0
                reporter = None
                progress_msg_id = None
                progress_msg_since = 0
                tool_tracker.reset()

                # Skill growth: check if we should suggest saving as Skill
                if self._skill_growth.should_suggest(name):
                    suggestion = self._skill_growth.get_suggestion(name)
                    self._skill_growth.mark_suggested(name)
                    # Send suggestion to the agent's stdin (not TG)
                    await self.daemon.send_message(name, suggestion)
                    log.info("🌱 Skill growth suggestion sent to %s", name)

            except asyncio.CancelledError:
                if buffer and not reply_only:
                    await self._flush_buffer(buffer, name, topic_id=topic_id, private_chat_id=private_chat_id)
                return
            except Exception as e:
                log.warning("Output poll error for %s: %s", name, e)
                buffer = ""
                reporter = None
                progress_msg_id = None
                progress_msg_since = 0
                await asyncio.sleep(10)

    async def _flush_buffer(self, raw: str, name: str, *, topic_id: int | None = None, private_chat_id: int | None = None) -> None:
        """清理、格式化並發送一段完整的 agent 輸出。超長訊息自動分段並加序列號。"""
        # Stop typing indicator — agent has produced output
        self._stop_typing(name)
        cleaned = self._clean_output(raw)
        cleaned = self._extract_final_reply(cleaned)
        if not cleaned.strip():
            return
        formatted = self._format_telegram(cleaned)
        limit = self.config.max_message_length
        chunks = [formatted[i:i+limit] for i in range(0, len(formatted), limit)] if len(formatted) > limit else [formatted]
        total = len(chunks)

        chat_id = private_chat_id or self.config.group_id
        thread_id = None if private_chat_id else topic_id

        for idx, chunk in enumerate(chunks, start=1):
            if total > 1:
                chunk = f"<b>[{idx}/{total}]</b>\n{chunk}"
            # Try HTML first, fallback to plain
            plain_chunk = _strip_html(chunk)
            if self._queue:
                from .message_queue import QueuedMessage, MessageType
                self._queue.enqueue(chat_id, thread_id, QueuedMessage(
                    type=MessageType.CONTENT,
                    text=chunk,
                    parse_mode="HTML",
                ))
            else:
                # Fallback: direct send (queue not ready)
                if private_chat_id:
                    try:
                        await self._send_to_private(private_chat_id, chunk, parse_mode="HTML")
                    except Exception:
                        await self._send_to_private(private_chat_id, plain_chunk)
                else:
                    try:
                        await self._send_to_topic(topic_id, chunk, parse_mode="HTML")
                    except Exception:
                        await self._send_to_topic(topic_id, plain_chunk)
        log.debug("Flushed %d chars in %d parts to %s", len(formatted), total, name)

    @staticmethod
    def _clean_output(text: str) -> str:
        """擷取 agent 有意義的回覆，過濾工具呼叫與執行雜訊。"""
        import re

        # 去除 ANSI escape codes（完整版：CSI / OSC / 其他控制序列）
        text = re.sub(r"\x1b\[[0-9;?]*[A-Za-z]", "", text)   # CSI sequences
        text = re.sub(r"\x1b\][^\x07\x1b]*(?:\x07|\x1b\\)", "", text)  # OSC sequences
        text = re.sub(r"\x1b[^[\]A-Za-z]?[A-Za-z]?", "", text)  # other ESC
        text = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]", "", text)  # other control chars

        lines = text.splitlines()
        result = []
        skip = False

        for line in lines:
            stripped = line.strip()

            if not stripped:
                if result and result[-1] != "":
                    result.append("")
                continue

            # 裝飾線
            if all(c in "─━═│┌┐└┘├┤┬┴┼╭╮╰╯▀▄█░▒▓● " for c in stripped):
                continue

            # tool_use / tool_result / function_calls XML 區塊
            if stripped in ("<function_calls>", "</function_calls>", "<function_results>", "</function_results>"):
                skip = True
                continue
            if stripped.startswith("<invoke") or stripped.startswith("<parameter") or stripped.startswith("</"):
                skip = True
                continue
            if re.match(r"^(Tool Use|Tool Result)\b", stripped):
                skip = True
                continue
            if stripped.startswith("tool_use") or stripped.startswith("tool_result"):
                skip = True
                continue

            # Spinner 字元開頭的行（⠧ Thinking...> 等）
            if stripped and stripped[0] in "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏⣾⣽⣻⢿⡿⣟⣯⣷":
                continue
            # Kiro CLI 工具呼叫 UI（Running tool xxx / ⋮ {} / â® {}）
            if re.match(r"^Running tool\s+\w+", stripped, re.I):
                continue
            if re.match(r"^[â®⋮]\s*[\{\"]", stripped) or stripped in ("⋮ {}", "â® {}", "⋮  }", "â®  }"):
                continue
            if re.match(r"^[â®⋮]\s+\"(text|instance|message|task)\"\s*:", stripped):
                continue

            # MCP tool call JSON block: lines starting with ⋮ that form a JSON object
            # Skip entire block from ⋮  { to ⋮  }
            if re.match(r"^[⋮â®]\s*\{", stripped):
                skip = True
                continue
            if skip and re.match(r"^[⋮â®]\s*\}", stripped):
                skip = False
                continue
            if skip and re.match(r"^[⋮â®]\s", stripped):
                continue
            # Kiro 工具執行失敗訊息
            if re.match(r"^● Execution failed after", stripped):
                continue
            if re.match(r"^no occurrences of", stripped, re.I):
                continue
            if re.match(r".+\"\s+were found$", stripped):
                continue
            if re.match(r"^❗\s*(No files found|File not found|Path not found)", stripped, re.I):
                continue
            # Go 程式碼片段
            if re.match(r"^(func |var |type |package |import |const )\w", stripped):
                continue
            if re.match(r"^t\.(Error|Fatal|Errorf|Fatalf|Log|Logf|Skip|Helper)\(", stripped):
                continue
            if re.match(r"^(for|if|switch|select|case|default|return|defer|go)\s+", stripped):
                continue
            if stripped in ("break", "continue", "}", "{", "}", ")"):
                continue
            if re.match(r"^(r|p|t|s|w|b|c|m|g|f)\s*:?=\s*(new|add|make|append|\w+\(|&\w+{|false|true|\d)", stripped):
                continue
            if re.match(r"^\w+\s*=\s*(true|false|\d+|nil|\".*\")$", stripped):
                continue
            if re.match(r"^\w+\.\w+\(.*\)$", stripped):
                continue
            if re.match(r"^請執行(狀況回報|代理分析|計劃|代理重啟)[：:]", stripped):
                continue
            if re.match(r"^\d+\.\s+(整理本\s*agent|讀取\s*memory|參考\s*knowledge|文件化到|立即執行|完成後更新)", stripped):
                continue
            if re.match(r"^\s+-\s+(使用模型|參考檔案|可用\s*skill|待辦任務|優化建議)", stripped):
                continue
            if re.match(r"^完成後(用\s*reply|更新\s*memory|回報)", stripped):
                continue
            if stripped in ("⋮", "…", "·", "•", "‥"):
                continue
            clean_stripped = re.sub(r"^[⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏⣾⣽⣻⢿⡿⣟⣯⣷\s]+", "", stripped).rstrip(">").strip()
            if re.match(r"^\.{1,3}$", clean_stripped) or re.match(r"^\.*(T(h(i(n(k(i(n(g\.*)?)?)?)?)?)?)?)\.{0,3}$", clean_stripped, re.I):
                if not result or result[-1] != "🤔 思考中...":
                    result.append("🤔 思考中...")
                continue

            # 工具呼叫區塊
            if re.match(r"^(Tool Use|Tool Result|Running|Executing|Reading|Writing|Searching|Created|Modified)\b", stripped):
                skip = True
                continue
            # 工具執行摘要（Summary: N operations processed...）
            if re.match(r"^[•·\-\*]?\s*Summary:\s*\d+", stripped, re.I):
                continue
            if re.match(r"^\d+\s+(operations?|files?|items?)\s+(processed|successful|failed)", stripped, re.I):
                continue
            # pytest / 測試框架 raw output
            if re.match(r"^(FAILED|PASSED|ERROR|SKIPPED)\s+.*::", stripped):
                continue
            if re.match(r"^(TimeoutError|AssertionError|RuntimeError|ValueError|KeyError|TypeError):", stripped):
                continue
            if re.match(r"^\s*(tests?/|\.\.\/tests?/)", stripped):
                continue
            # Python 標準庫路徑（C:\Python312\Lib\...）
            if re.match(r"^[A-Za-z]:\\.*\\(Lib|site-packages)\\.*:\d+:", stripped):
                continue
            # pytest-asyncio / pytest 警告訊息
            if re.match(r"^(The event loop scope|Future versions of pytest|Set the def|asyncio_mode|PytestUnraisableExceptionWarning)", stripped, re.I):
                continue
            if re.match(r"^(ault fixture loop scope|Valid fixture loop scopes)", stripped, re.I):
                continue
            # pytest 進度條（....F....  [100%]）
            if re.match(r"^[\.FEsxX]+\s*\[\s*\d+%\]", stripped):
                continue
            # pytest 分隔線與區塊標題
            if re.match(r"^=+\s*(FAILURES|ERRORS|WARNINGS|short test summary|passed|failed|error)", stripped, re.I):
                continue
            if re.match(r"^=+$", stripped):
                continue
            if re.match(r"^_+\s+\w.*\s+_+$", stripped):
                continue
            # pytest 總結行（1 failed, 48 passed in 128.22s）
            if re.match(r"^\d+\s+(failed|passed|error|warning)", stripped, re.I):
                continue
            # Go 測試輸出（file.go:line: 訊息）
            if re.match(r"^\w+_test\.go:\d+:", stripped):
                continue
            # Go 程式碼搜尋結果（types.go:124: GunParts...）
            if re.match(r"^\w+\.go:\d+:", stripped):
                continue
            # Go log 輸出（2026/05/02 00:18:21 ...）
            if re.match(r"^\d{4}/\d{2}/\d{2}\s+\d{2}:\d{2}:\d{2}\s+", stripped):
                continue
            # Shell 指令行（cd xxx && git/go/npm/docker...）
            if re.match(r"^cd\s+\S+\s*&&", stripped):
                continue
            if re.match(r"^\+\s+cd\s+", stripped):
                continue
            if re.match(r"^(git|go|npm|pip|docker|kubectl|helm)\s+(push|pull|build|run|deploy|install)", stripped):
                continue
            # git status 輸出（M/A/D/R/? 開頭的檔案狀態）
            if re.match(r"^[MADRCU\?!]{1,2}\s+\S+\.\w+$", stripped):
                continue
            # git diff stat（server/game.go | 25 +++---）
            if re.match(r"^\S+\s*\|\s*\d+\s*[\+\-]+", stripped):
                continue
            if re.match(r"^(fatal|error|remote):\s+", stripped, re.I):
                continue
            if re.match(r"^git\s*:\s+", stripped, re.I):
                continue
            if re.match(r"^hint:\s+", stripped, re.I):
                continue
            if re.match(r"^(Please make sure|and the repository|Could not read from)", stripped, re.I):
                continue
            # Docker build 輸出
            if re.match(r"^#\d+\s+\[", stripped):
                continue
            if re.match(r"^#\d+\s+(transferring|load|DONE|CACHED|ERROR)", stripped, re.I):
                continue
            if re.match(r"^#\d+\s+\d+\.\d+", stripped):
                continue
            # PowerShell 錯誤輸出
            if re.match(r"^At line:\d+", stripped):
                continue
            if re.match(r"^\+\s+.*\$", stripped):
                continue
            if re.match(r"^\+\s+~+$", stripped):
                continue
            if re.match(r"^\s+\+\s+CategoryInfo\s*:", stripped):
                continue
            if re.match(r"^\s+\+\s+FullyQualifiedErrorId\s*:", stripped):
                continue
            # PowerShell cmdlet 錯誤（Invoke-WebRequest、Get-Content 等）
            if re.match(r"^(Invoke-WebRequest|Invoke-RestMethod|Get-Content|Set-Content|New-Item|Remove-Item)\s*:", stripped):
                continue
            if re.match(r"^The remote name could not be resolved", stripped):
                continue
            # Shell 路徑 + 指令輸出
            if re.match(r"^\+\s+\.\.\.", stripped):
                continue
            # Kiro CLI 啟動訊息
            if re.match(r"^(KIRO|Welcome|Prefer the classic|Warning:|In this mode|This mode is|By proceeding|trust all tools|Yes, I accept|No, exit|Credits:|ask a question)", stripped, re.I):
                continue
            # Kiro CLI tool purpose marker（Purpose: xxx）
            if re.match(r"^Purpose:\s+", stripped):
                continue
            # Go compiler warnings
            if re.match(r"^go:\s+(warning|downloading|extracting)", stripped):
                continue
            # Docker desktop / buildx links
            if re.match(r"^View build details:\s+docker-desktop://", stripped):
                continue
            # Bare image/container name echo (single word, no spaces, looks like hash or name)
            if re.match(r"^[a-z][a-z0-9_-]+$", stripped) and len(stripped) < 40:
                continue
            # File listing output (Mode/LastWriteTime/Length/Name table)
            if re.match(r"^(Mode|----)\s+(LastWriteTime|-----)", stripped):
                continue
            if re.match(r"^[d-]{6}\s+\d{4}/\d{1,2}/\d{1,2}", stripped):
                continue
            if re.match(r"^目錄:\s+[A-Z]:\\", stripped):
                continue
            # Time metadata / tool completion / fetch results
            if re.match(r"^[▸▹►]?\s*Time:", stripped):
                continue
            # Tool completion results (all ✓ lines are tool output)
            if stripped.startswith(("✓", "✔", "☑")):
                continue
            # Bullet completion lines
            if re.match(r"^[•·\-\*]\s*Completed", stripped):
                continue
            # "Completed in" anywhere
            if "Completed in " in stripped:
                continue
            if re.match(r"^[A-Z]:\\|^/[a-z]", stripped) and skip:
                continue
            if stripped == "```" and skip:
                skip = not skip
                continue

            # 偵測到正常文字，停止跳過
            if skip and not re.match(r"^[\s│├└┌\d]+$", stripped):
                skip = False

            if not skip:
                result.append(stripped)

        while result and result[0] == "":
            result.pop(0)
        while result and result[-1] == "":
            result.pop()

        return "\n".join(result)

    # 使用者可見訊息的硬上限（含截斷提示）
    _MAX_REPLY_CHARS = 3500
    _TRUNCATE_HINT = "\n\n📎 原文過長已截斷"

    @staticmethod
    def _extract_final_reply(cleaned: str) -> str:
        """從 cleaned 輸出中擷取 agent 的最終回覆。

        策略：
        1. 若有 `> ` 前綴：只取最後一段 `> ` 區塊（排除工具呼叫前文）
        2. 若無 `> ` 前綴：以 shell pattern 黑名單過濾後發出（純 markdown 回覆也保留）
        3. 套用 _MAX_REPLY_CHARS 硬上限
        """
        import re

        if not cleaned.strip():
            return ""

        lines = cleaned.splitlines()

        # 尋找 '> ' agent 回覆前綴
        reply_indices = [i for i, line in enumerate(lines) if line.startswith("> ")]

        if reply_indices:
            # 有 `> ` 段落：取最後一段
            start = reply_indices[-1]
            collected: list[str] = []
            for ln in lines[start:]:
                # Kiro CLI 回覆後會接 timer footer
                if re.match(r"^\s*▸\s+Time:", ln):
                    break
                if re.match(r"^\s*-\s*Completed in ", ln):
                    break
                collected.append(ln)
            if collected and collected[0].startswith("> "):
                collected[0] = collected[0][2:]
            while collected and not collected[-1].strip():
                collected.pop()
            result = "\n".join(collected)
        else:
            # 沒 `> ` 段落：用 shell pattern 過濾後放行（fallback）
            fallback = TelegramAdapter._drop_shell_output(cleaned)
            if not fallback.strip():
                log.info("No '> ' prefix and fallback empty — suppressing (%d chars)", len(cleaned))
                return ""
            log.info("No '> ' prefix — using fallback filter (%d→%d chars)", len(cleaned), len(fallback))
            result = fallback

        # 硬截斷保險絲
        if len(result) > TelegramAdapter._MAX_REPLY_CHARS:
            cap = TelegramAdapter._MAX_REPLY_CHARS - len(TelegramAdapter._TRUNCATE_HINT)
            result = result[:cap].rstrip() + TelegramAdapter._TRUNCATE_HINT

        return result

    # Known shell stdout line patterns — drop these when no `>` reply marker exists.
    _SHELL_LINE_PATTERNS = [
        # git
        re.compile(r"^\s*\d+ files? changed"),
        re.compile(r"^\s*create mode \d+ "),
        re.compile(r"^\s*delete mode \d+ "),
        re.compile(r"^\s*rename \S+ => \S+"),
        re.compile(r"^\s*\d+ insertions?\(\+\)"),
        re.compile(r"^\s*\d+ deletions?\(-\)"),
        re.compile(r"^To https?://.+\.git$"),
        re.compile(r"^Updating [0-9a-f]{7,}\.\.[0-9a-f]{7,}$"),
        re.compile(r"^Fast-forward$"),
        re.compile(r"^Initialized empty Git repository"),
        re.compile(r"^Cloning into '.+'\.{3}$"),
        re.compile(r"^From https?://\S+$"),
        re.compile(r"^\s*\*\s+\[new branch\]\s"),
        re.compile(r"^\s*\*\s+\[new tag\]\s"),
        re.compile(r"^[AMD]\s{2,}\S+"),           # git status short format
        re.compile(r"^remote: "),
        re.compile(r"^Branch '.+' set up to track"),
        re.compile(r"^Switched to (a new )?branch "),
        re.compile(r"^\s+\S+\s+\|\s+\d+\s+[+-]+\s*$"),  # git diff stat line
        re.compile(r"^Counting objects: "),
        re.compile(r"^Compressing objects: "),
        re.compile(r"^Writing objects: "),
        re.compile(r"^Resolving deltas: "),
        re.compile(r"^Enumerating objects: "),
        re.compile(r"^Total \d+ \(delta \d+\)"),
        # npm / yarn
        re.compile(r"^\s*added \d+ packages"),
        re.compile(r"^\s*removed \d+ packages"),
        re.compile(r"^\s*changed \d+ packages"),
        # docker
        re.compile(r"^Successfully built [0-9a-f]{12}"),
        re.compile(r"^Successfully tagged "),
        # Kiro CLI tool timer
        re.compile(r"^\s*-\s*Completed in [\d.]+s$"),
        re.compile(r"^\s*▸\s+Time: "),
    ]

    @staticmethod
    def _drop_shell_output(text: str) -> str:
        """Drop lines matching known shell-stdout patterns. Best-effort fallback."""
        kept: list[str] = []
        for line in text.splitlines():
            if any(p.match(line) for p in TelegramAdapter._SHELL_LINE_PATTERNS):
                continue
            kept.append(line)
        # Remove duplicate blank lines
        result: list[str] = []
        for line in kept:
            if not line.strip() and result and not result[-1].strip():
                continue
            result.append(line)
        while result and not result[0].strip():
            result.pop(0)
        while result and not result[-1].strip():
            result.pop()
        return "\n".join(result)

    @staticmethod
    def _format_telegram(text: str) -> str:
        """將 agent 回覆轉換為 Telegram HTML 格式，精美呈現。"""
        import re
        from html import escape

        lines = text.splitlines()
        out = []
        in_code = False
        code_lang = ""
        code_buf = []

        for line in lines:
            # Code block 開始/結束
            m = re.match(r"^```(\w*)$", line.strip())
            if m:
                if in_code:
                    # 結束 code block
                    code_content = escape("\n".join(code_buf))
                    if code_lang:
                        out.append(f'<pre><code class="language-{code_lang}">{code_content}</code></pre>')
                    else:
                        out.append(f"<pre>{code_content}</pre>")
                    code_buf = []
                    in_code = False
                else:
                    in_code = True
                    code_lang = m.group(1)
                continue

            if in_code:
                code_buf.append(line)
                continue

            stripped = line.strip()

            # 標題 → 粗體
            hm = re.match(r"^(#{1,3})\s+(.+)$", stripped)
            if hm:
                out.append(f"\n<b>{escape(hm.group(2))}</b>")
                continue

            # 列表項 → bullet
            lm = re.match(r"^[-*]\s+(.+)$", stripped)
            if lm:
                out.append(f"  • {_inline_fmt(lm.group(1))}")
                continue

            # 數字列表
            nm = re.match(r"^(\d+)[.)]\s+(.+)$", stripped)
            if nm:
                out.append(f"  {nm.group(1)}. {_inline_fmt(nm.group(2))}")
                continue

            # 空行
            if not stripped:
                out.append("")
                continue

            # 一般文字
            out.append(_inline_fmt(stripped))

        # 未關閉的 code block
        if in_code and code_buf:
            out.append(f"<pre>{escape(chr(10).join(code_buf))}</pre>")

        result = "\n".join(out).strip()

        # 壓縮連續空行
        result = re.sub(r"\n{3,}", "\n\n", result)
        return result


def _strip_html(text: str) -> str:
    """移除 HTML 標籤，還原為純文字。"""
    import re
    from html import unescape
    text = re.sub(r"<[^>]+>", "", text)
    return unescape(text)


def _inline_fmt(text: str) -> str:
    """處理行內 markdown 格式 → Telegram HTML。"""
    from html import escape
    import re

    text = escape(text)
    # **bold** → <b>
    text = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", text)
    # *italic* → <i>
    text = re.sub(r"\*(.+?)\*", r"<i>\1</i>", text)
    # `code` → <code>
    text = re.sub(r"`(.+?)`", r"<code>\1</code>", text)
    return text
