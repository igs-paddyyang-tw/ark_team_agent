"""任務板截圖工具 — 將任務資料渲染為手機友善 HTML 後截圖。

Usage:
    py scripts/task_screenshot.py [--status completed] [--output path.png]
"""
from __future__ import annotations

import argparse
import json
import sys
import tempfile
from datetime import datetime
from pathlib import Path

# ── 加入 src 到 path ──────────────────────────────────────────
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))


def load_tasks(status: str | None = None) -> list[dict]:
    """從 board.json 載入任務。

    預設規則（status=None）：顯示未完成任務 + 最近 7 天已完成。
    指定 status 時：僅顯示該狀態的任務。
    """
    from ark_team_agent.config import get_home
    board_path = get_home() / "tasks" / "board.json"
    if not board_path.exists():
        return []
    data = json.loads(board_path.read_text(encoding="utf-8"))
    tasks = data.get("tasks", [])
    if status:
        tasks = [t for t in tasks if t.get("status") == status]
    else:
        # 預設：未完成 + 最近 7 天已完成
        from datetime import timedelta
        cutoff = (datetime.now() - timedelta(days=7)).isoformat()
        result = []
        for t in tasks:
            s = t.get("status", "pending")
            if s in ("pending", "in_progress", "blocked", "failed"):
                result.append(t)
            elif s == "completed":
                completed_at = t.get("completed_at", "")
                if completed_at >= cutoff:
                    result.append(t)
        tasks = result
    return tasks


def render_html(tasks: list[dict], title: str = "任務板") -> str:
    """將任務列表渲染為手機友善 HTML。"""
    codenames = {
        "pm-agent": "🔱綱手", "gamedev-agent": "🎮鳴人", "frontend-agent": "👁️寧次",
        "backend-agent": "🐛志乃", "gameqa-agent": "🔍雛田", "design-agent": "🧠佐助",
        "art-agent": "🎨井野", "audio-agent": "🎵紅", "analyst-agent": "📈小櫻",
        "devops-agent": "⚙️卡卡西", "prodops-agent": "📊鹿丸", "team-agent": "👑Kiro",
        "game-team-agent": "🏯大名",
    }
    priority_colors = {
        "critical": "#ef4444", "high": "#f97316", "medium": "#eab308", "low": "#22c55e",
    }
    status_icons = {
        "pending": "⏳", "in_progress": "🔄", "completed": "✅", "blocked": "🚫", "failed": "❌",
    }

    # 統計
    by_status: dict[str, int] = {}
    for t in tasks:
        s = t.get("status", "pending")
        by_status[s] = by_status.get(s, 0) + 1
    total = len(tasks)

    now = datetime.now().strftime("%Y-%m-%d %H:%M")

    # 產生任務行
    rows = []
    for t in tasks:
        name = codenames.get(t.get("assignee", ""), t.get("assignee", ""))
        priority = t.get("priority", "medium")
        p_color = priority_colors.get(priority, "#94a3b8")
        s_icon = status_icons.get(t.get("status", ""), "•")
        note = t.get("note", "") or ""
        if len(note) > 20:
            note = note[:20] + "…"
        created = (t.get("created_at") or "")[:10]
        completed = (t.get("completed_at") or "")[:10]

        rows.append(f"""<tr>
<td class="pri" style="border-left:3px solid {p_color}">{s_icon}</td>
<td class="title">{_esc(t.get('title', ''))}</td>
<td class="assignee">{name}</td>
<td class="date">{completed or created}</td>
</tr>""")

    rows_html = "\n".join(rows)

    # 統計 bar
    stats_parts = []
    for s, icon in [("completed", "✅"), ("in_progress", "🔄"), ("pending", "⏳"), ("blocked", "🚫"), ("failed", "❌")]:
        cnt = by_status.get(s, 0)
        if cnt:
            stats_parts.append(f'<span class="stat">{icon} {cnt}</span>')
    stats_html = " ".join(stats_parts)

    return f"""<!DOCTYPE html>
<html lang="zh-TW">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=390">
<style>
* {{ margin:0; padding:0; box-sizing:border-box; }}
body {{
  font-family: -apple-system, "Microsoft JhengHei", "Noto Sans TC", sans-serif;
  background: #0f172a;
  color: #e2e8f0;
  padding: 16px;
  width: 390px;
}}
.header {{
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12px;
  padding-bottom: 8px;
  border-bottom: 1px solid #334155;
}}
.header h1 {{
  font-size: 18px;
  font-weight: 700;
  color: #22d3ee;
}}
.header .time {{
  font-size: 11px;
  color: #64748b;
}}
.stats {{
  display: flex;
  gap: 12px;
  margin-bottom: 12px;
  font-size: 13px;
}}
.stat {{
  background: #1e293b;
  padding: 4px 8px;
  border-radius: 6px;
}}
table {{
  width: 100%;
  border-collapse: collapse;
  font-size: 12px;
}}
th {{
  text-align: left;
  padding: 6px 4px;
  color: #94a3b8;
  font-size: 10px;
  font-weight: 600;
  text-transform: uppercase;
  border-bottom: 1px solid #334155;
}}
td {{
  padding: 7px 4px;
  border-bottom: 1px solid #1e293b;
  vertical-align: top;
}}
.pri {{ width: 24px; text-align: center; }}
.title {{ font-weight: 500; color: #f1f5f9; line-height: 1.3; }}
.assignee {{ white-space: nowrap; color: #94a3b8; font-size: 11px; }}
.date {{ white-space: nowrap; color: #64748b; font-size: 10px; }}
.footer {{
  margin-top: 10px;
  text-align: center;
  font-size: 10px;
  color: #475569;
}}
</style>
</head>
<body>
<div class="header">
  <h1>📋 {_esc(title)}</h1>
  <span class="time">{now}</span>
</div>
<div class="stats">{stats_html} <span class="stat">共 {total}</span></div>
<table>
<thead><tr><th></th><th>任務</th><th>負責</th><th>日期</th></tr></thead>
<tbody>
{rows_html}
</tbody>
</table>
<div class="footer">ark-team-agent · 自動產出</div>
</body>
</html>"""


def _esc(text: str) -> str:
    """HTML escape."""
    return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")


def screenshot_html(html: str, output: Path) -> Path:
    """用 Playwright 截圖 HTML。"""
    from playwright.sync_api import sync_playwright

    with tempfile.NamedTemporaryFile(suffix=".html", delete=False, mode="w", encoding="utf-8") as f:
        f.write(html)
        html_path = Path(f.name)

    try:
        with sync_playwright() as p:
            browser = p.chromium.launch()
            page = browser.new_page(viewport={"width": 390, "height": 800})
            page.goto(f"file:///{html_path.as_posix()}", wait_until="networkidle")
            # 自動調整高度
            height = page.evaluate("document.body.scrollHeight")
            page.set_viewport_size({"width": 390, "height": min(height + 32, 4096)})
            output.parent.mkdir(parents=True, exist_ok=True)
            page.screenshot(path=str(output), full_page=True)
            browser.close()
    finally:
        html_path.unlink(missing_ok=True)

    return output


def generate_task_image(status: str | None = None, title: str = "任務板") -> Path:
    """一站式：載入任務 → 渲染 HTML → 截圖 → 回傳圖片路徑。"""
    tasks = load_tasks(status)
    if not tasks:
        # 空任務也產出一張圖
        tasks = []
    html = render_html(tasks, title=title)
    output = Path(tempfile.gettempdir()) / "ark_task_board.png"
    return screenshot_html(html, output)


def main() -> None:
    parser = argparse.ArgumentParser(description="任務板截圖")
    parser.add_argument("--status", default=None, help="篩選狀態")
    parser.add_argument("--output", default=None, help="輸出路徑")
    parser.add_argument("--title", default="任務板", help="標題")
    args = parser.parse_args()

    tasks = load_tasks(args.status)
    html = render_html(tasks, title=args.title)
    # 預設輸出以 team home 為基準，不用 cwd 相對路徑 ——
    # `load_tasks()` 已經是用 `get_home()` 讀 board.json，輸出卻依 cwd 會不對稱：
    # 從別的目錄跑會「讀到正確的任務、但把圖寫到別處」。
    # （`team_mcp` 一律傳 `--output`，所以這個預設只有人手動跑才會用到。）
    if args.output:
        output = Path(args.output)
    else:
        from ark_team_agent.config import get_home
        output = get_home() / "artifacts" / "task_board.png"
        output.parent.mkdir(parents=True, exist_ok=True)
    result = screenshot_html(html, output)
    print(f"✅ 截圖完成：{result}")


if __name__ == "__main__":
    main()
