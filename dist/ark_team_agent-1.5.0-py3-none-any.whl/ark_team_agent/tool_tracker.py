"""ToolTracker — real-time tool call progress display via Telegram message editing."""
from __future__ import annotations

import logging
import re
import time

log = logging.getLogger(__name__)

# Kiro CLI tool-use output patterns (observed from stdout)
_TOOL_START_PATTERNS = [
    # ⏺ Read(file_path="src/main.py") — Claude Code format
    re.compile(r"⏺\s*(Read|Write|Edit|MultiEdit)\(.*?file_path=\"([^\"]+)\""),
    # ⏺ Bash(command="pytest ...")
    re.compile(r"⏺\s*(Bash)\(.*?command=\"([^\"]{0,60})"),
    # ⏺ Glob(pattern="**/*.py")
    re.compile(r"⏺\s*(Glob|Grep)\(.*?pattern=\"([^\"]+)\""),
    # ⏺ WebSearch(query="...")
    re.compile(r"⏺\s*(WebSearch|WebFetch)\(.*?(?:query|url)=\"([^\"]{0,60})"),
    # ⏺ ListDirectory(path="src/")
    re.compile(r"⏺\s*(ListDirectory)\(.*?path=\"([^\"]+)\""),
    # Kiro CLI --legacy-ui format: "Using tool: tool_name" or "Tool: tool_name"
    re.compile(r"(?:Using tool|Tool):\s*([a-z_]+)", re.IGNORECASE),
    # Kiro CLI MCP tool call: "fs_read", "fs_write", "grep", "glob", "execute_cmd", etc.
    re.compile(r"^\s*(?:Calling|Invoking)\s+([a-z_]+)", re.IGNORECASE),
    # Kiro CLI function call format: tool_name(params)
    re.compile(r"^([a-z_]{3,30})\("),
    # Generic fallback: ⏺ ToolName(...)
    re.compile(r"⏺\s*([A-Z][A-Za-z]+)\("),
]

# Tool completion pattern
_TOOL_DONE_PATTERN = re.compile(r"^\s*[-─]\s*Completed in [\d.]+s")

# Debounce: minimum interval between edits (seconds)
_EDIT_DEBOUNCE = 3.0
# [1.2.7] Skill 自薦門檻：完成時步數 ≥ 此值 → 提示可沉澱為 Skill（取經 hoyeah #12）
SKILL_HINT_STEPS = 12
# Max lines to show
_MAX_LINES = 8

# 階段映射：tool 名稱 → 使用者可讀階段描述
_PHASE_MAP: dict[str, str] = {
    # 分析類 → 統一「分析中」（含 Kiro 小寫實名 read/grep/glob）
    "wiki_query": "🔍 分析中",
    "grep": "🔍 分析中",
    "glob": "🔍 分析中",
    "read": "🔍 分析中",
    "fs_read": "🔍 分析中",
    "Read": "🔍 分析中",
    "Grep": "🔍 分析中",
    "Glob": "🔍 分析中",
    "ListDirectory": "🔍 分析中",
    "WebSearch": "🔍 分析中",
    "WebFetch": "🔍 分析中",
    # 撰寫類 → 統一「撰寫中」（含 Kiro 小寫實名 write/edit）
    "write": "✍️ 撰寫中",
    "edit": "✍️ 撰寫中",
    "fs_write": "✍️ 撰寫中",
    "Write": "✍️ 撰寫中",
    "Edit": "✍️ 撰寫中",
    "MultiEdit": "✍️ 撰寫中",
    # 執行類（含 Kiro 小寫實名 shell）
    "shell": "⚙️ 執行中",
    "Bash": "⚙️ 執行中",
    "execute_cmd": "⚙️ 執行中",
    # 協作類 → 統一「派工中」
    "delegate_task": "📋 派工中",
    "send_to_instance": "📋 派工中",
    "reply": "✅ 回覆中",
}


class ToolTracker:
    """Tracks tool calls from Kiro CLI stdout and updates a single Telegram message.

    Usage:
        tracker = ToolTracker(send_fn, edit_fn)
        tracker.set_context("👑 KIRO", "修復啟動訊息重複")
        tracker.feed(new_output_chunk)  # call on each poll
        # When task is done:
        await tracker.finalize()  # edit to completed state (not delete)
        tracker.reset()
    """

    def __init__(
        self,
        send_fn,   # async (text) -> message with .message_id
        edit_fn,   # async (message_id, text) -> None
        delete_fn=None,  # async (message_id) -> None
        enabled: bool = True,
        detail: bool = False,  # [1.1.9 E] True=完整工具序列，False=人性化單行階段（預設）
    ) -> None:
        self._send = send_fn
        self._edit = edit_fn
        self._delete_fn = delete_fn
        self._enabled = enabled
        self._detail = detail
        self._message_id: int | None = None
        self._lines: list[str] = []
        # [1.2.7] 真實步數累計（_lines 受 _MAX_LINES 截斷，不能當步數 —— 原本長任務會低報）
        self._total_steps: int = 0
        self._current_tool: str | None = None
        self._last_edit: float = 0
        self._pending_edit: bool = False
        self._codename: str = ""
        self._task_summary: str = ""
        self._start_time: float = 0

    @property
    def message_id(self) -> int | None:
        return self._message_id

    @property
    def has_activity(self) -> bool:
        return len(self._lines) > 0

    def set_context(self, codename: str, task_summary: str = "") -> None:
        """Set who is working and on what task."""
        self._codename = codename
        self._task_summary = task_summary[:60] if task_summary else ""
        self._start_time = time.time()

    def _render(self, done: bool = False, user_facing: bool = False) -> str:
        """Render the tracker message text.

        Args:
            done: Whether the task is completed.
            user_facing: If True, show human-readable phases instead of tool details.
        """
        header = ""
        if self._codename:
            status = "✅ 完成" if done else "⏳ 工作中"
            header = f"{self._codename} {status}"
            if self._task_summary:
                header += f"\n📋 {self._task_summary}"
            header += "\n\n"

        if user_facing:
            # 使用者模式：顯示當前階段（從階段映射取得）
            phase = _PHASE_MAP.get(self._current_tool, "⏳ 處理中") if self._current_tool else "⏳ 處理中"
            n = self._total_steps or len(self._lines)
            if done:
                body = f"✅ 已完成（{n} 步驟）"
                # [1.2.7] Skill 自薦：步數達門檻 → 提示可沉澱為 Skill（推動 Skill 成長迴圈）
                if n >= SKILL_HINT_STEPS:
                    body += f"\n💡 這個任務走了 {n} 步，重複做的話建議存成 Skill"
            else:
                body = f"{phase}...（第 {n} 步）"
        else:
            body = "\n".join(self._lines)
        return f"{header}{body}"

    def feed(self, text: str) -> None:
        """Feed new stdout chunk. Detects tool starts and completions."""
        for line in text.splitlines():
            stripped = line.strip()
            if not stripped:
                continue

            # Check for tool completion
            if _TOOL_DONE_PATTERN.match(stripped) and self._current_tool:
                # Mark current tool as done
                for i in range(len(self._lines) - 1, -1, -1):
                    if self._lines[i].startswith("🔧") and self._current_tool in self._lines[i]:
                        self._lines[i] = self._lines[i].replace("🔧", "✅", 1)
                        break
                self._current_tool = None
                self._pending_edit = True
                continue

            # Check for tool start
            for pattern in _TOOL_START_PATTERNS:
                m = pattern.search(stripped)
                if m:
                    tool_name = m.group(1)
                    detail = m.group(2) if m.lastindex >= 2 else ""
                    summary = f"🔧 {tool_name}: {detail}" if detail else f"🔧 {tool_name}"

                    # Mark previous tool as done if still pending
                    if self._current_tool:
                        for i in range(len(self._lines) - 1, -1, -1):
                            if self._lines[i].startswith("🔧"):
                                self._lines[i] = self._lines[i].replace("🔧", "✅", 1)
                                break

                    self._lines.append(summary)
                    self._total_steps += 1
                    self._current_tool = tool_name

                    # Keep only last N lines
                    if len(self._lines) > _MAX_LINES:
                        self._lines = self._lines[-_MAX_LINES:]

                    self._pending_edit = True
                    break

    async def flush(self) -> None:
        """Send or edit the progress message if there are pending changes."""
        if not self._enabled:
            return
        if not self._pending_edit or not self._lines:
            return

        now = time.time()
        if now - self._last_edit < _EDIT_DEBOUNCE:
            return

        text = self._render(user_facing=not self._detail)  # [1.1.9 E] detail=True→完整工具序列
        self._pending_edit = False
        self._last_edit = now

        try:
            if not self._message_id:
                msg = await self._send(text)
                self._message_id = msg.message_id
            else:
                await self._edit(self._message_id, text)
        except Exception as e:
            log.debug("ToolTracker edit failed: %s", e)

    async def finalize(self) -> None:
        """Edit message to completed state. Skip if task < 10s or disabled."""
        if not self._enabled:
            return
        if not self._message_id or not self._lines:
            return
        # 快速任務（<10 秒）不顯示完成訊息，直接刪除
        elapsed = time.time() - self._start_time if self._start_time else 0
        if elapsed < 10:
            try:
                await self._edit(self._message_id, "")
            except Exception:
                pass
            return
        text = self._render(done=True, user_facing=not self._detail)  # [1.1.9 E] detail=True→完整工具序列
        try:
            await self._edit(self._message_id, text)
        except Exception as e:
            log.debug("ToolTracker finalize failed: %s", e)

    def reset(self) -> None:
        """Reset tracker state for next task."""
        self._message_id = None
        self._lines.clear()
        self._total_steps = 0  # [1.2.7] 跨任務歸零，避免步數累加
        self._current_tool = None
        self._pending_edit = False
        self._last_edit = 0
        self._codename = ""
        self._task_summary = ""
        self._start_time = 0

    def soft_reset(self) -> None:
        """段落間 reset：清 lines 但保留 message_id，讓下一段繼續 edit 同一條訊息。

        用於 _poll_output 多段 stdout 之間，避免產生多條工具狀態訊息。
        """
        self._lines.clear()
        self._current_tool = None
        self._pending_edit = False
        # 保留：_message_id / _codename / _start_time / _last_edit

    async def delete(self) -> None:
        """刪除工具狀態訊息。任務完成且有 reply 時呼叫，讓 Topic 只留最終回覆。"""
        if not self._message_id or not self._delete_fn:
            return
        try:
            await self._delete_fn(self._message_id)
        except Exception as e:
            log.debug("ToolTracker delete failed: %s", e)
        finally:
            self._message_id = None
