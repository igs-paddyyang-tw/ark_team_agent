"""ChatRouter — @mention parsing and instance routing for private chat."""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field

log = logging.getLogger(__name__)

# @mention pattern: @codename (Chinese or English, 1-20 chars)
_MENTION_PATTERN = re.compile(r"@([\w\u4e00-\u9fff]{1,20})")


@dataclass
class RouteResult:
    """Result of routing a message."""

    targets: list[str] = field(default_factory=list)
    text: str = ""  # message with @mentions stripped
    is_broadcast: bool = False


class ChatRouter:
    """Parse @mentions and route to target instances.

    Usage:
        router = ChatRouter(codename_map, instances)
        result = router.route("@鳴人 寫登入 API")
        # result.targets = ["gamedev-agent"]
        # result.text = "寫登入 API"
    """

    def __init__(
        self,
        codename_map: dict[str, str] | None = None,
        instances: list[str] | None = None,
    ) -> None:
        """Initialize router.

        Args:
            codename_map: {codename → instance_name} mapping.
                          Supports emoji+name (e.g. "🎮 鳴人") and plain name ("鳴人").
            instances: list of valid instance names for direct @instance matching.
        """
        self._instances = set(instances or [])
        # Build lookup: lowercase/stripped codename → instance_name
        self._lookup: dict[str, str] = {}
        if codename_map:
            for instance, display in codename_map.items():
                # Strip emoji prefix for matching
                name_only = re.sub(r"^[^\w\u4e00-\u9fff]+", "", display).strip()
                self._lookup[name_only.lower()] = instance
                # Also add without spaces
                self._lookup[name_only.replace(" ", "").lower()] = instance
                # Add instance name without -agent suffix
                short = instance.replace("-agent", "")
                self._lookup[short.lower()] = instance

    def route(self, text: str, fallback: str | None = None) -> RouteResult:
        """Parse @mentions and determine targets.

        Args:
            text: raw message text
            fallback: instance to use when no @mention found (e.g. "team-agent")

        Returns:
            RouteResult with targets and cleaned text.
        """
        mentions = _MENTION_PATTERN.findall(text)

        if not mentions:
            return RouteResult(
                targets=[fallback] if fallback else [],
                text=text.strip(),
            )

        # Check for @all broadcast
        if "all" in [m.lower() for m in mentions]:
            cleaned = _MENTION_PATTERN.sub("", text).strip()
            return RouteResult(
                targets=list(self._instances),
                text=cleaned,
                is_broadcast=True,
            )

        # Resolve each mention
        targets: list[str] = []
        for mention in mentions:
            resolved = self._resolve(mention)
            if resolved and resolved not in targets:
                targets.append(resolved)

        cleaned = _MENTION_PATTERN.sub("", text).strip()

        # If no valid targets resolved, use fallback
        if not targets and fallback:
            return RouteResult(targets=[fallback], text=text.strip())

        return RouteResult(targets=targets, text=cleaned)

    def _resolve(self, mention: str) -> str | None:
        """Resolve a single mention to an instance name."""
        key = mention.lower()

        # Exact match in lookup
        if key in self._lookup:
            return self._lookup[key]

        # Direct instance name match (e.g. @gamedev-agent)
        if key in self._instances or f"{key}-agent" in self._instances:
            return key if key in self._instances else f"{key}-agent"

        # Prefix match (fuzzy): @鳴 → 鳴人 → gamedev-agent
        candidates = []
        for codename, instance in self._lookup.items():
            if codename.startswith(key):
                candidates.append(instance)

        if len(candidates) == 1:
            return candidates[0]

        # No match
        if candidates:
            log.debug("Ambiguous @%s: %s", mention, candidates)
        else:
            log.debug("Unknown @%s", mention)
        return None

    def suggest(self, mention: str) -> list[str]:
        """Get suggestions for an unresolved mention."""
        key = mention.lower()
        suggestions = []
        for codename, instance in self._lookup.items():
            if key in codename or codename.startswith(key):
                suggestions.append(f"@{codename} → {instance}")
        return suggestions[:5]

    def route_by_keyword(
        self,
        text: str,
        fallback: str | None = None,
        keyword_routes: dict[str, list[str]] | None = None,
    ) -> str | None:
        """Route a message by keyword matching.

        Args:
            text: message text
            fallback: default target when no keyword matches. 由**呼叫端**決定 ——
                     套件不預設任何 instance 名。
            keyword_routes: {instance_name: [keyword, ...]} from team.yaml config.
                           e.g. {"<tech-agent>": ["技術", "bug"], "<pm-agent>": ["需求", "進度"]}
                           If None or empty, returns fallback immediately.

        Returns:
            target instance name，或 `None`（無命中且呼叫端未給 fallback）

        [1.2.23] 原本預設值寫死 `fallback="ark-agent"` —— 那是 nana 的 instance 名，
        對其他部署毫無意義。它一直沒出事是因為唯一呼叫端明確傳了 `bound_instance`，
        所以那行是**死代碼**；留著只會讓人以為套件有「預設路由目標」這回事。
        改回 `None`：沒有目標就明說沒有，由呼叫端處理，不要靜默指向某個特定 agent。
        """
        if not keyword_routes:
            return fallback

        for instance, keywords in keyword_routes.items():
            # Only route to instances that actually exist
            if instance not in self._instances:
                continue
            if any(kw in text for kw in keywords):
                return instance

        return fallback
