"""Conversation planner — intent routing, clarification, reset."""
from __future__ import annotations

import re
from dataclasses import dataclass, field


@dataclass
class Action:
    type: str                          # clarify | execute | answer | reset
    message: str | None = None         # 回覆文字
    instance: str | None = None        # 目標 instance
    keyboard: list[list[dict]] | None = None  # Inline Keyboard rows


# --- Patterns ---

_RESET = re.compile(r"^(取消|重來|重新開始|/reset)$", re.I)
_GREETING = re.compile(r"^(嗨|hi|hello|你好|哈囉|hey)\s*[!！]?$", re.I)
_STATUS = re.compile(r"^(/status|狀態|status)$", re.I)


def _build_route_hints(instances: dict) -> list[tuple[re.Pattern, str]]:
    """Build routing hints dynamically from instance descriptions.

    Parses keywords from description (after — separator) and creates
    regex patterns for routing. Falls back to role-based defaults.
    """
    hints: list[tuple[re.Pattern, str]] = []
    for name, ic in instances.items():
        desc = getattr(ic, "description", "") or ""
        if "—" not in desc:
            continue
        # Extract keywords after —
        _, keywords_part = desc.split("—", 1)
        # Split by 、and 、 to get individual keywords, strip and filter
        keywords = [k.strip() for k in re.split(r"[、,/]", keywords_part) if k.strip()]
        if keywords:
            pattern_str = "|".join(re.escape(k) for k in keywords)
            hints.append((re.compile(pattern_str, re.I), name))
    return hints


class ConversationPlanner:
    """Analyse message + session context, decide next action."""

    def __init__(self, topic_map: dict[int, str], instances: dict, daemon=None) -> None:
        self._topic_map = topic_map      # topic_id → instance name
        self._instances = instances       # daemon.instances
        self._daemon = daemon             # optional — for cost_guard access
        # Build route hints dynamically from config
        config_instances = daemon.config.instances if daemon and hasattr(daemon, "config") else {}
        self._route_hints = _build_route_hints(config_instances)

    def plan(self, session, message: str, memory_ctx: str = "") -> Action:
        # 1. Reset
        if _RESET.match(message.strip()):
            return Action("reset", "好的，重新開始。有什麼可以幫你的嗎？")

        # 2. Status
        if _STATUS.match(message.strip()):
            return Action("answer", self._build_status())

        # 3. Greeting
        if _GREETING.match(message.strip()):
            return Action("answer", "嗨！直接告訴我你想做什麼 🚀")

        # 4. Topic already bound → direct execute
        if session.instance:
            return Action("execute", instance=session.instance)

        # 5. Try route by content
        instance = self._route_by_content(message)
        if instance:
            session.instance = instance
            return Action("execute", instance=instance)

        # 6. Try route by memory preference
        if memory_ctx:
            from . import memory as mem
            pref = mem.get_preference(session.user_id, "常用 instance")
            if pref and pref in self._instances:
                session.instance = pref
                return Action("execute", instance=pref)

        # 7. Can't determine → clarify
        return self._build_clarify()

    def _route_by_content(self, message: str) -> str | None:
        for pattern, instance in self._route_hints:
            if pattern.search(message):
                if instance in self._instances:
                    return instance
        return None

    def _build_clarify(self) -> Action:
        buttons = []
        for name, state in self._instances.items():
            desc = state.config.description or name
            buttons.append([{"text": f"{'🏗️' if 'backend' in name else '🎨'} {desc}", "callback_data": f"route:{name}"}])
        return Action(
            "clarify",
            "想交給哪個 Agent？",
            keyboard=buttons,
        )

    def _build_status(self) -> str:
        import time

        icons = {"running": "🟢", "stopped": "⚪", "crashed": "🔴",
                 "starting": "🟡", "paused": "⏸️"}
        cg = getattr(self._daemon, "cost_guard", None) if self._daemon else None

        lines = []
        running_count = 0
        total = len(self._instances)
        now = time.time()

        for name, state in self._instances.items():
            status = state.status.value
            icon = icons.get(status, "❓")
            if status == "running":
                running_count += 1

            parts = [status]

            # Crash count
            crashes = getattr(state, "crash_count", 0)
            if crashes > 0:
                parts.append(f"{crashes} crash{'es' if crashes > 1 else ''}")

            # Idle time (only for running instances with activity)
            last_active = getattr(state, "last_activity", 0)
            if status == "running" and last_active:
                idle_sec = now - last_active
                if idle_sec < 60:
                    parts.append(f"活躍 {int(idle_sec)}s ago")
                elif idle_sec < 3600:
                    parts.append(f"活躍 {int(idle_sec/60)}m ago")
                else:
                    parts.append(f"活躍 {int(idle_sec/3600)}h ago")

            # Cost (if tracked)
            if cg:
                spent = cg.get_today_spend(name)
                if spent > 0:
                    parts.append(f"${spent:.2f}")

            lines.append(f"{icon} {name} — {', '.join(parts)}")

        if not lines:
            return "沒有運行中的 instance"

        # Team summary footer
        lines.append("")
        footer = f"團隊: {running_count}/{total} 運行中"
        if cg:
            total_spent = sum(cg.get_today_all().values())
            footer += f", 總成本 ${total_spent:.2f} / ${cg.daily_limit_usd:.2f}"
        lines.append(footer)

        return "\n".join(lines)
