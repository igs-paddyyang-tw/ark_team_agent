"""Extract API endpoints from Python source files (FastAPI/Flask patterns)."""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class APIEndpoint:
    """A single extracted API endpoint."""
    method: str          # GET, POST, PUT, DELETE, WEBSOCKET
    path: str            # /api/status
    function_name: str   # get_status
    file: str            # relative path
    line: int            # line number
    description: str = ""  # from docstring or comment


@dataclass
class ExtractionResult:
    """Result of scanning a codebase for API endpoints."""
    endpoints: list[APIEndpoint] = field(default_factory=list)
    files_scanned: int = 0
    errors: list[str] = field(default_factory=list)


# Patterns for FastAPI route decorators
_FASTAPI_ROUTE = re.compile(
    r'@\w+\.(get|post|put|delete|patch|websocket)\(\s*["\']([^"\']+)["\']',
    re.IGNORECASE,
)

# Also match: @app.get("/path") style without @ (inline in method body)
_INLINE_ROUTE = re.compile(
    r'\w+\.(get|post|put|delete|patch|websocket)\(\s*["\']([^"\']+)["\']',
    re.IGNORECASE,
)

# [1.2.8] APIRouter(prefix="/api/xxx") — 掛載前綴須併入路徑，否則同一批端點會被
# 同時算成「spec 有但 code 沒實作」與「code 多出」（重複計，v1.2.7 前 22/54 drift 皆源於此）
_ROUTER_PREFIX = re.compile(r'APIRouter\([^)]*prefix\s*=\s*["\']([^"\']+)["\']')

# Pattern for function definition following a decorator
_FUNC_DEF = re.compile(r'^\s*(?:async\s+)?def\s+(\w+)')

# Pattern for docstring (first line)
_DOCSTRING = re.compile(r'^\s*"""(.+?)"""', re.DOTALL)
_DOCSTRING_START = re.compile(r'^\s*"""(.+)')


def extract_from_file(filepath: Path, base_dir: Path | None = None) -> list[APIEndpoint]:
    """Extract API endpoints from a single Python file."""
    try:
        content = filepath.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return []

    lines = content.splitlines()
    endpoints: list[APIEndpoint] = []
    rel_path = str(filepath.relative_to(base_dir)) if base_dir else str(filepath)

    # [1.2.8] 取本檔的 APIRouter 掛載前綴（如 dashboard_api.py 的 "/api/dashboard"）。
    # 只看非註解行 —— 否則說明用的註解範例會被當成真前綴／真路由（本檔自身就踩過）。
    _code_only = "\n".join(
        ln for ln in lines if not ln.strip().startswith("#")
    )
    _pm = _ROUTER_PREFIX.search(_code_only)
    router_prefix = _pm.group(1).rstrip("/") if _pm else ""

    i = 0
    while i < len(lines):
        if lines[i].strip().startswith("#"):   # [1.2.8] 註解不算路由
            i += 1
            continue
        # Try decorator pattern first: @app.get("/path")
        match = _FASTAPI_ROUTE.search(lines[i])
        # Also try inline pattern: app.get("/path") (inside class methods)
        if not match:
            match = _INLINE_ROUTE.search(lines[i])
        if match:
            method = match.group(1).upper()
            path = match.group(2)
            # [1.2.8] 併入 router 前綴（避免與 spec 的完整路徑對不上）
            if router_prefix and path.startswith("/") and not path.startswith(router_prefix):
                path = router_prefix + path

            # Only count HTTP route paths (skip non-route .get() calls)
            if not path.startswith("/"):
                i += 1
                continue
            # [1.2.8] 移除原本此處對 method/path 的重複賦值 —— 它會把上方併入的
            # router_prefix 抹掉（既有冗餘 bug，加 prefix 後才顯現）
            line_num = i + 1

            # Look for function def on next lines
            func_name = ""
            description = ""
            for j in range(i + 1, min(i + 5, len(lines))):
                func_match = _FUNC_DEF.match(lines[j])
                if func_match:
                    func_name = func_match.group(1)
                    # Look for docstring
                    if j + 1 < len(lines):
                        doc_match = _DOCSTRING.match(lines[j + 1])
                        if doc_match:
                            description = doc_match.group(1).strip()
                        else:
                            doc_start = _DOCSTRING_START.match(lines[j + 1])
                            if doc_start:
                                description = doc_start.group(1).strip()
                    break

            endpoints.append(APIEndpoint(
                method=method,
                path=path,
                function_name=func_name,
                file=rel_path,
                line=line_num,
                description=description,
            ))
        i += 1

    return endpoints


def extract_from_directory(directory: Path, patterns: list[str] | None = None) -> ExtractionResult:
    """Scan a directory for Python files and extract all API endpoints.

    Args:
        directory: Root directory to scan.
        patterns: Glob patterns for files to include (default: **/*.py).
    """
    result = ExtractionResult()

    for filepath in directory.rglob("*.py"):
        # [1.2.8] 跳過 templates/（範本資產，非套件對外 API）
        if "/templates/" in filepath.as_posix():
            continue
        if filepath.is_file():
            try:
                endpoints = extract_from_file(filepath, base_dir=directory)
                result.endpoints.extend(endpoints)
                result.files_scanned += 1
            except Exception as e:
                result.errors.append(f"{filepath}: {e}")

    return result
