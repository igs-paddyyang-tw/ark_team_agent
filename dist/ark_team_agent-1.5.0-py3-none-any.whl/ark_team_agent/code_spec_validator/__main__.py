"""CLI entry point: python -m ark_team_agent.skills.code_spec_validator [--full] [project_root]"""
from __future__ import annotations

import sys
import logging
from pathlib import Path


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(message)s")

    full_mode = "--full" in sys.argv
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    project_root = Path(args[0]) if args else Path.cwd()

    if full_mode:
        from .validator import validate_full
        result = validate_full(project_root)
        print()
        print(result)
    else:
        from .validator import validate_project
        output = project_root / "knowledge" / "team-agent" / "wiki" / "operations" / "drift-report.md"
        report = validate_project(project_root, output_path=output)
        print()
        print(report.summary)
        print(f"Report: {output}")
        sys.exit(0 if report.is_clean else 1)


if __name__ == "__main__":
    main()
