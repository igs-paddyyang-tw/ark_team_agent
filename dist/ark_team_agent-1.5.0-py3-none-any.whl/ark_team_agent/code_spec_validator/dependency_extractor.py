"""Extract Python import dependency graph from source code."""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class ImportEdge:
    """A single import relationship."""
    source_module: str   # ark_team_agent.telegram
    target_module: str   # ark_team_agent.cost_guard
    import_type: str     # "from" | "import"
    file: str = ""
    line: int = 0


@dataclass
class DependencyGraph:
    """Module dependency graph."""
    edges: list[ImportEdge] = field(default_factory=list)
    modules: set[str] = field(default_factory=set)
    files_scanned: int = 0

    def get_imports_for(self, module: str) -> list[str]:
        """Get all modules that a given module imports."""
        return [e.target_module for e in self.edges if e.source_module == module]

    def get_importers_of(self, module: str) -> list[str]:
        """Get all modules that import a given module."""
        return [e.source_module for e in self.edges if e.target_module == module]

    def check_violation(self, source: str, forbidden_target: str) -> list[ImportEdge]:
        """Check if source imports forbidden_target (directly or via submodule)."""
        return [e for e in self.edges
                if source in e.source_module and forbidden_target in e.target_module]


@dataclass
class DesignDependencyRule:
    """A dependency rule extracted from design documents."""
    source: str          # module that should NOT import target
    forbidden_target: str
    reason: str = ""
    source_file: str = ""
    line: int = 0


# Import patterns
_FROM_IMPORT = re.compile(r'^from\s+([\w.]+)\s+import')
_IMPORT = re.compile(r'^import\s+([\w.]+)')

# Design doc dependency rules: "X should not import Y" or "X 不應 import Y"
_DEPENDENCY_RULE = re.compile(
    r'(\w[\w.]*)\s+(?:should not|must not|不應|禁止)\s+(?:import|依賴|呼叫)\s+(\w[\w.]*)',
    re.IGNORECASE,
)


def extract_from_directory(directory: Path, package_prefix: str = "") -> DependencyGraph:
    """Build dependency graph from Python source files.

    Args:
        directory: Source directory to scan.
        package_prefix: Only include imports matching this prefix (e.g. "ark_team_agent").
    """
    graph = DependencyGraph()

    for filepath in directory.rglob("*.py"):
        if not filepath.is_file():
            continue
        try:
            content = filepath.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue

        # Derive module name from file path
        rel = filepath.relative_to(directory)
        parts = list(rel.parts)
        if parts[-1] == "__init__.py":
            parts = parts[:-1]
        else:
            parts[-1] = parts[-1].replace(".py", "")
        source_module = ".".join(parts)
        graph.modules.add(source_module)
        graph.files_scanned += 1

        rel_path = str(filepath.relative_to(directory))

        for i, line in enumerate(content.splitlines()):
            line = line.strip()

            m = _FROM_IMPORT.match(line)
            if m:
                target = m.group(1)
                if target.startswith("."):
                    # Relative import — resolve
                    target = _resolve_relative(source_module, target)
                if not package_prefix or target.startswith(package_prefix):
                    graph.edges.append(ImportEdge(
                        source_module=source_module,
                        target_module=target,
                        import_type="from",
                        file=rel_path,
                        line=i + 1,
                    ))
                continue

            m = _IMPORT.match(line)
            if m:
                target = m.group(1)
                if not package_prefix or target.startswith(package_prefix):
                    graph.edges.append(ImportEdge(
                        source_module=source_module,
                        target_module=target,
                        import_type="import",
                        file=rel_path,
                        line=i + 1,
                    ))

    return graph


def _resolve_relative(source_module: str, relative_import: str) -> str:
    """Resolve a relative import (e.g. '.config') to absolute module path."""
    dots = len(relative_import) - len(relative_import.lstrip("."))
    remainder = relative_import.lstrip(".")
    parts = source_module.split(".")
    if dots <= len(parts):
        base = ".".join(parts[:-dots]) if dots > 0 else source_module
    else:
        base = ""
    if remainder:
        return f"{base}.{remainder}" if base else remainder
    return base


def extract_design_rules(docs_dir: Path) -> list[DesignDependencyRule]:
    """Extract dependency rules from design documents."""
    rules: list[DesignDependencyRule] = []

    for filepath in docs_dir.rglob("*.md"):
        if not filepath.is_file():
            continue
        try:
            content = filepath.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue

        rel_path = str(filepath.relative_to(docs_dir))
        for i, line in enumerate(content.splitlines()):
            m = _DEPENDENCY_RULE.search(line)
            if m:
                rules.append(DesignDependencyRule(
                    source=m.group(1),
                    forbidden_target=m.group(2),
                    reason=line.strip(),
                    source_file=rel_path,
                    line=i + 1,
                ))

    return rules
