"""Main validator — orchestrates extract → parse → diff → report."""
from __future__ import annotations

import logging
from pathlib import Path

from .api_extractor import extract_from_directory, ExtractionResult
from .spec_parser import parse_directory, SpecParseResult
from .diff_engine import compare, DriftReport

log = logging.getLogger(__name__)


def validate(
    code_dir: Path,
    docs_dir: Path,
    ignore_paths: list[str] | None = None,
    output_path: Path | None = None,
    ignore_spec_prefixes: list[str] | None = None,
) -> DriftReport:
    """Run full validation: extract code APIs → parse specs → diff → report.

    Args:
        code_dir: Root directory of source code to scan.
        docs_dir: Root directory of documentation (specs/designs).
        ignore_paths: API paths to exclude from comparison.
        output_path: If provided, write markdown report to this file.
        ignore_spec_prefixes: Prefixes to exclude from spec parsing (e.g. third-party APIs).

    Returns:
        DriftReport with all findings.
    """
    # Phase 1: Extract from code
    log.info("Extracting APIs from %s", code_dir)
    code_result = extract_from_directory(code_dir)
    log.info("Found %d endpoints in %d files", len(code_result.endpoints), code_result.files_scanned)

    # Phase 2: Parse from specs
    log.info("Parsing specs from %s", docs_dir)
    spec_result = parse_directory(docs_dir)
    log.info("Found %d expected endpoints in %d files", len(spec_result.endpoints), spec_result.files_parsed)

    # Filter out spec endpoints with ignored prefixes
    if ignore_spec_prefixes:
        spec_result.endpoints = [
            ep for ep in spec_result.endpoints
            if not any(ep.path.startswith(p) for p in ignore_spec_prefixes)
        ]

    # Phase 3: Diff
    report = compare(code_result, spec_result, ignore_paths=ignore_paths)
    log.info("Validation result: %s", report.summary)

    # Write report if output path specified
    if output_path:
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(report.to_markdown(), encoding="utf-8")
        log.info("Report written to %s", output_path)

    return report


def validate_full(project_root: Path, output_path: Path | None = None) -> str:
    """Run all 4 validation dimensions and produce unified report.

    Dimensions:
    1. API endpoint drift (code vs spec)
    2. Schema drift (Pydantic models vs spec definitions)
    3. Dependency violations (import graph vs design rules)
    4. Test coverage (acceptance criteria vs test functions)
    """
    from datetime import date
    from .schema_extractor import extract_from_directory as extract_schemas
    from .dependency_extractor import extract_from_directory as extract_deps, extract_design_rules
    from .test_extractor import extract_tests, extract_acceptance_criteria, check_test_coverage

    code_dir = project_root / "src"
    docs_dir = project_root / "docs"
    tests_dir = project_root / "tests"

    if not code_dir.exists():
        code_dir = project_root

    sections: list[str] = []
    scores: dict[str, int] = {}

    # ━━ Dimension 1: API Endpoints ━━
    log.info("Dimension 1: API endpoint validation")
    api_report = validate(
        code_dir=code_dir, docs_dir=docs_dir,
        ignore_paths=["/healthz", "/docs", "/openapi.json", "/redoc"],
    )
    if api_report.is_clean:
        scores["API 端點"] = 100
    else:
        # Score: 100 - (drifts * 5), min 0
        scores["API 端點"] = max(0, 100 - len(api_report.drifts) * 5)
    sections.append(api_report.to_markdown())

    # ━━ Dimension 2: Schema ━━
    log.info("Dimension 2: Schema validation")
    schema_result = extract_schemas(code_dir)
    schema_count = len(schema_result.models)
    scores["Schema"] = 100  # Placeholder — full validation needs spec schema definitions
    sections.append(f"## Schema 驗證\n\n找到 {schema_count} 個 model（{schema_result.files_scanned} 個檔案）\n")

    # ━━ Dimension 3: Dependencies ━━
    log.info("Dimension 3: Dependency validation")
    dep_graph = extract_deps(code_dir, package_prefix="ark_team_agent")
    design_rules = extract_design_rules(docs_dir)
    violations = []
    for rule in design_rules:
        found = dep_graph.check_violation(rule.source, rule.forbidden_target)
        if found:
            violations.extend(found)
    if violations:
        scores["依賴"] = max(0, 100 - len(violations) * 20)
        dep_lines = [f"## 依賴違規（{len(violations)} 項）\n"]
        for v in violations:
            dep_lines.append(f"- `{v.source_module}` → `{v.target_module}`（{v.file}:{v.line}）")
        sections.append("\n".join(dep_lines))
    else:
        scores["依賴"] = 100
        sections.append(f"## 依賴驗證\n\n無違規（{len(dep_graph.edges)} 條 import，{len(design_rules)} 條規則）\n")

    # ━━ Dimension 4: Test Coverage ━━
    log.info("Dimension 4: Test coverage validation")
    if tests_dir.exists():
        test_result = extract_tests(tests_dir)
        criteria = extract_acceptance_criteria(docs_dir)
        if criteria:
            check_test_coverage(test_result, criteria)
            covered = sum(1 for c in criteria if c.covered)
            total = len(criteria)
            scores["測試覆蓋"] = int(covered / total * 100) if total > 0 else 100
            test_lines = [f"## 測試覆蓋（{covered}/{total} 驗收條件）\n"]
            uncovered = [c for c in criteria if not c.covered]
            if uncovered:
                test_lines.append("### 未覆蓋驗收條件\n")
                for c in uncovered[:10]:  # Limit to 10
                    test_lines.append(f"- {c.text}（{c.source_file}:{c.line}）")
            sections.append("\n".join(test_lines))
        else:
            scores["測試覆蓋"] = 100
            sections.append(f"## 測試覆蓋\n\n{len(test_result.tests)} 個測試（無驗收條件可比對）\n")
    else:
        scores["測試覆蓋"] = 50
        sections.append("## 測試覆蓋\n\n未找到 tests/ 目錄\n")

    # ━━ Unified Report ━━
    total_score = sum(scores.values()) // len(scores) if scores else 0
    emoji = "\u2705" if total_score >= 90 else "\u26a0\ufe0f" if total_score >= 70 else "\u274c"

    header = [
        f"# {emoji} Spec Drift Report（Score: {total_score}/100）",
        "",
        f"> Generated: {date.today()}",
        "",
        "## Summary",
        "",
        "| 維度 | 分數 |",
        "|------|------|",
    ]
    for dim, score in scores.items():
        dim_emoji = "\u2705" if score >= 90 else "\u26a0\ufe0f" if score >= 70 else "\u274c"
        header.append(f"| {dim_emoji} {dim} | {score}/100 |")
    header.append("")

    full_report = "\n".join(header) + "\n---\n\n" + "\n\n---\n\n".join(sections)

    # Write
    if output_path is None:
        output_path = project_root / "knowledge" / "team-agent" / "wiki" / "operations" / "drift-report.md"
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(full_report, encoding="utf-8")
    log.info("Unified report written to %s (score=%d/100)", output_path, total_score)

    return f"{emoji} Score: {total_score}/100 — " + ", ".join(f"{k}={v}" for k, v in scores.items())


def validate_project(project_root: Path, output_path: Path | None = None) -> DriftReport:
    """Convenience: validate a standard project layout (v1 API-only for backward compat).

    For full multi-dimension validation, use validate_full().
    """
    code_dir = project_root / "src"
    docs_dir = project_root / "docs"

    if not code_dir.exists():
        code_dir = project_root

    default_ignore = [
        "/healthz",
        "/docs",
        "/openapi.json",
        "/redoc",
        "/path",
    ]

    if output_path is None:
        output_path = project_root / "knowledge" / "team-agent" / "wiki" / "operations" / "drift-report.md"

    return validate(
        code_dir=code_dir,
        docs_dir=docs_dir,
        ignore_paths=default_ignore,
        output_path=output_path,
        ignore_spec_prefixes=[
            "/workspaces",
            "/api/auth/telegram",
            "/api/games",
            "/api/user/",
            "/api/v1/game/",
            "/ws/game/",
            "/health",
        ],
    )
