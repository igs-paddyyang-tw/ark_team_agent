"""Parse spec/design documents to extract expected API definitions."""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class ExpectedEndpoint:
    """An API endpoint defined in a spec or design document."""
    method: str          # GET, POST, PUT, DELETE, WS
    path: str            # /api/status
    description: str = ""
    source_file: str = ""
    line: int = 0


@dataclass
class SpecParseResult:
    """Result of parsing spec/design documents."""
    endpoints: list[ExpectedEndpoint] = field(default_factory=list)
    files_parsed: int = 0
    errors: list[str] = field(default_factory=list)


# Patterns for API endpoint definitions in markdown
# Matches: | `/api/status` | GET | description |
# Or: | GET | /api/status | description |
# Or: | /api/status | GET/POST | description |
_TABLE_ENDPOINT = re.compile(
    r'\|\s*`?(/[^\s`|]*)`?\s*\|\s*(GET|POST|PUT|DELETE|WS|PATCH|WEBSOCKET)\s*\|',
    re.IGNORECASE,
)
_TABLE_ENDPOINT_ALT = re.compile(
    r'\|\s*(GET|POST|PUT|DELETE|WS|PATCH|WEBSOCKET)\s*\|\s*`?(/[^\s`|]*)`?\s*\|',
    re.IGNORECASE,
)

# Matches: GET /api/status — description
_INLINE_ENDPOINT = re.compile(
    r'^\s*(GET|POST|PUT|DELETE|WS|PATCH|WEBSOCKET)\s+(/[^\s`|]+)',
    re.IGNORECASE | re.MULTILINE,
)

# Matches: | `/api/status` | GET | description | (with method after path)
_TABLE_PATH_METHOD = re.compile(
    r'\|\s*`?(/api[^\s`|]+)`?\s*\|\s*(GET|POST|PUT|DELETE|WS|PATCH|WEBSOCKET)\s*\|\s*([^|]*)\|',
    re.IGNORECASE,
)


def parse_file(filepath: Path, base_dir: Path | None = None) -> list[ExpectedEndpoint]:
    """Parse a single markdown file for API endpoint definitions."""
    try:
        content = filepath.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return []

    rel_path = str(filepath.relative_to(base_dir)) if base_dir else str(filepath)
    endpoints: list[ExpectedEndpoint] = []
    seen: set[tuple[str, str]] = set()

    lines = content.splitlines()
    for i, line in enumerate(lines):
        # Skip [Planned] endpoints
        if "[Planned]" in line or "[planned]" in line:
            continue

        # Try table format: | path | METHOD | desc |
        m = _TABLE_PATH_METHOD.search(line)
        if m:
            path, method, desc = m.group(1), m.group(2).upper(), m.group(3).strip()
            key = (method, path)
            if key not in seen:
                seen.add(key)
                endpoints.append(ExpectedEndpoint(
                    method=method, path=path, description=desc,
                    source_file=rel_path, line=i + 1,
                ))
            continue

        # Try: | /path | METHOD |
        m = _TABLE_ENDPOINT.search(line)
        if m:
            path, method = m.group(1), m.group(2).upper()
            key = (method, path)
            if key not in seen:
                seen.add(key)
                endpoints.append(ExpectedEndpoint(
                    method=method, path=path,
                    source_file=rel_path, line=i + 1,
                ))
            continue

        # Try: | METHOD | /path |
        m = _TABLE_ENDPOINT_ALT.search(line)
        if m:
            method, path = m.group(1).upper(), m.group(2)
            key = (method, path)
            if key not in seen:
                seen.add(key)
                endpoints.append(ExpectedEndpoint(
                    method=method, path=path,
                    source_file=rel_path, line=i + 1,
                ))
            continue

        # Try inline: GET /api/path
        m = _INLINE_ENDPOINT.match(line)
        if m:
            method, path = m.group(1).upper(), m.group(2)
            key = (method, path)
            if key not in seen:
                seen.add(key)
                endpoints.append(ExpectedEndpoint(
                    method=method, path=path,
                    source_file=rel_path, line=i + 1,
                ))

    return endpoints


def parse_directory(directory: Path, patterns: list[str] | None = None) -> SpecParseResult:
    """Scan docs directory for spec/design files and extract expected endpoints.

    Args:
        directory: Root docs directory to scan.
        patterns: Glob patterns (default: **/*.md).
    """
    if patterns is None:
        patterns = ["**/*.md"]

    result = SpecParseResult()

    for pattern in patterns:
        for filepath in directory.rglob("*.md"):
            # [1.2.8] 跳過 archive/：已歸檔的歷史設計（如已停用專案）不計入現行 spec
            if "/archive/" in filepath.as_posix():
                continue
            if filepath.is_file():
                try:
                    endpoints = parse_file(filepath, base_dir=directory)
                    result.endpoints.extend(endpoints)
                    result.files_parsed += 1
                except Exception as e:
                    result.errors.append(f"{filepath}: {e}")

    return result
