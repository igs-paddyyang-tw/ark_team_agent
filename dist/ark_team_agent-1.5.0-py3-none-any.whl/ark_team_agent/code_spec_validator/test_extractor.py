"""Extract test functions and their coverage intent from test files."""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class ExtractedTest:
    """An extracted test case."""
    name: str            # test_load_team_config
    file: str            # tests/test_all.py
    line: int
    description: str = ""  # from docstring
    tags: list[str] = field(default_factory=list)  # inferred topics


@dataclass
class TestExtractionResult:
    tests: list[ExtractedTest] = field(default_factory=list)
    files_scanned: int = 0


@dataclass
class SpecAcceptanceCriteria:
    """An acceptance criterion extracted from a spec document."""
    text: str
    source_file: str
    line: int
    covered: bool = False
    matching_tests: list[str] = field(default_factory=list)


_TEST_FUNC = re.compile(r'^(?:async\s+)?def\s+(test_\w+)')
_DOCSTRING_INLINE = re.compile(r'^\s+"""(.+?)"""')
_DOCSTRING_START = re.compile(r'^\s+"""(.+)')

# Spec acceptance criteria patterns
# [1.2.8] 只取**未勾選**的 checkbox：`- [x]` 代表已驗證完成，計入「未覆蓋」是假訊號
_CHECKBOX = re.compile(r'^\s*-\s*\[ \]\s*(.+)')
_CHECKBOX_DONE = re.compile(r'^\s*-\s*\[x\]\s*(.+)', re.IGNORECASE)
_ACCEPTANCE_HEADER = re.compile(r'^#+\s*(?:驗收|acceptance|驗證|verification|DoD)', re.IGNORECASE)


def extract_tests(directory: Path) -> TestExtractionResult:
    """Extract all test functions from a test directory."""
    result = TestExtractionResult()

    for filepath in directory.rglob("test_*.py"):
        if not filepath.is_file():
            continue
        try:
            content = filepath.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue

        lines = content.splitlines()
        rel_path = str(filepath.relative_to(directory.parent)) if directory.parent else str(filepath)
        result.files_scanned += 1

        for i, line in enumerate(lines):
            m = _TEST_FUNC.match(line)
            if m:
                name = m.group(1)
                description = ""
                # Look for docstring on next line
                if i + 1 < len(lines):
                    dm = _DOCSTRING_INLINE.match(lines[i + 1])
                    if dm:
                        description = dm.group(1).strip()
                    else:
                        ds = _DOCSTRING_START.match(lines[i + 1])
                        if ds:
                            description = ds.group(1).strip()

                # Infer tags from test name
                tags = _infer_tags(name)

                result.tests.append(ExtractedTest(
                    name=name, file=rel_path, line=i + 1,
                    description=description, tags=tags,
                ))

    return result


def _infer_tags(test_name: str) -> list[str]:
    """Infer topic tags from test function name."""
    tags = []
    parts = test_name.replace("test_", "").split("_")
    # Common module names
    modules = {"api", "config", "telegram", "session", "planner", "memory",
               "progress", "mcp", "cost", "hang", "reload", "event", "webbot",
               "wiki", "kiro", "scheduler", "daily"}
    for part in parts:
        if part in modules:
            tags.append(part)
    return tags


def extract_acceptance_criteria(docs_dir: Path) -> list[SpecAcceptanceCriteria]:
    """Extract acceptance criteria (checkboxes) from spec documents."""
    criteria: list[SpecAcceptanceCriteria] = []

    for filepath in docs_dir.rglob("*.md"):
        if not filepath.is_file():
            continue
        # [1.2.8] 跳過 reports/：那是「已驗證的記錄」（產出），本維度比對的是 spec（輸入）
        if "/reports/" in filepath.as_posix():
            continue
        try:
            content = filepath.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue

        lines = content.splitlines()
        rel_path = str(filepath.relative_to(docs_dir)) if docs_dir else str(filepath)
        in_acceptance_section = False

        for i, line in enumerate(lines):
            # Detect acceptance/verification section
            if _ACCEPTANCE_HEADER.match(line):
                in_acceptance_section = True
                continue
            if line.startswith("#") and in_acceptance_section:
                in_acceptance_section = False
                continue

            if in_acceptance_section:
                m = _CHECKBOX.match(line)
                if m:
                    criteria.append(SpecAcceptanceCriteria(
                        text=m.group(1).strip(),
                        source_file=rel_path,
                        line=i + 1,
                    ))

    return criteria


def check_test_coverage(
    tests: TestExtractionResult,
    criteria: list[SpecAcceptanceCriteria],
) -> list[SpecAcceptanceCriteria]:
    """Check which acceptance criteria have matching tests.

    Uses keyword matching: if criterion keywords appear in test names/descriptions.
    """
    for criterion in criteria:
        # Extract keywords from criterion text
        keywords = _extract_keywords(criterion.text)
        if not keywords:
            continue

        for test in tests.tests:
            test_text = f"{test.name} {test.description}".lower()
            # If at least 2 keywords match, consider it covered
            matches = sum(1 for kw in keywords if kw in test_text)
            if matches >= min(2, len(keywords)):
                criterion.covered = True
                criterion.matching_tests.append(test.name)

    return criteria


def _extract_keywords(text: str) -> list[str]:
    """Extract meaningful keywords from acceptance criterion text."""
    # Remove common filler words
    stop_words = {"的", "是", "在", "有", "可以", "能", "會", "已", "被", "與",
                  "the", "is", "are", "can", "should", "must", "will", "be",
                  "a", "an", "to", "for", "of", "in", "on", "at", "by"}
    low = text.lower()
    words = [w for w in re.findall(r'[a-z_]+', low) if w not in stop_words and len(w) > 2]
    # [1.2.8] CJK：以標點/空白切段，保留 >=3 字的片段（原本整句視為單一 token，
    # 與英文 test 函式名永無交集 → 系統性假「未覆蓋」）
    for seg in re.split(r'[\s、，,。．\.：:；;（）()「」『』\[\]/|→+*`\-—]+', text):
        seg = seg.strip()
        if len(seg) >= 3 and re.search(r'[\u4e00-\u9fff]', seg):
            words.append(seg.lower())
    return words
