"""Extract Pydantic/dataclass schema definitions from Python source."""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class SchemaField:
    """A single field in a schema."""
    name: str
    type_hint: str
    required: bool = True
    default: str | None = None


@dataclass
class SchemaModel:
    """An extracted schema model (Pydantic BaseModel or dataclass)."""
    name: str
    fields: list[SchemaField] = field(default_factory=list)
    file: str = ""
    line: int = 0
    kind: str = "dataclass"  # "dataclass" | "pydantic"


@dataclass
class SchemaExtractionResult:
    models: list[SchemaModel] = field(default_factory=list)
    files_scanned: int = 0


# Patterns
_CLASS_DEF = re.compile(r'^class\s+(\w+)\s*\(.*(?:BaseModel|BaseSettings)\s*\)', re.MULTILINE)
_DATACLASS_DEC = re.compile(r'^@dataclass')
_DATACLASS_CLASS = re.compile(r'^class\s+(\w+)')
_FIELD_DEF = re.compile(r'^\s+(\w+)\s*:\s*(.+?)(?:\s*=\s*(.+))?$')


def extract_from_file(filepath: Path, base_dir: Path | None = None) -> list[SchemaModel]:
    """Extract schema models from a single Python file."""
    try:
        content = filepath.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return []

    lines = content.splitlines()
    rel_path = str(filepath.relative_to(base_dir)) if base_dir else str(filepath)
    models: list[SchemaModel] = []

    i = 0
    while i < len(lines):
        line = lines[i]

        # Pydantic BaseModel
        m = _CLASS_DEF.match(line)
        if m:
            model = SchemaModel(name=m.group(1), file=rel_path, line=i + 1, kind="pydantic")
            i += 1
            # Collect fields
            while i < len(lines) and (lines[i].startswith("    ") or lines[i].strip() == ""):
                fm = _FIELD_DEF.match(lines[i])
                if fm:
                    fname, ftype, fdefault = fm.group(1), fm.group(2).strip(), fm.group(3)
                    if fname.startswith("_"):
                        i += 1
                        continue
                    required = fdefault is None or fdefault.strip() == "..."
                    model.fields.append(SchemaField(
                        name=fname, type_hint=ftype, required=required,
                        default=fdefault.strip() if fdefault else None,
                    ))
                i += 1
            if model.fields:
                models.append(model)
            continue

        # @dataclass
        if _DATACLASS_DEC.match(line.strip()):
            i += 1
            if i < len(lines):
                cm = _DATACLASS_CLASS.match(lines[i])
                if cm:
                    model = SchemaModel(name=cm.group(1), file=rel_path, line=i + 1, kind="dataclass")
                    i += 1
                    while i < len(lines) and (lines[i].startswith("    ") or lines[i].strip() == ""):
                        fm = _FIELD_DEF.match(lines[i])
                        if fm:
                            fname, ftype, fdefault = fm.group(1), fm.group(2).strip(), fm.group(3)
                            if fname.startswith("_"):
                                i += 1
                                continue
                            required = fdefault is None
                            model.fields.append(SchemaField(
                                name=fname, type_hint=ftype, required=required,
                                default=fdefault.strip() if fdefault else None,
                            ))
                        elif lines[i].strip() and not lines[i].strip().startswith(("#", "\"\"\"", "def ", "@")):
                            pass
                        elif lines[i].strip().startswith("def "):
                            break
                        i += 1
                    if model.fields:
                        models.append(model)
                    continue

        i += 1

    return models


def extract_from_directory(directory: Path) -> SchemaExtractionResult:
    """Scan directory for all schema definitions."""
    result = SchemaExtractionResult()

    for filepath in directory.rglob("*.py"):
        if filepath.is_file():
            models = extract_from_file(filepath, base_dir=directory)
            result.models.extend(models)
            result.files_scanned += 1

    return result
