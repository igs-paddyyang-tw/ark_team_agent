"""Code ↔ Spec validator — detect drift between code and documentation."""
from __future__ import annotations
