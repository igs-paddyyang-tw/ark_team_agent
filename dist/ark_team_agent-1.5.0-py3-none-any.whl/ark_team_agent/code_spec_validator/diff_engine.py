"""Diff engine — compare extracted code APIs with spec-defined APIs."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date

from .api_extractor import APIEndpoint, ExtractionResult
from .spec_parser import ExpectedEndpoint, SpecParseResult


@dataclass
class DriftItem:
    """A single drift between code and spec."""
    category: str        # "missing_in_code" | "extra_in_code" | "method_mismatch"
    method: str
    path: str
    detail: str = ""
    source: str = ""     # which spec/code file


@dataclass
class DriftReport:
    """Full drift report comparing code vs spec."""
    drifts: list[DriftItem] = field(default_factory=list)
    code_endpoints: int = 0
    spec_endpoints: int = 0
    matched: int = 0
    generated_at: str = ""

    @property
    def is_clean(self) -> bool:
        return len(self.drifts) == 0

    @property
    def summary(self) -> str:
        if self.is_clean:
            return f"✅ No drift detected ({self.matched} endpoints matched)"
        missing = sum(1 for d in self.drifts if d.category == "missing_in_code")
        extra = sum(1 for d in self.drifts if d.category == "extra_in_code")
        mismatch = sum(1 for d in self.drifts if d.category == "method_mismatch")
        parts = []
        if missing:
            parts.append(f"{missing} missing in code")
        if extra:
            parts.append(f"{extra} extra in code")
        if mismatch:
            parts.append(f"{mismatch} method mismatch")
        return f"❌ {len(self.drifts)} drifts: {', '.join(parts)}"

    def to_markdown(self) -> str:
        """Generate a markdown drift report."""
        lines = [
            f"# {'✅' if self.is_clean else '❌'} Spec Drift Report",
            f"",
            f"> Generated: {self.generated_at}",
            f"> Code endpoints: {self.code_endpoints} | Spec endpoints: {self.spec_endpoints} | Matched: {self.matched}",
            f"",
        ]

        if self.is_clean:
            lines.append("All endpoints match. No drift detected.")
            return "\n".join(lines)

        # Group by category
        missing = [d for d in self.drifts if d.category == "missing_in_code"]
        extra = [d for d in self.drifts if d.category == "extra_in_code"]
        mismatch = [d for d in self.drifts if d.category == "method_mismatch"]

        if missing:
            lines.append("## ⚠️ Spec 有定義但 Code 沒實作")
            lines.append("")
            for d in missing:
                lines.append(f"- `{d.method} {d.path}` — {d.detail}")
            lines.append("")

        if extra:
            lines.append("## 📝 Code 有實作但 Spec 沒定義")
            lines.append("")
            for d in extra:
                lines.append(f"- `{d.method} {d.path}` — {d.detail}")
            lines.append("")

        if mismatch:
            lines.append("## 🔀 Method 不一致")
            lines.append("")
            for d in mismatch:
                lines.append(f"- `{d.path}` — {d.detail}")
            lines.append("")

        return "\n".join(lines)


def compare(code: ExtractionResult, spec: SpecParseResult,
            ignore_paths: list[str] | None = None) -> DriftReport:
    """Compare code endpoints with spec endpoints and produce a drift report.

    Args:
        code: Extracted endpoints from source code.
        spec: Expected endpoints from spec/design docs.
        ignore_paths: API paths to ignore (e.g. internal health endpoints).
    """
    ignore = set(ignore_paths or [])

    # Normalize method aliases (WS ↔ WEBSOCKET)
    def _norm_method(m: str) -> str:
        return "WS" if m.upper() in ("WS", "WEBSOCKET") else m.upper()

    report = DriftReport(
        code_endpoints=len(code.endpoints),
        spec_endpoints=len(spec.endpoints),
        generated_at=str(date.today()),
    )

    # Build lookup maps
    code_map: dict[str, list[APIEndpoint]] = {}  # path → endpoints
    for ep in code.endpoints:
        if ep.path in ignore:
            continue
        code_map.setdefault(ep.path, []).append(ep)

    spec_map: dict[str, list[ExpectedEndpoint]] = {}  # path → endpoints
    for ep in spec.endpoints:
        if ep.path in ignore:
            continue
        spec_map.setdefault(ep.path, []).append(ep)

    # Find matches and drifts
    all_paths = set(code_map.keys()) | set(spec_map.keys())

    for path in sorted(all_paths):
        code_eps = code_map.get(path, [])
        spec_eps = spec_map.get(path, [])

        code_methods = {_norm_method(ep.method) for ep in code_eps}
        spec_methods = {_norm_method(ep.method) for ep in spec_eps}

        if not code_eps and spec_eps:
            # In spec but not in code
            for ep in spec_eps:
                report.drifts.append(DriftItem(
                    category="missing_in_code",
                    method=ep.method,
                    path=path,
                    detail=f"defined in {ep.source_file}:{ep.line}",
                    source=ep.source_file,
                ))
        elif code_eps and not spec_eps:
            # In code but not in spec
            for ep in code_eps:
                report.drifts.append(DriftItem(
                    category="extra_in_code",
                    method=ep.method,
                    path=path,
                    detail=f"implemented in {ep.file}:{ep.line}",
                    source=ep.file,
                ))
        else:
            # Both exist — check method match
            matched_methods = code_methods & spec_methods
            report.matched += len(matched_methods)

            for method in spec_methods - code_methods:
                report.drifts.append(DriftItem(
                    category="missing_in_code",
                    method=method,
                    path=path,
                    detail=f"spec says {method} but code doesn't have it",
                ))
            for method in code_methods - spec_methods:
                report.drifts.append(DriftItem(
                    category="extra_in_code",
                    method=method,
                    path=path,
                    detail=f"code has {method} but spec doesn't define it",
                ))

    return report
