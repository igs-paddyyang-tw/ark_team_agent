"""A2A FeedbackLoop — fix → retest 自動修復迴圈。"""
from __future__ import annotations

import logging
from typing import Callable, Awaitable

from .a2a_protocol import TaskHandoff

log = logging.getLogger(__name__)


class MaxIterationsExceeded(Exception):
    """超過最大重試次數。"""


class FeedbackLoop:
    """執行 fix → review 迴圈，最多 max_iterations 次。"""

    def __init__(
        self,
        spawn_fn: Callable[[str, str], Awaitable[str | None]],
    ) -> None:
        self.spawn_fn = spawn_fn

    async def run(self, task: TaskHandoff, failure_reason: str) -> str:
        """執行 feedback loop。

        1. 發給 executor 修復
        2. 發給 loop_back（reviewer）驗證
        3. 通過 → 回傳結果；失敗 → 重複

        Raises:
            MaxIterationsExceeded: 超過 max_iterations 仍未通過
        """
        executor = task.to_agent
        reviewer = task.loop_back
        if not reviewer:
            raise ValueError("No loop_back agent specified for feedback loop")

        reason = failure_reason

        for i in range(task.max_iterations):
            log.info(
                "FeedbackLoop %s: iteration %d/%d",
                task.task_id, i + 1, task.max_iterations,
            )

            # Step 1: Fix
            fix_msg = (
                f"修復任務：{task.title}\n\n"
                f"問題（第 {i + 1} 次）：{reason}\n\n"
                f"驗收條件：{task.acceptance_criteria}"
            )
            fix_result = await self.spawn_fn(executor, fix_msg)
            if not fix_result:
                reason = "executor returned empty response"
                continue

            # Step 2: Review
            review_msg = (
                f"驗證修復：{task.title}\n\n"
                f"修復結果：{fix_result[:1000]}\n\n"
                f"驗收條件：{task.acceptance_criteria}\n\n"
                f"請回覆 PASS 或說明失敗原因。"
            )
            review_result = await self.spawn_fn(reviewer, review_msg)

            # Step 3: 判斷通過
            if review_result and _is_pass(review_result):
                log.info(
                    "FeedbackLoop %s: PASSED at iteration %d",
                    task.task_id, i + 1,
                )
                return fix_result

            reason = review_result or "review returned empty"
            log.info(
                "FeedbackLoop %s: iteration %d FAILED: %s",
                task.task_id, i + 1, reason[:100],
            )

        log.warning("FeedbackLoop %s: max iterations exceeded", task.task_id)
        raise MaxIterationsExceeded(
            f"{task.task_id}: exhausted {task.max_iterations} iterations — {reason[:200]}"
        )


def _is_pass(text: str) -> bool:
    """判斷 review 結果是否為通過。"""
    upper = text.upper()
    return any(kw in upper for kw in ["PASS", "通過", "[DONE]", "✅", "LGTM"])
