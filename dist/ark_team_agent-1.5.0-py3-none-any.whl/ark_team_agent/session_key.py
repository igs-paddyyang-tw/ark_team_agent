"""多使用者衍生 session 的識別碼。

`multi_user` instance 會針對每個使用者衍生獨立的 kiro-cli session，
其 instance 名為 `base~user_id`（例：`admin-agent~937896656`）。

## 為什麼要有這個模組（而不是直接拼字串）

原本識別碼靠 `f"{name}#{user_id}"` 生成、靠 `"#" in n` 判斷，散落在
daemon 與 telegram 各處。實測 28 處列舉 `config.instances` 的地方只有 2 處
記得過濾 —— 這與 1.2.16 的 `IDLE` 事故同型（當時用 enum grep 盤點，
漏掉 4 處字串字面值比對，導致 `/api/health` 的 alive 算錯）。

**分隔符只在本模組出現一次。** 外部一律用類別方法，不要自己拼字串或用 `in` 判斷 ——
`tests/test_session_key.py` 有掃描測試會擋下那種寫法。

## 為什麼分隔符是 `~`

原本用 `#`，但它是 URL fragment 分隔符。而 `api.py` 有兩個端點以路徑參數
接收 instance 名（`/api/output/{name}`、`/api/instances/{name}/restart`），
未編碼呼叫時 `user_id` 整段丟失且**不會報錯** —— 操作靜默打到 base instance。

`~` 屬 RFC 3986 unreserved（`ALPHA / DIGIT / - . _ ~`），
在 URL 任何位置免編碼，同時是 POSIX 與 Windows 都合法的檔名字元。
`#` 在 Windows 檔名合法但 URL 危險、`:` 恰好相反 —— 只有 unreserved 三邊都過。
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import ClassVar


@dataclass(frozen=True, slots=True)
class SessionKey:
    """衍生 session 的識別碼（`base~user_id`）。

    刻意**不繼承 `str`**：繼承後任何字串操作都不會報錯，等於保留了
    本模組要消除的誤用空間。呼叫端必須 `str(key)` 才能當 instance 名，
    這個摩擦讓「這裡在處理 session key」在程式碼上看得見。
    """

    base: str
    user_id: int

    #: 分隔符。改這一行就等於改了全部行為 —— 這正是本模組存在的目的。
    SEP: ClassVar[str] = "~"

    def __str__(self) -> str:
        return f"{self.base}{self.SEP}{self.user_id}"

    @classmethod
    def parse(cls, name: str) -> SessionKey | None:
        """解析 instance 名；不是 session 就回 `None`（**不拋例外**）。

        用 `rpartition` 取**最後一個**分隔符，且 user_id 必須是純數字 ——
        base 本身含分隔符時才不會誤判。

        不拋例外是刻意的：列舉點會對每個名字呼叫這個方法，
        畸形名字讓整個列舉崩掉是不能接受的。
        """
        if not name:
            return None
        base, sep, uid = name.rpartition(cls.SEP)
        if not sep or not base or not uid.isdigit():
            return None
        return cls(base, int(uid))

    @classmethod
    def is_session(cls, name: str) -> bool:
        """這個 instance 名是衍生 session 嗎。"""
        return cls.parse(name) is not None

    @classmethod
    def base_of(cls, name: str) -> str:
        """取本體 instance 名；不是 session 時**原樣回傳**。

        原樣回傳讓呼叫端不必先判斷 —— `base_of(n) == base_name` 對
        本體與 session 都成立，比較邏輯只要寫一次。
        """
        key = cls.parse(name)
        return key.base if key else name
